---
component: <skills/... | CLAUDE.md §... | general>
type: pain | deviation | proposal
severity: blocker | major | minor
date: YYYY-MM-DD
core_version: <hash из .claude/toolkit-manifest.md; опционально>
platform: <агентская платформа записи, напр. claude-code | codex-cli-0.143.0; опционально>
---

**Что произошло:** <в момент трения: что делал, где ядро подвело / почему отступил / что улучшить>

**Почему это про тулкит, а не про проект:** <признак обобщаемости за пределы этой инсталляции>

**Предложение:** <как могло бы быть в ядре; или «—»>
