# Ворктри-на-задачу: схема per-task meta-каталога

Изоляция параллельных задач: **ворктри = задача** (не сессия). Каждая единица работы
(тикет, TODO-NNN, ad-hoc; проектная или агент-инфра) живёт в своём git-worktree —
задачи не мешают друг другу по состоянию репо, длинная задача (несколько сессий)
не теряет незакоммиченное.

## Модель

- Каталог: `~/worktrees/{{PROJECT}}/<task>`, ветка `wt/<task>`, форк от **агентской** ветки.
- Окружение (venv/node_modules/...) — симлинк на общее окружение главного репо
  (ось адаптера «тестовый стек»; в референсе one-web: `ln -s <main>/venv <worktree>/venv`).
- WIP коммитим свободно (чекпоинты сессий); конец сессии → агент обновляет PROGRESS.
- Сведение+доставка — `/worktree-land` (squash WIP → rebase на базу → `merge --ff-only`
  → MR из диапазона ровно этой задачи). Skill только сводит и доставляет; ворктри не создаёт.

## Meta-каталог `.tasks/worktree-<task>/`

Засевается при создании ворктри (bootstrap-скрипт — волна 2; в референсе one-web — Warp
tab-config). Gitignored (`.tasks/worktree-*/`), в git/retro не уходит. Это **per-task-состояние,
не skill-scratch** — при чистках `.tasks/_scratch/` не сметать.

| Файл | Содержимое | Кто читает |
|---|---|---|
| `base` | Одна строка — имя базовой агентской ветки, от которой форкнут ворктри | `/worktree-land` (куда сводить); резолв стенда/окружения задачи (ворктри-safe, в отличие от резолва по текущей ветке) |
| `PROGRESS.md` | Handoff между сессиями по `PROGRESS-template.md` | агент при возврате к задаче (`PROGRESS + git log wt/<task>` восстанавливают контекст) |

## Последовательность создания (референс)

```bash
mkdir -p ~/worktrees/{{PROJECT}}
git worktree add -b wt/<task> ~/worktrees/{{PROJECT}}/<task> <base>
ln -s <main-repo>/venv ~/worktrees/{{PROJECT}}/<task>/venv          # адаптер стека
mkdir -p ~/worktrees/{{PROJECT}}/<task>/.tasks/worktree-<task>
printf '%s\n' '<base>' > .../worktree-<task>/base
cp <PROGRESS-template> .../worktree-<task>/PROGRESS.md
```

Создание — только для **новой** задачи (повтор упадёт `branch already exists` — полезный
предохранитель). Возврат к задаче — обычный `cd` в каталог (переживает сессии).

## Точки входа (терминал / IDE)

Модель не привязана к конкретному терминалу: создание — `worktree_bootstrap.sh
<task> [<base>]` из любого шелла, возврат — открыть каталог ворктри любым способом.

- **Любой терминал**: `cd ~/worktrees/{{PROJECT}}/<task>` → агент CLI. Референс one-web:
  Warp tab-config («+ → Worktree», параметры task/base) — удобство, не требование.
- **VS Code**: каталог ворктри = отдельное окно (`code ~/worktrees/{{PROJECT}}/<task>`);
  расширение Claude Code работает от корня открытой папки; создание — скриптом
  во встроенном терминале.
- **PyCharm** (и прочие JetBrains): File → Open → каталог ворктри как отдельный
  проект; git-интеграция понимает worktree; интерпретатор — общее окружение
  главного репо через симлинк (Existing environment → `<ворктри>/venv/bin/python`).

Инвариант для всех точек входа: агент запускается с **cwd = корень ворктри** —
от cwd резолвятся ветка `wt/<task>`, meta-каталог и окружение.

## Гигиена

- Сироты (ветка `wt/<task>` без живого каталога, либо `prunable` в `git worktree list`) —
  находка `/retro`: `git branch -d` если заленджено (`merge-base --is-ancestor` в агентскую
  ветку), иначе `-D` = потеря WIP (только по аппруву).
- Статус задачи беклога `in-progress` выводится из живого ворктри `wt/TODO-NNN`
  (`backlog_dashboard.py`), перекрывая файловый `open` — на land/retire возвращается сам.
