#!/usr/bin/env python3
"""codex_project — проекция живого CC-слоя в Codex-слой (тулкит 061 §3.2, Режим 1 dual).

Codex-слой = ДЕРИВАТ живого CC-слоя, не вторая сопровождаемая копия. Снимает рекуррентную
ручную реконверсию, похоронившую дуальный слой one-web: каждый /toolkit-update синкает
`.claude/`, затем ЭТОТ скрипт механически перепроецирует Codex-слой через codexify. Дрейфовать
нечему — слой = codexify(живой CC). Байт-стабильность иррелевантна (оптовая перезапись).

Проецирует (перезаписывает производные файлы):
  .claude/skills/<name>/  → .agents/skills/<name>/            (.md через codexify, прочее — копия)
  .claude/rules/*.md      → .agents/rules/*.md                 (codexify)
  .claude/agents/*.md     → .codex/agents-instructions/*.md    (codexify) + TOML-стаб если нет
  .claude/evals/**        → .codex/evals/**                    (codexify .md)     [если есть]
  CLAUDE.md               → AGENTS.md   (codexify тела + секция «Память» из .codex/memory.md)

НЕ трогает (deploy-once, человеческое суждение — рецепт reference-codex): .codex/hooks.json,
.codex/config.toml, .codex/rules/ (per-проектные sandbox/сеть/allowlist); TOML-стаб с ручными
полями (sandbox_mode/mcp_servers) — создаётся лишь если отсутствует. Общий ресурс dual —
.claude/scripts, .claude/hooks, .tasks/, каталог памяти — не копируется. Чужие (не из CC)
скиллы в .agents/skills/ (напр. upstream `playwright`) сохраняются — перепроецируются только
подкаталоги, соответствующие скиллам CC.

Инвариант неприкосновенности CC (§4, на критическом пути — CC-слой one-web живой):
  1. ПОЗИТИВНЫЙ пре-запись-ассерт: каждая цель — внутри корня репо И под .agents/.codex/
     либо == AGENTS.md (realpath+normcase: ловит path-escape `../`, симлинки, macOS-регистр).
     Мистранслейт падает, а не корраптит CC.
  2. FOOTPRINT CONFINED: дельта `git status --porcelain` вокруг проекции не вносит НИ ОДНОЙ
     записи вне Codex-путей. При политике «коммитим слой» строгий after==before неверен —
     правка CC легитимно меняет закоммиченный слой (.agents/... становится ' M'); проверяем,
     что след не выходит за .agents/.codex/AGENTS.md. Плоский `git diff --exit-code` отвергнут:
     пропускает создание untracked-файла, ложно падает на штатной грязи (design 061 §4).

Свежесть (MF4, несущая при политике «коммитим слой»): маркер .codex/.projected-from хранит
core-hash, из которого собран слой. `--check` сверяет с манифестом — расхождение = громкая
ошибка (устаревшая закоммиченная проекция иначе необнаружима; невидимое отставание хуже
мёртвого снимка). SessionStart-хук на mtime отвергнут (mtime сбрасываются при checkout).

Кто зовёт: /toolkit-update финальным шагом на dual-развёртке (MF1 — исполнение, не
напоминание: печатные чекпоинты Codex имеют доказанную нулевую дисциплину). Чистый stdlib
≥3.13, ядро; ложится к потребителю как есть.
"""
import argparse
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import codexify  # noqa: E402  (сосед по .claude/scripts / .codex/scripts)
import manifest_contract  # noqa: E402

CODEX_ROOTS = (".agents", ".codex")
AGENTS_MD = "AGENTS.md"
MARKER = Path(".codex/.projected-from")
MEMORY_FILE = Path(".codex/memory.md")

# Секция «Память» AGENTS.md — эмуляция файловой памяти (у Codex нет нативной осознанной записи).
# Deploy-once .codex/memory.md; путь каталога заполняется при развёртке (для dual — общий CC-каталог).
MEMORY_TEMPLATE = """## Память
Персистентная память — файлы в <КАТАЛОГ ПАМЯТИ — заполнить при развёртке; для dual это общий
CC-каталог памяти проекта> (формат — memory-format.md). На старте сессии прочитай MEMORY.md
(индекс); релевантные памяти открой файлами. Новое устойчивое знание — запиши файлом по
формату + строка в MEMORY.md.
"""


class ProjectionError(Exception):
    """Нарушение инварианта неприкосновенности CC или отсутствие развёрнутого слоя."""


# --- git ---

def git(args, cwd, check=True):
    return subprocess.run(["git", *args], cwd=cwd, check=check,
                          capture_output=True, text=True)


def git_status(root: Path):
    """Множество непустых строк `git status --porcelain` (снимок состояния дерева)."""
    r = git(["status", "--porcelain"], cwd=root, check=False)
    if r.returncode != 0:
        raise ProjectionError(f"git status не удался в {root}: {r.stderr.strip()}")
    return {ln for ln in r.stdout.splitlines() if ln.strip()}


def _porcelain_path(line: str):
    """Путь из строки porcelain `XY path` / `XY orig -> path` (rename → новый путь)."""
    body = line[3:] if len(line) > 3 else line
    if " -> " in body:
        body = body.split(" -> ", 1)[1]
    return body.strip().strip('"')


def _is_codex_path(path: str):
    first = path.replace("\\", "/").split("/", 1)[0]
    return first in CODEX_ROOTS or path == AGENTS_MD


# --- пре-запись-ассерт (позитивный): цель обязана быть в Codex-слое ---

def assert_codex_target(target: Path, root: Path):
    real = os.path.normcase(os.path.realpath(target))
    root_real = os.path.normcase(os.path.realpath(root))
    try:
        common = os.path.commonpath([real, root_real])
    except ValueError:
        raise ProjectionError(f"цель на другом томе, вне репо: {target}")
    if common != root_real:
        raise ProjectionError(f"цель вне корня репо (path-escape?): {target}")
    rel = os.path.relpath(real, root_real)
    first = rel.split(os.sep, 1)[0]
    is_agents_md = os.path.normcase(rel) == os.path.normcase(AGENTS_MD)
    if not (first in CODEX_ROOTS or is_agents_md):
        raise ProjectionError(
            f"цель НЕ в Codex-слое (.agents/.codex/AGENTS.md) — отказ писать в CC/общий ресурс: {target}")


# --- манифест / маркер свежести ---

def manifest_core_hash(root: Path):
    m = root / ".claude" / "toolkit-manifest.md"
    if not m.is_file():
        return None
    return manifest_contract.core_hash(m.read_text(encoding="utf-8"))


def write_marker(root: Path):
    marker = root / MARKER
    assert_codex_target(marker, root)
    marker.parent.mkdir(parents=True, exist_ok=True)
    marker.write_text((manifest_core_hash(root) or "unknown") + "\n", encoding="utf-8")


# --- проекция ---

def _write_target(target: Path, root: Path, content: str):
    assert_codex_target(target, root)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding="utf-8")


def _copy_target(src: Path, target: Path, root: Path):
    assert_codex_target(target, root)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, target)


def _project_file(src: Path, target: Path, root: Path, names):
    if src.suffix == ".md":
        _write_target(target, root, codexify.codexify(src.read_text(encoding="utf-8"), names, "dual"))
    else:
        _copy_target(src, target, root)  # scripts/assets — не CC-проза, копия как есть


def project_skills(claude: Path, root: Path, names):
    """Перепроецирование ПОДКАТАЛОГОВ, соответствующих скиллам CC (чужие в .agents/skills сохранены)."""
    src_root = claude / "skills"
    if not src_root.is_dir():
        return
    dst_root = root / ".agents" / "skills"
    for sub in sorted(p for p in src_root.iterdir() if p.is_dir()):
        dst_sub = dst_root / sub.name
        assert_codex_target(dst_sub, root)
        if dst_sub.exists():
            shutil.rmtree(dst_sub)  # чистим лишь производный подкаталог (внутрискилловые удаления)
        for f in sorted(sub.rglob("*")):
            if f.is_file():
                _project_file(f, dst_sub / f.relative_to(sub), root, names)


def project_flat(src_dir: Path, dst_dir: Path, root: Path, names):
    """Плоское дерево (.md через codexify, прочее — копия); перезапись по файлам."""
    if not src_dir.is_dir():
        return
    for f in sorted(src_dir.rglob("*")):
        if f.is_file():
            _project_file(f, dst_dir / f.relative_to(src_dir), root, names)


def _agent_meta(md: Path):
    """(name, description) из frontmatter агент-файла для TOML-стаба."""
    fm = codexify.split_frontmatter(md.read_text(encoding="utf-8"))[0]
    name = re.search(r"^name:\s*(.+)$", fm, re.MULTILINE)
    desc = re.search(r"^description:\s*(.+)$", fm, re.MULTILINE)
    return (name.group(1).strip() if name else md.stem,
            desc.group(1).strip() if desc else "")


def _toml_stub(name: str, desc: str):
    esc = desc.replace("\\", "\\\\").replace('"', '\\"')
    return (f'name = "{name}"\n'
            f'description = "{esc}"\n'
            'developer_instructions = """\n'
            f'Твоя роль определена в .codex/agents-instructions/{name}.md —\n'
            'прочитай его целиком ПЕРВЫМ действием и строго следуй ему.\n'
            '"""\n'
            '# опционально: model / model_reasoning_effort / sandbox_mode / mcp_servers\n')


def project_agents(claude: Path, root: Path, names):
    src_dir = claude / "agents"
    if not src_dir.is_dir():
        return
    for md in sorted(src_dir.glob("*.md")):
        _project_file(md, root / ".codex" / "agents-instructions" / md.name, root, names)
        name, desc = _agent_meta(md)
        stub = root / ".codex" / "agents" / f"{name}.toml"
        if not stub.exists():  # deploy-once: ручные поля (sandbox_mode/mcp_servers) не затираем
            _write_target(stub, root, _toml_stub(name, desc))


def ensure_memory_block(root: Path):
    mem = root / MEMORY_FILE
    if not mem.exists():
        _write_target(mem, root, MEMORY_TEMPLATE)
    return mem.read_text(encoding="utf-8")


def project_agents_md(claude_md: Path, root: Path, names):
    body = codexify.codexify_root_document(
        claude_md.read_text(encoding="utf-8"), names, "dual"
    )
    memory = ensure_memory_block(root)
    _write_target(root / AGENTS_MD, root, body.rstrip("\n") + "\n\n" + memory.strip("\n") + "\n")


def verify_footprint(before: set, after: set, root: Path):
    """След проекции обязан лежать в .agents/.codex/AGENTS.md — иначе протечка в CC (§4)."""
    leaks = sorted(ln for ln in (after ^ before) if not _is_codex_path(_porcelain_path(ln)))
    if leaks:
        print("✗ ИНВАРИАНТ НАРУШЕН: проекция затронула не-Codex пути (протечка в CC-слой):",
              file=sys.stderr)
        for ln in leaks:
            print(f"    {ln}", file=sys.stderr)
        raise ProjectionError("footprint проекции вышел за .agents/.codex/AGENTS.md")


def project(root: Path, quiet=False):
    claude = root / ".claude"
    claude_md = root / "CLAUDE.md"
    if not claude.is_dir() or not claude_md.is_file():
        raise ProjectionError(
            "нет развёрнутого CC-слоя (.claude/ + CLAUDE.md) — codex_project проецирует dual-развёртку, "
            "не dev-репо тулкита")
    names = codexify.skill_names_in(claude / "skills")
    before = git_status(root)
    project_skills(claude, root, names)
    project_flat(claude / "rules", root / ".agents" / "rules", root, names)
    project_agents(claude, root, names)
    if (claude / "evals").is_dir():
        project_flat(claude / "evals", root / ".codex" / "evals", root, names)
    project_agents_md(claude_md, root, names)
    write_marker(root)
    after = git_status(root)
    verify_footprint(before, after, root)
    if not quiet:
        h = manifest_core_hash(root) or "unknown"
        print(f"✓ Codex-слой спроецирован из живого CC (core-hash {h}); "
              f"allowlist {len(names)} скиллов; footprint в .agents/.codex/AGENTS.md.")
    return 0


def check_freshness(root: Path):
    marker = root / MARKER
    manifest_hash = manifest_core_hash(root)
    if not marker.exists():
        print("✗ Codex-слой не проецировался (нет .codex/.projected-from) — "
              "прогнать: python3 .claude/scripts/codex_project.py", file=sys.stderr)
        return 1
    built = marker.read_text(encoding="utf-8").strip()
    if manifest_hash and built != manifest_hash:
        print(f"✗ Codex-слой ОТСТАЛ: собран из {built}, ядро манифеста {manifest_hash}. "
              f"Перепроецировать: python3 .claude/scripts/codex_project.py", file=sys.stderr)
        return 1
    print(f"✓ Codex-слой свеж (собран из core-hash {built}).")
    return 0


# --- self-check: синтетическая dual-развёртка в temp git-репо (валидация на чистом core) ---

def self_check(toolkit_root: Path):
    import tempfile
    names_ok = codexify.skill_names_in(toolkit_root / "core" / "claude" / "skills")
    print(f"codex_project --self-check: синтетическая dual-развёртка, {len(names_ok)} скиллов ядра")

    # 1. позитивный пре-запись-ассерт отвергает не-Codex цели
    with tempfile.TemporaryDirectory() as td:
        r = Path(td)
        for bad in (r / ".claude" / "skills" / "x.md", r / "CLAUDE.md",
                    r / ".tasks" / "y.md", r / ".." / "escape.md"):
            try:
                assert_codex_target(bad, r)
                print(f"  ✗ пре-запись-ассерт НЕ отверг не-Codex цель: {bad}")
                return 1
            except ProjectionError:
                pass
        for good in (r / ".agents" / "skills" / "s" / "SKILL.md", r / ".codex" / "x.toml",
                     r / "AGENTS.md"):
            assert_codex_target(good, r)  # не должно бросать
    print("  ✓ пре-запись-ассерт: не-Codex цели отвергнуты, Codex-цели пропущены")

    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        # синтетическая CC-развёртка из core (плейсхолдеры для теста проекции безразличны)
        for sub in ("skills", "rules", "agents"):
            s = toolkit_root / "core" / "claude" / sub
            if s.is_dir():
                shutil.copytree(s, root / ".claude" / sub)
        shutil.copy2(toolkit_root / "core" / "CLAUDE.template.md", root / "CLAUDE.md")
        (root / ".claude").mkdir(exist_ok=True)
        # Исторический формат без backticks обязан давать тот же marker, что канонический.
        (root / ".claude" / "toolkit-manifest.md").write_text(
            "## Манифест\nЯдро: deadbeef1234\n", encoding="utf-8")
        gc = ["-c", "user.email=t@t", "-c", "user.name=t"]
        git(["init", "-q"], cwd=root)
        git(["add", "-A"], cwd=root)
        git([*gc, "commit", "-q", "-m", "CC-слой"], cwd=root)

        # первая проекция — untracked Codex-слой, footprint только .agents/.codex/AGENTS.md
        project(root, quiet=True)
        after = git_status(root)
        non_codex = [ln for ln in after if not _is_codex_path(_porcelain_path(ln))]
        if non_codex:
            print(f"  ✗ первая проекция затронула не-Codex пути: {non_codex[:5]}")
            return 1
        if not (root / "AGENTS.md").is_file() or not (root / ".agents" / "skills").is_dir():
            print("  ✗ проекция не создала AGENTS.md / .agents/skills")
            return 1
        agents_md = (root / "AGENTS.md").read_text(encoding="utf-8")
        root_leaks = codexify.root_document_leaks(agents_md)
        if root_leaks:
            print(f"  ✗ AGENTS.md представляется инструкцией Claude: {root_leaks}")
            return 1
        if "`CLAUDE.md` + `.claude/`" not in agents_md:
            print("  ✗ root-transform потерял указатель на живой CC-слой")
            return 1
        print("  ✓ root-transform: AGENTS.md в терминах Codex, ссылка на живой CC-слой сохранена")
        print(f"  ✓ первая проекция: footprint в Codex-слое, {len(after)} новых путей")

        # leak-lint по спроецированным SKILL.md — остаточных CC-токенов быть не должно
        proj_names = codexify.skill_names_in(root / ".claude" / "skills")
        leaks_total = 0
        for f in (root / ".agents" / "skills").rglob("*.md"):
            leaks_total += len(codexify.leak_lint(f.read_text(encoding="utf-8"), proj_names, "dual"))
        for f in (root / ".codex" / "agents-instructions").glob("*.md"):
            leaks_total += len(codexify.leak_lint(f.read_text(encoding="utf-8"), proj_names, "dual"))
        if leaks_total:
            print(f"  ✗ leak-lint нашёл {leaks_total} остаточных CC-токенов в Codex-слое")
            return 1
        print("  ✓ leak-lint по спроецированному слою пуст")

        # чужой (не из CC) скилл в .agents/skills — напр. upstream playwright — должен пережить проекцию
        foreign = root / ".agents" / "skills" / "playwright" / "SKILL.md"
        foreign.parent.mkdir(parents=True, exist_ok=True)
        foreign.write_text("---\nname: playwright\n---\nUpstream skill.\n", encoding="utf-8")

        # коммитим слой (политика «коммитим слой») → идемпотентность: повтор без изменений
        git(["add", "-A"], cwd=root)
        git([*gc, "commit", "-q", "-m", "Codex-слой"], cwd=root)
        project(root, quiet=True)
        if git_status(root):
            print(f"  ✗ повторная проекция не идемпотентна: {sorted(git_status(root))[:5]}")
            return 1
        if not foreign.is_file():
            print("  ✗ проекция снесла чужой (не из CC) скилл playwright в .agents/skills")
            return 1
        print("  ✓ идемпотентность: повтор — чистый git status; чужой скилл playwright сохранён")

        # правка CC → проекция легитимно меняет закоммиченный слой, но лишь в .agents/
        skill_md = next((root / ".claude" / "skills").rglob("SKILL.md"))
        skill_md.write_text(skill_md.read_text(encoding="utf-8") + "\nПравка CC: см. /run-tests.\n",
                            encoding="utf-8")
        git(["add", "-A"], cwd=root)
        git([*gc, "commit", "-q", "-m", "правка CC"], cwd=root)
        project(root, quiet=True)  # не должно бросить (footprint confined), хотя слой меняется
        changed = git_status(root)
        if any(not _is_codex_path(_porcelain_path(ln)) for ln in changed):
            print(f"  ✗ проекция после правки CC вышла за Codex-слой: {sorted(changed)[:5]}")
            return 1
        print("  ✓ правка CC: проекция обновила слой, footprint остался в Codex-путях")

        # свежесть: маркер сверяется с манифестом; порча маркера ловится --check
        if check_freshness(root) != 0:
            print("  ✗ --check свежести провалился на свежем слое")
            return 1
        (root / MARKER).write_text("stale00\n", encoding="utf-8")
        if check_freshness(root) == 0:
            print("  ✗ --check свежести НЕ поймал устаревший маркер")
            return 1
        print("  ✓ --check свежести: свежий слой ок, устаревший маркер пойман")

    print("\n✓ codex_project: пре-запись-ассерт, footprint-инвариант, leak-lint, идемпотентность, "
          "свежесть — все зелёные.")
    return 0


def main():
    ap = argparse.ArgumentParser(
        description="Проекция живого CC-слоя в Codex-слой (тулкит 061, Режим 1 dual).")
    ap.add_argument("--root", type=Path, default=Path("."),
                    help="Корень dual-развёртки (.claude/ + CLAUDE.md). Умолч. — текущий каталог.")
    ap.add_argument("--check", action="store_true",
                    help="Только сверить свежесть маркера с манифестом (не проецировать).")
    ap.add_argument("--self-check", type=Path, metavar="TOOLKIT_ROOT",
                    help="Валидация механизма на синтетической развёртке из core в TOOLKIT_ROOT.")
    args = ap.parse_args()

    if args.self_check:
        return self_check(args.self_check)
    if args.check:
        return check_freshness(args.root)
    try:
        return project(args.root)
    except ProjectionError as e:
        print(f"✗ {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
