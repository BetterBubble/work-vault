#!/usr/bin/env python3
"""Транспорт потребитель → inbox репозитория тулкита (доставка фидбэка + регистрация).

Транспорт A (см. схему `.tasks/toolkit-feedback/README.md`): агент потребителя пушит файлы
в orphan-ветку `inbox` репо тулкита, под своим неймспейсом `<consumer>/`. Разработчик тулкита
собирает их одной процедурой (`/feedback-collect` в remote-режиме).

Два режима:
  • **Доставка** (по умолчанию) — накопленные записи `.tasks/toolkit-feedback/*.md` уезжают
    в `inbox/<consumer>/YYYY-MM-DD-slug.md`. Идемпотентно: отправляются только записи из
    **корня** outbox (кроме `README.md`/`_TEMPLATE.md`); после успешного push они переезжают
    в `.tasks/toolkit-feedback/_sent/` — «отправлено», не «сброшено» (файл жив до сбора
    агрегатором, но повторная доставка его не дублирует). Сброс из `inbox` делает разработчик.
  • **Регистрация** (`--register`) — разовый шаг при развёртке: кладёт маркер
    `inbox/<consumer>/.registered` (дата, hash ядра, контакт). Делает развёртку видимой
    разработчику тулкита ещё до первого фидбэка (иначе «молчащая» установка неизвестна).

Изоляция: всё идёт через **эфемерный shallow-клон** ветки `inbox` во временный каталог —
продуктовый репозиторий потребителя (его origin, ветки) не трогается вовсе.

python ≥3.13, чистый stdlib.
"""
import argparse
import datetime
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

# Репозиторий тулкита — один для всех потребителей (не плейсхолдер, фиксирован).
INBOX_URL = "https://git.hi-tech.org/ivaqa/aqa-agent-toolkit.git"
INBOX_BRANCH = "inbox"
# Неймспейс потребителя в inbox = его slug (совпадает с {{PROJECT}} и label в реестре dev).
CONSUMER = "{{PROJECT}}"

FEEDBACK_DIR = Path(".tasks/toolkit-feedback")
MANIFESTS = (Path(".claude/toolkit-manifest.md"), Path(".codex/toolkit-manifest.md"))
SKIP = {"README.md", "_TEMPLATE.md"}


def git(*args, cwd=None, check=True):
    return subprocess.run(["git", *args], cwd=cwd, check=check,
                          capture_output=True, text=True)


def push_to_inbox(url: str, consumer: str, files: dict, commit_msg: str):
    """Клон `inbox` → запись `files` ({имя: содержимое}) в `<consumer>/` → commit → push.

    Возврат: 'pushed' | 'nochange' (файлы уже там) | 'error: <причина>'.
    """
    tmp = Path(tempfile.mkdtemp(prefix="toolkit-inbox-"))
    try:
        clone = git("clone", "--branch", INBOX_BRANCH, "--single-branch", "--depth", "1",
                    url, str(tmp), check=False)
        if clone.returncode != 0:
            return f"error: клон {INBOX_BRANCH} не удался: {clone.stderr.strip()}"

        ns = tmp / consumer
        ns.mkdir(exist_ok=True)
        for name, content in files.items():
            (ns / name).write_text(content, encoding="utf-8")

        git("add", consumer, cwd=str(tmp))
        if not git("status", "--porcelain", cwd=str(tmp)).stdout.strip():
            return "nochange"
        git("commit", "-m", commit_msg, cwd=str(tmp))
        push = git("push", "origin", INBOX_BRANCH, cwd=str(tmp), check=False)
        if push.returncode != 0:
            return f"error: push не удался: {push.stderr.strip()}"
        return "pushed"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def pending_records(feedback_dir: Path):
    """Записи к отправке: *.md в корне outbox, кроме README/_TEMPLATE (не рекурсивно)."""
    if not feedback_dir.is_dir():
        return []
    return sorted(f for f in feedback_dir.glob("*.md") if f.name not in SKIP)


def read_core_version(manifest: Path):
    """Hash ядра из шапки манифеста (`Ядро: `hash``); пусто, если манифеста/строки нет."""
    if not manifest.exists():
        return ""
    m = re.search(r"Ядро:\s*`([0-9a-f]+)`", manifest.read_text(encoding="utf-8"))
    return m.group(1) if m else ""


def deliver(feedback_dir: Path, consumer: str, url: str, dry_run: bool):
    records = pending_records(feedback_dir)
    if not records:
        print("Нет непосланных записей toolkit-feedback — доставлять нечего.")
        return 0

    print(f"Потребитель: {consumer}")
    print(f"К отправке в {url} (ветка {INBOX_BRANCH}) — {len(records)} записей:")
    for r in records:
        print(f"  • {r.name}")
    if dry_run:
        print("\n[dry-run] клон/копирование/push не выполнялись.")
        return 0

    today = datetime.date.today().isoformat()
    files = {r.name: r.read_text(encoding="utf-8") for r in records}
    result = push_to_inbox(url, consumer, files, f"feedback: {consumer} — {len(records)} записей ({today})")
    if result.startswith("error:"):
        print(f"Доставка не удалась (записи оставлены на месте):\n{result[7:].strip()}", file=sys.stderr)
        return 1
    print("Все записи уже есть в inbox — помечаю отправленными."
          if result == "nochange" else f"Запушено в {INBOX_BRANCH}.")

    # Успех — помечаем локальные записи отправленными (в _sent/).
    sent_dir = feedback_dir / "_sent"
    sent_dir.mkdir(exist_ok=True)
    for r in records:
        shutil.move(str(r), str(sent_dir / r.name))
    print(f"Перемещено в {sent_dir}/ (отправлено): {len(records)} записей.")
    return 0


def register(consumer: str, url: str, contact: str, manifest: Path, dry_run: bool):
    today = datetime.date.today().isoformat()
    marker = (f"consumer: {consumer}\n"
              f"registered: {today}\n"
              f"core_version: {read_core_version(manifest)}\n"
              f"contact: {contact or '—'}\n")
    print(f"Регистрация потребителя '{consumer}' в {url} (ветка {INBOX_BRANCH}).")
    print("Маркер .registered:")
    for line in marker.splitlines():
        print(f"  {line}")
    if dry_run:
        print("\n[dry-run] клон/push не выполнялись.")
        return 0

    result = push_to_inbox(url, consumer, {".registered": marker}, f"register: {consumer} ({today})")
    if result.startswith("error:"):
        print(f"Регистрация не удалась:\n{result[7:].strip()}", file=sys.stderr)
        return 1
    print("Регистрация уже актуальна (маркер не изменился)."
          if result == "nochange" else f"Зарегистрирован в {INBOX_BRANCH}.")
    return 0


def main():
    ap = argparse.ArgumentParser(description="Транспорт потребитель → inbox тулкита (доставка/регистрация).")
    ap.add_argument("--register", action="store_true",
                    help="Режим регистрации развёртки (маркер .registered) вместо доставки записей.")
    ap.add_argument("--contact", default="", help="Контакт для маркера регистрации (кто/как связаться).")
    ap.add_argument("--dry-run", action="store_true", help="Показать действие без клона/push.")
    ap.add_argument("--consumer", default=CONSUMER, help="Неймспейс потребителя в inbox.")
    ap.add_argument("--url", default=INBOX_URL, help="URL репозитория тулкита.")
    ap.add_argument("--feedback-dir", type=Path, default=FEEDBACK_DIR,
                    help="Каталог outbox (по умолчанию .tasks/toolkit-feedback).")
    ap.add_argument("--manifest", type=Path,
                    default=next((m for m in MANIFESTS if m.exists()), MANIFESTS[0]),
                    help="Манифест развёртки (для core_version при регистрации; "
                         "по умолчанию .claude/, нет — .codex/toolkit-manifest.md).")
    args = ap.parse_args()

    if args.register:
        return register(args.consumer, args.url, args.contact, args.manifest, args.dry_run)
    return deliver(args.feedback_dir, args.consumer, args.url, args.dry_run)


if __name__ == "__main__":
    sys.exit(main())
