#!/usr/bin/env python3
"""Механика обновления ядра тулкита у потребителя — детерминированная часть /toolkit-update.

Механизация INSTALL §7 (семантика — диалоги, осевые блоки, шаблоны, миграции — в SKILL.md
скилла /toolkit-update; здесь только то, что делается без понимания текста):

  • --plan (дефолт, read-only): манифест (hash ядра, путь клона, анкета) → `git fetch
    origin main` в клоне → `git diff <hash>..origin/main --name-status -- core/ adapters/`
    → классификация по карте раскладки (правила = INSTALL §2/§5, менять парой) → план
    по классам + скан миграций §7.1 по hash-конвенции + сверка полноты раскладки:
    полный обход дерева `core/` — цели карты, отсутствующие в проекте при неизменном
    ядре («тихая» потеря, дифф её не видит), отдельным блоком; легитимные отсутствия
    отфильтрованы (файлы невыбранных осей; цели из «Отступлений» манифеста — как FYI).
    Плюс дрейф-детект: адаптер-шпаргалки, изменённые в диффе и упомянутые в «Отступлениях»
    манифеста по имени/стему, — блок «сверить локальную копию» (verify-prompt: агент по
    прозе отступления различает удерживаемую локальную копию от клон-ссылки).

  • --apply: пишет в проект ТОЛЬКО файлы «as-is без [ось]-блоков» и только при чистом
    3-way сравнении рендеров: deployed == старый рендер → замена на новый; deployed ==
    новый рендер → skip (уже обновлён — идемпотентность, безопасный повтор). Всё
    остальное — осевые файлы, конфликты, новые плейсхолдеры — материалами в staging
    `.tasks/_scratch/toolkit-update/` (old.render / new.render / core.diff), решает агент
    с пользователем. Шаблоны (*.template.*), адаптеры, миграции скрипт не трогает вовсе.

Рендер = подстановка анкеты манифеста ({{КЛЮЧ}} → значение; значение «—…» = оси нет,
не подставлять). Остаточные {{...}} после подстановки — «нужно значение» (новый
плейсхолдер ядра), файл не пишется, решает агент.

Git-дисциплина: клон тулкита может быть dev-репо разработчика — в клоне ТОЛЬКО `fetch`,
все чтения через `git show origin/main:<путь>`, рабочее дерево клона не трогается.
Push отсутствует; в проекте — только запись файлов рабочего дерева.

Раскладка целей: CC (`.claude/…`, референс) по умолчанию; манифест найден в `.codex/` ⇒
цели карты переводятся на Codex-раскладку (CODEX_TARGETS = таблице конверсии рецепта
reference-codex). Скрипт один для обеих платформ — развёрнутые копии не адаптируются.

python ≥3.13, чистый stdlib. Плейсхолдеров в этом файле нет — вся параметризация
читается из манифеста; файл ложится к потребителю как есть (как backlog_dashboard.py).
"""
import argparse
import re
import shutil
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import manifest_contract  # noqa: E402  (сосед по .claude/scripts / .codex/scripts)

TOOLKIT_URL = "https://git.hi-tech.org/ivaqa/aqa-agent-toolkit.git"
UPSTREAM = "origin/main"
MANIFESTS = (Path(".claude/toolkit-manifest.md"), Path(".codex/toolkit-manifest.md"))
STAGING = Path(".tasks/_scratch/toolkit-update")

AXES = ("dual-line", "vendored-dep", "test-stack", "product-api", "tms",
        "browser-driver", "living-aut-map")
AXIS_RE = re.compile(r"\[(%s)\]" % "|".join(AXES))
PH_RE = re.compile(r"\{\{[A-Z][A-Z_0-9]*\}\}")

# --- карта раскладки core→проект (= INSTALL §2/§5; расхождение = баг, менять парой) ---

EXACT = {
    "core/CLAUDE.template.md": ("template", "CLAUDE.md"),
    "core/gitignore.template": ("template", ".gitignore"),
    "core/claude/settings.template.json": ("template", ".claude/settings.json"),
    "core/claude/evals/EVALS.template.md": ("template", ".claude/evals/EVALS.md"),
    "core/tasks-schemas/TODO/INDEX.template.md": ("template", ".tasks/TODO/INDEX.md"),
    "core/tasks-schemas/TODO/_TEMPLATE.md": ("as-is", ".tasks/TODO/_TEMPLATE.md"),
    "core/tasks-schemas/tasks-README.md": ("as-is", ".tasks/README.md"),
    "core/tasks-schemas/metrics-README.md": ("as-is", ".tasks/metrics-README.md"),
    "core/tasks-schemas/PROGRESS-template.md":
        ("as-is", ".claude/skills/worktree-land/references/PROGRESS-template.md"),
    "core/tasks-schemas/worktree-meta.md": ("not-deployed", None),
    "core/memory-format.md": ("not-deployed", None),
}
PREFIX = [
    ("core/claude/skills/", ".claude/skills/"),
    ("core/claude/agents/", ".claude/agents/"),
    ("core/claude/rules/", ".claude/rules/"),
    ("core/claude/hooks/", ".claude/hooks/"),
    ("core/scripts/", ".claude/scripts/"),
    ("core/tasks-schemas/toolkit-feedback/", ".tasks/toolkit-feedback/"),
]
# Файлы, разворачиваемые только при включённой оси (пометки «только при [ось]» в §2):
# решение оси в манифесте «нет…» → отсутствие цели легитимно, сверка полноты молчит.
AXIS_ONLY = {
    "core/claude/hooks/detect-dep-commit.py": "vendored-dep",
    "core/claude/skills/launch-parse/SKILL.md": "tms",
    "core/claude/skills/aut-overview-bump-version/SKILL.md": "living-aut-map",
}

# Codex-раскладка: переводы CC-целей (= таблица конверсии
# adapters/agent-platform/reference-codex/README.md; расхождение = баг, менять парой).
# Ключи-каталоги (с хвостовым «/») переводятся префиксно, остальные — целиком.
CODEX_TARGETS = {
    "CLAUDE.md": "AGENTS.md",
    ".claude/settings.json": ".codex/hooks.json",
    ".claude/evals/": ".codex/evals/",
    ".claude/skills/": ".agents/skills/",
    ".claude/agents/": ".codex/agents-instructions/",
    ".claude/rules/": ".agents/rules/",
    ".claude/hooks/": ".codex/hooks/",
    ".claude/scripts/": ".codex/scripts/",
}


def translate_codex(target: str):
    if target in CODEX_TARGETS:
        return CODEX_TARGETS[target]
    for src, dst in CODEX_TARGETS.items():
        if src.endswith("/") and target.startswith(src):
            return dst + target[len(src):]
    return target


def apply_layout(manifest: Path):
    """Детект раскладки по месту манифеста: `.codex/` ⇒ цели карты — Codex-перевод."""
    global EXACT, PREFIX
    if ".codex" not in manifest.parts:
        return
    EXACT = {p: (k, translate_codex(t) if t else t) for p, (k, t) in EXACT.items()}
    PREFIX = [(src, translate_codex(dst)) for src, dst in PREFIX]


def classify(path: str):
    """Файл ядра → (класс, целевой путь в проекте | None)."""
    if path in EXACT:
        return EXACT[path]
    if path.startswith("adapters/"):
        # Рабочие копии у потребителя (INSTALL §5) vs шпаргалки (читаются из клона).
        if "/testops/" in path or path.endswith("research_user.py") \
                or path.endswith("secrets.yaml.example"):
            return "adapter", None
        return "adapter-doc", None
    for src, dst in PREFIX:
        if path.startswith(src):
            rel = path[len(src):]
            if ".template." in Path(path).name:
                return "template", dst + rel.replace(".template.", ".", 1)
            return "as-is", dst + rel
    return "new", None  # правила в карте нет — агент решает по свежему INSTALL §2


def git(args, cwd=None, check=True):
    return subprocess.run(["git", *args], cwd=cwd, check=check,
                          capture_output=True, text=True)


def show(clone: Path, ref: str, path: str):
    r = git(["show", f"{ref}:{path}"], cwd=clone, check=False)
    return r.stdout if r.returncode == 0 else None


def parse_manifest(path: Path):
    """Манифест → (hash ядра, путь клона, анкета {КЛЮЧ: значение}, полный текст)."""
    if not path.exists():
        sys.exit(f"Манифест {path} не найден — это не развёртка тулкита "
                 f"(bootstrap — по INSTALL.md).")
    text = path.read_text(encoding="utf-8")
    parsed_hash = manifest_contract.core_hash(text)
    if not parsed_hash:
        sys.exit("В манифесте не найден корректный hex-hash ядра "
                 "(каноническая строка: «Ядро: `<hash>`»).")
    c = re.search(r"Клон тулкита:\s*`?([^`\n]+?)`?\s*$", text, re.MULTILINE)
    if not c:
        sys.exit("В манифесте не найден путь клона (строка «Клон тулкита: ...»).")
    anketa, section = {}, ""
    for line in text.splitlines():
        if line.startswith("## "):
            section = line
            continue
        if section.startswith("## Анкета") and line.startswith("|"):
            cells = [x.strip().strip("`") for x in line.strip().strip("|").split("|")]
            if len(cells) < 2 or not cells[0] or cells[0] == "Плейсхолдер" \
                    or set(cells[0]) <= {"-", " ", ":"}:
                continue
            if cells[1] and not cells[1].startswith("—"):  # «—…» = оси нет
                anketa[cells[0]] = cells[1]
    try:
        manifest_contract.validate_branch_model(anketa, text)
    except manifest_contract.ManifestContractError as exc:
        sys.exit(f"Некорректная веточная модель манифеста: {exc}")
    return parsed_hash, Path(c.group(1).strip()).expanduser(), anketa, text


def parse_axes(text: str):
    """Таблица «## Оси» манифеста → {ось: решение}."""
    axes, section = {}, ""
    for line in text.splitlines():
        if line.startswith("## "):
            section = line
            continue
        if section.startswith("## Оси") and line.startswith("|"):
            cells = [x.strip().strip("`") for x in line.strip().strip("|").split("|")]
            if len(cells) < 2 or not cells[0] or cells[0] == "Ось" \
                    or set(cells[0]) <= {"-", " ", ":"}:
                continue
            axes[cells[0].strip("*")] = cells[1]
    return axes


def render(content: str, anketa: dict):
    """Подстановка анкеты; возврат (текст, [остаточные {{...}}])."""
    out = PH_RE.sub(lambda m: anketa.get(m.group(0)[2:-2], m.group(0)), content)
    return out, sorted(set(PH_RE.findall(out)))


def preflight(clone: Path, core_hash: str):
    """Fetch + санити; возврат — список предупреждений (фаталы выходят сразу)."""
    warns = []
    if not (clone / ".git").exists():
        sys.exit(f"Клон тулкита не найден: {clone}\n"
                 f"Свежий клон (полный, не shallow — нужна история до hash манифеста):\n"
                 f"  git clone --single-branch --branch main {TOOLKIT_URL} <путь>\n"
                 f"затем поправить «Клон тулкита:» в манифесте.")
    f = git(["fetch", "origin", "main"], cwd=clone, check=False)
    if f.returncode != 0:
        warns.append(f"fetch не удался ({f.stderr.strip()}) — работаю от локального "
                     f"{UPSTREAM}, он может отставать от GitLab.")
    if git(["rev-parse", "--verify", "-q", UPSTREAM], cwd=clone, check=False).returncode != 0:
        sys.exit(f"В клоне {clone} нет {UPSTREAM} — проверь remote (ожидается {TOOLKIT_URL}).")
    if git(["cat-file", "-e", core_hash + "^{commit}"], cwd=clone, check=False).returncode != 0:
        sys.exit(f"Hash манифеста {core_hash} не найден в клоне {clone} "
                 f"(shallow-клон? см. INSTALL §7).")
    if git(["merge-base", "--is-ancestor", core_hash, UPSTREAM],
           cwd=clone, check=False).returncode != 0:
        warns.append(f"{core_hash} не достижим с {UPSTREAM} — аномальный baseline; "
                     f"дифф валиден как сравнение снапшотов, но детекция миграций "
                     f"может ошибаться — сверить §7.1 вручную.")
    return warns


def changed_files(clone: Path, core_hash: str):
    """Дифф ядра+адаптеров → [(status, path, note)]; rename разложен в D+A."""
    r = git(["diff", f"{core_hash}..{UPSTREAM}", "--name-status", "--",
             "core/", "adapters/"], cwd=clone)
    items = []
    for line in r.stdout.splitlines():
        parts = line.split("\t")
        if parts[0].startswith("R") and len(parts) == 3:
            items.append(("D", parts[1], f"переименован → {parts[2]}"))
            items.append(("A", parts[2], f"переименован ← {parts[1]}"))
        else:
            items.append((parts[0], parts[1], ""))
    return items


def scan_completeness(clone: Path, diff_paths, axes: dict, manifest_text: str):
    """Цели карты, отсутствующие в проекте при неизменном ядре (дифф такое не видит).

    Возврат (missing, covered, unruled): missing — потеря либо незафиксированное
    отступление, решается диалогом; covered — цель упомянута в «Отступлениях» манифеста
    (матч по имени — эвристика, агент сверяет); unruled — файл ядра без правила карты
    (карта скрипта разошлась с INSTALL §2).
    """
    m = re.search(r"^## Отступления.*?(?=\n## |\Z)", manifest_text, re.MULTILINE | re.DOTALL)
    deviations = m.group(0) if m else ""
    missing, covered, unruled = [], [], []
    tree = git(["ls-tree", "-r", "--name-only", UPSTREAM, "--", "core/"], cwd=clone)
    for path in tree.stdout.splitlines():
        if path in diff_paths:
            continue  # уже в плане диффа; потерю изменённого файла ловит --apply
        klass, target = classify(path)
        if klass == "new":
            unruled.append(path)
        if target is None or Path(target).exists():
            continue
        axis = AXIS_ONLY.get(path)
        if axis and re.match(r"[\s*]*нет\b", axes.get(axis, "").lower()):
            continue  # ось выключена — отсутствие легитимно
        if target in deviations or Path(target).name in deviations:
            covered.append((path, target))
        else:
            missing.append((path, klass, target))
    return missing, covered, unruled


def scan_migrations(clone: Path, core_hash: str):
    """§7.1 INSTALL из upstream: заголовки миграций с main-hash; применимость по ancestry.

    Каждая применимая миграция — {"head": заголовок, "grep_key": подстрока устаревшей
    точки входа из строки «Grep-ключ: `…`» тела миграции (пустая, если миграция не
    меняет указателей)}.
    """
    install = show(clone, UPSTREAM, "INSTALL.md") or ""
    sec = re.search(r"### 7\.1.*?(?=\n## |\Z)", install, re.DOTALL)
    applicable, warns = [], []
    if not sec:
        return applicable, warns
    # кусок миграции = болд-заголовок + тело до следующего болд-заголовка
    for chunk in re.split(r"\n(?=\*\*)", sec.group(0)):
        m = re.match(r"\*\*(.+?)\*\*", chunk)
        if not m:
            continue
        head = m.group(1)
        h = re.search(r"main-hash `([0-9a-f]+)`", head)
        if not h:
            warns.append(f"болд-заголовок §7.1 без main-hash — сверить вручную: «{head[:80]}»")
            continue
        was = git(["merge-base", "--is-ancestor", h.group(1), core_hash],
                  cwd=clone, check=False).returncode == 0
        now = git(["merge-base", "--is-ancestor", h.group(1), UPSTREAM],
                  cwd=clone, check=False).returncode == 0
        if now and not was:
            key = re.search(r"Grep-ключ: `([^`]+)`", chunk)
            applicable.append({"head": head, "grep_key": key.group(1) if key else ""})
    return applicable, warns


# Носители consumer-facing указателей для smoke-grep миграций: развёрнутые слои знаний,
# по которым агент реально ходит. Манифест исключён — его летопись легитимно упоминает
# устаревшие точки входа (история миграций).
POINTER_FILES = ("CLAUDE.md", "CLAUDE.local.md", "AGENTS.md")
POINTER_DIRS = (".claude", ".codex", ".agents")


def scan_stale_pointers(migs):
    """Smoke-grep развёртки по Grep-ключам применимых миграций §7.1.

    Механика содержимое осевых/адаптированных файлов не переписывает по построению —
    смена канонной точки входа в них не доезжает без явного сигнала. Находка здесь =
    носитель знаний всё ещё ведёт агента на устаревшую точку; судьба каждой — диалог
    (SKILL Phase 3). Возвращает [(grep_key, "path:line", фрагмент)].
    """
    keys = [m["grep_key"] for m in migs if m.get("grep_key")]
    hits = []
    if not keys:
        return hits
    candidates = [Path(name) for name in POINTER_FILES]
    for d in POINTER_DIRS:
        if Path(d).is_dir():
            candidates.extend(sorted(Path(d).rglob("*")))
    for path in candidates:
        if not path.is_file() or "toolkit-manifest" in path.name \
                or "__pycache__" in path.parts:
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, OSError):
            continue  # бинарь/нечитаемое — не носитель указателей
        for i, line in enumerate(text.splitlines(), 1):
            for key in keys:
                if key in line:
                    hits.append((key, f"{path}:{i}", line.strip()[:100]))
    return hits


def scan_local_copy_drift(clone: Path, plan, manifest_text: str):
    """Изменённые адаптер-шпаргалки (клон-ссылочные доки), чьё имя/стем упомянуты в секции
    «Отступления» манифеста, — КАНДИДАТЫ на дрейф удерживаемой локальной копии. Классифицировать
    прозу «Отступлений» скрипт не берётся: держит ли потребитель шпаргалку локальной копией
    (клон-hunks не применяются → копия отстаёт) ИЛИ это клон-ссылка/референс (имя упомянуто по
    другой причине) — различает агент, прочитавший секцию в Phase 0.2. Поэтому вывод —
    verify-prompt «сверить», а не утверждение «устарела» (иначе ложный плюс на референс-упоминании
    вроде rn-web `test-templates.md` и ложный минус на переименовании — оба поймала верификация).

    Матч по имени И стему: стем ловит задокументированное «Отступлениями» переименование core→локаль
    (`batch-conventions → conventions.md` — имени `batch-conventions.md` в тексте нет, стема
    `batch-conventions` перед стрелкой — да). Имя шпаргалки в «Отступлениях» не упомянуто вовсе →
    блок пуст (штатная развёртка, клон-ссылки — ничего сверять).

    Плюс — разворачиваемые файлы этого синка, ссылающиеся на шпаргалку по имени: высокоточный
    сигнал `↳` (раздел-зависимость может отсутствовать в отставшей копии). Возврат
    [(path, name, [dependent_targets])].
    """
    m = re.search(r"^## Отступления.*?(?=\n## |\Z)", manifest_text, re.MULTILINE | re.DOTALL)
    deviations = m.group(0) if m else ""
    if not deviations:
        return []

    def mentioned(p):
        name, stem = Path(p).name, Path(p).stem
        lb = r"(?<![\w-])"  # левая граница: имя не должно быть хвостом длиннее токена
        #                     (api.md ⊄ some-api.md; batch-conventions ⊄ pre-batch-conventions)
        if re.search(lb + re.escape(name), deviations):
            return True
        # переименование core→локаль в «Отступлениях»: «<стем> → <локальное имя>»
        return bool(re.search(lb + re.escape(stem) + r"\s*(?:→|->|=>)", deviations))

    cand = [(p, Path(p).name) for st, p, _n, k, _t, _ax in plan
            if st != "D" and k == "adapter-doc" and mentioned(p)]
    if not cand:
        return []
    # Разворачиваемые файлы этого синка — по их upstream-содержимому ищем ссылку по имени.
    deployed = [(t, dp) for st, dp, _n, k, t, _ax in plan
                if st != "D" and k in ("as-is", "template") and t]
    contents = {t: (show(clone, UPSTREAM, dp) or "") for t, dp in deployed}
    drift = []
    for path, name in cand:
        deps = sorted(t for t, c in contents.items() if name in c)
        drift.append((path, name, deps))
    return drift


def build_plan(clone: Path, core_hash: str, items):
    """Классификация диффа: [(status, path, note, klass, target, axes)]."""
    plan = []
    for status, path, note in items:
        klass, target = classify(path)
        axes = []
        if klass == "as-is" and status != "D":
            raw = show(clone, UPSTREAM, path) or ""
            axes = sorted(set(AXIS_RE.findall(raw)))
        plan.append((status, path, note, klass, target, axes))
    return plan


def print_plan(plan, migs, warns, missing=(), covered=(), pointer_hits=(), local_drift=()):
    def block(title, rows):
        if rows:
            print(f"\n{title}:")
            for status, path, note, _, target, axes in rows:
                arrow = f" → {target}" if target else ""
                ax = f"  [{', '.join(axes)}]" if axes else ""
                nt = f"  ({note})" if note else ""
                print(f"  {status}  {path}{arrow}{ax}{nt}")

    live = [p for p in plan if p[0] != "D"]
    block("as-is без осевых блоков — механика --apply",
          [p for p in live if p[3] == "as-is" and not p[5]])
    block("as-is с [ось]-блоками — staging, доработка агентом",
          [p for p in live if p[3] == "as-is" and p[5]])
    block("шаблоны — рекомендации, автозамены нет",
          [p for p in live if p[3] == "template"])
    block("адаптеры — применимость по осям манифеста, применение по README",
          [p for p in live if p[3] == "adapter"])
    block("новые без правила карты — раскладка по свежему INSTALL §2",
          [p for p in live if p[3] == "new"])
    block("не разворачивается (FYI)",
          [p for p in live if p[3] in ("not-deployed", "adapter-doc")])
    block("удалено из ядра — подтвердить удаление копии",
          [p for p in plan if p[0] == "D"])
    if missing:
        print("\nотсутствуют в проекте при неизменном ядре — восстановить или"
              " зафиксировать отступление (диалог):")
        for path, klass, target in missing:
            print(f"  !  {path} → {target}  [{klass}]")
    if covered:
        print("\nотсутствуют, но упомянуты в «Отступлениях» манифеста — сверить (FYI):")
        for path, target in covered:
            print(f"  ~  {path} → {target}")
    if local_drift:
        print("\nадаптер-доки, изменённые ядром и упомянутые в «Отступлениях» манифеста —"
              " СВЕРИТЬ (держишь локальной копией → перенести правки core.diff; клон-ссылка →"
              " пропустить; разбор — SKILL Phase 3):")
        for path, name, deps in local_drift:
            print(f"  ⟳  {name}  ({path} изменён ядром)")
            for t in deps:
                print(f"       ↳ {t} (этого синка) ссылается на {name} по имени — если держишь"
                      f" копию, нужного раздела в ней может не быть")
    if migs:
        print("\nМиграции §7.1 — применимы при этом переходе (шаги — в INSTALL из клона):")
        for m in migs:
            print(f"  • {m['head']}")
    if pointer_hits:
        print("\nУказатели устаревшей точки входа (smoke-grep по Grep-ключам миграций) —"
              " судьба каждой находки диалогом (SKILL Phase 3):")
        for key, loc, frag in pointer_hits:
            print(f"  ?  [{key}] {loc}  {frag}")
    for w in warns:
        print(f"\n⚠ {w}")


def stage(target: str, old_render, new_render, core_diff):
    """Материалы для агента: staging/<target с __>/(old|new).render + core.diff."""
    # lstrip точки: target'ы начинаются с ".claude/…"/".codex/…" — скрытый каталог прятался бы от ls
    d = STAGING / target.replace("/", "__").lstrip(".")
    d.mkdir(parents=True, exist_ok=True)
    if old_render is not None:
        (d / "old.render").write_text(old_render, encoding="utf-8")
    (d / "new.render").write_text(new_render, encoding="utf-8")
    (d / "core.diff").write_text(core_diff, encoding="utf-8")
    return d


def do_apply(clone: Path, core_hash: str, anketa: dict, plan):
    shutil.rmtree(STAGING, ignore_errors=True)
    report = {"updated": [], "created": [], "skipped": [], "axis": [],
              "conflict": [], "needs-value": []}
    for status, path, _note, klass, target, axes in plan:
        if klass != "as-is" or status == "D":
            continue
        new_raw = show(clone, UPSTREAM, path)
        if new_raw is None:
            continue
        new_render, leftovers = render(new_raw, anketa)
        old_raw = show(clone, core_hash, path)
        old_render = render(old_raw, anketa)[0] if old_raw is not None else None
        diff_raw = git(["diff", f"{core_hash}..{UPSTREAM}", "--", path], cwd=clone).stdout
        core_diff = render(diff_raw, anketa)[0]
        tpath = Path(target)
        deployed = tpath.read_text(encoding="utf-8") if tpath.exists() else None

        if deployed == new_render:
            report["skipped"].append(target)
        elif axes:
            stage(target, old_render, new_render, core_diff)
            report["axis"].append((target, axes, leftovers))
        elif leftovers:
            stage(target, old_render, new_render, core_diff)
            report["needs-value"].append((target, leftovers))
        elif deployed is None and old_render is None:
            tpath.parent.mkdir(parents=True, exist_ok=True)
            tpath.write_text(new_render, encoding="utf-8")
            report["created"].append(target)
        elif deployed == old_render:
            tpath.write_text(new_render, encoding="utf-8")
            report["updated"].append(target)
        else:
            note = "deployed отсутствует (удалён потребителем?)" if deployed is None \
                else "локальные правки против рендера ядра"
            stage(target, old_render, new_render, core_diff)
            report["conflict"].append((target, note))

    print(f"Заменено чисто: {len(report['updated'])}")
    for t in report["updated"]:
        print(f"  ✓ {t}")
    for t in report["created"]:
        print(f"  + {t} (новый файл ядра)")
    if report["skipped"]:
        print(f"Уже обновлены (skip): {len(report['skipped'])}")
    for target, axes, leftovers in report["axis"]:
        lo = f"; нужны значения: {', '.join(leftovers)}" if leftovers else ""
        print(f"  ⚙ {target} — осевые блоки [{', '.join(axes)}]{lo} → staging")
    for target, leftovers in report["needs-value"]:
        print(f"  ? {target} — новые плейсхолдеры: {', '.join(leftovers)} → staging")
    for target, note in report["conflict"]:
        print(f"  ✗ {target} — конфликт: {note} → staging")
    if report["axis"] or report["conflict"] or report["needs-value"]:
        print(f"\nМатериалы для ручного разбора: {STAGING}/<путь>/(old|new).render, core.diff")
    return 0


def project_codex_if_dual():
    """MF1 (тулкит 061): dual-развёртка (.agents/ + AGENTS.md рядом с живым CC-слоем) —
    перепроецировать Codex-слой из только что синкнутого живого CC. ИСПОЛНЕНИЕ, а не печатное
    напоминание: рекуррентный забываемый ручной шаг реконверсии похоронил дуальный слой one-web
    (Codex-дисциплина печатных чекпоинтов доказанно нулевая). Codex-слой — дериват
    (codex_project.py), не копия."""
    if not (Path(".agents").is_dir() and Path("AGENTS.md").is_file()
            and Path(".claude").is_dir() and Path("CLAUDE.md").is_file()):
        return  # не dual: чистый CC (Codex-слоя нет) или single-layer Codex (нет живого CC,
        #         проецировать не из чего — контент там ведётся вручную, Режим 2 не построен)
    script = Path(__file__).resolve().parent / "codex_project.py"
    if not script.exists():
        print("\n⚠ dual-развёртка, но codex_project.py не найден рядом — Codex-слой НЕ "
              "перепроецирован (синкнут только CC). Доставить скрипт ядра (тулкит 061).")
        return
    print("\n— dual-развёртка: перепроецирую Codex-слой из синкнутого CC (codex_project.py) —")
    if subprocess.run([sys.executable, str(script)], check=False).returncode != 0:
        print("⚠ проекция Codex-слоя завершилась с ошибкой (см. выше) — CC-слой синкнут, "
              "Codex-слой требует внимания.")


def self_check():
    """Общий контракт + интеграция parse_manifest с анкетой toolkit-update."""
    import tempfile

    if manifest_contract.self_check() != 0:
        return 1
    table = """## Анкета (значения плейсхолдеров)
| Плейсхолдер | Значение |
|---|---|
| MAIN_BRANCH | main |
| AGENT_BRANCH | at-creation |

## Отступления от ядра
"""
    with tempfile.TemporaryDirectory() as td:
        manifest = Path(td) / "toolkit-manifest.md"
        for hash_field in ("`deadbeef12`", "deadbeef12"):
            manifest.write_text(
                f"- Ядро: {hash_field}\n- Клон тулкита: `{td}`\n\n{table}",
                encoding="utf-8",
            )
            parsed, _clone, anketa, _text = parse_manifest(manifest)
            if parsed != "deadbeef12" or anketa.get("AGENT_BRANCH") != "at-creation":
                print(f"✗ toolkit_update.parse_manifest не принял формат {hash_field}")
                return 1
    print("✓ toolkit_update parse_manifest: оба hash-формата и веточный preflight зелёные.")
    return 0


def main():
    ap = argparse.ArgumentParser(
        description="Механика /toolkit-update: план обновления ядра и применение чистых замен.")
    ap.add_argument("--apply", action="store_true",
                    help="Применить чистые замены (без флага — только план).")
    ap.add_argument("--manifest", type=Path,
                    default=next((m for m in MANIFESTS if m.exists()), MANIFESTS[0]),
                    help="Манифест развёртки (по умолчанию .claude/toolkit-manifest.md, "
                         "нет — .codex/toolkit-manifest.md).")
    ap.add_argument("--self-check", action="store_true",
                    help="Проверить общий контракт hash и веточной модели без fetch/записи.")
    args = ap.parse_args()

    if args.self_check:
        return self_check()

    apply_layout(args.manifest)
    core_hash, clone, anketa, manifest_text = parse_manifest(args.manifest)
    warns = preflight(clone, core_hash)
    head = git(["rev-parse", "--short", UPSTREAM], cwd=clone).stdout.strip()
    count = git(["rev-list", "--count", f"{core_hash}..{UPSTREAM}"],
                cwd=clone, check=False).stdout.strip() or "?"
    print(f"Ядро манифеста: {core_hash}; upstream {UPSTREAM} = {head} (+{count} коммитов)")

    items = changed_files(clone, core_hash)
    missing, covered, unruled = scan_completeness(
        clone, {p for _s, p, _n in items}, parse_axes(manifest_text), manifest_text)
    warns += [f"файл ядра без правила карты (вне диффа): {p} — карта скрипта "
              f"разошлась с INSTALL §2" for p in unruled]
    if not items and not missing:
        for w in warns:
            print(f"⚠ {w}")
        note = (f" ({len(covered)} отсутствий — отступления манифеста)") if covered else ""
        print(f"Дифф пуст — ядро не менялось; сверка полноты чиста{note}.")
        return 0
    migs, mig_warns = scan_migrations(clone, core_hash)
    pointer_hits = scan_stale_pointers(migs)
    plan = build_plan(clone, core_hash, items)
    local_drift = scan_local_copy_drift(clone, plan, manifest_text)
    if args.apply:
        for w in warns + mig_warns:
            print(f"⚠ {w}")
        rc = do_apply(clone, core_hash, anketa, plan)
        if missing:
            print(f"\nВне диффа отсутствуют {len(missing)} целей карты (см. --plan) — "
                  f"механика их не пишет, разбор диалогом.")
        if pointer_hits:
            print(f"\nSmoke-grep миграций нашёл {len(pointer_hits)} указателей устаревшей "
                  f"точки входа (см. --plan) — механика их не переводит, разбор диалогом.")
        if local_drift:
            print(f"\nАдаптер-доки под сверку локальной копии: {len(local_drift)} "
                  f"(см. --plan) — механика их не переносит, разбор диалогом (SKILL Phase 3).")
        project_codex_if_dual()
        return rc
    print_plan(plan, migs, warns + mig_warns, missing, covered, pointer_hits, local_drift)
    return 0


if __name__ == "__main__":
    sys.exit(main())
