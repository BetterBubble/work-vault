#!/usr/bin/env python3
"""codexify — детерминированная контентная конверсия CC-флейвор → Codex (тулкит 061 §3.1).

ЕДИНСТВЕННОЕ место перевода ТЕКСТА файлов знаний (скиллы/агенты/правила/CLAUDE) из терминов
Claude Code в термины OpenAI Codex. Планка — ДЕТЕРМИНИЗМ, не полнота: конвертит лишь однозначное
подмножество, двусмысленную прозу оставляет как есть. Дрейфовать нечему — Codex-слой становится
функцией codexify(живой CC-слой), а не второй сопровождаемой копией.

Что делает (только над ТЕЛОМ файла — frontmatter не трогается, см. ниже):
  1. frontmatter (первый `---…---`) — as-is. Codex безвредно игнорирует `allowed-tools`
     (прививка: файловая замена малформила бы YAML — `AskUserQuestion`/`Task` сидят в
     строке allowed-tools). Все трансформы — только после закрывающего `---`.
  2. пути в текстах `.claude/…` → Codex-раскладка (режимо-зависимо: в dual скрипты/хуки
     общие, остаются в `.claude/`).
  3. словарь терминов: `AskUserQuestion` → «спроси текстом»; `Task` (в безопасных паттернах:
     бэктики, стрелка, «через») → `spawn` (нативное делегирование Codex).
  4. `/имя` → `$имя` строго по ЖИВОМУ allowlist имён скиллов, с границей токена и НЕ внутри
     fenced-блоков (там `$имя` раскрылось бы как shell-переменная).

Гарантии: идемпотентность codexify(codexify(x)) == codexify(x); leak_lint() над выводом
должен быть ПУСТ (остаточные CC-токены = баг конверсии). Обе проверяются `--self-check`.

Кто зовёт: codex_project.py (Режим 1, dual — проекция живого CC-слоя) и, в перспективе,
toolkit_update.py do_apply (Режим 2, single-layer Codex-only). Чистый stdlib ≥3.13; файл —
ядро, ложится к потребителю как есть (плейсхолдеров нет).
"""
import argparse
import re
import sys
from pathlib import Path

# --- словарь терминов (тело файла) ---
# AskUserQuestion: на Codex нет аналога вне Plan mode → инструкция «спроси текстом».
ASK_REPLACEMENT = "спроси пользователя текстом, дождись ответа"
# Task: у Codex делегирование — нативные spawn/multi_agent, тула `Task` нет. Конвертируем
# лишь в БЕЗОПАСНЫХ паттернах (бэктики / `Task →` / «через Task»); голый Task — оставляем.
TASK_TOKEN = "spawn"

# --- карта путей в текстах (совпадает с CODEX_TARGETS toolkit_update.py; расхождение = баг) ---
# Всегда (оба режима): файлы, которые в Codex-раскладке физически переезжают.
PATH_MAP = {
    ".claude/skills/": ".agents/skills/",
    ".claude/rules/": ".agents/rules/",
    ".claude/agents/": ".codex/agents-instructions/",
    ".claude/evals/": ".codex/evals/",
}
# Только Режим 2 (single): в dual скрипты/хуки — общий ресурс, остаются в `.claude/`.
PATH_MAP_SINGLE = {
    ".claude/scripts/": ".codex/scripts/",
    ".claude/hooks/": ".codex/hooks/",
}

# Только корневой CLAUDE.md → AGENTS.md. Это точечные контекстные замены, а не
# глобальное Claude→Codex: ссылки на живой CC-слой в dual обязаны сохраниться.
ROOT_EXACT_REPLACEMENTS = (
    ("CLAUDE.template.md — каркас проектного CLAUDE.md для agent-driven тест-репозитория.",
     "AGENTS.md — производная инструкция Codex для agent-driven тест-репозитория."),
    ("При bootstrap: скопировать в корень проекта как CLAUDE.md, заполнить {{плейсхолдеры}},",
     "Производный файл Codex: генерируется из живого CLAUDE.md; напрямую не редактировать,"),
    ("референс: one-web CLAUDE.md.", "референс: one-web AGENTS.md."),
    ("Агентская инфра (`CLAUDE.md`, `.claude/`, `.tasks/`) живёт на агентской ветке.",
     "Агентская инфра (живой CC-слой `CLAUDE.md` + `.claude/`, производный Codex-слой "
     "`AGENTS.md` + `.agents/` + `.codex/`, общие `.tasks/`) живёт на агентской ветке."),
    ("`Co-Authored-By: Claude ...`", "`Co-Authored-By: Codex ...`"),
    ("агентов/Claude/AI", "агентов/Codex/AI"),
)

FENCE_RE = re.compile(r"^(\s*)(`{3,}|~{3,})")


def split_frontmatter(content):
    """(frontmatter_с_разделителями, тело). Нет YAML-frontmatter → ("", content целиком)."""
    if not content.startswith("---\n"):
        return "", content
    # первый блок между строкой «---» и следующей строкой «---»
    lines = content.split("\n")
    for i in range(1, len(lines)):
        if lines[i].strip() == "---":
            fm = "\n".join(lines[: i + 1]) + "\n"
            body = "\n".join(lines[i + 1:])
            return fm, body
    return "", content  # незакрытый frontmatter — трактуем как тело целиком


def _slash_re(names):
    # длинные имена первыми — корректная альтернация; границы: не путь/URL слева
    # (`[\w./-]`), не длиннее токена справа (`[\w-]`).
    alt = "|".join(re.escape(n) for n in sorted(names, key=len, reverse=True))
    return re.compile(r"(?<![\w./-])/(" + alt + r")(?![\w-])")


def _walk_body(body):
    """Тело по строкам с флагом «внутри fenced-блока» (маркер ` или ~, симметричное закрытие)."""
    in_fence, marker = False, None
    for line in body.split("\n"):
        m = FENCE_RE.match(line)
        if m:
            ch = m.group(2)[0]
            if not in_fence:
                in_fence, marker = True, ch
            elif ch == marker:
                in_fence, marker = False, None
            yield line, True  # сама строка-ограда — не конвертируем
        else:
            yield line, in_fence


def convert_slash_calls(body, names):
    if not names:
        return body
    rx = _slash_re(names)
    out = []
    for line, in_fence in _walk_body(body):
        out.append(line if in_fence else rx.sub(r"$\1", line))
    return "\n".join(out)


def convert_terms(body):
    body = body.replace("AskUserQuestion", ASK_REPLACEMENT)
    body = body.replace("`Task`", f"`{TASK_TOKEN}`")
    body = re.sub(r"\bTask(?=\s*(?:→|->|=>))", TASK_TOKEN, body)
    body = re.sub(r"(через\s+)Task\b", r"\g<1>" + TASK_TOKEN, body)
    return body


def rewrite_paths(body, mode):
    mapping = dict(PATH_MAP)
    if mode == "single":
        mapping.update(PATH_MAP_SINGLE)
    for src, dst in mapping.items():
        body = body.replace(src, dst)
    return body


def codexify(content, skill_names, mode="dual"):
    """CC-флейвор текст → Codex-флейвор. mode: 'dual' (скрипты/хуки общие) | 'single'."""
    if mode not in ("dual", "single"):
        raise ValueError(f"mode должен быть 'dual' или 'single', получено {mode!r}")
    fm, body = split_frontmatter(content)
    body = rewrite_paths(body, mode)      # до слэш-конверсии: переписанные пути не ловятся /имя
    body = convert_terms(body)
    body = convert_slash_calls(body, skill_names)
    return fm + body


def transform_root_document(body):
    """Контекстные платформенные замены только для тела корневого документа."""
    body = re.sub(r"^(# .+ — инструкции для )Claude\s*$", r"\1Codex", body,
                  flags=re.MULTILINE)
    for source, target in ROOT_EXACT_REPLACEMENTS:
        body = body.replace(source, target)
    return body


def codexify_root_document(content, skill_names, mode="dual"):
    """Корневой CLAUDE.md → AGENTS.md; прочие `.md` должны звать обычный `codexify`."""
    converted = codexify(content, skill_names, mode)
    fm, body = split_frontmatter(converted)
    return fm + transform_root_document(body)


def root_document_leaks(content):
    """Остатки, из-за которых AGENTS.md представляется корневой инструкцией Claude."""
    _fm, body = split_frontmatter(content)
    leaks = []
    patterns = (
        ("root-title", re.compile(r"^# .+ — инструкции для Claude\s*$", re.MULTILINE)),
        ("root-template", re.compile(r"CLAUDE\.template\.md — каркас проектного CLAUDE\.md")),
        ("attribution", re.compile(r"Co-Authored-By: Claude")),
    )
    for kind, pattern in patterns:
        match = pattern.search(body)
        if match:
            leaks.append((kind, body[:match.start()].count("\n") + 1, match.group(0)))
    return leaks


# --- leak-lint: остаточные CC-токены в СОБРАННОМ Codex-слое = протечка конверсии ---

def leak_lint(content, skill_names, mode="dual"):
    """[(kind, lineno_в_теле, фрагмент)] — что не сконвертилось. Пусто = чистая конверсия."""
    fm, body = split_frontmatter(content)
    base = fm.count("\n")  # смещение номеров строк тела к номерам файла
    rx = _slash_re(skill_names) if skill_names else None
    leaks = []
    leftover_paths = list(PATH_MAP)
    if mode == "single":
        leftover_paths += list(PATH_MAP_SINGLE)
    for i, (line, in_fence) in enumerate(_walk_body(body), 1):
        n = base + i
        if rx and not in_fence:
            for m in rx.finditer(line):
                leaks.append(("slash-call", n, m.group(0)))
        if "AskUserQuestion" in line:
            leaks.append(("AskUserQuestion", n, line.strip()[:80]))
        for pat in ("`Task`", "Task →", "Task ->", "через Task"):
            if pat in line:
                leaks.append(("Task", n, line.strip()[:80]))
                break
        for src in leftover_paths:
            if src in line:
                leaks.append(("path", n, src))
    return leaks


def skill_names_in(skills_dir: Path):
    """Имена скиллов = каталоги первого уровня в skills_dir, кроме служебного _shared.

    allowlist для /имя→$имя. У потребителя скиллы в `.claude/skills/`, в dev-репо тулкита —
    `core/claude/skills/` (см. skill_names_from). ПИНИТЬ к тому же источнику, что и контент.
    """
    if not skills_dir.is_dir():
        return []
    return sorted(p.name for p in skills_dir.iterdir()
                  if p.is_dir() and p.name != "_shared" and not p.name.startswith("."))


def skill_names_from(root: Path):
    """Allowlist для dev-репо тулкита: каталоги в core/claude/skills/ (self-check, Режим 2)."""
    return skill_names_in(root / "core" / "claude" / "skills")


def _corpus_files(root: Path):
    """Файлы-носители знаний ядра для конверсии/самопроверки: скиллы, агенты, правила, CLAUDE."""
    files = []
    for sub in ("core/claude/skills", "core/claude/agents", "core/claude/rules"):
        p = root / sub
        if p.is_dir():
            files += sorted(f for f in p.rglob("*.md") if f.is_file())
    claude = root / "core" / "CLAUDE.template.md"
    if claude.is_file():
        files.append(claude)
    return files


def _count_conversions(body, names, mode):
    """Сколько конкретных трансформов сработает в теле (диагностика self-check)."""
    rewritten = rewrite_paths(body, mode)
    rx = _slash_re(names) if names else None
    slash = sum(len(rx.findall(line)) for line, in_fence in _walk_body(rewritten)
                if rx and not in_fence)
    ask = body.count("AskUserQuestion")
    task = (body.count("`Task`")
            + len(re.findall(r"\bTask(?=\s*(?:→|->|=>))", body))
            + len(re.findall(r"(?:через\s+)Task\b", body)))
    path = sum(body.count(s) for s in PATH_MAP)
    return slash, ask, task, path


def self_check(root: Path, mode: str):
    """Golden/идемпотентность/leak-lint по реальному корпусу ядра. Возврат exit-кода (0 ок)."""
    names = skill_names_from(root)
    files = _corpus_files(root)
    print(f"codexify --self-check: {len(files)} файлов, allowlist {len(names)} скиллов, mode={mode}")
    total = [0, 0, 0, 0]  # slash, ask, task, path
    idem_fail, leak_fail, fm_fail, root_fail = [], [], [], []
    for f in files:
        src = f.read_text(encoding="utf-8")
        rel = str(f.relative_to(root))
        is_root = rel == "core/CLAUDE.template.md"
        convert = codexify_root_document if is_root else codexify
        out = convert(src, names, mode)
        if split_frontmatter(src)[0] != split_frontmatter(out)[0]:
            fm_fail.append(rel)
        if convert(out, names, mode) != out:
            idem_fail.append(rel)
        leaks = leak_lint(out, names, mode)
        if leaks:
            leak_fail.append((rel, leaks))
        if is_root and root_document_leaks(out):
            root_fail.append((rel, root_document_leaks(out)))
        for i, c in enumerate(_count_conversions(split_frontmatter(src)[1], names, mode)):
            total[i] += c

    print(f"  слэш-конверсий /имя→$имя : {total[0]}")
    print(f"  AskUserQuestion (в теле) : {total[1]}")
    print(f"  Task (безопасн. паттерны): {total[2]}")
    print(f"  путей .claude/ переписано: {total[3]}")
    ok = True
    if fm_fail:
        ok = False
        print(f"\n✗ frontmatter изменён в {len(fm_fail)} файлах: {', '.join(fm_fail)}")
    if idem_fail:
        ok = False
        print(f"\n✗ идемпотентность нарушена в {len(idem_fail)} файлах: {', '.join(idem_fail)}")
    if leak_fail:
        ok = False
        print(f"\n✗ leak-lint нашёл остаточные CC-токены ({len(leak_fail)} файлов):")
        for rel, leaks in leak_fail:
            for kind, n, frag in leaks[:6]:
                print(f"    {rel}:{n}  [{kind}]  {frag}")
    if root_fail:
        ok = False
        print("\n✗ root-document transform оставил Claude-корень:")
        for rel, leaks in root_fail:
            for kind, n, frag in leaks:
                print(f"    {rel}:{n}  [{kind}]  {frag}")

    golden = """# Demo — инструкции для Claude
- Живой источник: `CLAUDE.md` + `.claude/skills/`.
- **Никаких `Co-Authored-By: Claude ...`**.
"""
    golden_out = codexify_root_document(golden, names, mode)
    if "# Demo — инструкции для Codex" not in golden_out \
            or "`Co-Authored-By: Codex ...`" not in golden_out \
            or "Живой источник: `CLAUDE.md`" not in golden_out:
        ok = False
        print("\n✗ golden root-transform: платформа/атрибуция не переведены или CC-ссылка потеряна")
    if ok:
        print("\n✓ идемпотентно, frontmatter не тронут, leak-lint пуст, root golden зелёный.")
        return 0
    return 1


def main():
    ap = argparse.ArgumentParser(description="Контентная конверсия CC→Codex (тулкит 061).")
    ap.add_argument("--mode", choices=("dual", "single"), default="dual",
                    help="dual: скрипты/хуки общие в .claude/ (умолч.); single: переносятся в .codex/.")
    ap.add_argument("--self-check", type=Path, metavar="ROOT",
                    help="Прогнать golden/идемпотентность/leak-lint по корпусу ядра в ROOT.")
    ap.add_argument("--root", type=Path, default=Path("."),
                    help="Корень тулкита для allowlist скиллов при конверсии файла (умолч. .).")
    ap.add_argument("--root-document", action="store_true",
                    help="Применить контекстный transform корневого CLAUDE.md → AGENTS.md.")
    ap.add_argument("file", nargs="?", type=Path,
                    help="Файл для конверсии (вывод в stdout). Нет — читаем stdin.")
    args = ap.parse_args()

    if args.self_check:
        return self_check(args.self_check, args.mode)

    names = skill_names_from(args.root)
    src = args.file.read_text(encoding="utf-8") if args.file else sys.stdin.read()
    convert = codexify_root_document if args.root_document else codexify
    sys.stdout.write(convert(src, names, args.mode))
    return 0


if __name__ == "__main__":
    sys.exit(main())
