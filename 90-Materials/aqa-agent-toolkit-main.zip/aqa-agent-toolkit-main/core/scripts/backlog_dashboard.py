#!/usr/bin/env python3
"""Генератор статичного HTML-дашборда беклога `.tasks/TODO/`.

Читает файлы задач `NNN-*.md` (источник истины — у них есть и шапка-метаданные,
и тело-секции для drill-down) и секцию «Закрытые» из `INDEX.md`, собирает один
самодостаточный .html (инлайн CSS, ноль зависимостей, ноль JS — drill-down на
нативных <details>). Файл пересылается в Slack/почту, открывается оффлайн.

Часть ядра aqa-agent-toolkit: чистый stdlib, кладётся в `.claude/scripts/` проекта как есть.
Завязки на конвенции ядра: беклог `.tasks/TODO/` (формат tasks-schemas), выход в
`.tasks/_scratch/`, ветки задач `wt/<task>` (статус in-progress из живого ворктри).

Запуск (из корня репо, любым python3 ≥ 3.13):
    python3 .claude/scripts/backlog_dashboard.py [--out PATH] [--open] [--json]
"""

import argparse
import html
import json
import re
import subprocess
import sys
import webbrowser
from datetime import date, datetime
from pathlib import Path


# --- пороги старения (дни) ---
AGING_DAYS = 14   # янтарь
STALE_DAYS = 30   # красный

PRIO_RANK = {"P1": 0, "P2": 1, "P3": 2}

# --- регэкспы парсинга ---
TITLE_RE = re.compile(r"^#\s*\d+:\s*(.+?)\s*$", re.M)
META_LINE_RE = re.compile(r"^-\s*\*\*Приоритет:\*\*.*$", re.M)
SOURCE_LINE_RE = re.compile(r"^-\s*\*\*Источник:\*\*\s*(.+?)\s*$", re.M)
SECTION_RE = re.compile(r"^##\s+(.+?)\s*$", re.M)
DATE_RE = re.compile(r"(\d{4})-(\d{2})-(\d{2})")
UNESC_PIPE_RE = re.compile(r"(?<!\\)\|")
BOLD_RE = re.compile(r"\*\*(.+?)\*\*")
CODE_RE = re.compile(r"`([^`]+)`")
BULLET_RE = re.compile(r"^[-*]\s+(.*)$")


def _force_utf8():
    """Кириллица в консоль независимо от локали (как в модуле testops)."""
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8")
        except (AttributeError, ValueError):
            pass


def repo_root() -> Path:
    # .claude/scripts/backlog_dashboard.py → parents[2] = корень репо
    return Path(__file__).resolve().parents[2]


def live_worktree_task_nums(root: Path) -> set[int]:
    """Номера задач бэклога с живым ворктри `wt/<task>` → статус in-progress.

    `git worktree list` = ground truth «над задачей идёт работа»: пока задача живёт
    в ворктри, её статус на агентской ветке остаётся `open` (дашборд читает чекаут
    main_repo, а работа — в форке) → выводим in-progress из существования ворктри.
    Ветка `wt/TODO-043` (или `wt/043`) → задача 43; матч по int снимает нулевое
    дополнение. Не-бэклоговые ворктри (`wt/VCSAT-1200`, `wt/fix-toast`) числа не дают.
    """
    try:
        out = subprocess.run(
            ["git", "worktree", "list", "--porcelain"],
            cwd=root, capture_output=True, text=True, timeout=10,
        ).stdout
    except Exception:
        return set()
    nums = set()
    for line in out.splitlines():
        if not line.startswith("branch "):
            continue
        m = re.search(r"/wt/(?:TODO-)?0*(\d+)$", line.strip())
        if m:
            nums.add(int(m.group(1)))
    return nums


# ----------------------------------------------------------------------------
# Парсинг
# ----------------------------------------------------------------------------
def _field(meta_line: str, label: str):
    """Значение поля **label:** до следующего | или конца строки."""
    m = re.search(r"\*\*" + re.escape(label) + r":\*\*\s*(.+?)\s*(?:\||$)", meta_line)
    return m.group(1).strip() if m else None


def parse_metadata(text: str) -> dict:
    line_m = META_LINE_RE.search(text)
    if not line_m:
        return {"priority": "P?", "status": "open", "added": None, "estimate": None}
    line = line_m.group(0)

    prio_raw = _field(line, "Приоритет") or ""
    pm = re.search(r"P[123]", prio_raw)
    priority = pm.group(0) if pm else "P?"

    status_raw = _field(line, "Статус") or ""
    sm = re.search(r"in-progress|blocked|open", status_raw)
    status = sm.group(0) if sm else "open"

    added = None
    added_raw = _field(line, "Добавлена") or ""
    dm = DATE_RE.search(added_raw)  # первая дата (хвост «(переоформлена ...)» игнорим)
    if dm:
        try:
            added = date(int(dm.group(1)), int(dm.group(2)), int(dm.group(3)))
        except ValueError:
            added = None

    return {
        "priority": priority,
        "status": status,
        "added": added,
        "estimate": _field(line, "Оценка"),
    }


def split_sections(text: str):
    """Любые `## `-секции в порядке появления (имена не хардкодим)."""
    marks = list(SECTION_RE.finditer(text))
    out = []
    for i, m in enumerate(marks):
        start = m.end()
        end = marks[i + 1].start() if i + 1 < len(marks) else len(text)
        out.append((m.group(1), text[start:end].strip()))
    return out


def parse_task_file(path: Path) -> dict:
    text = path.read_text(encoding="utf-8")
    num = path.name.split("-", 1)[0]

    tm = TITLE_RE.search(text)
    title = tm.group(1) if tm else path.stem

    meta = parse_metadata(text)
    sm = SOURCE_LINE_RE.search(text)
    source = sm.group(1) if sm else None

    age = None
    if meta["added"]:
        age = max((date.today() - meta["added"]).days, 0)

    return {
        "num": num,
        "title": title,
        "priority": meta["priority"],
        "status": meta["status"],
        "added": meta["added"],
        "age": age,
        "estimate": meta["estimate"],
        "source": source,
        "sections": split_sections(text),
    }


def parse_closed(index_text: str):
    """Псевдотаблица `## Закрытые` (4 кол., без |---|, экранированные \\| в ретро)."""
    m = re.search(r"^##\s+Закрыт", index_text, re.M)
    if not m:
        return []
    section = index_text[m.end():]
    rows = []
    for line in section.splitlines():
        line = line.strip()
        if not line.startswith("|"):
            continue
        inner = line.strip("|")
        cells = [c.strip() for c in UNESC_PIPE_RE.split(inner, maxsplit=3)]
        if len(cells) < 3 or not re.match(r"^\d+$", cells[0]):
            continue
        rows.append({
            "num": cells[0],
            "title": cells[1],
            "outcome": cells[2],
            "retro": cells[3].replace(r"\|", "|") if len(cells) > 3 else "",
        })
    return rows


# ----------------------------------------------------------------------------
# Лёгкий md → html
# ----------------------------------------------------------------------------
def _inline(s: str) -> str:
    s = html.escape(s)                                   # экранируем всё
    s = BOLD_RE.sub(r"<strong>\1</strong>", s)           # **bold**
    s = CODE_RE.sub(r"<code>\1</code>", s)               # `code`
    return s


def md_to_html(text: str) -> str:
    """Абзацы (пустая строка), нативные списки `- `, инлайн bold/code.

    [[links]] / TC-номера / пути остаются текстом (escape их не трогает).
    """
    lines = text.strip().split("\n")
    parts, para = [], []

    def flush():
        if para:
            parts.append("<p>" + "<br>\n".join(para) + "</p>")
            para.clear()

    i = 0
    while i < len(lines):
        stripped = lines[i].strip()
        if not stripped:
            flush()
            i += 1
            continue
        if BULLET_RE.match(stripped):
            flush()
            items = []
            while i < len(lines) and BULLET_RE.match(lines[i].strip()):
                items.append("<li>" + _inline(BULLET_RE.match(lines[i].strip()).group(1)) + "</li>")
                i += 1
            parts.append("<ul>" + "".join(items) + "</ul>")
            continue
        para.append(_inline(stripped))
        i += 1
    flush()
    return "\n".join(parts)


# ----------------------------------------------------------------------------
# Рендер HTML
# ----------------------------------------------------------------------------
# Колонки строки: каретка | # | P | статус | название | возраст.
# Один и тот же шаблон у шапки-сортировки (.thead) и у summary карточки (.row) → выравнивание.
GRID = "1.1rem 2.8rem 2.4rem 6.2rem minmax(0, 1fr) 4.4rem"

CSS = """
:root { color-scheme: light; }
* { box-sizing: border-box; }
body { font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
       max-width: 1040px; margin: 1.5rem auto; padding: 0 1rem;
       color: #1a1a1a; background: #fafafa; line-height: 1.5; }
h1 { margin: 0 0 .2rem; font-size: 1.5rem; }
.meta { color: #666; font-size: .85rem; }
.toolbar { margin: 1rem 0 .3rem; display: flex; gap: .6rem; align-items: center; }
#q { flex: 1; padding: .45rem .7rem; font-size: .95rem; border: 1px solid #ccc;
     border-radius: 6px; background: #fff; }
#count { color: #888; font-size: .8rem; white-space: nowrap; }
.row { display: grid; grid-template-columns: __GRID__; gap: .5rem; align-items: center; }
.thead { position: sticky; top: 0; z-index: 2; background: #fafafa;
         padding: .4rem .85rem .4rem 1.15rem; border-bottom: 2px solid #e0e0e0; }
.thead button { background: none; border: none; padding: .1rem 0; font: inherit;
         font-size: .8rem; font-weight: 600; color: #666; cursor: pointer;
         text-align: left; display: flex; gap: .25rem; align-items: center; }
.thead button:hover { color: #000; }
.thead button.active { color: #000; }
.thead .arr { font-size: .7rem; }
details.card { border: 1px solid #ddd; border-left: 4px solid #bbb; border-radius: 6px;
               margin: .4rem 0; background: #fff; }
details.card > summary { padding: .45rem .85rem; }
details.card.blocked { border-left-color: #d33; background: #fff7f7; }
details.card.stale   { border-left-color: #e67e00; }
details.card.aging   { border-left-color: #f0c000; }
summary { cursor: pointer; list-style: none; }
summary::-webkit-details-marker { display: none; }
.caret { color: #aaa; font-size: .8rem; display: inline-block; transition: transform .12s; }
details[open] > summary .caret { transform: rotate(90deg); }
.num { font-variant-numeric: tabular-nums; color: #999; font-weight: 700; font-size: .85rem; }
.title { font-weight: 600; }
.badge { font-size: .72rem; padding: .05rem .5rem; border-radius: 10px;
         font-weight: 600; white-space: nowrap; justify-self: start; }
.p1 { background: #d33; color: #fff; } .p2 { background: #e6920a; color: #fff; }
.p3 { background: #3a8a5a; color: #fff; } .px { background: #999; color: #fff; }
.st-blocked { background: #d33; color: #fff; }
.st-inprogress { background: #2878c8; color: #fff; }
.st-open { background: #ececec; color: #555; }
.age { color: #888; font-size: .78rem; white-space: nowrap; justify-self: end; }
.body { padding: .2rem .85rem .5rem 1.95rem; }
.body h4 { margin: .8rem 0 .15rem; font-size: .9rem; color: #333; }
.body p { margin: .3rem 0; }
.body ul { margin: .3rem 0; padding-left: 1.2rem; }
.body code { background: #f0f0f0; padding: 0 .25rem; border-radius: 3px;
             font-size: .88em; font-family: ui-monospace, Menlo, Consolas, monospace; }
.body .src { color: #888; font-size: .82rem; font-style: italic; }
.body .est { color: #888; font-size: .82rem; }
mark { background: #ffe35a; color: inherit; border-radius: 2px; padding: 0 .05rem; }
details.closed { margin-top: 2rem; border-top: 1px solid #ddd; padding-top: .8rem; }
details.closed > summary { font-weight: 600; color: #555; }
details.closed > summary::-webkit-details-marker { display: none; }
details.closed ul { list-style: none; padding-left: 0; }
details.closed li { padding: .25rem 0; border-bottom: 1px solid #f0f0f0; font-size: .9rem; }
details.closed .outcome { color: #888; font-size: .82rem; }
""".replace("__GRID__", GRID)


# Инлайн-JS: сортировка плоского списка по колонкам + поиск с подсветкой вхождений.
JS = r"""
(function () {
  var list = document.getElementById('list');
  var cards = Array.prototype.slice.call(list.querySelectorAll('details.card'));
  var orig = new Map();
  cards.forEach(function (c) { orig.set(c, c.innerHTML); });
  var q = document.getElementById('q');
  var count = document.getElementById('count');
  var total = cards.length;
  var sortKey = null, sortDir = 1;

  function highlight(card, needle) {
    var w = document.createTreeWalker(card, NodeFilter.SHOW_TEXT, null), nodes = [], n;
    while ((n = w.nextNode())) {
      if (n.nodeValue.toLowerCase().indexOf(needle) !== -1) nodes.push(n);
    }
    nodes.forEach(function (node) {
      var text = node.nodeValue, low = text.toLowerCase();
      var frag = document.createDocumentFragment(), i = 0, idx;
      while ((idx = low.indexOf(needle, i)) !== -1) {
        if (idx > i) frag.appendChild(document.createTextNode(text.slice(i, idx)));
        var m = document.createElement('mark');
        m.textContent = text.slice(idx, idx + needle.length);
        frag.appendChild(m);
        i = idx + needle.length;
      }
      if (i < text.length) frag.appendChild(document.createTextNode(text.slice(i)));
      node.parentNode.replaceChild(frag, node);
    });
  }

  function applySearch() {
    var needle = q.value.trim().toLowerCase(), shown = 0;
    cards.forEach(function (card) {
      card.innerHTML = orig.get(card);               // сброс прошлой подсветки
      if (!needle) { card.style.display = ''; card.open = false; shown++; return; }
      if (card.textContent.toLowerCase().indexOf(needle) !== -1) {
        highlight(card, needle);
        card.style.display = '';
        var body = card.querySelector('.body');      // совпадение в теле → раскрыть
        card.open = !!(body && body.textContent.toLowerCase().indexOf(needle) !== -1);
        shown++;
      } else {
        card.style.display = 'none';
        card.open = false;
      }
    });
    count.textContent = needle ? ('показано ' + shown + ' из ' + total) : (total + ' задач');
  }

  function sortBy(key) {
    if (sortKey === key) sortDir = -sortDir; else { sortKey = key; sortDir = 1; }
    function num(c) { var v = c.dataset[key]; return (v === '' || v == null) ? -1 : Number(v); }
    var arr = cards.slice().sort(function (a, b) {
      if (key === 'title') return a.dataset.title.localeCompare(b.dataset.title, 'ru') * sortDir;
      return (num(a) - num(b)) * sortDir;
    });
    arr.forEach(function (c) { list.appendChild(c); });
    Array.prototype.forEach.call(document.querySelectorAll('.thead button'), function (btn) {
      var on = btn.getAttribute('data-sort') === key;
      btn.classList.toggle('active', on);
      btn.querySelector('.arr').textContent = on ? (sortDir > 0 ? '▲' : '▼') : '';
    });
  }

  q.addEventListener('input', applySearch);
  Array.prototype.forEach.call(document.querySelectorAll('.thead button'), function (btn) {
    btn.addEventListener('click', function () { sortBy(btn.getAttribute('data-sort')); });
  });
})();
"""


def _status_badge(status: str) -> str:
    cls = {"blocked": "st-blocked", "in-progress": "st-inprogress"}.get(status, "st-open")
    return f'<span class="badge {cls}">{html.escape(status)}</span>'


def _card_class(task: dict) -> str:
    if task["status"] == "blocked":
        return "card blocked"
    age = task["age"]
    if age is not None and age >= STALE_DAYS:
        return "card stale"
    if age is not None and age >= AGING_DAYS:
        return "card aging"
    return "card"


def _age_label(task: dict) -> str:
    return f'{task["age"]} дн.' if task["age"] is not None else "?"


STATUS_RANK = {"blocked": 0, "in-progress": 1, "open": 2}


def render_card(task: dict) -> str:
    pcls = {"P1": "p1", "P2": "p2", "P3": "p3"}.get(task["priority"], "px")
    body = []
    if task["source"]:
        body.append(f'<p class="src">Источник: {_inline(task["source"])}</p>')
    if task["estimate"]:
        body.append(f'<p class="est">Оценка: {html.escape(task["estimate"])}</p>')
    for heading, text in task["sections"]:
        body.append(f"<h4>{_inline(heading)}</h4>")
        body.append(md_to_html(text))
    try:
        num_sort = int(task["num"])
    except ValueError:
        num_sort = 0
    age_attr = task["age"] if task["age"] is not None else ""
    return (
        f'<details class="{_card_class(task)}"'
        f' data-num="{num_sort}" data-prio="{PRIO_RANK.get(task["priority"], 9)}"'
        f' data-status="{STATUS_RANK.get(task["status"], 3)}" data-age="{age_attr}"'
        f' data-title="{html.escape(task["title"].lower(), quote=True)}">'
        f'<summary class="row">'
        f'<span class="caret">▸</span>'
        f'<span class="num">{html.escape(task["num"])}</span>'
        f'<span class="badge {pcls}">{html.escape(task["priority"])}</span>'
        f'{_status_badge(task["status"])}'
        f'<span class="title">{_inline(task["title"])}</span>'
        f'<span class="age">{_age_label(task)}</span>'
        f"</summary>"
        f'<div class="body">{"".join(body)}</div>'
        f"</details>"
    )


def _sort_headers() -> str:
    cols = [("num", "#"), ("prio", "P"), ("status", "Статус"),
            ("title", "Название"), ("age", "Возраст")]
    btns = "".join(
        f'<button data-sort="{key}">{label}<span class="arr"></span></button>'
        for key, label in cols
    )
    return f'<div class="thead row"><span></span>{btns}</div>'


def render_html(tasks: list, closed: list) -> str:
    # Начальный порядок плоского списка: blocked сверху, затем приоритет, затем возраст ↓.
    # Дальше пользователь пересортировывает кликом по колонке (JS).
    order = sorted(tasks, key=lambda t: (
        t["status"] != "blocked", PRIO_RANK.get(t["priority"], 9), -(t["age"] or 0),
    ))
    blocked_n = sum(1 for t in tasks if t["status"] == "blocked")
    by_prio = {}
    for t in tasks:
        by_prio.setdefault(t["priority"], []).append(t)
    counts = " ".join(
        f"{p}·{len(by_prio[p])}"
        for p in sorted(by_prio, key=lambda p: PRIO_RANK.get(p, 9))
    )
    stamp = datetime.now().strftime("%Y-%m-%d %H:%M")

    out = [
        '<!DOCTYPE html><html lang="ru"><head><meta charset="utf-8">',
        '<meta name="viewport" content="width=device-width, initial-scale=1">',
        "<title>Беклог отложенных задач</title>",
        f"<style>{CSS}</style></head><body>",
        "<h1>Беклог отложенных задач</h1>",
        f'<p class="meta">Сгенерирован {stamp} · открытых: {len(tasks)}'
        f" · blocked: {blocked_n} · {counts}</p>",
        '<div class="toolbar">'
        '<input id="q" type="search" placeholder="Поиск по названию и содержимому…" autocomplete="off">'
        f'<span id="count">{len(tasks)} задач</span></div>',
        _sort_headers(),
        '<div id="list">',
    ]
    out.extend(render_card(t) for t in order)
    out.append("</div>")

    if closed:
        out.append(f'<details class="closed"><summary>Закрытые (из INDEX) — {len(closed)}</summary><ul>')
        for c in closed:
            out.append(
                f'<li><span class="num">{html.escape(c["num"])}</span> '
                f'{_inline(c["title"])} '
                f'<span class="outcome">{html.escape(c["outcome"])}</span></li>'
            )
        out.append("</ul></details>")

    out.append(f"<script>{JS}</script>")
    out.append("</body></html>")
    return "\n".join(out)


# ----------------------------------------------------------------------------
# CLI
# ----------------------------------------------------------------------------
def _json_model(tasks: list, closed: list) -> str:
    def task_dict(t):
        d = dict(t)
        d["added"] = t["added"].isoformat() if t["added"] else None
        d["sections"] = [{"heading": h, "body": b} for h, b in t["sections"]]
        return d
    return json.dumps(
        {"open": [task_dict(t) for t in tasks], "closed": closed},
        ensure_ascii=False, indent=2,
    )


def main(argv=None):
    _force_utf8()
    root = repo_root()
    parser = argparse.ArgumentParser(description="HTML-дашборд беклога .tasks/TODO/")
    parser.add_argument("--todo-dir", type=Path, default=root / ".tasks" / "TODO")
    parser.add_argument("--out", type=Path,
                        default=root / ".tasks" / "_scratch" / "backlog-dashboard" / "dashboard.html")
    parser.add_argument("--open", action="store_true", help="открыть в браузере после генерации")
    parser.add_argument("--json", action="store_true", help="напечатать распарсенную модель, не генерить HTML")
    args = parser.parse_args(argv)

    todo_dir = args.todo_dir
    files = sorted(p for p in todo_dir.glob("[0-9]*.md"))
    if not files:
        print(f"Не найдено файлов задач NNN-*.md в {todo_dir}", file=sys.stderr)
        return 1

    tasks = [parse_task_file(p) for p in files]

    # Живой ворктри `wt/TODO-NNN` → задача in-progress (перекрывает файловый `open`;
    # blocked/уже-in-progress не трогаем). Статус выведен из факта, а не из текста → не дрейфит.
    live = live_worktree_task_nums(root)
    for t in tasks:
        try:
            n = int(t["num"])
        except (ValueError, TypeError):
            continue
        if n in live and t["status"] == "open":
            t["status"] = "in-progress"

    index_path = todo_dir / "INDEX.md"
    closed = parse_closed(index_path.read_text(encoding="utf-8")) if index_path.exists() else []

    if args.json:
        print(_json_model(tasks, closed))
        return 0

    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(render_html(tasks, closed), encoding="utf-8")
    print(f"Готово: {len(tasks)} открытых задач (+{len(closed)} закрытых) → {args.out}")

    if args.open:
        webbrowser.open(args.out.resolve().as_uri())
    return 0


if __name__ == "__main__":
    sys.exit(main())
