#!/usr/bin/env bash
# Создание ворктри-на-задачу (модель — {{TOOLKIT}}/core/tasks-schemas/worktree-meta.md).
#
# Часть ядра aqa-agent-toolkit: кладётся в .claude/scripts/ проекта; конфиг — блок ниже
# (референс one-web создавал ворктри Warp tab-config'ом — этот скрипт его заменяет
# и работает из любого терминала/агента).
#
# Использование (из любого каталога):
#     worktree_bootstrap.sh <task> [<base>]
#     <task> — id/slug задачи (TASK-1200, TODO-042, fix-toast...) → каталог и ветка wt/<task>
#     <base> — базовая агентская ветка (дефолт — DEFAULT_BASE)
#
# Создание = ТОЛЬКО для НОВОЙ задачи: повтор упадёт `branch already exists` — полезный
# предохранитель. ВОЗВРАТ к задаче = просто cd в каталог (переживает сессии).
# Сведение+доставка — skill /worktree-land.
set -euo pipefail

# --- конфиг проекта (заполнить при bootstrap) -------------------------------
MAIN_REPO="${MAIN_REPO:-{{PROJECT_DIR}}}"   # главный чекаут репо (полный путь)
MAIN_REPO="${MAIN_REPO/#\~/$HOME}"          # анкета допускает ~/… — в кавычках bash сам не раскроет
WORKTREES_ROOT="${WORKTREES_ROOT:-$HOME/worktrees/{{PROJECT}}}"
DEFAULT_BASE="${DEFAULT_BASE:-{{AGENT_BRANCH}}}"
# Общее окружение стека, симлинкуемое в ворктри (пусто = не линковать; ось test-stack):
ENV_DIR_NAME="${ENV_DIR_NAME:-venv}"
# Gitignored файл секретов, симлинкуемый в ворктри (пусто = не линковать; принцип
# «схема в git, значения вне git» — через git в ворктри не приезжает):
SECRETS_FILE_NAME="${SECRETS_FILE_NAME:-secrets.yaml}"
# Шаблон PROGRESS-handoff (из {{TOOLKIT}}/core/tasks-schemas/PROGRESS-template.md, копируется в проект
# при развёртке ядра; Codex-раскладка кладёт скиллы в .agents/skills/ — фоллбэк ниже):
if [ -z "${PROGRESS_TEMPLATE:-}" ]; then
  PROGRESS_TEMPLATE="$MAIN_REPO/.claude/skills/worktree-land/references/PROGRESS-template.md"
  [ -f "$PROGRESS_TEMPLATE" ] || PROGRESS_TEMPLATE="$MAIN_REPO/.agents/skills/worktree-land/references/PROGRESS-template.md"
fi
# ----------------------------------------------------------------------------

TASK="${1:?usage: worktree_bootstrap.sh <task> [<base>]}"
BASE="${2:-$DEFAULT_BASE}"
WT_DIR="$WORKTREES_ROOT/$TASK"

mkdir -p "$WORKTREES_ROOT"

# Ветка wt/<task> от базовой агентской ветки; упадёт, если ветка уже существует.
git -C "$MAIN_REPO" worktree add -b "wt/$TASK" "$WT_DIR" "$BASE"

# Симлинк общего окружения (venv/node_modules/... — каталог живёт в главном репо).
if [ -n "$ENV_DIR_NAME" ] && [ -e "$MAIN_REPO/$ENV_DIR_NAME" ]; then
  ln -s "$MAIN_REPO/$ENV_DIR_NAME" "$WT_DIR/$ENV_DIR_NAME"
fi

# Симлинк секретов (gitignored — без него ворктри рождается без учёток/токенов:
# TMS-обёртка и тесты падают).
if [ -n "$SECRETS_FILE_NAME" ] && [ -e "$MAIN_REPO/$SECRETS_FILE_NAME" ]; then
  ln -s "$MAIN_REPO/$SECRETS_FILE_NAME" "$WT_DIR/$SECRETS_FILE_NAME"
fi

# Meta-каталог задачи: base (читает /worktree-land и резолверы окружения) + PROGRESS-handoff.
META_DIR="$WT_DIR/.tasks/worktree-$TASK"
mkdir -p "$META_DIR"
printf '%s\n' "$BASE" > "$META_DIR/base"
if [ -f "$PROGRESS_TEMPLATE" ]; then
  cp "$PROGRESS_TEMPLATE" "$META_DIR/PROGRESS.md"
else
  echo "WARN: PROGRESS-шаблон не найден ($PROGRESS_TEMPLATE) — PROGRESS.md не засеян" >&2
fi

echo "Ворктри готов: $WT_DIR (ветка wt/$TASK от $BASE)"
echo "cd $WT_DIR"
