#!/usr/bin/env python3
"""Общий машинный контракт `.claude/toolkit-manifest.md`.

Файл импортируют `toolkit_update.py` и `codex_project.py`. Разбор полей, от которых
зависят baseline обновления и свежесть Codex-проекции, обязан жить в одном месте.
Чистый stdlib, плейсхолдеров нет; поставляется потребителю рядом с обоими скриптами.
"""
import argparse
import re


class ManifestContractError(ValueError):
    """Манифест нарушает машинный контракт."""


CORE_HASH_RE = re.compile(
    r"^\s*(?:-\s*)?Ядро:\s*(?:`([0-9a-fA-F]+)`|([0-9a-fA-F]+))(?=\s*(?:\(|$))",
    re.MULTILINE,
)
EQUAL_BRANCHES_MARKER = "ALLOW_AGENT_BRANCH_EQUALS_MAIN=true"
EQUAL_BRANCHES_RE = re.compile(
    rf"^\s*-\s*`{re.escape(EQUAL_BRANCHES_MARKER)}`:\s*\S.*$",
    re.MULTILINE,
)


def core_hash(text: str):
    """Hash из строки `Ядро:`: канонический с backticks или исторический без них."""
    match = CORE_HASH_RE.search(text)
    return (match.group(1) or match.group(2)).lower() if match else None


def _section(text: str, heading: str):
    match = re.search(
        rf"^## {re.escape(heading)}[^\n]*\n(.*?)(?=^## |\Z)",
        text,
        re.MULTILINE | re.DOTALL,
    )
    return match.group(1) if match else ""


def allows_equal_branches(text: str):
    """Только точный буллет-маркер в `Отступлениях`; свободная проза не считается."""
    return bool(EQUAL_BRANCHES_RE.search(_section(text, "Отступления")))


def validate_branch_model(anketa: dict, manifest_text: str):
    """Push-модель требует двух непустых разных веток либо явного machine override."""
    main = anketa.get("MAIN_BRANCH", "").strip()
    agent = anketa.get("AGENT_BRANCH", "").strip()
    missing = [name for name, value in (("MAIN_BRANCH", main), ("AGENT_BRANCH", agent))
               if not value]
    if missing:
        raise ManifestContractError(
            "В анкете манифеста не заполнены обязательные ветки: " + ", ".join(missing)
        )
    if main == agent and not allows_equal_branches(manifest_text):
        raise ManifestContractError(
            f"AGENT_BRANCH и MAIN_BRANCH обе равны {main!r}. Push-модель требует отдельную "
            "локальную агентскую ветку: создай её от интеграционной и поправь анкету. "
            "Осознанное исключение допускается только точным маркером "
            f"`{EQUAL_BRANCHES_MARKER}` в секции «Отступления от ядра»."
        )


def self_check():
    hash_cases = {
        "- Ядро: `deadBEEF12` (синк 2026-07-15)": "deadbeef12",
        "- Ядро: deadbeef12 (синк 2026-07-15)": "deadbeef12",
        "Ядро: `abc123`": "abc123",
    }
    bad_hashes = (
        "- Ядро: <commit-hash>",
        "- Ядро: ``",
        "- Ядро: `xyz123`",
        "- Ядро: deadbeef-notes",
        "- Ядро: `deadbeef",
    )
    for sample, expected in hash_cases.items():
        if core_hash(sample) != expected:
            print(f"✗ hash не разобран: {sample!r}")
            return 1
    for sample in bad_hashes:
        if core_hash(sample) is not None:
            print(f"✗ мусор ошибочно принят за hash: {sample!r}")
            return 1

    different = {"MAIN_BRANCH": "main", "AGENT_BRANCH": "at-creation"}
    validate_branch_model(different, "## Отступления от ядра\n")
    equal = {"MAIN_BRANCH": "future", "AGENT_BRANCH": "future"}
    try:
        validate_branch_model(equal, "## Отступления от ядра\n- обычная проза\n")
    except ManifestContractError:
        pass
    else:
        print("✗ равные ветки прошли без явного исключения")
        return 1
    try:
        validate_branch_model(
            equal,
            f"## Отступления от ядра\n- в тексте упомянут {EQUAL_BRANCHES_MARKER}\n",
        )
    except ManifestContractError:
        pass
    else:
        print("✗ свободная проза случайно отключила branch-гейт")
        return 1
    validate_branch_model(
        equal,
        "## Отступления от ядра\n"
        f"- `{EQUAL_BRANCHES_MARKER}`: проект осознанно работает без push-модели\n",
    )
    try:
        validate_branch_model({"MAIN_BRANCH": "main"}, "## Отступления от ядра\n")
    except ManifestContractError:
        pass
    else:
        print("✗ пустая AGENT_BRANCH прошла branch-гейт")
        return 1

    print("✓ manifest contract: оба hash-формата, строгий hex, разные ветки, "
          "отказ равных и точное исключение — зелёные.")
    return 0


def main():
    parser = argparse.ArgumentParser(description="Self-check контракта манифеста тулкита.")
    parser.add_argument("--self-check", action="store_true")
    args = parser.parse_args()
    if args.self_check:
        return self_check()
    parser.error("укажи --self-check")


if __name__ == "__main__":
    raise SystemExit(main())
