# Exclusion patterns

Полный список glob-паттернов, по которым `prepare-mr-branch` относит файл к **agent-files**
(Phase 2 классификации). Это «следы агентной работы», локальные/инструментальные артефакты,
а также файлы, которые по правилу пользователя не должны переноситься в MR без явного запроса.

<!-- Шаблон ядра. Блок «ядро» переносится как есть; блок «стек» подстраивается под раннер
(референс pytest+allure); блок «проектные политики» — решения конкретного проекта. -->

## Как сопоставлять

Для каждой строки из `git show --name-only --format= {sha}` берём путь и проверяем по каждому
pattern из таблицы ниже. Pattern сопоставляется как `fnmatch` с поддержкой `**` (рекурсивное
«любые сегменты»). Первый сматчившийся pattern определяет причину drop'а.

Файл всегда нормализуется к slash-форме (`tests/pages/chat.py`, не `tests\pages\chat.py`).

## Таблица паттернов — ядро

| Pattern | Категория | Причина |
|---|---|---|
| `.claude/**` | agent-config | Конфиги Claude Code: агенты, скиллы, скрипты, settings.local.json, worktrees |
| `.tasks/**` | skill-artifacts | Intermediate-файлы скиллов: state.md, analysis/locators, PROGRESS, скриншоты |
| `.idea/**` | ide-local | Конфиг JetBrains — индивидуальный, в проектный репо не идёт |
| `.vscode/**` | ide-local | Конфиг VS Code — индивидуальный |
| `**/.DS_Store` | os-junk | macOS thumbnail cache |
| `**/Thumbs.db` | os-junk | Windows thumbnail cache |
| `**/settings.local.json` | agent-config | Claude per-machine settings (permissions, env), не репо-уровня |
| `.envrc`, `.env.local` | local-deps | Локальные env-файлы |
| `secrets.yaml` | local-deps | Секреты — вне git по принципу ядра (DESIGN §1); сюда попасть не должен вовсе |
| `.gitignore` | gitignore-policy | По явному правилу пользователя skill **никогда** не трогает `.gitignore` в target без прямого запроса. Правка в mixed-коммите откатывается при amend |
| `CLAUDE.md` | agent-docs | Основной CLAUDE.md проекта — инфра/инструкции для агента. Всегда dropped, без вопросов |
| `CLAUDE.local.md` | agent-docs | Локальные дефолты пользователя, не коммитятся вообще |
| `**/CLAUDE.md` | agent-docs | Вложенные CLAUDE.md (subprojects) — тоже агентный артефакт |

## Таблица паттернов — стек (референс pytest+allure; подстроить)

| Pattern | Категория | Причина |
|---|---|---|
| `**/__pycache__/**` | build-artifacts | Python bytecode |
| `*.pyc`, `*.pyo` | build-artifacts | Скомпилированный Python |
| `**/allure-raw/**` | test-output | Сырые результаты прогона |
| `tests/logs/**` | test-output | Логи раннера |
| `report.xml` | test-output | JUnit-отчёт |
| `*.whl`, `*.tar.gz` | local-deps | Локально положенные пакеты (vendored-dep wheel рядом с venv) |
| `.playwright-cli/**` | skill-artifacts | Снимки страниц браузер-разведки: console/network-логи, скриншоты, page-снапшоты |

## Таблица паттернов — проектные политики (примеры из референса one-web)

| Pattern | Категория | Причина |
|---|---|---|
| `.tcs/**` | skill-artifacts | CSV-кеш выгрузки тест-кейсов из TMS |
| `.cursor/**` | agent-config | Наследие других агентских IDE |
| `docs/**` | project-docs | Пример **этапного** решения проекта: docs держится агентно-локально и не доставляется, пока команда не решила версионировать её в интеграционной ветке. Перед добавлением такой политики убедиться, что guard чист (на origin/{{MAIN_BRANCH}} директории нет) |

## Что НЕ в deny-list (намеренно)

- `README.md` — легитимный проектный документ. Переносим как обычно.
- Манифесты зависимостей (`requirements.txt` / `pyproject.toml` / аналоги) — проектная
  конфигурация. Переносим.
- Любые `*.md` внутри тестовых/инструментальных каталогов проекта — проектная документация.
- Конфиг раннера (`pytest.ini`, `conftest.py` / аналоги) — проектный.

## Как добавить новый паттерн

1. Перед добавлением — убедись, что pattern не матчит ни один **трекнутый в текущей
   интеграционной ветке** файл. Грубо: `git ls-files origin/{{MAIN_BRANCH}} | <fnmatch>`
   должен быть пуст.
2. Добавь строку в таблицу с категорией и одним предложением обоснования.
3. Pattern привязан к новому skill — категория `skill-artifacts` + имя skill'а.
4. Pattern — новый IDE / агент / external tool — категория `agent-config` или `ide-local`.

## Категории — пояснение

- **agent-config** — конфигурация Claude / прочих агентов. Никогда не нужна в проектном MR.
- **agent-docs** — markdown-инструкции для агентов (CLAUDE.md и варианты). Не идут в MR.
- **skill-artifacts** — побочный продукт работы скиллов. Можно безопасно удалить.
- **ide-local** — индивидуальная настройка рабочей машины.
- **build-artifacts** — результат компиляции / запуска.
- **test-output** — артефакты прогона тестов.
- **os-junk** — мусор от ОС.
- **local-deps** — локально подложенные зависимости (пакеты, env-файлы, секреты).
- **gitignore-policy** — `.gitignore`: скилл его никогда не трогает в target без явной
  команды пользователя.
- **project-docs** — проектные политики этапа (пересматриваются решением команды).
