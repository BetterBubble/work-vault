# Phase 5 — Cross-browser verification

После того как Phase 4 применила фикс, нужно убедиться, что:
1. Фикс закрыл падение на target-платформе.
2. Фикс **не сломал** другие браузеры.

<!-- Шаблон ядра. Механика (матрица «target ∪ verify-набор \ target», порядок, лимит 1 retry
на браузер, вердикты fixed/fixed_partial, правила параллелизма «разные машины — можно,
одна машина — нельзя», per-прогон каталоги артефактов) — generic. Конкретный verify-набор,
имена маркеров и single-session-правило — [test-stack], словарь-референс one-web,
маппится на конфигурации проекта при bootstrap. -->

Прогоны на браузерах **разных машин** grid'а (референс one-web: lin-selenoid / mac-selenoid / win-selenoid) можно вести **параллельно**; последовательно обязательны только прогоны, делящие одну машину (референс: win+win). При параллельном запуске каждому прогону — **свой** каталог сырых результатов `./allure-raw-{marker}` (CLI-опция раннера перекрывает конфиг): быстрый вердикт берём из stdout, а полные артефакты падения (скриншоты, расширенный лог) остаются в папке своего браузера. Последовательные прогоны пишут в общий `./allure-raw`, как раньше.

## Объём по классу правки

Полная матрица на каждый фикс не масштабируется на батчи в 15–35 тестов. Класс правки
предсказывает браузерозависимость — объём Phase 5 выводится из категории Phase 4 и
применённого playbook, а не решается ad-hoc:

| Класс правки (Phase 4) | Браузерозависимость | Объём Phase 5 |
|---|---|---|
| Замена селектора (`DOM_CHANGED`), i18n-строка | DOM один во всех браузерах | **target-браузер** |
| REST-гейт/композиция в тест-слое (готовность бэка), правка вызова API (`API_CONTRACT_CHANGED`) | кода браузера не касается | **target-браузер** |
| Регистрация/импорт (`IMPORT_OR_REGISTRY`) | структурная | **target-браузер** |
| Новый UI-шаг, интеракции: click/hover/scroll/send_keys-обходы (`UX_FLOW_CHANGED`) | зависят | **полная матрица** |
| Браузерные гарды, JS-workaround (`WEBDRIVER_QUIRK`); тайминги/ожидания (`FLAKY_TIMING`) | суть правки браузерная | **полная матрица** |

«Target-браузер достаточен» опирается на то, что cross-browser закрывают **плановые прогоны
проекта** (CI-матрицы win/safari) — правило неприменимо, если таких прогонов у проекта нет.
Выбор объёма и класс правки зафиксировать в `fix-{test}-crossbrowser.md`
(`cross-browser: skipped by fix-class (<класс>)`). Смешанная правка (селектор + новый шаг)
или сомнение в классе → полная матрица.

## Матрица браузеров *[test-stack]*

```
{target} ∪ <verify-набор проекта> \ {target}
```

Референс one-web: verify-набор = `{browser_lin_chrome, browser_win_firefox, browser_mac_safari}`. Примеры:
- target = `browser_lin_chrome` → `lin_chrome` (target) + `firefox` + `safari` = 3 прогона
- target = `browser_win_ya` → `ya` (target) + `lin_chrome` + `firefox` + `safari` = 4 прогона
- target = `browser_mac_safari` → `safari` + `lin_chrome` + `firefox` = 3 прогона

## Single-session правило *[test-stack]*

Однобраузерная single-session-платформа (референс: `browser_mac_safari`) пропускается, если тест мультисессионный (референс one-web: фикстура `setup_multiple_auts`; enforced хуком авто-маркировки в conftest):

```python
if 'setup_aut' in item.fixturenames and 'setup_multiple_auts' not in item.fixturenames:
    item.add_marker(pytest.mark.browser_mac_safari)
```

Skill узнаёт о фикстурах из `fix-{test}-analysis.md` (codebase-analyst inventory). Если в inventory указана мультисессионная фикстура — пропускаем single-session-платформу, записываем `N/A (multi-session)` в crossbrowser.md.

## Порядок прогонов

**Сначала target**, потом cross-browser. Браузеры verify-набора живут на разных машинах — после зелёного target их можно запускать **параллельно**. При последовательном запуске порядок: быстрые машины первыми, single-session-платформа — последней (референс: `lin_chrome → firefox → safari`).

## Команда (референс pytest)

```bash
{{RUNNER}} -k <test_name> -m <marker> --env {{DEFAULT_ENV}} --browser-tag current --tb=native --showlocals -p no:randomly
```

В cross-browser прогонах маркер передаём явно даже для дефолтной конфигурации (нужен конкретный браузер, а не дефолт); стек-специфичные флаги версий браузера — по словарю проекта (референс one-web: `--browser-tag` нужен только win-браузерам, остальные игнорируют — не мешает). При параллельном запуске добавь каждому прогону `--alluredir=./allure-raw-<marker>`.

Таймаут — 5 минут на прогон.

## Алгоритм для одного теста

```
1. Прогон target marker
   PASS → переход к cross-browser списку
   FAIL → 1 retry Phase 4 (точечная правка под target)
          если retry PASS → cross-browser
          если retry FAIL → FIX_NOT_APPLIED, выходим из теста, переход к следующему

2. Для каждого browser из cross-browser списка (последовательно):
   Прогон marker
   PASS → ✅ записать в crossbrowser.md
   FAIL → 1 retry Phase 4 (точечная правка под этот browser, обычно браузерный гард)
          если retry PASS → ✅
          если retry FAIL → ❌ записать в crossbrowser.md как «не починили», но не зацикливаться. Переходим к следующему browser в матрице.

3. Подытожить статус теста:
   - если все 3-4 браузера PASS → fixed
   - если target PASS + один-два cross-browser FAIL → fixed_partial (в отчёт с предупреждением)
   - если target FAIL → НЕ fixed, в escalation
```

**Лимит**: 1 retry Phase 4 на браузер. Не зацикливаемся.

## Что писать в `fix-{test}-crossbrowser.md`

```markdown
# Cross-browser verification — {test_name}

## Матрица результатов

| Browser | Marker | Прогон 1 | Retry P4? | Финал | Время |
|---|---|---|---|---|---|
| Chrome (target) | browser_win_chrome | PASS | — | ✅ PASS | 2m18s |
| Lin Chrome | browser_lin_chrome | FAIL (NoSuchElement L_SEND) | yes — добавлен JS-scroll гард | ✅ PASS | 2m44s + 2m12s |
| Firefox | browser_win_firefox | PASS | — | ✅ PASS | 2m31s |
| Safari | browser_mac_safari | N/A (multi-session) | — | пропущен | — |

## Финальный вердикт
✅ FIXED (3/3 применимых браузера PASS)

## Артефакты прогонов
- ./allure-raw (последний прогон) → safari N/A, остальные — passed
- логи: см. stdout раннера в `.tasks/work/batch-{ts}/fix-{test}-pytest-{marker}.log` если сохранены
```

или в случае partial fix:

```markdown
## Финальный вердикт
⚠️ FIXED_PARTIAL — Firefox остаётся FAIL после retry

## Что не помогло в Firefox
- Прогон 1: TimeoutException на ожидании кнопки
- Retry с js-clickable-wait: тот же таймаут
- Гипотеза: специфика Firefox-driver для contenteditable; нужен глубже разбор, не зацикливаемся
- Перенесено в Phase 6 как AUTOMATION_ONLY для Firefox
```

## Параллелизм

Разрешён между браузерами **разных машин** (решение проекта-референса): дефолтный браузер (основная grid-машина) + firefox (вторая машина) + safari (третья машина) можно гнать одновременно — wall-clock этапа сжимается до самого медленного прогона.

Ограничения:
- браузеры одной машины (референс: win-браузеры между собой) — только последовательно: один grid-хост, конкуренция за ресурсы = флаки.
- single-session-платформа выдаёт одну сессию за раз — два параллельных прогона на ней не бывает.
- артефакты: при параллели каждому прогону свой `--alluredir=./allure-raw-{marker}` — иначе результаты смешаются и скриншоты/логи падений нельзя будет атрибутировать браузеру. Папки временные (следующий прогон перезаписывает, в архивные копии не складываем — правило проекта-референса «no allure-raw archive on verify»); при падении разбор ведём по папке упавшего браузера, не только по stdout.

## Time budget

Один тест × 3-4 браузера × ~3 мин = ~12 минут последовательно. Параллельный запуск тройки разных машин сжимает этап до самого медленного прогона (~3-4 мин на тест). Для batch'и из 5 тестов — 20-60 минут в зависимости от параллелизма. **Это нормально**.

Бюджет режется правилом «Объём по классу правки» (секция выше): браузеронезависимые фиксы матрицу не гоняют по построению. Для классов, требующих полной матрицы, cross-browser обязателен — «по-быстрому» его не срезает.
