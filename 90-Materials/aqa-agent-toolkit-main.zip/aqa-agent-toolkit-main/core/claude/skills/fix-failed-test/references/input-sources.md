# Источники информации о падении

Skill принимает пять типов входа. Распознавание — по содержанию пользовательского сообщения и аргументов.

<!-- Шаблон ядра. Механика распознавания веток и нормализации в «список тестов» — generic.
Форматы конкретных источников — по контрактам адаптеров: сырые результаты и запуск раннера —
adapters/test-stack/ (референс: reference-pytest-selenium/{allure-raw-parser,pytest-runner}.md),
ланч TMS — adapters/tms/ (референс: reference-allure-testops/launch-parser.md).
{{PYTHON}}/{{RUNNER}}/{{TMS}} — плейсхолдеры bootstrap. -->

**Все источники** превращаются в **список тестов** длиной от 1. `pytest-run` и `stack-trace-parse` — частные случаи batch'а длиной 1. `allure-raw-parse` и `launch-parse` — источники, где список может быть длиннее. `tc-diff` (diff-bundle) — особый вход: триггер не падение, а **расхождение TC↔код** (приходит из `/update-autotest`); минует repro-фазы.

## 1. Имя теста / TC-id (ветка `pytest-run`)

Признак: пользовательский ввод содержит **только** имя функции (`test_<...>`) или TC-id, и **не содержит** ни stack trace, ни путь к директории.

Примеры:
- `/fix-failed-test test_channel_edit_avatar_visible`
- `/fix-failed-test test_chat_send_receive_message`
- `/fix-failed-test 925` (TC-id)

В этой ветке skill **сам запускает** раннер (по контракту test-stack; референс: `{{TOOLKIT}}/adapters/test-stack/reference-pytest-selenium/pytest-runner.md`).

Если дан TC-id (число) — найти тест по id в метаданных теста (контракт tms «Идентификация автоматизации»; референс: `@allure.id`):
```bash
grep -r "@allure.id(\"<id>\")" tests/
```
Результат — имя файла и тестовой функции.

### Обогащение через CLI-обёртку TMS-порта (опционально)

После того как TC-id известен (из аргумента, или вытащен grep'ом по метаданным в тестах), можно read-only подтянуть бизнес-сценарий из {{TMS}} (операция `get` по {{TOOLKIT}}/adapters/tms/CONTRACT.md):

```
{{TMS_CLI}} get <tc_id>
```

Когда это полезно:
- **Phase 3 (Manual walkthrough)** — сверить «что должен делать пользователь» по TC vs «что делает тест». Если шаги расходятся (например, в TC появился новый шаг подтверждения, а тест его не учитывает) — это сразу гипотеза `UX_FLOW_CHANGED`.
- **Phase 7 (комментарии для issue-трекера)** — Feature/Story из custom fields для маркировки коммента, URL тест-кейса сразу из ответа.

Если TMS-модуль вернул ошибку / TC не найден / у TC нет шагов — пропустить enrichment, не блокировать pipeline. Это **необязательный** шаг.

## 2. Stack trace в чате (ветка `stack-trace-parse`)

Признак: в сообщении пользователя есть одна из строк (референс pytest+Selenium):
- `Traceback (most recent call last):`
- `File "tests/...", line N`
- имя exception-класса драйвера (`selenium.common.exceptions.<ExceptionType>`)
- `E   `... + exception message

Здесь skill **не запускает раннер** на Phase 0 — берёт данные из текста. Перезапуск произойдёт только на верификации (Phase 5).

Что вытаскивать из stack trace:
- имя файла теста и тестовой функции (последний кадр в тест-файлах)
- последний кадр в page/chunk/locators-слое — это эпицентр
- класс exception и его сообщение
- селектор из сообщения exception (если есть) — «Unable to locate element using xpath: //...»

См. подробный парсинг в `failure-localization.md`.

## 3. Директория сырых результатов прогона (ветка `allure-raw-parse`)

Признак: пользовательский ввод содержит существующий путь к директории, в которой есть файлы `*-result.json`.

Примеры:
- `/fix-failed-test ./allure-raw`
- `/fix-failed-test <абсолютный путь>/allure-raw`

Проверка: `Glob` по `<path>/*-result.json`. Если хоть один файл найден — ветка распознана.

В этой ветке skill парсит JSON-ы, ищет файлы со `status:"failed"`. Если их несколько — спросить пользователя через `AskUserQuestion`:

> Найдено N упавших тестов: {short list}. Что фиксить?
> - **все по очереди в batch'е** (Recommended)
> - выбрать подмножество (укажу имена)
> - один конкретный

Дефолт — «все по очереди». Все последующие фазы итерируются по выбранному списку — см. `batch-discovery.md`.

Формат JSON — по контракту адаптера test-stack (референс: `{{TOOLKIT}}/adapters/test-stack/reference-pytest-selenium/allure-raw-parser.md`).

## 4. Ланч {{TMS}} (ветка `launch-parse`)

Признак: пользовательский ввод содержит URL ланча {{TMS}} или команду вида `launch <id>` / `ланч <id>`.

Примеры:
- `/fix-failed-test <URL ланча {{TMS}}>`
- `/fix-failed-test launch 726`

В этой ветке skill читает ланч read-only через CLI-обёртку TMS-порта (без локальных сырых результатов) и формирует список **всех не-зелёных** результатов (операция `launch` по {{TOOLKIT}}/adapters/tms/CONTRACT.md):

```bash
{{TMS_CLI}} launch <id> --attachments .tasks/work/batch-{ts}/launch-att --json
```

Разбор JSON, маппинг в список тестов и развилка по `kind` (failed/broken/xpass → фикс-пайплайн; xfail → верификация места падения; skipped → только список) — по контракту адаптера tms (референс: `{{TOOLKIT}}/adapters/tms/reference-allure-testops/launch-parser.md`). Если N>1 — спросить через `AskUserQuestion` («все по очереди» — дефолт), как в `allure-raw-parse`.

## 5. diff-bundle от /update-autotest (ветка `tc-diff`)

Признак: вход содержит **имя теста + структурированную дельту «TC↔код»** (не stack trace, не падение). Приходит из `/update-autotest` (minor-маршрут), когда тест-кейс в {{TMS}} изменился и тест надо привести в соответствие. Триггер — **расхождение, а не падение**: тест может быть зелёным на старом сценарии.

Вход:
- `test_path` + `test_name` + `tc_id`;
- **дельта** (из `.tasks/work/update-{id}/diff.md`): added/removed/reordered шаги, изменённые expected→assert, дифф метаданных, protected-список (skip/xfail/стабилизации/дивергентные локаторы — НЕ трогать).

Отличия ветки от обычного фикс-пайплайна:
- **Минует Phase 1–3** (reproduce target / local / manual walkthrough) — воспроизводить нечего, цель не «повторить падение», а «привести код к свежему TC».
- **Phase 4 — delta-driven, не taxonomy-driven.** Failure-таксономия не применяется; спецификация правки = сама дельта. Делегирование: `codebase-analyst` (mode=fix) inventory → при DOM-дельте (новый/изменённый шаг требует нового локатора) `dom-explorer` (mode=fix) → `code-writer` **хирургически** применяет дельту (add/remove/reorder шагов-логирования + соответствующие page/chunk-вызовы, правка assert'ов, i18n-ключи). Дефолт — хирургия, **не** rewrite.
- **expected-дельта строже action-дельты:** изменённый/добавленный expected → обязательно правка `assert`, не косметика.
- **Гарды:** protected-список из дельты переносится дословно; дивергентные локаторы другой линии *[dual-line]*, skip/xfail, стабилизации — не трогать (см. `/update-autotest` → `references/diff-routing-guards.md`).
- **Phase 5 — только дефолтная конфигурация** (усечён; кросс-браузер — работа пайплайна). Критерий: PASS на свежем сценарии И дельта реально применена.
- Красный после правки → обычный фикс-пайплайн (это уже настоящее падение). Маскировка `skip`/`xfail` запрещена.

Phase 6 (deferred) и Phase 7 (batch-report) — как обычно; в отчёте помечать, что вход был `tc-diff` (ресинк под изменённый TC), а не падение.

## Если входной артефакт нечитаем

- раннер не запустился (нет окружения, env-переменные не заданы) → сообщить пользователю и остановиться. Не «фиксить» отсутствие окружения.
- Stack trace в чате обрезанный (нет имени теста и нет пути к файлу) → попросить пользователя дать полный traceback или имя теста для перезапуска.
- В директории сырых результатов нет `failed`-результатов → сообщить «все тесты в этой директории прошли, нечего фиксить».

## Формат `fix-{test_name}-failure.md`

```markdown
# Failure bundle: {test_name}

## Метаданные
- test_path: tests/test_chat.py
- test_name: test_channel_edit_avatar_visible
- tc_id: 925
- источник: pytest-run | stack-trace-parse | allure-raw-parse

## Exception
- class: selenium.common.exceptions.NoSuchElementException
- message: Unable to locate element using xpath: //chat-sidebar//input[@type="file"]

## Stack trace
```
File "tests/test_chat.py", line 1314, in test_channel_edit_avatar_visible
    info_channel_profile.upload_avatar(avatar_file_name)
File "tests/pages/chunks/chat_profile_base.py", line 142, in upload_avatar
    file_input = self.driver.find_element(*self.L_AVATAR_UPLOAD_INPUT())
...
```

## Скриншот (если есть)
- путь: ./allure-raw/<uuid>-attachment.png (из сырых результатов)

## Связанные шаги сценария (если есть)
- step 3.1 "Загрузить аватар" → failed
- предыдущий пройденный шаг: step 3 "Открыть профиль чата"
```
