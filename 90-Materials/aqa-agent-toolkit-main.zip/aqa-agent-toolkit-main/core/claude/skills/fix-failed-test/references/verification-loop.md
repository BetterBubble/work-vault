# Verification: цикл проверки фикса (Phase 5)

Phase 5 = single-browser verification + cross-browser. Этот файл описывает single-browser-цикл (target). Cross-browser детально — в `cross-browser-verification.md`.

<!-- Шаблон ядра. Механика (лимит 2 итераций per-test, критерий «тот же эпицентр»,
вердикты PASSED/FIX_NOT_APPLIED/ESCALATED, идемпотентность артефактов) — generic.
Команды раннера — контракт test-stack, {{RUNNER}}/{{DEFAULT_ENV}} — плейсхолдеры. -->

## Зачем нужен лимит

Без лимита skill может бесконечно фиксить одну ошибку за другой, особенно при множественных проблемах в одном тесте. Лимит — **2 итерации фаз 3-4 на один тест**. После — эскалация пользователю, без права редактировать дальше.

Лимит — **per-test**, не глобальный для batch'и. Если в batch'е 5 тестов и каждый требует 2 итерации — это нормально.

## Алгоритм single-browser (target)

```
итерация := 1

ПОВТОРЯТЬ:
    запустить раннер на target marker (по контракту test-stack; референс:
    {{TOOLKIT}}/adapters/test-stack/reference-pytest-selenium/pytest-runner.md)

    ЕСЛИ PASS:
        перейти к cross-browser (cross-browser-verification.md)
        выйти из single-browser цикла

    ЕСЛИ FAIL:
        вытащить новый эпицентр и exception

        ЕСЛИ эпицентр (file:line) тот же, что в предыдущей итерации:
            playbook не сработал
            записать fix-{test}-crossbrowser.md с итогом FIX_NOT_APPLIED
            тест → escalation
            выйти

        ЕСЛИ эпицентр другой:
            это новая проблема
            итерация := итерация + 1

            ЕСЛИ итерация > 2:
                лимит достигнут
                записать fix-{test}-crossbrowser.md с итогом ESCALATED (limit reached)
                тест → escalation
                выйти

            иначе:
                повторить Phase 3 (manual walkthrough, если нужно), Phase 4 (taxonomy + apply)
```

После single-browser PASS — переход в **cross-browser-verification** (`cross-browser-verification.md`): прогон поочерёдно по verify-набору проекта `\ {target}` (референс one-web: `{ya, firefox, safari}`). На FAIL отдельного браузера — 1 retry Phase 4. Не зацикливаемся.

## Что считать «тем же эпицентром»

Эпицентр = `(file, line)` последнего «нашего» кадра (из `failure-localization.md`).

- Тот же `(file, line)` → playbook не помог (либо локатор всё ещё не находится, либо метод всё ещё падает).
- Другой `(file, line)` в том же файле → новая проблема в том же модуле (вероятно, того же класса).
- Другой файл → новая проблема в другом модуле.

## Если первая итерация PASS

Skill завершается на верификации с итогом `PASSED`. Финальный отчёт — обязательный, даже при success: показать пользователю, что было сделано.

## Если первая итерация FAIL в той же точке

`FIX_NOT_APPLIED`. Возможные причины:
- Code-writer не применил Edit (например, не нашёл `old_string` из-за изменений в файле между чтением и записью). Проверить diff через `git diff`.
- Был выбран неправильный playbook (например, для `DOM_CHANGED` локатор обновили, но проблема была не в локаторе).

В отчёте указать diff попыток + предложить пользователю расширенный traceback и ручную диагностику.

## Если первая итерация FAIL в другой точке

Это нормальный случай каскадного фикса: после починки одного, тест продвинулся дальше и упал в новой точке. Идём на 2-ю итерацию.

## Лимит = 2 — почему

- 1 итерации мало: каскадные проблемы (DOM_CHANGED → UX_FLOW_CHANGED) не закрываются за один прогон.
- 3+ итераций — высокий риск, что skill «правит не то». Лучше попросить пользователя.

Лимит **жёсткий**: даже если 3-я итерация уже почти PASS — выходить и сообщать.

## Per-test итог Phase 5

Single-browser результат записывается в `fix-{test}-crossbrowser.md`. Глобальный batch-отчёт собирается в Phase 7 (см. `batch-report.md`).

## Формат per-test записи на разных итогах

### PASSED
```markdown
# Single-browser verification — {test_name}

## Итог
PASSED ✅

## Категории и фиксы (по итерациям)
| Итерация | Категория | Файл | Что изменено |
|---|---|---|---|
| 1 | DOM_CHANGED | <файл локаторов page/chunk> | L_AVATAR_UPLOAD_INPUT — селектор обновлён |

## Команды для подтверждения
{{RUNNER}} -k {test_name} -m <target_marker> --env {{DEFAULT_ENV}} --browser-tag current
(таблица маркеров и правило выбора браузера — референс {{TOOLKIT}}/adapters/test-stack/reference-pytest-selenium/pytest-runner.md)
```

### FIX_NOT_APPLIED
```markdown
# Single-browser verification — {test_name}

## Итог
FIX_NOT_APPLIED ❌ (фикс применён, но тест падает в той же точке)

## Что было сделано
| Категория | Файл | Изменение |
|---|---|---|
| DOM_CHANGED | ... | ... |

## Что НЕ помогло
Тест падает в `{file}:{line}` с тем же exception: `{class}: {msg}`.
Возможные причины: см. {ссылка на failure-taxonomy подраздел}

## Что попробовать
- Запустить вручную в том же браузере, где было падение: `{{RUNNER}} -k {test_name} -m <target_marker> --env {{DEFAULT_ENV}} --browser-tag current --tb=long --capture=no`
- Перезапустить /fix-failed-test с полным traceback (ветка stack-trace-parse)
```

### ESCALATED (limit reached)
```markdown
# Single-browser verification — {test_name}

## Итог
ESCALATED ⚠️ (достигнут лимит 2 итераций)

## Итерации
### Итерация 1
- Категория: DOM_CHANGED
- Эпицентр: ...
- Фикс: ...

### Итерация 2
- Категория: UX_FLOW_CHANGED
- Эпицентр: ...
- Фикс: ...

## Текущее состояние
Тест падает в `{file}:{line}` с exception `{class}`. Это уже 3-я проблема в тесте.

## Рекомендация
Сценарий теста, видимо, существенно изменился. Стоит рассмотреть переписывание теста через /write-autotest, начиная с актуального тест-кейса из {{TMS}}.
```

### NEEDS_DEP / NEEDS_USER
См. `fix-playbooks.md` соответствующие категории.

## Идемпотентность

Все `.tasks/work/batch-{ts}/fix-{test_name}-*.md` перезаписываются при каждой итерации внутри одного прогона skill. Каждый новый запуск skill создаёт **новую** batch-директорию (с новым timestamp), поэтому старые прогоны не затираются.

После завершения работы и применения коммита — артефакты можно удалить: `rm -rf .tasks/work/batch-*`.
