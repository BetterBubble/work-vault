# Локализация падения по stack trace

Цель — из stack trace вытащить эпицентр падения: тестовая функция → page/chunk метод → локатор.

<!-- Шаблон ядра. Механика (эпицентр = последний «наш» кадр; mapping эпицентр → подозреваемая
сущность по ролям POM-контракта; корреляция trace ↔ log; chained exceptions) — generic.
Формат trace и regex — [test-stack]-референс Python/pytest+Selenium; каталоги тест-слоя —
референс one-web (роли — по adapters/test-stack/CONTRACT.md, маски путей маппятся на проект). -->

## Формат stack trace (референс Python)

```
Traceback (most recent call last):
  File "tests/test_chat.py", line 1314, in test_channel_edit_avatar_visible
    info_channel_profile.upload_avatar(avatar_file_name)
  File "tests/pages/chunks/chat_profile_base.py", line 142, in upload_avatar
    file_input = self.driver.find_element(*self.L_AVATAR_UPLOAD_INPUT())
  File "venv\Lib\site-packages\selenium\webdriver\remote\webdriver.py", line 738, in find_element
    return self.execute(Command.FIND_ELEMENT, {"using": by, "value": value})['value']
  ...
selenium.common.exceptions.NoSuchElementException: Message: no such element: Unable to locate element: {"method":"xpath","selector":"//chat-sidebar//input[@type=\"file\"]"}
```

## Парсинг (regex, референс Python)

### Извлечение кадров

```
^\s*File "(?P<file>[^"]+)", line (?P<line>\d+), in (?P<func>\w+)$
```

Каждый кадр содержит file/line/function. Идём **сверху вниз** (от внешнего вызова к внутреннему).

### Фильтр кадров «нашего кода»

Интересны только кадры, у которых `file` начинается с префикса тест-слоя проекта:
- `tests/` (или `tests\` на Windows)
- НЕ каталог окружения/библиотек (референс: `venv/` — код драйвера и зависимостей, не наш)

В примере выше «наши» кадры:
1. `tests/test_chat.py:1314` — `test_channel_edit_avatar_visible`
2. `tests/pages/chunks/chat_profile_base.py:142` — `upload_avatar`

### Извлечение exception

Последняя строка trace:
```
^(?P<exc_class>[\w.]+(?:Exception|Error)): (?P<msg>.*)$
```

Или с префиксом `Message:`:
```
^[\w.]+Exception: Message: (?P<msg>.*)$
```

В примере: `exc_class = selenium.common.exceptions.NoSuchElementException`, `msg = no such element: Unable to locate element: {...}`.

### Извлечение селектора из сообщения драйвера

```
"selector":"(?P<xpath>[^"]+)"
```

или

```
Unable to locate element using xpath: (?P<xpath>.+)$
```

В примере: `xpath = //chat-sidebar//input[@type="file"]`.

## Что считается эпицентром

Эпицентр = **последний наш кадр** в стеке (самый глубокий внутри тест-слоя, не считая библиотек).

В примере эпицентр:
- `file = tests/pages/chunks/chat_profile_base.py`
- `line = 142`
- `function = upload_avatar`

## Mapping эпицентра → подозреваемые сущности

Роли — по POM-контракту test-stack; маски путей — референс one-web, маппятся на структуру проекта:

| Файл эпицентра | Подозреваемая сущность |
|---|---|
| файлы локаторов (`tests/pages/locators/**`) | локатор |
| chunk-слой (`tests/pages/chunks/**`) | метод chunk-объекта + локаторы, которые он использует |
| page-слой (`tests/pages/<page>.py`) | метод page-объекта + локаторы, которые он использует |
| тест-файлы (`tests/test_*.py`) | сам тест (например, плохой ассерт или неправильный вызов API) |
| реестры page/chunk (`__init__.py` слоёв) | реестр (`get_page`/`get_chunk`) |

Подозреваемые сущности записываются в `fix-{test_name}-analysis.md` (заполняет `codebase-analyst`) и затем используются в `failure-taxonomy.md` для классификации.

## Если stack trace отсутствует или обрезан

- Нет ни одного «нашего» кадра в стеке → exception, скорее всего, в фикстуре / сборе тестов (конфигурация раннера, `ImportError` на старте). Эпицентр — тест-файл или конфигурация раннера (если упоминается).
- Кадры есть, но имени функции нет → возможно, ошибка в импортах. Считать эпицентром файл из самого нижнего кадра в тест-слое.
- Только одна строка с exception, без `Traceback:` → попросить пользователя вставить полный traceback или указать имя теста для перезапуска.

## Корреляция с log-attachment

Stack trace показывает **где** упало (file:line). Log-attachment часто показывает **с каким значением**. Эти два источника читаются вместе:

1. Из stack trace получаем эпицентр (например, `tests/pages/chat.py:431` в `assert_link_redirect_correct`).
2. Из лога ищем строки, упомянутые в коде эпицентра. Например, в этом методе есть `log.info(f'Текущий url: "{cur_url}"')` — значит в логе будет `INFO chat.py:431 Текущий url: "..."` с **реальным значением**, на котором упал ассерт. Это превращает «assert не сработал» в «assert не сработал потому что URL = `about:blank`».
3. Алгоритм связки:
   - В коде эпицентра найти вызовы логирования (`log.info(...)`, `log.debug(...)`, `log.step(...)`) — это шаблоны строк, которые попали в лог.
   - В файле лога grep'ом по этим шаблонам найти **реальные значения** в момент падения (`grep -n '<pattern>' <log_file>`).
   - Записать найденное в `fix-{test_name}-failure.md` секцию «Лог (выдержка)».

Сканирование log-attachment — по контракту адаптера test-stack (референс: `{{TOOLKIT}}/adapters/test-stack/reference-pytest-selenium/allure-raw-parser.md`, секция «Сканирование log-attachment»).

## Особый случай: множественные exceptions (chained)

В trace часто видно (референс Python):
```
During handling of the above exception, another exception occurred:
```

В этом случае брать **последний** Traceback (он обычно более конкретный), но в `fix-{test_name}-failure.md` сохранять оба для контекста.
