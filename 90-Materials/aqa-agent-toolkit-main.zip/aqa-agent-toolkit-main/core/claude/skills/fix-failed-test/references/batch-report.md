# Phase 7 — Final batch report

Финальный артефакт `/fix-failed-test`. Должен быть полностью «копируемым» — из него пользователь без дополнительных вопросов:
- Прикладывает комментарий issue-трекера к каждому фиксу/workaround'у;
- Создаёт баг в issue-трекере по каждому `PRODUCT_BUG` в нужном формате;
- Видит, что осталось в эскалации, и почему.

<!-- Шаблон ядра. Структура отчёта, чек-лист обязательного, анти-«вода» и инвариант ledger —
generic. Примеры команд/URL — [test-stack]/[browser-driver]-референс one-web; issue-трекер —
референс Jira. {{RUNNER}}/{{PYTHON}}/{{DEFAULT_ENV}} — плейсхолдеры. -->

## Имя файла

`.tasks/work/batch-{timestamp}/fix-batch-{timestamp}-report.md`

## Структура

```markdown
# Fix batch report — {timestamp}

## Summary
- Источник: {pytest-run | stack-trace-parse | allure-raw-parse}
- Путь к сырым результатам (если есть): ...
- Тестов всего: N
- ✅ Исправлено: K (target PASS + cross-browser применимое PASS)
- ⚠️ Partial: K_partial (target PASS, но один из cross-browser FAIL)
- 🐌 Flaky стабилизированы: F_ok / F
- 🤖 Automation-only с workaround: A_ok / A
- 🐛 Product bugs (требуют issue): P
- 🚨 Escalation (без решения): E
- 📦 Покрыто недоставленным фиксом: C (только launch-parse при local_ahead)
- 🏚 Стенд-инцидент: S (окно {HH:MM}-{HH:MM}, кода не касались)
- ♻ Известные баги подтверждены: K (сигнатура совпала с .tasks/known-issues.md, без полного разбора)

## Изменённые файлы (только staged, НЕ закоммичено)
| Файл | Тесты, для которых правлено |
|---|---|
| tests/pages/chat.py | test_a, test_b |
| <общий модуль хелперов> | test_c |

Команда для review:
```bash
git status; git diff --staged
```
После проверки — `git commit` (вручную, не скиллом).

---

## Комментарии для issue-трекера (по тесту)

### ✅ test_xxx_yyy — FIXED
- Категория: `WEBDRIVER_QUIRK`
- Что произошло: Safari WebDriver не активирует virtual-scroll после программного клика — новое сообщение виртуализируется и ассерт присутствия не находит элемент.
- Что изменено:
  - `tests/pages/chat.py:431` — после `send` добавлен JS-скролл-хелпер с гардом `if self.driver.name in ['safari', 'firefox']`
- Локаторы — все актуальны (проверено dom-explorer).
- Cross-browser verification:
  - chrome PASS, ya PASS, firefox PASS, safari PASS
- Команда верификации:
  ```bash
  {{RUNNER}} -k test_xxx_yyy -m browser_mac_safari --env {{DEFAULT_ENV}} --browser-tag current
  ```

### ✅ test_qqq — STABILIZED (was flaky)
- Категория: `NON_REPRODUCIBLE_FLAKY` → стабилизировано
- Гипотеза причины: гонка с async-render — клик до завершения hydration компонента
- Что добавлено: js-clickable-wait перед кликом в `tests/pages/chunks/chat_profile_base.py:88`
- Cross-browser verification: полная матрица (js-wait — браузерозависимый класс правки): chrome PASS, firefox PASS, safari PASS
- Команда верификации:
  ```bash
  {{RUNNER}} -k test_qqq -m browser_lin_chrome --env {{DEFAULT_ENV}}
  ```

### ⚠️ test_zzz — DEFERRED (automation-only, без workaround)
- Категория: `AUTOMATION_ONLY`
- Что пробовали:
  1. JS-click (`execute_script('arguments[0].click()')`) — retry FAIL (тот же TimeoutException на следующем шаге)
  2. API-bypass через REST-обёртку продукта — retry FAIL (UI-wait на receive не находит сообщение)
- Почему не помогло: симптом не воспроизводится руками ни в CLI разведки, ни в driver-скрипте; обходы не закрывают исходное падение
- Рекомендация: проверить, не помечен ли тестовый юзер как «подозрительный» в anti-abuse эвристиках стенда

### 🐛 test_www — PRODUCT_BUG (не правим, см. секцию Product bugs)

---

## Product bugs (кандидаты для issue-трекера)

По каждому подтверждённому багу — **каталог-кандидат** в `.tasks/jira-candidates/`
(внутри `draft.md` + копии всех артефактов: скриншоты, лог-выдержки; формат и
именование `<NNN>-TC-<XXXXX>-<slug>/` — `.claude/skills/_shared/jira-candidates.md`).
Секция отчёта — только указатели:

### Bug 1 — Кнопка «Отправить» в редакторе сообщения не реагирует на клик
- Кандидат: `.tasks/jira-candidates/007-TC-53241-edit-message-send-noop/` (скопировать
  Summary + описание из `draft.md` в трекер как есть; артефакты — в том же каталоге)
- Тесты, ловящие регресс: test_chat_edit_message_keep
- VNC live (если ещё активна): <URL live-сессии инструмента>

### Bug 2 — ...

---

## Покрыто недоставленным фиксом (если корзина непуста)

- Ветка ланча: `{branch}`; недоставленные коммиты: `{sha list}` (`git log origin/{branch}..HEAD`)
- Тесты: {test → каким коммитом покрыт}
- **Действие:** доставить фиксы (MR/merge) до следующего CI-прогона; правок в этой batch'е
  по этим тестам нет намеренно (код уже починен).

## Стенд-инцидент (если корзина непуста)

- Окно: {HH:MM}-{HH:MM} {дата}; симптомы: {502/503, пустая IdP-страница, ...}
- Тесты-жертвы: {list} — одна запись на окно, не N диагнозов
- Подтверждение: repro-PASS вне окна, дифф ревизии чист
- Рекуррентность: {первое окно / N-е за неделю → рекомендация issue на стенд}

## Известные баги подтверждены (если корзина непуста)

- {test → Issue → дата первого диагноза (строка .tasks/known-issues.md)} — сигнатура
  совпала, полный разбор не выполнялся (references/known-issues.md)
- Снятые с реестра (green в этом прогоне): {list или «нет»}

## Deferred (escalation — решения не найдено)

### test_aaa — FLAKY без стабилизации
- Попыток стабилизации: 2 (js-clickable-wait → ожидание появления 15s)
- Обоснование: тест зависит от состояния общего пользователя, что приводит к non-deterministic порядку сообщений; рефактор setup-фикстуры под dedicated user — out-of-scope для текущей batch'и
- Рекомендация: завести задачу на refactor setup-фикстуры для этого теста

### test_bbb — AUTOMATION_ONLY без workaround
- Попыток workaround'ов: 2
- Обоснование: ...
- Рекомендация: ...

---

## Отступления от протокола скилла

Систематические трения батча (шаг скилла неясен/неверен/избыточен, пришлось отступить).
Каждая строка — с исходом связывания (инвариант — `.claude/skills/_shared/ledger-and-deviations.md`):

- {отступление, одной строкой} → outbox: {ссылка на .tasks/toolkit-feedback/<файл>.md |
  запись создана этим шагом: <файл>.md | локальная причуда инсталляции, не для ядра}

Отступлений не было → одна строка «отступлений нет».

---

## Helper-скрипты для ручной проверки *[browser-driver]*

Если хочешь повторить ручной разбор сам (референс one-web):

```bash
# Через VNC посмотреть Safari-сессию
{{PYTHON}} .claude/scripts/selenoid_mac_safari.py --file .tasks/work/batch-{ts}/manual_test_chat_edit_message_keep.py

# Через Firefox-driver-скрипт
{{PYTHON}} .claude/scripts/selenoid_win_firefox.py --script "drv.get('<web_url стенда>'); print(drv.title)"
```

## Очистка артефактов

После применения коммита и закрытия задач в issue-трекере:
```bash
rm -rf .tasks/work/batch-{ts}
```
```

## Что обязательно должно быть в отчёте

- [ ] Summary с числами (тестов / fixed / deferred / product_bugs / escalation).
- [ ] Список staged-файлов с обратной связью «какие тесты затронуты».
- [ ] **Для каждого fixed-теста**: категория, краткое «что произошло», точный файл:строка правки, cross-browser-матрица, команда верификации.
- [ ] **Для каждого PRODUCT_BUG**: каталог-кандидат в `.tasks/jira-candidates/` (`draft.md`: Summary + Окружение / Шаги / ФР / ОР / примечания в разметке трекера; артефакты скопированы в каталог) — `.claude/skills/_shared/jira-candidates.md`; в отчёте — ссылка на кандидата.
- [ ] **Для каждого deferred-в-escalation**: список попыток, обоснование почему не решено, рекомендация для пользователя.
- [ ] Команды для повторного запуска helper-скриптов (если пользователь захочет руками проверить).
- [ ] **Строка метрик** в `.tasks/metrics.jsonl` на каждый тест с финальным исходом (только standalone-запуск; инвариант — секция «Ledger метрик» ниже).
- [ ] **Секция «Отступления от протокола скилла»**: каждая строка — с исходом связывания (ссылка на запись outbox / запись создана этим шагом / «локальная причуда»); строка без исхода = отчёт не закрыт (SKILL Phase 7).

## Чего НЕ должно быть в отчёте

- ❌ «Воды»: «было непросто», «потребовало времени», «можно было бы», «возможно».
- ❌ Описаний внутренней механики скилла («после Phase 3 мы перешли в Phase 4»).
- ❌ Перечисления того, что **не** меняли («библиотеки не трогали») — это invariant скилла, не достижение.
- ❌ Дублирования: если для теста уже есть комментарий issue-трекера — не повторять то же самое в секции product bugs.

## Ledger метрик — часть закрытия отчёта

Инвариант ledger — `.claude/skills/_shared/ledger-and-deviations.md`; специфика fix: **тест попал в Summary отчёта тогда и только тогда, когда дописана его строка метрик** (у каждого теста с финальным исходом — парная строка в `.tasks/metrics.jsonl`), только для **standalone**-запусков (внутри `/batch-autotest` метрики TC пишет батч — `batch-autotest/references/phases.md` §2.5). Значения строки fix: `skill=fix-failed-test`; `result`: `green` (fixed/stabilized/workaround PASS) | `red-product-bug` (PRODUCT_BUG) | `deferred` (escalation, automation-only без workaround) | `stand-incident` (STAND_INCIDENT — окно деградации, кода не касались) | `covered-by-undelivered` (repro-PASS покрыт недоставленным фиксом) | `known-issue` (сигнатура совпала с реестром known-issues, быстрый путь); `fix_iterations` = число попыток по тесту; `wall_minutes` — от mtime первого артефакта теста в `.tasks/work/batch-{ts}/`. Формат и остальные поля — `.tasks/metrics-README.md`.
