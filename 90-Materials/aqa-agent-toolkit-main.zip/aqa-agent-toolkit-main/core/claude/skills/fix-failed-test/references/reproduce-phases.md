# Phases 1-2 — Reproduce on target / Reproduce locally

Цель — **до** любых правок установить, как ведёт себя падение:
- воспроизводится ли на той же платформе, что в исходном прогоне (`target`);
- воспроизводится ли локально, без grid/selenoid (локальный режим стека).

<!-- Шаблон ядра. Механика двух repro-прогонов и интерпретация (матрица target×local) —
generic. Команды — по контракту адаптера test-stack (референс:
adapters/test-stack/reference-pytest-selenium/pytest-runner.md); {{RUNNER}}/{{DEFAULT_ENV}} —
плейсхолдеры. [test-stack] — локальный режим `--local` (нет в стеке → Phase 2 всегда skip). -->

Это критично для классификации:
- `target FAIL + local FAIL` → нормальный случай, идём в Phase 3 (manual walkthrough).
- `target PASS` → `NON_REPRODUCIBLE_FLAKY` (отложить).
- `target FAIL + local PASS` → grid/WebDriver-specific — это намёк на `WEBDRIVER_QUIRK`, но окончательно классифицирует Phase 4.

## Phase 1 — Reproduce on target

### Команда (референс pytest)

```bash
{{RUNNER}} -k <test_name> -m <target_marker> --env {{DEFAULT_ENV}} --browser-tag current --tb=native --showlocals -p no:randomly
```

`<target_marker>` — это значение, извлечённое в Phase 0 (см. `batch-discovery.md`) из словаря конфигураций проекта (референс one-web: `browser_lin_chrome`, `browser_win_firefox`, `browser_mac_safari`).

Таймаут Bash-вызова — 5 минут (`timeout=300000`).

### Анализ результата

- **PASS** → тест проходит. Это `NON_REPRODUCIBLE_FLAKY`:
  - Записать в `fix-{test}-reproduce.md` → `target_repro=false (passed on retry)`.
  - Записать в state.md → `deferred_flaky += [test]`.
  - **Не идти в Phase 2/3/4/5**. Тест будет разобран в Phase 6.
- **FAIL та же точка** → стабильно воспроизводится → `target_repro=true`. Идём в Phase 2 (если не был локальным изначально).
- **FAIL другая точка** → пишем эпицентр актуальный, идём в Phase 2 с новым failure-bundle. Возможно, исходное падение было устаревшим.

### Особый случай: target-marker не определён

Если в Phase 0 не удалось извлечь конфигурационный маркер из сырых результатов (отсутствует labels/parameters, нет внятного имени директории) — использовать **дефолтную верификационную конфигурацию проекта** (референс one-web: `lin_chrome`, без `-m`-маркера; см. правило выбора браузера в `{{TOOLKIT}}/adapters/test-stack/reference-pytest-selenium/pytest-runner.md`).

## Phase 2 — Reproduce locally *[test-stack]*

Применимо только если стек проекта имеет локальный режим прогона (референс pytest one-web: флаг `--local` — локальный браузер dev-машины вместо selenoid). Нет локального режима → `local_repro=skipped (no local mode)` и сразу Phase 3.

### Skip-conditions

Phase 2 **условная**. Её единственный дискриминатор — `target FAIL + local PASS` ⇒ намёк на
`WEBDRIVER_QUIRK`; выполнять её стоит только пока жива гипотеза браузер/окружение-специфики.
Каждый skip — явный, одной строкой в `fix-{test}-reproduce.md` и state.md (не тихое
отступление):

- **изначальный прогон был локальным** (`was_local=true` из Phase 0) →
  `local_repro=skipped (was_local=true)`;
- источник входа — `stack-trace-parse` без сырых результатов (не знаем, как был запущен
  исходный прогон → допускаем, что уже локально) → та же пометка;
- **гипотеза после Phase 1 — стендовая/серверная или DOM-дрейф**: падение объясняется
  гонками данных стенда / готовностью бэка (асинхронная материализация) / дрейфом DOM
  сборки, доказанным canary/DE/предыдущим батчем (DOM один во всех окружениях) →
  `local_repro=skipped (hypothesis: <класс>)` — локальный прогон не даст
  дискриминирующего сигнала, а стоит по прогону на тест;
- **групповой режим** (`batch-discovery.md` §4а): решение о Phase 2 принимается один раз
  по представителю группы.

**Late-check:** Phase 4 склоняется к `WEBDRIVER_QUIRK`, а Phase 2 была пропущена →
вернуться и прогнать её для дискриминации (падение и локально = не quirk).

### Команда (референс pytest)

```bash
{{RUNNER}} -k <test_name> --env {{DEFAULT_ENV}} --local --tb=native --showlocals -p no:randomly
```

**Важно:** **никаких конфигурационных маркеров браузера**. В локальном режиме стек-референс собирает локальный браузер dev-машины (см. `{{TOOLKIT}}/adapters/test-stack/reference-pytest-selenium/pytest-runner.md`, секция про `--local`). Маркер тут бесполезен и может смутить.

Таймаут — 5 минут.

### Анализ результата

| target_repro | local_repro | Интерпретация | Куда идём |
|---|---|---|---|
| FAIL | FAIL | Воспроизводится везде. Скорее всего `DOM_CHANGED`/`UX_FLOW_CHANGED`/`API_CONTRACT_CHANGED`/`PRODUCT_BUG`. | Phase 3 |
| FAIL | PASS | Grid/platform-specific. Скорее всего `WEBDRIVER_QUIRK`. | Phase 3 (надо понять, что именно ломается под WebDriver) |
| FAIL | skipped | Локальный прогон пропущен. | Phase 3 |
| PASS (target) | — | Уже отложили в Phase 1 | (не доходит сюда) |

## Что писать в `fix-{test}-reproduce.md`

```markdown
# Reproduce — {test_name}

## Phase 1 — target
- marker: browser_lin_chrome
- результат: FAIL
- exception: selenium.common.exceptions.NoSuchElementException
- эпицентр: tests/pages/chunks/chat_profile_base.py:142
- artifact (свежие сырые результаты retry): ./allure-raw/<uuid>-result.json
- log-выдержка (3-5 строк):
  - `[INFO] chat.py:403 Текущий url: "about:blank"`

## Phase 2 — local
- результат: PASS (или skipped — был локальным изначально / нет локального режима)
- если PASS — это сигнал WEBDRIVER_QUIRK
- если FAIL — эпицентр такой же / другой / новый
```

## Эскалация если раннер не запускается

Если раннер падает на сборе тестов (ошибка импорта в конфигурации, missing fixture) — это валидный сигнал, который ловится категорией `IMPORT_OR_REGISTRY` (см. `failure-taxonomy.md`). НЕ переходить в Phase 6 как `NON_REPRODUCIBLE_FLAKY` — это разные классы проблем.
