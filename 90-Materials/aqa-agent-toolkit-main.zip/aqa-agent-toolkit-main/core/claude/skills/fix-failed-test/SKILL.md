---
name: fix-failed-test
description: >-
  Чинит упавший тест {{PROJECT}} и вносит правки (локаторы/методы page-chunk/импорты/вызовы;
  НЕ правит {{DEP}}). Вход: имя теста/TC-id (гоняет раннер сам), stack trace, путь к каталогу
  сырых результатов прогона (allure-raw), ссылка на ланч {{TMS}} либо diff-bundle от
  /update-autotest. Batch 1..N не-зелёных за прогон. Тест ещё не написан → /write-autotest;
  TC изменился (а не упал) → /update-autotest; только посмотреть ланч без фикса → /launch-parse.
allowed-tools: Read, Write, Edit, Glob, Grep, Bash, Task, AskUserQuestion
---

<!-- Шаблон ядра aqa-agent-toolkit. Оси параметризации: {{PROJECT}}, {{RUNNER}}/{{PYTHON}}
(команды раннера — adapters/test-stack/CONTRACT.md), {{DEFAULT_ENV}} (стенд), {{TMS}}
(чтение ланчей/TC — adapters/tms/CONTRACT.md), [dual-line] — резолв стенда по активной ветке
(single-line: убрать), [vendored-dep] — {{DEP}}/{{DEP_PATH}} (нет таковой: убрать блоки),
[test-stack] — раннер/браузер-специфика (словарь конфигураций `browser_<os>_<browser>`,
режим `--local`, имена Selenium-исключений в таксономии — референс-словарь one-web, при
bootstrap маппится на словарь проекта), [browser-driver] — инструмент ручной разведки
(adapters/browser-driver/CONTRACT.md; референс: playwright-cli + per-браузер driver-скрипты),
[product-api] — REST-обёртки и исходники продукта. Целиком стековые references вынесены
в адаптеры: adapters/test-stack/reference-pytest-selenium/{allure-raw-parser,pytest-runner}.md,
adapters/tms/reference-allure-testops/launch-parser.md. Референс всех осей — one-web. -->

# Анализ и фикс упавших тестов {{PROJECT}} (batch)

Skill принимает информацию о падении (имя теста / stack trace / каталог сырых результатов
прогона / ссылка на ланч {{TMS}}), формирует список не-зелёных тестов длиной от 1, для каждого
воспроизводит, классифицирует, фиксит, верифицирует cross-browser, и в конце выдаёт сводный
batch-отчёт с готовыми комментариями для issue-трекера и bug-report'ами.

## Карта AUT (living-AUT-map)

При анализе падения консультируйся с картой AUT проекта (паттерн — `{{TOOLKIT}}/docs/patterns/living-aut-map.md`
ядра; референс one-web: `.tasks/aut-research/AUT_OVERVIEW.md`):
- В **Phase 3 (Manual walkthrough)** — карта показывает, какая последовательность UI-шагов должна привести в нужную точку. Если документ говорит «между шагом N и шагом M есть подтверждающая модалка», а тест её не обрабатывает — это сразу гипотеза `UX_FLOW_CHANGED`.
- В **Phase 4 (Classify + Fix)** — раздел карты «Известные quirks» содержит готовые гипотезы flake'ов (референс one-web: race-before-operation → wait-api-idle-хелпер, виртуальный скролл → JS-скролл-хелпер, click target в компонентной библиотеке → внутренний интерактивный элемент).
- При **DOM_CHANGED / UX_FLOW_CHANGED** делегируешь `dom-explorer` (mode=fix) — он использует карту AUT для навигации к точке падения. Если он обнаружит расхождение между картой и реальным DOM — обновит документ сам.

**Документ — снимок UI на конкретной сборке AUT**, может отставать. Если падение объясняется тем, что AUT уехал вперёд — не редактируй карту руками; делегируй `dom-explorer`, он подтвердит через инструмент разведки и сделает edit + добавит запись в changelog карты.

В **Phase 7 (Final batch report)** — если по ходу работы карта AUT была обновлена, упомяни это в разделе «Изменённые файлы» с пометкой «AUT-карта обновлена: §X.Y».

## Исходники продукта *[product-api]*

Если проекту доступен локальный read-only клон исходников фронтенда продукта (референс one-web: Nx-монорепо Angular) — это второй источник знаний после карты AUT. Где помогает:
- **Phase 3-4 (гипотезы):** код компонента отвечает «что реально происходит при действии» — какие XHR летят (паттерн для wait-api-idle), где дебаунсы/ретраи, есть ли optimistic UI. Надёжнее, чем угадывать по DOM.
- **DOM_CHANGED:** `git -C <клон> diff <старый-тег> <новый-тег> -- <каталог фичи>` показывает, что именно переименовали/перестроили — готовое объяснение для diagnosis.md.
- `dom-explorer` (mode=fix) сам сверяется с исходниками при перепроверке локаторов.

## Инвариант

> Один пайплайн для случая «1 тест» и «N тестов». Все три исторические ветки входа (имя теста / stack trace / сырые результаты прогона) — частные случаи списка длиной от 1.
>
> Phases 1-5 итерируются по каждому тесту, накапливая глобальный state `{fixed, deferred_flaky, deferred_automation, product_bugs, escalation, covered_by_undelivered, stand_incident, known_issue_confirmed}`. Phase 6 запускается **один раз** для двух корзин deferred-тестов. Phase 7 пишет единый batch-report.
>
> Массовые однопричинные падения (критерии — `references/batch-discovery.md` §4а) идут **групповым режимом**: Phases 1–3 — по представителю группы, фикс — эпицентра; Phase 5 — всё равно per-test для каждого теста группы (верификация прогоном не срезается).

Делегирует работу субагентам:
- `codebase-analyst` (fix-mode) — собирает inventory упавшего теста (фикстуры, методы, локаторы, API).
- `dom-explorer` (fix-mode) — проверяет, актуальны ли локаторы; при необходимости использует инструмент разведки browser-driver-порта (интерактивный CLI либо per-браузер driver-скрипт — {{TOOLKIT}}/adapters/browser-driver/CONTRACT.md).
- `code-writer` (fix-mode) — правит локаторы / методы / импорты через `Edit`.

Все прямые вызовы этих ролей здесь и в `references/` подчиняются единому контракту
`../_shared/subagent-fallback.md`: локальная подмена допустима только при подтверждённом
отказе запуска до начала работы роли, с теми же границами доступа и форматом выхода.

## Phase 0 — Discovery & Subgrouping

См. `references/batch-discovery.md`.

1. Определить источник входа по правилам `references/input-sources.md`:

| Признак | Ветка |
|---|---|
| Имя теста / TC-id без stack trace | `pytest-run` — запускаем раннер сами (по контракту адаптера test-stack; референс: `{{TOOLKIT}}/adapters/test-stack/reference-pytest-selenium/pytest-runner.md`) |
| `Traceback (most recent call last):` или `File "tests/...", line N` | `stack-trace-parse` — разбираем текст пользователя |
| Существующий путь к директории, в которой есть `*-result.json` со `status:"failed"` | `allure-raw-parse` — парсим сырые результаты прогона (по контракту адаптера test-stack; референс: `{{TOOLKIT}}/adapters/test-stack/reference-pytest-selenium/allure-raw-parser.md`) |
| URL ланча {{TMS}} или `launch <id>` | `launch-parse` — читаем ланч read-only через CLI-обёртку TMS-порта (по контракту адаптера tms; референс: `{{TOOLKIT}}/adapters/tms/reference-allure-testops/launch-parser.md`) |
| Имя теста + структурированная дельта «TC↔код» (из `/update-autotest`) | `tc-diff` — ресинк под изменившийся TC, **не** падение; **минует Phase 1–3**, Phase 4 delta-driven (см. `references/input-sources.md` §5) |

2. Сформировать **список тестов** для обработки. В `allure-raw-parse` и `launch-parse` — если N>1, спросить пользователя через `AskUserQuestion` («все по очереди» — дефолт).

3. Для каждого теста извлечь *[test-stack]*:
   - `target_marker` — конфигурация браузера/платформы из словаря проекта (референс-словарь one-web: `browser_<os>_<browser>`). Для allure-raw — из `labels`/`parameters`/имени директории; для launch — **браузер из тегов ланча**, на нём тест и упал; иначе дефолт — верификационная конфигурация проекта (референс one-web: `lin_chrome`, без `-m`-маркера). Отлаживать падение можно на быстрой дефолтной конфигурации, но **первичный repro (Phase 1) и финальная верификация (Phase 5) — на браузере ланча** (если он совпадает с дефолтной конфигурацией — отдельный прогон не нужен);
   - `was_local` (для allure-raw — из `environment.properties`; для launch — всегда False; иначе False);
   - `kind` (для launch — `failed`/`broken`/`xpass`/`xfail`/`skipped`; для xfail — отдельная ветка верификации места падения, см. `references/xfail-verification.md`).

3a. Определить `env` (один на батч). Single-line (дефолт ядра): `env = {{DEFAULT_ENV}}`.
   *[dual-line]* При двух линиях — по активной ветке: `git branch --show-current` = `{{AGENT_BRANCH_2}}` → стенд линии 2, иначе `{{DEFAULT_ENV}}` (референс one-web: `at-creation-crc` → RC-стенд). Записать в `state.md`. Во всех командах ниже и в references `--env {{DEFAULT_ENV}}` — пример основной линии: подставляй свой `{env}`.

> Вход `launch-parse`, пришедший через развилку скилла `/launch-parse` (в args — готовые
> вердикты его сводки): **сверки** 3b/3c не повторять — перенести из сводки в `state.md`
> флаг `local_ahead` со списком недоставленных коммитов, границы окна деградации
> и known-issues-отметки. Действия по вердиктам — здесь, как обычно: «♻ подтверждён» →
> корзина `known_issue_confirmed` (обновить дату строки реестра, метрика
> `result=known-issue`); «⚠ сигнатура изменилась» → полный разбор с пометкой.

3b. **Только `launch-parse` — сверка ревизий и хронология** (процедура — launch-parser
   адаптера tms, разделы «Сверка ревизий» и «Окна по времени»):
   - ветка ланча vs локальный код (`git log origin/<branch>..HEAD -- <тест-слой>`):
     локальный код впереди → `local_ahead=true` + список недоставленных коммитов
     в `state.md` — влияет на трактовку PASS в Phase 1;
   - кластер падений в узком временном окне + деградационные симптомы (5xx, пустые
     IdP-страницы) → кандидат `STAND_INCIDENT` (см. `failure-taxonomy.md`), зафиксировать
     границы окна в `state.md`.

3c. **Сверка с реестром known-issues** (`.tasks/known-issues.md`, все входы; процедура и
   критерий — `references/known-issues.md`): тест из входа имеет строку в реестре →
   сверить сигнатуру текущего падения (эпицентр + exception_class + ключевой фрагмент
   message) с записанной. Совпали все три → «подтверждён известный баг»: корзина
   `known_issue_confirmed`, Phase 1–6 не выполняются (метрика `result=known-issue`,
   дата строки обновляется). Разошёлся любой → полный разбор с пометкой «сигнатура
   изменилась» (гард от маскировки новой регрессии под старый баг). Вход `pytest-run`
   (trace ещё нет) — сверка после первого FAIL Phase 1.

4. Сгруппировать тесты по эпицентру (primary) → по симптому (fallback). Проверить критерии
   **группового режима** (`references/batch-discovery.md` §4а: от 3 тестов одного
   эпицентра/симптома + корень доказан canary/drift-report/DE/предыдущим батчем) —
   выполняются → пометить группу `mode=group` (Phases 1–3 пройдёт представитель).
   Записать в `state.md` (группу — с явным эпицентром).

5. Создать рабочий каталог батча `.tasks/work/batch-{YYYYMMDD-HHMMSS}/` (раскладка `.tasks/` — карта `.tasks/README.md`). В него кладём все артефакты: `state.md`, `fix-{test}-*.md`, скриншоты. Путь каталога передавай субагентам в каждом задании (`batch_dir`) — свои артефакты они пишут туда, не в корень `.tasks/`.

## Phase 1 — Reproduce on target

См. `references/reproduce-phases.md` секцию Phase 1.

Для каждого теста — прогон одного теста на конфигурации `target_marker` по контракту test-stack (референс pytest: `{{RUNNER}} -k <test> -m <target_marker> --env {env} --browser-tag current --tb=native --showlocals -p no:randomly`; разбор флагов — `{{TOOLKIT}}/adapters/test-stack/reference-pytest-selenium/pytest-runner.md`). Таймаут 5 минут.

**Групповой режим** (`mode=group` из Phase 0): Phases 1–3 проходит **представитель** группы;
остальным тестам группы repro до фикса не гоняется — их верифицирует Phase 5 per-test
прогоном. Падение представителя не объясняет группу (иной эпицентр/симптом) → откат:
группа расформировывается, тесты идут полным per-test пайплайном
(`references/batch-discovery.md` §4а).

- PASS → **до** вердикта `NON_REPRODUCIBLE_FLAKY` две проверки (обе — `failure-taxonomy.md`):
  1. `local_ahead=true` (Phase 0 3b) и недоставленные коммиты трогают файлы теста/эпицентра
     → исход **«покрыто недоставленным фиксом»** → корзина `covered_by_undelivered`:
     Phase 2-6 не нужны, «стабилизация» починенного кода запрещена; в отчёт — напоминание
     доставить фиксы.
  2. Падение попадает в зафиксированное окно деградации (Phase 0 3b) с 5xx-evidence
     → `STAND_INCIDENT` → корзина `stand_incident`: кода не касаться, окно в отчёт.

  Ни то, ни другое → `NON_REPRODUCIBLE_FLAKY` → в `deferred_flaky` корзину. **НЕ** идти в Phase 2-5; ждать Phase 6.
- FAIL → `target_repro=true`, идём в Phase 2.

## Phase 2 — Reproduce locally *[test-stack]*

См. `references/reproduce-phases.md` секцию Phase 2.

Применимо, если стек проекта имеет локальный режим прогона (без grid/selenoid, на локальном браузере dev-машины; референс pytest: флаг `--local`). Нет локального режима → Phase 2 всегда skip.

**Phase 2 условная.** Её единственный дискриминатор — `target FAIL + local PASS` ⇒ намёк на
WEBDRIVER_QUIRK; выполняется, когда после Phase 1 жива гипотеза браузер/окружение-специфики.
Гипотеза стендовая/серверная (гонки данных, готовность бэка) или DOM-дрейф, доказанный
canary/DE/предыдущим батчем, → явный skip одной строкой обоснования
(`local_repro=skipped (hypothesis: <класс>)` в reproduce.md и state.md), не тихое
отступление. Late-check: Phase 4 склоняется к WEBDRIVER_QUIRK при пропущенной Phase 2 →
вернуться и прогнать её. Полные skip-условия — `references/reproduce-phases.md`.

Skip если изначальный прогон был локальным (`was_local=true`).

Команда (референс pytest): `{{RUNNER}} -k <test> --env {env} --local --tb=native --showlocals -p no:randomly` (БЕЗ маркера конфигурации браузера).

Результат сохраняется в `fix-{test}-reproduce.md`. Различение `(target FAIL, local PASS)` vs `(target FAIL, local FAIL)` — это сигнал для Phase 4 (WEBDRIVER_QUIRK vs универсальное падение).

## Phase 3 — Manual step-by-step walkthrough

См. `references/manual-walkthrough.md`.

Пошаговое ручное воспроизведение сценария (не перезапуск раннера) инструментом browser-driver-порта. В групповом режиме walkthrough выполняется по представителю группы (один прогон на эпицентр, см. Phase 1). Выбор инструмента *[browser-driver]* (референс one-web):
- target на движке Chromium → интерактивный CLI разведки (референс: playwright-cli, Chromium);
- target = safari → CLI с движком webkit → если не воспроизвёл → per-браузер driver-скрипт (референс: `selenoid_mac_safari.py`);
- target = firefox/прочие → CLI → если не воспроизвёл → per-браузер driver-скрипт (референс: `selenoid_<os>_<browser>.py`).

Если **ни один** инструмент не воспроизвёл — `AUTOMATION_ONLY` → в `deferred_automation` корзину. Phase 4 пропускается.

Результат — `fix-{test}-manual.md` с гипотезой причины.

## Phase 4 — Classify + Fix

Локализация (`references/failure-localization.md`) + классификация (`references/failure-taxonomy.md`) + playbook (`references/fix-playbooks.md`).

Делегируем:
1. `codebase-analyst` (mode=fix) → `fix-{test}-analysis.md` (inventory методов/локаторов/API/фикстур).
2. Классифицируем по таксономии (8 базовых категорий + 2 deferred + `STAND_INCIDENT`/«покрыто недоставленным фиксом» — последние четыре сюда не доходят, они терминальны раньше).
3. Записываем `fix-{test}-diagnosis.md`.
4. Для категорий, требующих перепроверки DOM (DOM_CHANGED / UX_FLOW_CHANGED / WEBDRIVER_QUIRK) — `dom-explorer` (mode=fix) → `fix-{test}-locators.md`.
5. `code-writer` (mode=fix, category=...) — правки в тест-слое: тесты, page/chunk, общий модуль хелперов, словарь i18n (контракт test-stack). *[vendored-dep]* **Не** правит `{{DEP_PATH}}`.

   **Порог тривиальности** (когда допустимо без делегирования): механическая правка ≤3 строк
   по образцу, уже доказанному в этом батче (вставка готового гейта/импорта/константы — фикс
   того же класса прошёл верификацию), — основной агент вносит сам (Edit + синтакс-гейт
   стека); верификация Phase 5 обязательна как обычно. Новые локаторы/методы/логика или
   первая правка класса в батче — только code-writer.

   **Гейт REST-вызовов** *[product-api]*: фикс добавляет **новый** HTTP-вызов к AUT
   (гейт готовности, создание данных) → сначала проверить обёртку эндпоинта в общей
   REST-библиотеке; обе ветки (обёртка той же работой / временный прямой вызов только
   с задачей на вынос) — `references/fix-playbooks.md`, секция «Гейт: новый REST-вызов».
6. Для `PRODUCT_BUG` — никаких правок; копим репро-bundle для issue-трекера.

## Phase 5 — Cross-browser verification

См. `references/cross-browser-verification.md`.

Для каждого исправленного теста:
0. Определить **объём верификации по классу правки** (`references/cross-browser-verification.md`,
   секция «Объём по классу правки»): браузеронезависимая правка (замена селектора, REST-гейт,
   i18n-строка, регистрация/импорт, правка вызова API) → достаточно target-браузера,
   cross-browser закрывают плановые прогоны проекта; браузерозависимая (интеракции, браузерные
   гарды, JS-workaround, тайминги) → полная матрица. Выбор зафиксировать в crossbrowser.md.
1. Target marker — если FAIL, 1 retry Phase 4. Если retry FAIL → `escalation`, к следующему тесту.
2. Cross-browser *[test-stack]* (если класс правки требует — шаг 0): verify-набор проекта `\ {target}` (референс one-web: `{ya, firefox, safari} \ {target}`), последовательно. Однобраузерная single-session-платформа (референс: safari) пропускается, если тест мультисессионный (референс: фикстура `setup_multiple_auts`).
3. На FAIL отдельного браузера — 1 retry Phase 4 (точечная правка под него, обычно браузерный гард). Не зацикливаемся.
4. Результат — `fix-{test}-crossbrowser.md` с матрицей.

После cross-browser — обновить корзину `fixed` в state.md.

## Phase 6 — Deferred handling

См. `references/deferred-handling.md`.

Один проход по двум корзинам:
- `deferred_flaky` (`NON_REPRODUCIBLE_FLAKY`) → попытка стабилизации (js-clickable-wait, presence-wait с потолочным таймаутом, изоляция данных). Лимит — 2 попытки.
- `deferred_automation` (`AUTOMATION_ONLY`) → workaround (JS-click, JS-send_keys, API-bypass, событийное ожидание с наблюдаемым условием). Лимит — 2 попытки. После workaround — обязательный cross-browser.

После Phase 6:
- Тест перешёл в `fixed` → ok.
- Не перешёл → `escalation` с обязательным **обоснованием** (списком попыток + рекомендацией пользователю).

## Phase 7 — Final batch report

См. `references/batch-report.md`.

Записать `.tasks/work/batch-{ts}/fix-batch-{ts}-report.md` с разделами:
- Summary (числа по корзинам);
- Изменённые файлы (только staged);
- Комментарии для issue-трекера (по тесту) — готовые блоки;
- Product bugs — по каждому подтверждённому багу **каталог-кандидат**
  `.tasks/jira-candidates/<NNN>-TC-<XXXXX>-<slug>/` (внутри `draft.md` + копии всех
  артефактов бага; формат, именование, разметка трекера —
  `.claude/skills/_shared/jira-candidates.md`), секция отчёта ссылается на кандидатов,
  не на сырые трейсы;
- Deferred (escalation с обоснованием);
- Отступления от протокола скилла (инвариант связывания — ниже);
- Helper-команды для повторной проверки руками.

**Обновить реестр known-issues** (`references/known-issues.md`): исходы `red-product-bug`/`deferred` → добавить/обновить строку `.tasks/known-issues.md`; доведённые до `green` тесты, числившиеся в реестре, → снять строку.

**Закрыть отчёт ledger'ом** (только standalone-запуск, не изнутри `/batch-autotest`) — инвариант
ledger `.claude/skills/_shared/ledger-and-deviations.md`; специфика fix: «тест в Summary отчёта ⇔
строка метрик», значения полей и `result` — `references/batch-report.md`.

**Инвариант связывания отступлений** (`.claude/skills/_shared/ledger-and-deviations.md`):
каждая строка секции «Отступления от протокола скилла» завершается исходом (а/б/в); секция без
исхода у каждой строки = **отчёт не закрыт** (симметрично инварианту ledger).

Сообщить пользователю:
- путь к `fix-batch-{ts}-report.md`;
- 1-2 строки итога (`K fixed / E escalation / P product bugs`);
- напоминание: коммит не сделан, `git status && git diff --staged` для review.

## Артефакты в `.tasks/work/batch-{ts}/`

```
.tasks/work/batch-{ts}/
├── state.md                            ← глобальный state (корзины, счётчики)
├── fix-{test}-failure.md               ← собранные факты + log-выдержка
├── fix-{test}-analysis.md              ← из codebase-analyst (inventory)
├── fix-{test}-reproduce.md             ← P1+P2: target_repro / local_repro
├── fix-{test}-manual.md                ← P3: walkthrough log + гипотеза
├── fix-{test}-locators.md              ← из dom-explorer (если был вызван)
├── fix-{test}-diagnosis.md             ← P4: категория + улики
├── fix-{test}-crossbrowser.md          ← P5: матрица результатов
├── fix-{test}-screenshot-step-*.png    ← из dom-explorer / инструмента разведки
├── manual_{test}.py                    ← сценарии driver-скриптов (если использовались)
└── fix-batch-{ts}-report.md            ← итоговый отчёт (Phase 7)
```

## Запреты

- ❌ *[vendored-dep]* Не править файлы в `{{DEP_PATH}}`.
- ❌ Не делать `git commit`. Только `git add` если нужно, но **финальный коммит** оставить пользователю.
- ❌ Не делать больше 2 итераций Phase 4 на тест (защита от циклов). Не делать больше 2 попыток стабилизации в Phase 6 на тест.
- ❌ Не переименовывать существующие методы page/chunk (сломает другие тесты).
- ❌ *[test-stack]* Не менять порядок наследования runtime-mixin page-объектов (референс one-web: `_PVersion → Version2Locators.L`).
- ❌ Не помечать тест `skip` или `xfail` как «фикс» — это не фикс, это сокрытие.
- ❌ Не запускать cross-browser параллельно (см. `cross-browser-verification.md` про причины).
- ❌ Не запускать раннер для нескольких тестов одной командой — каждый тест прогоняется отдельно (per-test сырые результаты, чище парсинг).
