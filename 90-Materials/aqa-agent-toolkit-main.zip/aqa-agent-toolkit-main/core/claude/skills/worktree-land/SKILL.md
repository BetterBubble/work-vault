---
name: worktree-land
description: >-
  Сводит ворктри-задачу {{PROJECT}} в её агентскую ветку и доставляет проектную часть: squash WIP →
  rebase на базу (конфликты решаются здесь, в контексте задачи) → merge --ff-only → /prepare-mr-branch
  из диапазона ровно этой задачи. Активируй: «сведи задачу», «заland ворктри», «доставь из ворктри»,
  «приземли wt/<task>». НЕ создаёт ворктри (это worktree_bootstrap/git), НЕ диф текущей правки
  (→ /simplify, /code-review).
allowed-tools: Read, Glob, Grep, Bash, AskUserQuestion, Skill
---

<!-- Шаблон ядра aqa-agent-toolkit. Оси: {{PROJECT}} (имя проекта — путь ~/worktrees/{{PROJECT}}/),
{{AGENT_BRANCH}} (агентская ветка; [dual-line] — вторая {{AGENT_BRANCH_2}} и маппинг стендов),
[product-api] — cleanup эфемерных ресурсов задачи (Phase 5.1; нет таковых — убрать). -->

# Сведение ворктри-задачи в агентскую ветку + доставка

Skill приземляет работу из ворктри-задачи (`~/worktrees/{{PROJECT}}/<task>`, ветка
`wt/<task>`) в её **агентскую ветку** через `rebase → merge --ff-only`, затем доставляет
**проектную** часть через `/prepare-mr-branch` из диапазона ровно этой задачи. Агент-инфра
остаётся на агентской ветке (её «общее пространство»). Модель «ворктри = задача» —
CLAUDE.md → «Ворктри-на-задачу» + `{{TOOLKIT}}/core/tasks-schemas/worktree-meta.md`.

## Инвариант

> **`--ff-only` — защёлка «доехало либо отказ, без полу-слияния».** Конфликты решаются
> на этапе **rebase** (Phase 2), в контексте задачи; к моменту `merge --ff-only` ветка
> `wt/<task>` строго впереди базы линейно. После ff критерий «село» проверяется явно
> (`git branch --merged <base>`). Доставка проектной части — отдельная Phase через
> `/prepare-mr-branch` с **явным `base_commit=pre_ff`** (диапазон ровно этой задачи,
> без протечки соседних). Агент-only задача → MR не создаём.

## Кросс-ворктри механика (важно — читать до запуска)

Ветки `wt/<task>` и `<base>` **checked out в разных ворктри**. Поэтому фазы бегут в разных
каталогах:
- **Phase 1 (squash) + Phase 2 (rebase)** — двигают `wt/<task>` → бегут в **ворктри задачи**
  (там она checked out; обычно это cwd сессии).
- **Phase 3 (ff) + Phase 4 (delivery) + Phase 5 (retire)** — трогают `<base>` и удаляют
  каталог задачи → бегут из **главного репо** (`<main_repo>`); перед ними `cd <main_repo>`
  (нельзя удалить ворктри, стоя в нём).

Детект каталогов в Phase 0; дальше — через `git -C <dir>` либо явный `cd`.

## Прежде всего

Выполняй Phases 0–5 **подряд**. Останавливайся только на:
- ожиданиях ответа от `AskUserQuestion` (группировка squash, имя MR-ветки);
- ошибках git (конфликт rebase, грязное дерево базы, не-FF) — STOP с пояснением, состояние
  в `state.md`, инструкция resume;
- отсутствии ворктри/ветки задачи.

Никаких «можно продолжать?» вне `AskUserQuestion`.

## Phase 0 — Resolve inputs

1. **`task` и `worktree`.** Если cwd — ворктри (`git branch --show-current` = `wt/<task>`) →
   `task` = ветка без префикса `wt/`, `worktree = $(pwd)`. Иначе — пользователь назвал задачу
   явно: найти каталог по ветке:
   ```bash
   worktree=$(git worktree list --porcelain | awk -v b="refs/heads/wt/<task>" '/^worktree /{w=$2} /^branch /{if($2==b)print w}')
   ```
   Нет ни того, ни другого → STOP: «не нашёл ворктри-задачу; запусти из
   `~/worktrees/{{PROJECT}}/<task>` или назови задачу».

2. **`main_repo`** (главный рабочий каталог репо, где живёт `.git`):
   ```bash
   main_repo=$(dirname "$(git rev-parse --path-format=absolute --git-common-dir)")
   ```

3. **`base`** (агентская ветка-цель). Источники по приоритету:
   - meta-файл `worktree/.tasks/worktree-<task>/base` (засеян при создании ворктри) —
     взять как есть;
   - фолбэк (нет файла) — single-line: `base = {{AGENT_BRANCH}}` (проверить ancestry:
     `git merge-base --is-ancestor {{AGENT_BRANCH}} wt/<task>`).

     *[dual-line]* ancestry-проверка по обеим агентским веткам; предки обе — предпочесть ту,
     к чьему tip ближе `wt/<task>` (`git rev-list --count <branch>..wt/<task>` минимальный).
     Неоднозначно → `AskUserQuestion`.

4. **`fork_point`**:
   ```bash
   fork_point=$(git merge-base wt/<task> <base>)
   ```
   *[dual-line]* Линия — по `base` (нужно только для отчёта; реальный детект линии делает
   `/prepare-mr-branch` по имени source).

5. Записать `state.md` в `<main_repo>/.tasks/_scratch/worktree-land/{YYYYMMDD-HHMMSS}/`
   (gitignored; в `main_repo`, чтобы пережить удаление ворктри в Phase 5):
   ```markdown
   task: <task>
   worktree: ~/worktrees/{{PROJECT}}/<task>
   main_repo: <абсолютный путь>
   base: {{AGENT_BRANCH}}
   line: main
   fork_point: <sha>
   pre_ff:                          # tip <base> до ff — Phase 3
   squashed: false
   started_at: <ISO-время>
   status: in_progress
   ```

6. **Sanity:** `git fetch origin --prune` (из `main_repo`); рабочее дерево ворктри
   по tracked-файлам чистое (`git -C <worktree> status --porcelain`, untracked игнорим);
   рабочее дерево `<base>` чистое (см. Phase 3 шаг 1).

## Phase 1 — Squash WIP (на `wt/<task>`, до rebase)

Цель: схлопнуть свободные WIP-чекпоинты сессий в осмысленные коммиты **до** rebase.
Бежит в ворктри (`cd <worktree>`).

1. Показать диапазон:
   ```bash
   git -C <worktree> log --oneline <fork_point>..wt/<task>
   ```
2. Если коммитов нет — нечего сводить, перейти к Phase 2. Если ровно один и он осмысленный
   (не «WIP»/«checkpoint»/«wip») — спросить через `AskUserQuestion`, оставить как есть или
   переписать message; по «оставить» — пропустить шаг 4.
3. Иначе через `AskUserQuestion` собрать **группировку** (сколько финальных коммитов и как
   делить диапазон) + **финальные сообщения** (в стиле репо: глагол + что сделано).
4. Схлопнуть **на самой `wt/<task>`** (НЕ в detached):
   ```bash
   cd <worktree>
   git reset --soft <fork_point>
   # затем по группам: git add -A <пути группы> && git commit -m "<сообщение>"
   ```
   Один итоговый коммит = `git commit` всего разом; несколько — поэтапный `git add`
   по путям/`git commit` на группу.
5. Записать `squashed: true` в `state.md`.

> Squash до rebase: переписываем «свою» историю, пока она не наслоилась на базу — конфликты
> Phase 2 относятся к настоящим изменениям, не к промежуточным WIP-состояниям.

## Phase 2 — Rebase на базу (на `wt/<task>`)

```bash
cd <worktree>
git rebase <base> wt/<task>
```

- **Конфликт** (`git status` → `unmerged paths`) — STOP. Сообщи: какие файлы конфликтуют;
  «реши вручную в ворктри → `git rebase --continue`, затем перезапусти `/worktree-land`
  (resume)». Конфликт решается **здесь**, в контексте задачи (это и есть смысл per-task
  изоляции).
- **pre-commit hook упал** — НЕ `--no-verify`; STOP, попроси разобраться, сохрани state.
- Успех → `wt/<task>` строго впереди `<base>` линейно (ff возможен).

## Phase 3 — Land (merge --ff-only)

Бежит из главного репо / того ворктри, где `<base>` checked out (обычно `main_repo`).

1. Найти каталог с `<base>` и проверить чистоту его дерева:
   ```bash
   base_wt=$(git worktree list --porcelain | awk -v b="refs/heads/<base>" '/^worktree /{w=$2} /^branch /{if($2==b)print w}')
   # base не checked out нигде → возьмём main_repo и переключим его:
   if [ -z "$base_wt" ]; then base_wt=<main_repo>; git -C "$base_wt" checkout <base>; fi
   git -C "$base_wt" status --porcelain   # должно быть пусто (по tracked) — иначе STOP
   ```
2. **Гард от протёкшего handoff (до ff).** Просканировать файлы, которые вот-вот
   заland'ятся, на stray-агент-артефакты в **корне** репо — handoff обязан жить
   в `.tasks/worktree-<task>/` (заигнорено), а не в корне:
   ```bash
   git -C "$base_wt" diff --name-only <base>..wt/<task> | grep -qx 'PROGRESS.md' && echo LEAK
   ```
   Нашёлся корневой `PROGRESS.md` (или иной handoff-черновик в корне) → **STOP до ff**:
   «в `wt/<task>` закоммичен корневой `PROGRESS.md` — промах размещения handoff'а (должен
   быть в `.tasks/worktree-<task>/`, оно заигнорено). Убери из ветки:
   `git -C <worktree> rm PROGRESS.md && git -C <worktree> commit --amend --no-edit` (или
   отдельным коммитом), затем перезапусти land». **Не делать ff**, пока не убран: иначе
   агент-артефакт сядет на базовую ветку и рискует утечь в MR (корневого `PROGRESS.md` нет
   в deny-list `prepare-mr` → он будет сочтён проектным).
3. Записать `pre_ff` (tip базы ДО ff — точка отсчёта диапазона задачи для Phase 4):
   ```bash
   pre_ff=$(git -C "$base_wt" rev-parse <base>)   # → записать в state.md
   ```
4. Fast-forward:
   ```bash
   git -C "$base_wt" merge --ff-only wt/<task>
   ```
   - Не-FF (`fatal: Not possible to fast-forward`) — база ушла вперёд после Phase 2 rebase
     (параллельный land). STOP: «база сдвинулась, перезапусти `/worktree-land` (повторный
     rebase подхватит)».
5. **Критерий «доехало»** (обязательная пост-проверка):
   ```bash
   git -C "$base_wt" branch --merged <base> | grep -qx '  wt/<task>\|* wt/<task>' \
     || git -C "$base_wt" merge-base --is-ancestor wt/<task> <base>
   ```
   Не подтвердилось → STOP, не продолжать к доставке. Подтвердилось → `cd <main_repo>`
   (для Phase 4–5) и дальше.

## Phase 4 — Классификация и доставка проектной части

Бежит из `<main_repo>`. Диапазон задачи на базе = `pre_ff..<base>`.

1. Что село — прогнать имена файлов через deny-list `/prepare-mr-branch` (канон —
   [`../prepare-mr-branch/references/exclusion-patterns.md`](../prepare-mr-branch/references/exclusion-patterns.md),
   **не дублировать**):
   ```bash
   git -C <main_repo> diff --name-only <pre_ff>..<base>
   ```
   Файл матчит deny-list → агентный; иначе → проектный.

2. **Есть проектные файлы → доставка через `/prepare-mr-branch`.** Сначала собрать имя
   MR-ветки — это **внешний идентификатор** (у потребителей обычно ключ AT-задачи, якорь
   связей CI/TMS/MR): `task` уже выглядит как тикет-ключ → взять его; иначе — **stop-gate**:
   `AskUserQuestion` с запросом точного ключа/имени (слаг задачи — опцией, только если у
   проекта MR-ветка не обязана быть тикет-ключом). Угадывать «свободный» номер из соседних
   задач запрещено (правило — `/prepare-mr-branch` Phase 0). Затем вызвать skill, передав
   всё в первом сообщении (чтобы он пропустил свои вопросы):
   ```
   Skill(skill="prepare-mr-branch",
     args="source=<base>, target=<MR-ветка>, режим=новая от base, base=origin/{{MAIN_BRANCH}}, base_commit=<pre_ff>[, dep_mr_url=<url> если есть]")
   ```
   - `source=<base>` — **source для MR = агентская ветка после ff, НЕ `wt/<task>`.**
     *[dual-line]* Линию `/prepare-mr-branch` задетектит сам по имени source-ветки.
   - `base_commit=<pre_ff>` — короткозамыкает авто-детект базовой точки → MR собирается
     из коммитов ровно этой задачи, без протечки соседних задач, севших на ту же базу.
   - prepare-mr запушит MR-ветку и создаст MR (его Phase 6.5, после аппрува diff).

3. **Всё агент-only (проектных файлов нет) → MR не создаём.** Отчёт: «село на `<base>`;
   изменения — агент-инфра». *[dual-line]* + «кросс-линия — вручную (CLAUDE.md → „Ветки
   и линии“)». Не звать `/prepare-mr-branch`.

## Phase 5 — Retire + отчёт

Из `<main_repo>` (cwd уже не внутри ворктри).

1. *[product-api]* **Снести эфемерные ресурсы задачи** (research-юзеры и т.п., до удаления
   каталога — пока `<worktree>` жив); референс one-web:
   ```bash
   [ -f <worktree>/.claude/scripts/research_user.py ] && \
     <worktree>/venv/bin/python <worktree>/.claude/scripts/research_user.py delete-task --task <task> --env <env> || \
     echo "скрипта нет — пропуск"
   ```
   `<env>` — по `base` из `state.md`. Реестр = имя на бэкенде (не файл в ворктри); ресурсов
   нет → пустой результат, не ошибка. Сирот от брошенных ворктри (без land) подстраховывает
   reap-механизм разведчика.
2. Удалить **каталог** ворктри сразу после ff (+MR, если был):
   ```bash
   git -C <main_repo> worktree remove ~/worktrees/{{PROJECT}}/<task>
   ```
   (`--force`, только если git ругается на untracked-артефакты skill'ов и они не нужны.)

   > ⚠️ Если сессия запущена из этого ворктри (дефолтный сценарий Phase 0) — удаление
   > сносит и её среду: реестр скиллов/субагентов привязан к `.claude/` удалённого
   > каталога, дальнейшие Skill-вызовы в этой сессии падают «Unknown skill», bash-cwd
   > сброшен. Поведение после retire — секция «Потеря среды после retire» ниже.
3. **Ветка `wt/<task>`:**
   - проектная задача (был MR) → **держать** до merge MR (нужна как source MR-ветки/для
     разбора);
   - агент-only → можно сразу `git -C <main_repo> branch -d wt/<task>`.
4. Статус в `state.md` — **по исходу, MR создан ≠ задача закрыта**:
   - был создан MR → `status: landed_mr_open` — работа продолжается (см. «Post-MR» ниже);
   - агент-only (MR нет) → `status: completed`.

   Отчёт пользователю:
   - куда село (`<base>`), критерий merged подтверждён;
   - URL созданного MR (если был) либо «агент-only, MR нет»;
   - судьба ветки `wt/<task>` (удалена / держим до merge);
   - **при MR — обязательной строкой:** «задача **НЕ закрыта** до pipeline + разбора
     ланча + merge; следующий шаг — пайплайн на MR-ветке (checklist „Post-MR“)»;
   - *[dual-line]* для агент-only — напоминание про ручную кросс-линию.

## Post-MR — до закрытия задачи (когда был MR)

DoD задачи живёт **позже** MR: `landed_mr_open` → `completed` только после этого checklist'а
(канон шагов пайплайн/ланч — delivery-хвост `_shared/delivery-tail.md`, Шаги 4–6, профиль
мутирующего оркестратора; здесь не дублируется):

1. **Пайплайн** на MR-ветке с нужными переменными (Шаг 4 хвоста; anchor `AT_ISSUE` =
   MR-ветка) → дождаться результата.
2. **Резолв и разбор ланча** (Шаги 5–6 хвоста): URL пользователю, не-зелёные —
   классифицировать и разобрать (развилка Шага 6).
3. **Merge MR** — решение человека либо по явному запросу (инвариант внешней
   поверхности — delivery-tail); дождаться merge.
4. **После merge:** `git pull` интеграционной ветки; удалить `wt/<task>`
   (`git branch -d`); закрыть TODO задачи (строка в «Закрытые» INDEX + rm карточки),
   если задача велась по беклогу.
5. `status: completed` в `state.md`.

### Потеря среды после retire

Phase 5 удалила каталог, из которого (в дефолтном сценарии) запущена текущая сессия —
её реестр скиллов/субагентов мёртв. Поэтому:
- post-MR шаги, требующие Skill-вызовов (например `/fix-failed-test` на разбор ланча), —
  **из новой сессии в главном репо** (там реестр живой); передай ей контекст (URL MR/ланча,
  путь `state.md`);
- в текущей сессии — только прямые команды (`bash`, чтение референсов из `<main_repo>`),
  Skill-вызовы не делать.

## Resume

Если в `<main_repo>/.tasks/_scratch/worktree-land/` есть `state.md` со
`status: in_progress`/`aborted` для этой задачи — через `AskUserQuestion` предложи
«продолжить (task=X, на фазе Y)» / «начать заново». Resume переиспользует
`task/worktree/base/fork_point/pre_ff` из `state.md`; стартует с фазы, где остановились
(после ручного `git rebase --continue` — с Phase 3).

## Запреты

- ❌ Не создавать ворктри — это `worktree_bootstrap.sh` / `git worktree add`
  (см. CLAUDE.md → «Ворктри-на-задачу»).
- ❌ Не делать `merge` без `--ff-only` — защёлка «доехало либо отказ»; не-FF = STOP,
  не полу-слияние.
- ❌ Не пушить `wt/<task>` и агентские ветки (push только MR-ветки — делает
  `/prepare-mr-branch`).
- ❌ Не угадывать AT-ключ/имя MR-ветки — нет явного ключа → вопрос пользователю
  (Phase 4 шаг 2).
- ❌ Никаких внешних write-actions сверх прописанных (push MR-ветки/создание MR — делает
  `/prepare-mr-branch` по аппруву): комментарии/labels/merge MR, пайплайны, мутации
  трекера/TMS — только по явному запросу (инвариант — `_shared/delivery-tail.md`).
- ❌ Не доставлять агент-инфру в MR — она садится на агентскую ветку.
- ❌ Не делать ff при корневом `PROGRESS.md` (или ином handoff-черновике в корне)
  в диапазоне land'а — STOP (Phase 3 шаг 2): handoff живёт в `.tasks/worktree-<task>/`,
  корневой утечёт в MR.
- ❌ Не править проектный код / не диф текущей правки — это `/simplify`, `/code-review`
  (skill только сводит и доставляет уже сделанное).
- ❌ Не `--no-verify` на rebase/cherry-pick; hook упал — STOP.
- ❌ Не удалять каталог ворктри, стоя внутри него — сначала `cd <main_repo>`.
- ❌ Не считать задачу закрытой на созданном MR — `landed_mr_open` ≠ `completed`;
  гейт закрытия — checklist «Post-MR» (pipeline → разбор ланча → merge → pull → TODO).
- ❌ Не вызывать Skill'ы из сессии, жившей в удалённом ворктри, — после retire её реестр
  мёртв («Потеря среды после retire»).
