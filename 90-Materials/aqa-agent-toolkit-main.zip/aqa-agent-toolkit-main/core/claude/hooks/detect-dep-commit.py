"""PostToolUse hook: detect `git commit` in the vendored-dep repo (паттерн
«detect-tool-usage → inject-guidance», см. {{TOOLKIT}}/docs/patterns/vendored-dep-rebuild.md).

Образец ядра aqa-agent-toolkit (прародитель-референс — исходная CC-развёртка one-web).
При bootstrap: задать DEP_MARKER / DEP_DIR_HINT / SKILL_NAME ниже (нет портированного
rebuild-скилла — SKILL_NAME пустой, напоминание сошлётся на рецепт); нет локальной
библиотеки-зависимости — хук не разворачивать.

Triggered after any Bash tool call. When the command is a `git commit` against
the vendored-dep repo, the hook returns `hookSpecificOutput.additionalContext`
asking the agent to invoke the rebuild skill next.

Hook output schema (Claude Code PostToolUse):
    {
      "continue": true,
      "hookSpecificOutput": {
        "hookEventName": "PostToolUse",
        "additionalContext": "<message shown to the agent as a system reminder>"
      }
    }

If the command is NOT a dep commit, the script exits 0 with no output.
"""
from __future__ import annotations

import json
import os
import re
import sys


# --- конфиг проекта (заполнить при bootstrap) --------------------------------
DEP_MARKER = "{{DEP}}"            # подстрока пути репо библиотеки (напр. "autocore")
DEP_DIR_HINT = "{{DEP_REPO}}"     # путь репо библиотеки для текста напоминания
SKILL_NAME = "/rebuild-{{DEP}}"   # скилл пересборки; нет такого скилла — оставить "" (пустым)
# Рецепт пересборки без скилла (текст напоминания при пустом SKILL_NAME):
RECIPE_PATH = "{{TOOLKIT}}/docs/patterns/vendored-dep-rebuild.md"
# ------------------------------------------------------------------------------

GIT_COMMIT_SUBCMD_RE = re.compile(r"^git\b.*\bcommit\b")
# Locate the git repo being committed to: an explicit `git -C <path>` or a
# `cd <path>` in the command chain. We resolve the repo *location* rather than
# matching DEP_MARKER anywhere in the command, so a commit *message* that
# mentions the dep never triggers.
GIT_C_PATH_RE = re.compile(r"\bgit\s+-C\s+(\S+)")
CD_PATH_RE = re.compile(r"\bcd\s+(\S+)")
# Quoted spans are data (printf/echo args, commit messages), not command
# structure — strip them so embedded git-commit-like text can't be misread.
QUOTED_RE = re.compile(r"'[^']*'|\"[^\"]*\"")


def _has_dep(path: str) -> bool:
    return DEP_MARKER in path.strip("'\"").replace("\\", "/").lower()


def _is_dep_commit(command: str, cwd: str) -> bool:
    if not command:
        return False
    scrubbed = QUOTED_RE.sub(" ", command)
    sub_cmds = [sub.strip() for sub in re.split(r"&&|\|\||;", scrubbed)]
    # Only a git/cd-led command qualifies — not an arbitrary command (python,
    # echo, …) that merely embeds git-commit-like text as an argument.
    if not sub_cmds or not re.match(r"(?:git|cd)\b", sub_cmds[0]):
        return False
    if not any(GIT_COMMIT_SUBCMD_RE.match(sub) for sub in sub_cmds):
        return False
    # Repo location: `git -C`, then `cd`, then the process cwd.
    for path in GIT_C_PATH_RE.findall(scrubbed):
        if _has_dep(path):
            return True
    for path in CD_PATH_RE.findall(scrubbed):
        if _has_dep(path):
            return True
    return bool(cwd) and _has_dep(cwd)


def main() -> int:
    try:
        payload = json.load(sys.stdin)
    except Exception:
        return 0

    if payload.get("tool_name") != "Bash":
        return 0

    tool_input = payload.get("tool_input") or {}
    command = tool_input.get("command") or ""
    cwd = payload.get("cwd") or ""

    if not _is_dep_commit(command, cwd):
        return 0

    if SKILL_NAME:
        skill_ref = SKILL_NAME
        # Дуальная развёртка: Codex-слой зовёт скиллы `$name`-синтаксисом; платформу
        # сообщает env AGENT_PLATFORM из hooks.json Codex-рецепта (нет env — CC-дефолт,
        # поведение не меняется).
        if os.environ.get("AGENT_PLATFORM") == "codex" and skill_ref.startswith("/"):
            skill_ref = "$" + skill_ref[1:]
        action = (
            f"Следующим действием вызови скилл `{skill_ref}` — он "
            f"пересоберёт и установит свежую версию в окружение проекта."
        )
    else:
        action = (
            f"Следующим действием пересобери и переустанови её в окружение "
            f"проекта по рецепту `{RECIPE_PATH}`."
        )
    message = (
        f"Только что прошёл `git commit` в репозитории библиотеки-зависимости "
        f"(`{DEP_DIR_HINT}`). {action} Не запускай тесты после rebuild и не бампь "
        f"версию — это отдельные решения пользователя."
    )

    output = {
        "continue": True,
        "hookSpecificOutput": {
            "hookEventName": "PostToolUse",
            "additionalContext": message,
        },
    }
    # ensure_ascii=True keeps the JSON pure-ASCII (cyrillic escaped as \uXXXX),
    # which survives any stdout encoding mismatch between this script and the
    # Claude Code hook consumer on Windows.
    json.dump(output, sys.stdout, ensure_ascii=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
