---
# [test-stack] Маска путей слоя page-object'ов — подстроить под структуру проекта
# (референс one-web: tests/pages/**).
paths:
  - "tests/pages/**/*.py"
---

<!-- Шаблон ядра aqa-agent-toolkit. Оси параметризации: {{TMS}} (название TMS),
[test-stack] — базовый page-класс, каркасы кода, реестры, хелперы (референс one-web:
pytest+Selenium; операции — adapters/test-stack/CONTRACT.md), [browser-driver] — стратегия
селекторов (adapters/browser-driver/CONTRACT.md), [vendored-dep] — внешняя базовая
библиотека, [product-api] — исходники продукта как источник i18n. Примеры кода —
референс one-web; при bootstrap заменить на каркасы своего стека, сохранив принципы.
Комментарий удаляется при bootstrap. -->

# Конвенции Page Objects и Chunks

> **Карта приложения.** Перед добавлением/правкой page/chunk-класса — открой карту AUT (`.tasks/aut-research/AUT_OVERVIEW.md`, паттерн living-AUT-map). Там описаны разделы AUT, sidebar'ы, формы и служебные routes — помогает понять, к какому корневому элементу/URL привязывать новый класс. Документ — снимок UI на конкретной версии/сборке AUT, может отставать от реальности. Если правишь page/chunk потому, что в UI что-то изменилось — параллельно обнови соответствующий раздел карты + строку changelog.

Page/Chunk и их локаторы живут в **отдельных модулях page-object слоя** по раскладке
выбранного `[test-stack]` (референс one-web: `tests/pages/<name>.py`,
`tests/pages/chunks/<name>.py` и зеркальные locators-каталоги). Тестовый модуль только
импортирует/получает зарегистрированный класс; объявлять Page/Chunk/Locators рядом с тестовой
функцией нельзя.

## Структура класса page

Page-классы строятся по mixin-паттерну `Internal × Locators`: внутренний класс несёт логику (методы действий), внешний — привязку к версии UI и подмешанный класс локаторов. Логика и локаторы не смешиваются в одном классе.

Образец каркаса — референс one-web (база `PBase` из vendored-библиотеки; при bootstrap заменить на каркас своего стека, сохранив разделение):

```python
from .locators import Version2 as Version2Locators
from autocore.base.web.base_page import PBase          # [vendored-dep] базовый page-класс
from autocore.test.logger import get_log               # [vendored-dep] логгер библиотеки

log = get_log()


class _PVersionLogin(PBase, _LocatorsTypingBase):   # внутренний класс с логикой
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_HEADER()
        self.page_path = ''
        super().__init__(*args, **kwargs)

    # методы действий — каждый оборачивает log.step
    def input_login(self, username: str, check_value=False):
        log.step(f'Ввести логин "{username}"', where='<лейбл AUT-клиента>')
        self.get_object(self.L_INPUT_LOGIN()).send_keys(username)


class PVersion2Login(_PVersionLogin, Version2Locators.LLogin):  # внешний класс с привязкой к версии
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.version = 'Version2'
```

Chunk-классы (переиспользуемые куски UI: сквозные виджеты — тосты, диалоги, меню, карточки) — то же самое, только префикс `C` вместо `P`:

```python
class _CLeftMenu(PBase, _LocatorsTypingBase):
    ...

class CVersion2LeftMenu(_CLeftMenu, Version2Locators.LLeftMenu):
    ...
```

### Многоуровневая иерархия chunks

Когда несколько chunk'ов разделяют общий UI-фрагмент с парой специфичных вариаций (референс one-web: профиль группового чата и профиль информационного канала живут в одном sidebar-компоненте с одинаковым набором кнопок — отличаются только пара методов и тексты delete-confirm диалога), вынеси общую часть в базовый Internal-класс и параллельный Locators-base, а специфичные методы и атрибуты — в подклассы:

```python
# референс one-web: tests/pages/chunks/chat_profile_base.py
class _CChatProfileBase(PBase, _LocatorsTypingBase):
    def click_more_menu_btn(self): ...
    def click_delete_chat_btn(self): ...                 # использует self.L_I18N_DELETE_CONFIRM_DIALOG
    ...

# tests/pages/chunks/group_chat_profile.py
class _CGroupChatProfile(_CChatProfileBase, _LocatorsTypingBase):
    def toggle_chat_public(self): ...                    # group-only

class CVersion2GroupChatProfile(_CGroupChatProfile, Version2Locators.LGroupChatProfile):
    ...

# tests/pages/chunks/info_channel_profile.py
class _CInfoChannelProfile(_CChatProfileBase, _LocatorsTypingBase):
    pass                                                  # пока без channel-only методов

class CVersion2InfoChannelProfile(_CInfoChannelProfile, Version2Locators.LInfoChannelProfile):
    ...
```

Локаторы зеркалят иерархию. Специфика выносится через class-attribute, который читается из base-локатора:

```python
class LChatProfileBase:
    _DELETE_CONFIRM_TITLE_KEY = None                      # переопределяется в подклассе

    @classmethod
    def L_I18N_DELETE_CONFIRM_DIALOG(cls, lang):
        i18n_str = i18n.get_str(cls._DELETE_CONFIRM_TITLE_KEY, lang)
        ...

class LGroupChatProfile(LChatProfileBase):
    _DELETE_CONFIRM_TITLE_KEY = 'group_chat_profile_delete_chat_confirm_dialog_title'

class LInfoChannelProfile(LChatProfileBase):
    _DELETE_CONFIRM_TITLE_KEY = 'group_chat_profile_delete_channel_confirm_dialog_title'
```

Каждый внешний `CVersion2<Name>` всё равно регистрируется отдельным ключом в реестре chunk'ов (например, `'group_chat_profile'` и `'info_channel_profile'`). Базовый `_CChatProfileBase` / `LChatProfileBase` в реестре НЕ регистрируется — он только для наследования, не для прямого использования из тестов.

**Когда стоит вводить такую иерархию:**
- 5+ общих методов между двумя-тремя chunk'ами одного «семейства».
- Реальные семантические различия в нескольких методах (не просто `is_channel` параметр — это антипаттерн, проще сделать subclass).
- Один и тот же DOM-корень (референс one-web: общий sidebar-компонент для group/channel) или хотя бы один и тот же набор селектор-фрагментов.

Если общего меньше или DOM-корни принципиально разные — оставь chunk'и независимыми, не натягивай общую базу ради 1–2 селекторов.

## Регистрация в реестрах

Каждый новый page обязательно добавляется в реестр page'ей, каждый chunk — в реестр chunk'ов (референс one-web: `tests/pages/__init__.py:get_page(version, page_name)` и `tests/pages/chunks/__init__.py:get_chunk(...)`). Без этого тест не сможет получить класс.

## Локаторы

- [test-stack] Лежат в отдельных файлах по страницам, chunk'овые — в подкаталоге chunks (референс one-web: `tests/pages/locators/Version2/<page_name>.py` и `.../Version2/chunks/<name>.py`).
- Класс называется `L<PageName>` (например, `LLogin`, `LLeftMenu`).
- Каждый локатор — метод с префиксом `L_`: `def L_INPUT_LOGIN(self) -> tuple[str, str]: return (By.XPATH, '//...')`.
- Локализованные локаторы принимают `lang`: `L_I18N_WRONG_AUTH_TEXT(self, lang)`.
- [browser-driver] **Стратегия селекторов** — параметр проекта, задаётся при bootstrap (`{{TOOLKIT}}/adapters/browser-driver/CONTRACT.md`: приоритет якорей testid → роль/aria → семантический XPath) и должна совпадать со стратегией браузерного разведчика (dom-explorer). Референс one-web: testid'ов в продукте нет → XPath приоритетнее CSS.

### Составные виджеты (toggle/checkbox): раздельные локаторы по ролям

Драйвер кликает в геометрический центр элемента. У контейнеров составных виджетов дизайн-системы центр может попадать в пустую зону между текстовой меткой и control'ом — событие до control не доходит (прецедент-референс one-web: toggle/checkbox-контейнеры, воспроизводилось на всех 4 браузерах). Поэтому на такой виджет — **пара-тройка локаторов с разными ролями**, а не один:

- `L_I18N_<X>_SWITCH` → внутренний интерактивный элемент — для **клика**. Не целиться в сам крошечный `<input>` (референс one-web: 34×14 px — Safari/Firefox дают `not interactable`).
- `L_I18N_<X>_CHECKBOX` → элемент состояния (`<input type="checkbox">`) — для **чтения состояния** (`is_selected()`; checked есть только как JS-property).
- Внешний контейнер — корень для чайлдов и `assert_presence`, по нему **не кликать**.

Правила применимы к аналогичным виджетам любой библиотеки компонентов — при смене библиотеки тегов дизайн-системы переноси роли на новые теги (референс one-web: миграция `ds-*` → `iva-*`, правила те же).

## Логирование

Каждое действие пользователя — `log.step(<текст>, where=<лейбл AUT-клиента>)`. Текст в инфинитиве, как в {{TMS}}: «Ввести логин», «Нажать кнопку», «Открыть профиль». Это попадает в отчёт {{TMS}} как step.

Для технических логов: `log.info` / `log.debug` / `log.warn`.

## Локализованные тексты

Через словарь строк проекта (референс one-web: `tools.i18n`):

```python
from tools import i18n
wrong_auth_text = i18n.get_str('wrong_auth_text', self.lang)
```

Новые ключи добавлять в словарь проекта (см. существующую структуру). Никаких хардкод-строк на языках локализации в page-классах.

[product-api] Значение нового ключа для второго языка — подтверждённый перевод из i18n-первоисточника исходников продукта, если локальный клон доступен (референс one-web: найти RU-текст в `ru-RU.json` i18n-ассетов продукта и взять значение того же ключа из соседнего `en-US.json`; карта клона — CLAUDE.md проекта → «Исходники продукта»). Ключ не нашёлся или репо недоступно — явное значение-заглушка `'TODO'`. Не дублировать текст первого языка с пометкой `# TODO: EN` — это ломает grep непереведённого.

## Ассерты

[test-stack] Проверки — через API базового page-класса, не изобретать свои (референс one-web, `PBase` vendored-библиотеки):

- `assert_fn(lambda: ..., msg)` — для проверок-«ждунов».
- `self.assert_presence(locator, message)` — проверить наличие элемента.
- `self.wait_presence(locator, message)` — дождаться.

Инварианты (стек-независимые):

- **Ассерт = проверка, требуемая сценарием ТК.** Каждый `assert_*` рождает шаг-проверку в отчёте {{TMS}} — читатель отчёта считает его частью спецификации. Служебное ожидание готовности UI (страница открылась, список смонтирован), которого нет в ожидаемых результатах ТК, — тихий `wait_*` без ассерта. И наоборот: проверка из ТК не может быть тихим wait — только видимым ассертом.
- **`assert_presence` сам пишет step отчёта** из `message` — не оборачивай его в `log.step` (получится двойной шаг в отчёте). То же для остальных `assert_*` базового класса. `wait_presence` — когда нужно дождаться без ассерта, нужен явный timeout или step уже пишется выше.
- **Сообщения ассертов — констатация факта**, не долженствование: «Кнопка отображается», «Поле НЕ доступно» (не «должна быть отображена», не «должно появиться»). Стиль сверяй с существующими: `Grep "assert_presence" <каталог page'ей>`.
- **Нестабильные DOM-области — через специализированный assert-хелпер**, не голый `assert_presence`: если у области есть известный класс нестабильности, хелпер инкапсулирует обход, и все тесты получают его автоматически (референс one-web: новое сообщение чата под Safari/Firefox стирается background-sync'ом через доли секунды после появления — optimistic-UI wipe; хелпер `_assert_chat_message_present` делает MutationObserver-fallback, для media-сообщений матчит по тегу, а не filename).

## Общие хелперы

[test-stack] Межстраничные хелперы живут в одном общем модуле (референс one-web: `tools/helpers/page_helpers.py`). Не плодить дубли — перед новым хелпером проверь существующие. Роли-образцы из референса:

- `upload_file_via_js(driver, file_input, local_path)` — upload файла через `DataTransfer` + dispatch событий; для браузеров, где `send_keys(path)` не работает с custom-input'ами.
- `wait_clickable_via_js(driver, element_getter, timeout=10)` — наблюдаемое ожидание «реально кликабельно»: размеры > 0, не disabled, не перекрыто другим элементом (`elementFromPoint`).
- `wait_api_idle(driver, idle_window_ms=500, timeout=5.0)` — наблюдаемое ожидание тишины по API-запросам (через performance-API браузера). Вызвать ПЕРЕД операцией (upload, save, send), которая на бэке плохо переносит гонку с фоновыми запросами. Закрывает класс flake'ов вида «автоматизация бежит быстрее реального пользователя».
- скролл-обходы браузерных багов (референс one-web: скролл виртуального списка чата через JS — обход бага auto-scroll в Safari/Firefox под WebDriver).

Если нужен новый хелпер межстраничного характера — клади его в общий модуль, а не в page/chunk-специфичный.

**Критерий принадлежности метода page/chunk:** метод остаётся в page/chunk, только если использует его локаторы/DOM-контекст или кодирует шаг сценария этого экрана. Технический примитив без привязки к экрану (JS-скролл произвольного контейнера, эмуляция сети, observer-латч, чтение performance-API) — сразу в общий модуль хелперов, даже если сейчас нужен одному page. В page/chunk допустима тонкая обёртка над хелпером, добавляющая семантику экрана (step, локаторы, тайминги раздела).

## Браузерные гарды

Ветвление по браузеру — через один канонический признак драйвера, единый по всей кодобазе (референс one-web: `self.driver.name`, не `driver.capabilities['browserName']`). Канон — case-insensitive сравнение: `self.driver.name.lower() == 'safari'` (драйвер может возвращать имя в разном регистре в зависимости от версии).

## Синтетический клик (click_via_js) — только доказанно

По умолчанию — обычный нативный клик через базовый page-класс. Реальные `<button>`, элементы меню, кнопки дизайн-системы кликаются классически на всех браузерах. Синтетический JS-клик — точечно, когда обычный клик **эмпирически** падает (как правило `ElementNotInteractableException` на Safari) на кастомном контейнере, где кликабельна вложенная нода (референс one-web: узел нав-дерева, где внутренняя ссылка триггерит router фреймворка — синтетический клик на Safari не навигирует). Прежде чем ставить JS-клик — прогони обычный клик на проблемном браузере; падает → JS + комментарий почему. Не копируй синтетический клик из соседнего метода «на всякий случай» — он маскирует реальное поведение и обходит нативную проверку интерактивности.

## Тосты — через chunk `toast`

Тост — глобальный сквозной виджет (один wrapper на всё приложение). Любая проверка / ожидание тоста идёт через единый chunk `toast`, чтобы не плодить локальные `L_I18N_*_TOAST` в каждом page/chunk:

```python
from tests.pages import chunks

toast = chunks.get_chunk(self.version, 'toast')(driver=self.driver, lang=self.lang)
toast.assert_i18n_visible('group_chat_profile_copy_link_toast',
                          'Отображается тост "Ссылка скопирована"')
toast.wait_i18n_visible('group_chat_profile_copy_link_toast')   # короткое ожидание появления
toast.wait_disappear()                                           # перед повторным кликом
```

API chunk'а (референс one-web: `CVersion2Toast`, `tests/pages/chunks/toast.py`):
- `assert_visible_by_text(text, message=None)` / `assert_i18n_visible(key, message=None)`
- `wait_visible_by_text(text, timeout=5)` / `wait_i18n_visible(key, timeout=5)`
- `wait_disappear(timeout=10)` — ожидание исчезновения wrapper'а.

Локаторы — в классе локаторов chunk'а (`LToast`): `L_ROOT`, `L_TOAST`, `L_TOAST_BY_TEXT(text)`, `L_I18N_TOAST(key, lang)`. Не определяй новых `L_I18N_*_TOAST` в pages/chunks — используй `LToast.L_I18N_TOAST(key, lang)` или соответствующий метод chunk'а. Тот же принцип — для любого другого глобального сквозного виджета.

## Чего не делать

- Не объявлять Page/Chunk-классы и их Locators внутри тестового модуля. Создать отдельный
  модуль стека, зарегистрировать класс и импортировать/получать его из теста.
- [test-stack] Не лезть в драйвер напрямую — используй методы базового page-класса (референс one-web: `get_object`, `wait_presence`, `assert_presence`, ...).
- Не дублировать локаторы между файлами — выноси в общий чанк, если нужен в двух местах.
- Не плодить page без регистрации в реестре.
- Не ссылаться в комментариях/докстрингах на агентскую инфраструктуру — только предметное содержимое (конвенция — CLAUDE.md проекта → «Git-конвенции»).
- [vendored-dep] Не править базовый page-класс внешней библиотеки (референс one-web: `{{DEP_PATH}}/base/web/base_page.py`).
