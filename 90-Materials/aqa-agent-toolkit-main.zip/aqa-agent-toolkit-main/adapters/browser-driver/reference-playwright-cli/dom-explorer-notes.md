# dom-explorer — заметки референс-реализации: playwright-cli + selenoid (one-web)

Инструментальный мануал, вынесенный при порте из субагента ядра
`core/claude/agents/dom-explorer.md`. Референс web-реализации контракта
`adapters/browser-driver/CONTRACT.md`: playwright-cli (интерактивная разведка DOM) +
mac-selenoid (реальный Safari для браузер-специфичных падений).

Всё содержимое — референс инсталляции-источника one-web: стенды `at-test-*`, юзеры,
IP grid'а, Angular-теги — примеры, при bootstrap подставляются значения своего проекта
в [browser-driver]-блоки субагента.

## Справка по командам playwright-cli

| Команда | Назначение |
|---------|-----------|
| `playwright-cli open <url>` | Открыть браузер |
| `playwright-cli goto <url>` | Перейти по URL |
| `playwright-cli snapshot` | Accessibility-снапшот (предпочтительнее скриншота) |
| `playwright-cli click <ref>` | Левый клик |
| `playwright-cli fill <ref> "text"` | Заполнить поле |
| `playwright-cli type "text"` | Ввести текст в активный элемент |
| `playwright-cli hover <ref>` | Навести курсор |
| `playwright-cli press <Key>` | Нажать клавишу (Enter, ArrowDown и т.д.) |
| `playwright-cli screenshot` | Скриншот (если нужно визуально) |
| `playwright-cli eval "code"` | Выполнить JavaScript |
| `playwright-cli go-back` | Вернуться назад |
| `playwright-cli close` | Закрыть браузер |

> `ref` из снапшота используется **только** для взаимодействия в браузере — в итоговый
> артефакт записывается селектор, не `ref` (инвариант контракта).

Грабля-референс: профиль playwright-cli персистентен и является синглтоном на машину —
параллельные разведчики бьются за SSO-сессию (см. CONTRACT.md → «Сессия и доступ»).

## Последовательность входа (референс one-web)

```bash
playwright-cli open https://at-test-1-one.ivcs.su/
playwright-cli fill e13 "<username из ensure>"
playwright-cli fill e17 "<password из ensure>"
playwright-cli click e21
```

После клика, через несколько секунд (не больше 10), появится попап разрешения уведомлений:
```bash
playwright-cli click e911
playwright-cli snapshot
```

Убедиться по снапшоту, что приложение загрузилось (нет попапа, виден интерфейс).

> **Если ref кнопок (e13, e17, e21, e911) изменились** — сделать `playwright-cli snapshot`
> и найти актуальные ref через accessibility-дерево.

## Правый клик (контекстное меню)

```bash
playwright-cli hover <ref_элемента>
playwright-cli mousedown right
playwright-cli mouseup right
playwright-cli snapshot
```

## Проверка XPath через eval

### mode=fix — есть ли узел (true/false)

```bash
playwright-cli eval "document.evaluate('//chat-sidebar//input[@type=\"file\"]', document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue !== null"
```
Возвращает `true`/`false` — есть ли элемент по этому XPath.

### mode=canary — подсчёт узлов (count ≥ 1)

```bash
playwright-cli eval "document.evaluate('<xpath>', document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null).snapshotLength"
```
Как в mode=fix, но считается число узлов: `≥1` → OK; `0` → BROKEN.

## Выбор браузерного движка (референс-матрица one-web)

| Кейс | Движок | Инструмент |
|---|---|---|
| Default — DOM / локаторы / Angular-структура | Chromium | `playwright-cli` (по умолчанию) |
| Проверить WebKit-специфичный рендер без mac-selenoid | WebKit | `playwright-cli open --browser=webkit` |
| **Safari-specific падения** (window.handles, popup, sent-status timing, click event) | Real Safari через mac-selenoid | `python .claude/scripts/selenoid_safari.py` (см. ниже) |

Решение по умолчанию — `playwright-cli`. На Safari — только когда упавший тест помечен
`failed_in: safari` и проблема не воспроизводится в Chromium/WebKit.

## Safari через mac-selenoid

Реальный Safari на macOS воспроизводит баги, которых нет в Playwright WebKit: ordering
`window.handles`, popup blocker, click event timing, sent-status icon обновление, и т.д.

### Helper

Файл `.claude/scripts/selenoid_safari.py` — обёртка над Selenium webdriver.Remote с подключением к `mac-selenoid` (IP читается из `config.yaml`; env по умолчанию — `default_env()` из `selenoid_common.py`: стенд активной линии, явный `--env` перекрывает).

**Ключевая особенность**: каждая Safari-сессия = один Python-скрипт. Reattach между вызовами **не поддерживается** (Safari WebDriver на selenoid плохо переживает повторные подключения). Поэтому весь сценарий разведки нужно собрать в одну Python-функцию, прогнать, сохранить артефакты.

### Доступные функции внутри сценария

| Функция | Назначение |
|---|---|
| `drv` | `selenium.webdriver.Remote` с открытой Safari-сессией |
| `dump_html(drv, xpath, first_n=3)` | `outerHTML` первых N элементов по XPath (для DOM-снапшота) |
| `xpath_count(drv, xpath)` | Сколько элементов нашлось |
| `wait_xpath(drv, xpath, timeout=15)` | Polling до появления элемента; `True/False` |
| `screenshot(drv, path)` | PNG-скриншот в `path` |
| `window_dump(drv)` | Список всех окон с URL/title (важно для редирект-кейсов) |
| `login_iva_one(username, password)` | Стандартная авторизация в AUT (референс one-web) |

### Запуск

```bash
# вариант 1: inline-скрипт
./venv/bin/python .claude/scripts/selenoid_safari.py --script "drv.get('https://at-test-1-one.ivcs.su/'); print(drv.title)"

# вариант 2: сценарий из файла
./venv/bin/python .claude/scripts/selenoid_safari.py --file .tasks/work/<task>/safari_scenario.py
```

Для нетривиальных сценариев — оформлять как файл в `.tasks/work/<task>/safari_<test_name>.py`.

*(В оригинале one-web пути в этих командах были с обратными слэшами
(`.claude\scripts\...`) — исправлено при порте, помечено как дрейф оригинала.)*

### Шаблон сценария

```python
# .tasks/work/<task>/safari_<test_name>.py — выполняется в области сценария selenoid_safari
# В scope доступны: drv, dump_html, xpath_count, wait_xpath, screenshot, window_dump, login_iva_one, time

import time

# 1. Логин
login_iva_one('<username>', '<password>')
wait_xpath(drv, '//chats-list', timeout=20)

# 2. Воспроизвести сценарий до точки падения
# ... шаги UI: drv.find_element('xpath', '...').click(), .send_keys('...'), ...

# 3. Снять DOM в точке интереса
print(dump_html(drv, '//chat-message-container[last()]'))
screenshot(drv, '.tasks/work/<task>/safari_<test_name>_step.png')

# 4. Проверить целевой локатор
print('matches:', xpath_count(drv, '//ds-icon-check-bold[contains(@class,"icon_sent")]'))
```

### Доступ к стенду (референс one-web)

- mac-selenoid: `10.6.0.219:4444`
- Перед запуском проверить сеть: `nc -z -G 3 10.6.0.219 4444` (exit 0 = доступен). Если недоступен (exit ≠ 0) — выйти с сообщением «нет доступа к mac-selenoid».
- VNC живой сессии: `http://10.6.0.219:4444/vnc/<session_id>` (скрипт сам выводит URL при открытии).
- Список активных сессий: `curl http://10.6.0.219:4444/status`.

### Формат вывода (mode=fix, Safari)

`{batch_dir}/fix-{test_name}-locators.md`, в дополнение к обычным секциям (общий формат — субагент
ядра, «Формат вывода (mode=fix, реальный браузер)»), добавить:

````markdown
## Safari (mac-selenoid) — фактический DOM в точке падения

- session VNC: http://10.6.0.219:4444/vnc/<id>
- scenario file: .tasks/work/<task>/safari_<test_name>.py
- screenshot:  .tasks/work/<task>/safari_<test_name>_step.png

### DOM фрагмент

```html
<chat-ui-seen-status ...>...</chat-ui-seen-status>
```

### Проверка целевого XPath
- count = N (где N=0 если не найден)
- альтернативный XPath, который находит реальный элемент: `//...`
````

### Ограничения Safari-режима

- Один сценарий = одна сессия. Между запусками `selenoid_safari.py` Safari-сессия закрывается, и DOM-состояние теряется. Если нужно «подвиснуть» в точке для мануального VNC-просмотра — добавить `time.sleep(N)` в конец сценария.
- Старт Safari ≈ 1с, login ≈ 5с, полный сценарий обычно 15-30с. Долгие сценарии (chat + media) — до 60с. По умолчанию `sessionTimeout=600s` хватит.
- Если сессия зависла и не закрылась штатно — она будет жить до `sessionTimeout` (10 минут), затем Selenoid сам её прибьёт. Можно вручную через `curl -X DELETE -m 5 http://10.6.0.219:4444/wd/hub/session/<id>` (наш `-m 5` нужен, потому что DELETE сам по себе может зависнуть).
- Параллельных Safari-сессий нет (mac-selenoid выдаёт по одной за раз — Safari instance is paired with another WebDriver session). Если получена эта ошибка — кто-то уже работает, надо подождать или прибить чужую сессию через `/status` + DELETE.
