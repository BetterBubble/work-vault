# reference-playwright-cli — референс browser-driver-порта (web)

Референс web-реализации контракта `adapters/browser-driver/CONTRACT.md`: инструмент
разведки — [microsoft/playwright-cli](https://github.com/microsoft/playwright-cli).

## Установка — апстримом, в тулкит не вендорится

Инструмент **сам поставляет свой скилл**: `playwright-cli install --skills` копирует
SKILL.md + references в `.claude/skills/` проекта; обновление — вместе с инструментом
(npm). Поэтому мануал в тулкит **не вендорится** — снапшот немедленно начинает
отставать от апстрима, а `install --skills` конфликтует с локальными правками
(урок референс-инсталляции one-web: апстрим-снапшот с вставками проектных конвенций
прямо в тело SKILL.md → форк без ресинка).

Bootstrap web-проекта:

1. `npm i -g @playwright/cli` (или локально в проект).
2. `playwright-cli install --skills` — штатный скилл в `.claude/skills/`.
3. Апстрим-скилл **не править**: конвенции проекта поверх инструмента живут в нашем
   слое — у субагента dom-explorer (единственный потребитель браузер-CLI): гигиена
   артефактов (`--filename` → служебный каталог), login-state (`state-save`/`state-load`),
   REST-setup вместо UI — уже в `core/claude/agents/dom-explorer.md`.

## Что лежит рядом

- `dom-explorer-notes.md` — наши заметки реализации контракта поверх playwright-cli
  (последовательность входа, грабли инструмента, Safari через grid) — на них ссылается
  dom-explorer ядра.

## Известное ограничение (референс one-web)

Профиль браузера playwright-cli — синглтон на машину: параллельные разведчики бьются
за SSO-сессию (см. CONTRACT.md «Сессия и доступ»; one-web TODO-052 — изоляция per-task
открыта). Разведка в real-браузерах вне chromium/webkit — `reference-selenoid/`.
