"""
Общие утилиты для selenoid_<os>_<browser>.py helper'ов.

Архитектура: каждый helper (selenoid_mac_safari.py, selenoid_win_firefox.py, ...) —
тонкая обёртка вокруг этого модуля. Он:
- читает config.yaml, возвращает IP нужного selenoid'а;
- открывает webdriver.Remote-сессию с capabilities под конкретный (os, browser);
- даёт стандартный набор разведочных функций (dump_html, xpath_count, wait_xpath,
  screenshot, window_dump, login_iva_one).

Все helper'ы реализуют один и тот же контракт:

    from selenoid_<x> import <browser>_session, dump_html, ...

    with <browser>_session() as drv:           # env по умолчанию — default_env()
        drv.get('https://...')
        print(dump_html(drv, '//some-xpath'))

Дефолтный env выбирается по активной агентской ветке (default_env()):
at-creation-crc -> at-test-3-one (RC-линия), иначе -> at-test-1-one (main-линия).
См. one-web CLAUDE.md -> «Ветки и линии разработки».

Reattach между вызовами не поддерживается (Selenoid сессия закрывается при
выходе из context manager'а). Если нужен интерактивный VNC-просмотр —
добавь time.sleep(...) в конец сценария.
"""
from __future__ import annotations

import time
from contextlib import contextmanager
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


# ============================================================
# Конфиг
# ============================================================

def _load_config():
    import yaml
    with open(ROOT / 'config.yaml') as f:
        return yaml.safe_load(f)


def default_env() -> str:
    """
    Дефолтный стенд по активной агентской ветке (CLAUDE.md «Ветки и линии»):
    at-creation-crc -> at-test-3-one (RC), иначе -> at-test-1-one (main-линия).
    """
    import subprocess
    try:
        branch = subprocess.run(
            ['git', 'branch', '--show-current'], cwd=ROOT,
            capture_output=True, text=True, timeout=10,
        ).stdout.strip()
    except Exception:
        branch = ''
    return 'at-test-3-one' if branch == 'at-creation-crc' else 'at-test-1-one'


# Карта (os, browser) → ключ selenoid'а в config.yaml
SELENOID_KEY = {
    ('lin', 'chrome'): 'selenoid',
    ('win', 'chrome'): 'new-win-selenoid',
    ('win', 'firefox'): 'new-win-selenoid',
    ('win', 'msedge'): 'new-win-selenoid',
    ('win', 'ya'): 'new-win-selenoid',
    ('mac', 'safari'): 'mac-selenoid',
}

# browserName в W3C capabilities (отличается от имени маркера)
BROWSER_NAME = {
    'chrome': 'chrome',
    'firefox': 'firefox',
    'msedge': 'MicrosoftEdge',
    'ya': 'yandex',
    'safari': 'safari',
}

# Yandex binary_location — путь к ya-браузеру внутри Windows-selenoid VM.
# Источник: venv/lib/python3.13/site-packages/autocore/aut/__init__.py:62
YANDEX_BINARY = r'C:\Users\gitlab\AppData\Local\Yandex\YandexBrowser\Application\browser.exe'


def _selenoid_url(env: str, os_name: str, browser: str) -> str:
    cfg = _load_config()
    key = SELENOID_KEY.get((os_name, browser))
    if key is None:
        raise ValueError(f'No selenoid mapping for ({os_name}, {browser})')
    ip = cfg[env][key]
    return f'http://{ip}:4444/wd/hub'


# ============================================================
# Открытие сессии
# ============================================================

@contextmanager
def open_session(os_name: str, browser: str, env: str | None = None,
                 session_timeout: str = '600s', enable_vnc: bool = True):
    """
    Открыть webdriver.Remote-сессию на нужном selenoid'е. Context manager
    гарантирует drv.quit() при выходе.

    Параметры:
        os_name      — 'win' | 'lin' | 'mac'
        browser      — 'chrome' | 'firefox' | 'msedge' | 'ya' | 'safari'
        env          — имя стенда из config.yaml (None -> default_env() по ветке)
        session_timeout — таймаут сессии (формат selenoid: '600s')
        enable_vnc   — включить VNC (для интерактивного дебага; selenoid Windows/Mac
                       поддерживают, lin — да)

    Yields:
        selenium.webdriver.remote.webdriver.WebDriver
    """
    from selenium import webdriver

    env = env or default_env()
    url = _selenoid_url(env, os_name, browser)
    browser_name = BROWSER_NAME[browser]
    caps = {
        'browserName': browser_name,
        'sessionTimeout': session_timeout,
        'enableVNC': enable_vnc,
    }

    # Browser-specific capabilities
    if browser == 'ya':
        # Yandex использует chromedriver под капотом — нужно указать binary через chromeOptions
        caps['goog:chromeOptions'] = {'binary': YANDEX_BINARY}
    elif browser == 'chrome' and os_name == 'lin':
        caps['browserVersion'] = 'latest'

    print(f'[{os_name}_{browser}] opening session on {url} ...', flush=True)
    t0 = time.time()
    drv = webdriver.Remote(command_executor=url, desired_capabilities=caps)
    print(f'[{os_name}_{browser}] session={drv.session_id} opened in {time.time() - t0:.1f}s', flush=True)
    host = url.split('//')[1].split(':')[0]
    print(f'[{os_name}_{browser}] vnc:  http://{host}:4444/vnc/{drv.session_id}', flush=True)
    try:
        yield drv
    finally:
        try:
            print(f'[{os_name}_{browser}] closing session {drv.session_id} ...', flush=True)
            drv.quit()
            print(f'[{os_name}_{browser}] closed', flush=True)
        except Exception as e:
            print(f'[{os_name}_{browser}] WARN quit failed: {e}', flush=True)


# ============================================================
# Утилиты для DOM-разведки внутри сессии
# ============================================================

def xpath_count(drv, xpath: str) -> int:
    """Количество элементов, найденных по XPath."""
    return len(drv.find_elements('xpath', xpath))


def dump_html(drv, xpath: str, first_n: int = 3, max_chars: int = 3000) -> str:
    """outerHTML первых N элементов по XPath. Удобно для DOM-снапшота."""
    elems = drv.find_elements('xpath', xpath)
    out = [f'count: {len(elems)}']
    for i, el in enumerate(elems[:first_n]):
        try:
            html = drv.execute_script('return arguments[0].outerHTML;', el) or ''
        except Exception as e:
            html = f'<error: {e}>'
        out.append(f'--- #{i} ---')
        out.append(html[:max_chars])
    return '\n'.join(out)


def screenshot(drv, path):
    """Сохранить PNG-скриншот."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    drv.get_screenshot_as_file(str(path))
    return path


def wait_xpath(drv, xpath: str, timeout: float = 15.0) -> bool:
    """Дождаться появления элемента (polling без stale-логики)."""
    end = time.time() + timeout
    while time.time() < end:
        if drv.find_elements('xpath', xpath):
            return True
        time.sleep(0.3)
    return False


def window_dump(drv) -> str:
    """Описание всех окон: handle, url, title."""
    cur = drv.current_window_handle
    handles = drv.window_handles
    out = [f'current: {cur}']
    for i, h in enumerate(handles):
        drv.switch_to.window(h)
        out.append(f'  [{i}] {h}  url={drv.current_url}  title={drv.title}')
    if cur in handles:
        drv.switch_to.window(cur)
    return '\n'.join(out)


# ============================================================
# Стандартный логин в IVA ONE WEB
# ============================================================

def login_iva_one(drv, username: str, password: str, env: str | None = None):
    """
    Открыть IVA ONE WEB и авторизоваться через Keycloak-форму.
    Локаторы — те же что в tests/pages/locators/Version2/login.py.
    """
    cfg = _load_config()
    web_url = cfg[env or default_env()]['web_url']
    print(f'[selenoid] login as {username} on {web_url}', flush=True)
    drv.get(web_url)
    if not wait_xpath(drv, '//input[@name="username"] | //input[@id="username"] | //input[@type="email"]', 20):
        raise RuntimeError('login: username field not found')
    drv.find_element('xpath', '//input[@name="username"] | //input[@id="username"] | //input[@type="email"]').send_keys(username)
    drv.find_element('xpath', '//input[@type="password"]').send_keys(password)
    drv.find_element('xpath', '//button[@type="submit"] | //input[@type="submit"]').click()
    print('[selenoid] login submitted', flush=True)


# ============================================================
# CLI-helper для запуска сценариев
# ============================================================

def run_scenario(os_name: str, browser: str, env: str | None, code: str):
    """
    Выполнить произвольный Python-фрагмент внутри open_session.

    В scope доступны:
        drv               — webdriver
        dump_html(drv, xpath, first_n=3)
        xpath_count(drv, xpath)
        screenshot(drv, path)
        wait_xpath(drv, xpath, timeout=15)
        window_dump(drv)
        login_iva_one(u, p, env=env)
    """
    env = env or default_env()
    with open_session(os_name, browser, env=env) as drv:
        scope = {
            'drv': drv,
            'dump_html': dump_html,
            'xpath_count': xpath_count,
            'screenshot': screenshot,
            'wait_xpath': wait_xpath,
            'window_dump': window_dump,
            'login_iva_one': lambda u, p, e=env: login_iva_one(drv, u, p, e),
            'time': time,
        }
        exec(compile(code, '<scenario>', 'exec'), scope)
