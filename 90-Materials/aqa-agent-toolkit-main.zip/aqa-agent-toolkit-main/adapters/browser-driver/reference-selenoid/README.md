# Selenoid-семейство — webdriver.Remote-сессии per-(os,browser) (референс browser-driver-порта)

Второй компонент web-референса контракта `adapters/browser-driver/CONTRACT.md`, рядом с
`reference-playwright-cli/`. Если playwright-cli — интерактивная разведка в локальном
Chromium (снапшоты, ref-клики, persistent-профиль), то selenoid-семейство — **прямые
`webdriver.Remote`-сессии на Selenoid-гриде** для DOM-разведки в конкретной паре
(os, browser). Исходник — one-web, `.claude/scripts/selenoid_*.py`; читатели — субагент
dom-explorer и скилл fix-failed-test.

Когда нужен selenoid, а не playwright-cli:

- разведка/repro **именно в целевом браузере прогона** — playwright-cli даёт только
  Chromium, а падение может быть браузер-специфичным (Safari, Firefox, Edge, Yandex);
- **VNC-наблюдение** за живой сессией (`open_session` печатает готовую ссылку
  `http://<grid>:4444/vnc/<session_id>`);
- среда, **идентичная раннерной**: тот же грид, те же browser-образы/VM, что у CI-прогона —
  поведенческий вывод переносится на прогон без оговорки «среда разведки ≠ среда прогона»
  из CONTRACT.md.

## Архитектурный паттерн (generic, переносится)

Семейство = **ядро + тонкие обёртки единого контракта + CLI-раннер + shim**:

1. **Ядро `selenoid_common.py`** — вся логика в одном модуле:
   - конфиг-загрузка (`_load_config` → `config.yaml` проекта);
   - декларативная карта `SELENOID_KEY: (os, browser) → ключ грида в конфиге` и
     `BROWSER_NAME: маркерное имя → browserName` W3C-capabilities;
   - `open_session(os, browser, env)` — context manager с **гарантированным `drv.quit()`**
     в `finally`, логом времени старта и **VNC-ссылкой** сразу после открытия;
   - стандартный набор разведочных функций: `dump_html` (outerHTML первых N узлов по XPath),
     `xpath_count`, `wait_xpath` (поллинг появления), `screenshot`, `window_dump`
     (все окна: handle/url/title), `login_<product>` (штатная авторизация);
   - `run_scenario(os, browser, env, code)` — CLI-исполнитель произвольного Python-фрагмента
     внутри открытой сессии: в scope прокинуты `drv` и все разведочные функции.
2. **Тонкие per-(os,browser) обёртки** `selenoid_<os>_<browser>.py` — единый контракт
   `<browser>_session(env=None, session_timeout='600s')`. Обёртка не несёт логики: фиксирует
   пару `(os, browser)`, реэкспортирует разведочные функции (`__all__`) и даёт CLI-раннер
   `--script "..."` | `--file scenario.py` [`--env <стенд>`]. Browser-специфичные дельты
   capabilities живут **в ядре** (ветки `open_session` + константы), не в обёртках —
   обёртки текстуально идентичны с точностью до пары и докстринга.
3. **Shim обратной совместимости** — при переименовании модуля старое имя остаётся
   файлом-реэкспортом (`selenoid_safari.py` → `selenoid_mac_safari.py`), чтобы прежние
   импорты и CLI-вызовы в скиллах/памяти не ломались.

Reattach между вызовами не поддерживается: сессия закрывается на выходе из context
manager'а, «одна сессия = один скрипт». Для интерактивного VNC-просмотра — `time.sleep(...)`
в конец сценария.

## Полное семейство one-web и дельты обёрток

| Обёртка | Грид (ключ config.yaml) | Контракт | Дельта |
|---|---|---|---|
| `selenoid_lin_chrome.py` | `selenoid` (lin, docker-образы) | `chrome_session()` | ядро ставит `browserVersion: latest` — форсит свежий browser-image на docker-гриде |
| `selenoid_win_chrome.py` | `new-win-selenoid` (Windows VM) | `chrome_session()` | нет — чистый экземпляр паттерна; назначение — версия Chrome из VM, отличная от локального Chromium |
| `selenoid_win_firefox.py` | `new-win-selenoid` | `firefox_session()` | нет в caps; докстринг фиксирует типовые Firefox-quirks (popup ordering, `switch_to.window(handles[1])`, contenteditable/ProseMirror) |
| `selenoid_win_msedge.py` | `new-win-selenoid` | `msedge_session()` | `browserName=MicrosoftEdge` через карту `BROWSER_NAME` ядра |
| `selenoid_win_ya.py` | `new-win-selenoid` | `yandex_session()` | `browserName=yandex` + `goog:chromeOptions.binary` = константа `YANDEX_BINARY` ядра (путь к Yandex Browser внутри Windows-VM — работает через chromedriver) |
| `selenoid_mac_safari.py` | `mac-selenoid` (реальный Mac) | `safari_session()` | квирки Safari: **параллельных сессий нет** («Safari instance is paired with another WebDriver session» → ждать либо прибить чужую через `GET /status` + `DELETE /wd/hub/session/<id>`); reattach особенно нестабилен — потому и правило «сессия = один скрипт»; тайминги: старт ≈1с, login ≈5с, сценарий 15–30с; артефакты — в `.tasks/work/<task>/safari_*.{png,html,md}` |
| `selenoid_safari.py` | — | реэкспорт | shim обратной совместимости поверх `selenoid_mac_safari` |

В каталог скопировано только **ядро** (`selenoid_common.py`) — в нём вся логика и все
browser-дельты. Обёртки **не копируются**: они дублируют паттерн дословно и при адаптации
генерируются по скелету ниже заменой пары `(os, browser)`, имени `<browser>_session`
и докстринга (дельты — таблица выше, живут в ядре):

```python
# .claude/scripts/selenoid_<os>_<browser>.py — тонкая обёртка, логики не несёт
import argparse, sys
from contextlib import contextmanager
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from selenoid_common import (open_session, dump_html, xpath_count, wait_xpath,
                             screenshot, window_dump, login_iva_one, run_scenario)

@contextmanager
def chrome_session(env=None, session_timeout='600s'):          # ← имя = <browser>_session
    with open_session('lin', 'chrome', env=env, session_timeout=session_timeout) as drv:
        yield drv                                              # ← пара (os, browser)

__all__ = ['chrome_session', 'dump_html', 'xpath_count', 'wait_xpath',
           'screenshot', 'window_dump', 'login_iva_one']

def main():                                                    # CLI-раннер сценариев
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--env', default=None)
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument('--script', help='Inline Python-фрагмент')
    g.add_argument('--file', help='Путь к Python-файлу-сценарию')
    args = ap.parse_args()
    code = args.script if args.script else Path(args.file).read_text(encoding='utf-8')
    run_scenario('lin', 'chrome', args.env, code)              # ← та же пара

if __name__ == '__main__':
    main()
```

## Параметризация при адаптации

| Что | В референсе (one-web) | При адаптации |
|---|---|---|
| Карта `SELENOID_KEY` | `(os,browser)` → ключи `selenoid` / `new-win-selenoid` / `mac-selenoid` в `config.yaml` | матрица (os,browser) браузеров прогона проекта + свои ключи гридов в конфиге стендов |
| Схема конфига | `cfg[env][<ключ>]` = IP грида; `cfg[env]['web_url']` = URL AUT | схема «env → {urls, grid}» целевого проекта |
| `login_iva_one` | Keycloak-форма IVA: `//input[@name="username"]`, `//input[@type="password"]`, submit | `login_<product>` — локаторы формы логина IdM целевого продукта; имя функции заменить во всём семействе (ядро, `run_scenario`-scope, `__all__` обёрток) |
| `default_env()` | [dual-line]-резолв: агентская ветка `at-creation-crc` → RC-стенд, иначе dev-стенд (git branch --show-current) | single-line проект: функция вырождается в `return '{{DEFAULT_ENV}}'`; dual-line — своя карта «ветка → стенд» |
| `ROOT` | `Path(__file__).resolve().parents[2]` — скрипты в `.claude/scripts/`, `config.yaml` в корне | глубина от фактического расположения скриптов относительно конфига |
| W3C capabilities | `webdriver.Remote(..., desired_capabilities=caps)` — API Selenium < 4.10 (версия venv референса); browser-дельты: `browserVersion` (lin chrome), `goog:chromeOptions.binary` (ya) | под версию Selenium проекта (4.10+ — `options=`-объекты вместо `desired_capabilities`); свои browser-дельты — тем же способом: константы + ветки в `open_session`, не в обёртках |
| IP/стенды в докстрингах | справочные `10.x.x.x:4444`, `at-test-*` в докстрингах обёрток | обновить на свои или убрать |

## Секреты (DESIGN §1)

Инвариант ядра «схема в git, значения вне git» семейством не нарушается:

- **IP гридов — не секрет**: адреса инфраструктуры, живут в конфиге стендов проекта как
  часть схемы «env → grid»;
- **кредов в коде нет**: `login_<product>` принимает `username`/`password` параметрами —
  источник у вызывающего (эфемерный research-юзер либо конфиг проекта по принципу
  secrets.yaml + env-override);
- `YANDEX_BINARY` — путь к бинарю внутри VM грида, не секрет.

## Статус кода в каталоге

`*.py` здесь — **референс one-web as-is** (S-слой по PORTING.md), не шаблон ядра:
копируется в `.claude/scripts/` целевого проекта и правится по таблице параметризации.
Внутри осознанно остаются one-web-упоминания (стенды `at-test-*`, ссылки на autocore
в комментариях-источниках констант, IP гридов) — это часть «референса one-web»,
при bootstrap заменяются значениями своего проекта.
