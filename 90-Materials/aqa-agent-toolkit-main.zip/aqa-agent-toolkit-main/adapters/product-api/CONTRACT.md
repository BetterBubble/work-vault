# Контракт адаптера: product-api (REST/IdM-порт продукта)

Программный доступ к продукту в обход UI: логин, управление тест-юзерами, REST-предусловия
тестов. На эту ось опираются скиллы тестового цикла (`[product-api]`-блоки: API-предусловия
write/batch/update/fix, фабрика юзеров rules), субагент dom-explorer (эфемерные
research-юзеры) и `/worktree-land` (cleanup юзеров задачи). Референс —
`reference-iva-one/` (research_user.py + схема реестра стендов; REST-обёртки продукта
в one-web — vendored-библиотека `iva_one`).

## Инварианты

- **Обёртки тонкие** (≈1 эндпоинт = 1 функция): поллинг, композиция, реформат ответов —
  в тест-слое проекта поверх, не в обёртках (граница vendored-dep ↔ тест-слой).
- **Секреты конфига** (пароли, client-secret IdM) — по принципу ядра «схема в git,
  значения вне git» (DESIGN §1): в git — схема реестра стендов, значения — secrets.yaml/env.
- **Предусловия тестов — через API, не через UI**: UI-путь только для проверяемого
  сценария; сетап данных (юзеры, сущности) — REST.

## Операции

| Группа | Операции | Кто использует |
|---|---|---|
| Реестр стендов | конфиг `env → {urls, realms, credentials, grid}` (схема — `reference-iva-one/config-schema.md`) | все компоненты со стендом; дефолтный env — `{{DEFAULT_ENV}}` |
| IdM / юзеры | admin-логин → token; create_user / set_user_password / list_users(search, пагинация) / delete_user в realm стенда | фабрика юзеров тест-стека; research_user |
| Research-юзеры (эфемерные) | CLI `ensure / create / list / delete / delete-task / reap` — жизненный цикл по ворктри-задаче | dom-explorer (`ensure` на старте, `reap` сирот), worktree-land (`delete-task` до retire) |
| REST-предусловия | обёртки сущностей продукта (референс one-web: create_chat, send_message, …) | тесты и скиллы write/batch/fix/update |

## Контракт research-юзеров (механика — generic, переносится)

- **Реестр = имя на бэкенде** (префикс `at-de-<task>-`): локального ledger нет, запись
  переживает удаление ворктри; сироту видно листингом IdM по префиксу.
- `ensure` идемпотентен (живой юзер задачи переиспользуется — засеянное состояние
  сохраняется) и печатает JSON `{username, password, env, task, ...}`.
- `reap`: сирота ⇔ ни один живой ворктри (`git worktree list`) не матчится префиксу
  + возрастной guard (не трогать свежесозданных — анти-гонка с setup нового ворктри).
- Env резолвится из meta `base` ворктри (`core/tasks-schemas/worktree-meta.md`),
  не по имени ветки — в ворктри ветка `wt/*` о линии не говорит.
- Нюанс-референс: IdM может нормализовать username (Keycloak хранит в lowercase) —
  генерить lowercase и матчить в lower.

## Словарь (маппится на проект при bootstrap)

| Термин | Референс one-web |
|---|---|
| IdM | Keycloak (realm на стенд, admin-token) |
| REST-обёртки продукта | vendored `{{DEP}}` = autocore, модуль `iva_one` |
| Префикс research-юзеров | `at-de-` |
| Пароль эфемерных юзеров | константа в коде — НЕ секрет (сами задаём создаваемым юзерам изолированных стендов) |
