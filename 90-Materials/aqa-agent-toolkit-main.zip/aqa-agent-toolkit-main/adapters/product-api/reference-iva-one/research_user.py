#!/usr/bin/env python3
"""
research_user.py — эфемерные исследовательские юзеры для dom-explorer с жизненным
циклом по ворктри-задаче. Оркестрация поверх autocore iva_one (создание/удаление/
листинг Keycloak-юзеров). Контекст и решения — .tasks/TODO/043-*.md + plan-043.md.

Ключевое:
- Реестр = ИМЯ на стенде (`at-de-<task>-<rand>`); локального ledger нет — сироту видно
  через iva_one.list_users(search='at-de-'), запись переживает удаление ворктри.
- Env резолвится из meta `.tasks/worktree-<task>/base` (в ворктри ветка wt/*, поэтому
  selenoid_common.default_env() по ветке для RC-линии ошибётся): at-creation-crc ->
  at-test-3-one, иначе -> at-test-1-one.
- reap: сирота ⇔ ни один живой ворктри (basename из `git worktree list`) не даёт
  startswith(f'at-de-{task}-'); + возрастной guard (не трогать младше REAP_MIN_AGE_MINUTES).
- Только at-test-1-one / at-test-3-one (users_factory-путь работает из коробки). gamma —
  вне scope (Keycloak-grants).

CLI (из корня one-web/ворктри, python из venv):
  ensure  [--task T] [--env E]       переиспользовать живого юзера задачи или создать → JSON
  create  [--task T] [--env E]       всегда создать нового → JSON
  list    [--task T] [--env E]       usernames юзеров задачи
  delete  --username U [--env E]     удалить одного
  delete-task --task T --env E       удалить всех юзеров задачи (worktree-land)
  reap    [--env E]                  снести сирот (нет живого ворктри) → JSON списка
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
import uuid
import warnings
from pathlib import Path

warnings.filterwarnings('ignore')  # InsecureRequestWarning от verify=False в iva_one

PASSWORD = 'DnUx0o'            # тот же тестовый пароль, что и conftest.create_user (reuse-логин по константе)
EMAIL_DOMAIN = 'example.org'
NAME_PREFIX = 'at-de-'
REAP_MIN_AGE_MINUTES = 15     # анти-гонка: не реапить только что созданных (setup нового ворктри)
PAGE = 100                    # размер страницы Keycloak-листинга

ROOT = Path(__file__).resolve().parents[2]   # корень ворктри/репо one-web (.claude/scripts/ -> parents[2])


def _iva():
    """autocore iva_one; конфиг гарантированно из ROOT/config.yaml (не зависим от cwd)."""
    from autocore.clients.rest import iva_one
    if not getattr(iva_one, 'conf', None):
        import yaml
        with open(ROOT / 'config.yaml') as f:
            iva_one.conf = yaml.safe_load(f)
    return iva_one


def repo_root() -> Path:
    try:
        out = subprocess.run(['git', 'rev-parse', '--show-toplevel'], cwd=ROOT,
                             capture_output=True, text=True, timeout=10).stdout.strip()
        return Path(out) if out else ROOT
    except Exception:
        return ROOT


def current_task() -> str:
    return repo_root().name


def resolve_env(task: str | None = None, env: str | None = None) -> str:
    if env:
        return env
    task = task or current_task()
    base_file = repo_root() / '.tasks' / f'worktree-{task}' / 'base'
    base = base_file.read_text().strip() if base_file.exists() else ''
    return 'at-test-3-one' if base == 'at-creation-crc' else 'at-test-1-one'


def _admin_token(iva, env: str) -> str:
    iva.env = env
    return iva.login(**iva.conf[env]['credentials']['admin'])


def _realm(iva, env: str) -> str:
    return iva.conf[env]['web-realm']


def _new_username(task: str) -> str:
    # Keycloak хранит username в нижнем регистре → генерим lowercase, чтобы клиентский
    # префикс-матчинг (list_for_task/reap) сходился с тем, что реально лежит на стенде.
    return f'{NAME_PREFIX}{task.lower()}-{uuid.uuid4().hex[:8]}@{EMAIL_DOMAIN}'


def create(task: str | None = None, env: str | None = None, attributes=None) -> dict:
    """Создать нового эфемерного юзера задачи. Возвращает {username,id,env,task,password}."""
    from autocore.test.generate_data import generate_cyryllic_name
    iva = _iva()
    task = task or current_task()
    env = resolve_env(task, env)
    token = _admin_token(iva, env)
    realm = _realm(iva, env)
    username = _new_username(task)
    cyr = generate_cyryllic_name()
    rec = iva.create_user(token, realm, username, username,
                          cyr['first_name'], cyr['last_name'], attributes=attributes)
    iva.set_user_password(token, realm, username, PASSWORD)
    return {'username': username, 'id': rec.get('id'), 'env': env, 'task': task, 'password': PASSWORD}


def list_for_task(task: str | None = None, env: str | None = None) -> list[str]:
    """Usernames живых юзеров задачи на стенде (строгий префикс at-de-<task>-)."""
    iva = _iva()
    task = task or current_task()
    env = resolve_env(task, env)
    token = _admin_token(iva, env)
    realm = _realm(iva, env)
    prefix = f'{NAME_PREFIX}{task.lower()}-'   # Keycloak lowercases usernames
    out: list[str] = []
    first = 0
    while True:
        page = iva.list_users(token, realm, search=prefix, first=first, limit=PAGE)
        out.extend(u['username'] for u in page if u.get('username', '').lower().startswith(prefix))
        if len(page) < PAGE:
            break
        first += PAGE
    return out


def ensure(task: str | None = None, env: str | None = None, attributes=None) -> dict:
    """Переиспользовать живого юзера задачи (сохранённое состояние) или создать нового."""
    task = task or current_task()
    env = resolve_env(task, env)
    existing = list_for_task(task, env)
    if existing:
        return {'username': existing[0], 'id': None, 'env': env, 'task': task,
                'password': PASSWORD, 'reused': True}
    rec = create(task, env, attributes)
    rec['reused'] = False
    return rec


def delete(username: str, env: str | None = None) -> None:
    iva = _iva()
    env = resolve_env(env=env)
    token = _admin_token(iva, env)
    iva.delete_user(_realm(iva, env), username, token=token)


def delete_task_users(task: str, env: str) -> list[str]:
    """Удалить всех юзеров задачи (вызывает worktree-land до retire каталога)."""
    iva = _iva()
    token = _admin_token(iva, env)
    realm = _realm(iva, env)
    users = list_for_task(task, env)
    for u in users:
        iva.delete_user(realm, u, token=token)
    return users


def _live_tasks() -> set[str]:
    """basename'ы всех живых ворктри репо (git worktree list)."""
    out = subprocess.run(['git', 'worktree', 'list', '--porcelain'], cwd=ROOT,
                         capture_output=True, text=True, timeout=10).stdout
    return {Path(line[len('worktree '):].strip()).name
            for line in out.splitlines() if line.startswith('worktree ')}


def reap(env: str | None = None) -> list[str]:
    """Снести at-de-сирот на стенде env: нет живого ворктри с их префиксом + старше guard."""
    iva = _iva()
    env = resolve_env(env=env)
    token = _admin_token(iva, env)
    realm = _realm(iva, env)
    live = _live_tasks()
    now_ms = time.time() * 1000
    deleted: list[str] = []
    first = 0
    while True:
        page = iva.list_users(token, realm, search=NAME_PREFIX, first=first, limit=PAGE)
        for u in page:
            uname = u.get('username', '').lower()   # Keycloak lowercases usernames
            if not uname.startswith(NAME_PREFIX):
                continue  # search мог зацепить чужое поле — страхуемся строгим префиксом
            created = u.get('createdTimestamp', 0) or 0
            if (now_ms - created) / 60000 < REAP_MIN_AGE_MINUTES:
                continue  # слишком свежий — возможно, идёт setup ворктри
            if any(uname.startswith(f'{NAME_PREFIX}{t.lower()}-') for t in live):
                continue  # владелец-ворктри жив
            iva.delete_user(realm, uname, token=token)
            deleted.append(uname)
        if len(page) < PAGE:
            break
        first += PAGE
    return deleted


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description='Эфемерные research-юзеры DE (жизненный цикл по ворктри-задаче).')
    sub = p.add_subparsers(dest='cmd', required=True)
    for name in ('ensure', 'create', 'list'):
        s = sub.add_parser(name)
        s.add_argument('--task')
        s.add_argument('--env')
    sd = sub.add_parser('delete')
    sd.add_argument('--username', required=True)
    sd.add_argument('--env')
    sdt = sub.add_parser('delete-task')
    sdt.add_argument('--task', required=True)
    sdt.add_argument('--env', required=True)
    sr = sub.add_parser('reap')
    sr.add_argument('--env')
    args = p.parse_args(argv)

    if args.cmd == 'ensure':
        print(json.dumps(ensure(args.task, args.env), ensure_ascii=False))
    elif args.cmd == 'create':
        print(json.dumps(create(args.task, args.env), ensure_ascii=False))
    elif args.cmd == 'list':
        print(json.dumps(list_for_task(args.task, args.env), ensure_ascii=False))
    elif args.cmd == 'delete':
        delete(args.username, args.env)
        print(json.dumps({'deleted': args.username}, ensure_ascii=False))
    elif args.cmd == 'delete-task':
        print(json.dumps({'deleted': delete_task_users(args.task, args.env)}, ensure_ascii=False))
    elif args.cmd == 'reap':
        print(json.dumps({'reaped': reap(args.env)}, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    sys.exit(main())
