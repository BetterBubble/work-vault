# reference-iva-one — референс product-api-порта (IVA ONE)

Реализация контракта `adapters/product-api/CONTRACT.md` из референс-инсталляции one-web:
`research_user.py` (эфемерные research-юзеры dom-explorer'а) + `config-schema.md`
(схема реестра стендов). REST-обёртки самого продукта в one-web — vendored-библиотека
`autocore` (модуль `iva_one`), в тулкит не тащится: у целевого продукта свои API
(см. `docs/patterns/vendored-dep-rebuild.md` про работу с vendored-библиотекой).

## research_user.py — расслоение при адаптации

Копируется в `.claude/scripts/` целевого проекта и правится по таблице. Код — as-is
из one-web (S-слой «референс»); generic-механика описана в CONTRACT.md
(«Контракт research-юзеров») — её при адаптации сохранять.

| Точка | Где в коде | Что менять |
|---|---|---|
| IdM-примитивы | `_iva()`, `iva.login/create_user/set_user_password/list_users/delete_user` | REST/IdM целевого продукта (тонкие обёртки, ≈1 эндпоинт) |
| Резолв env по meta `base` | `resolve_env()` | [dual-line]-маппинг `база → стенд`; single-line — фиксированный `{{DEFAULT_ENV}}` |
| Префикс/домен юзеров | `NAME_PREFIX`, `EMAIL_DOMAIN` | словарь проекта (префикс — и в dom-explorer/worktree-land) |
| Пароль эфемерных юзеров | `PASSWORD` | константа, НЕ секрет (см. CONTRACT.md «Словарь»); держать единой с фабрикой юзеров тест-стека |
| Генерация ФИО | `generate_cyryllic_name()` из `{{DEP}}` | генератор данных целевого стека |
| Глубина корня | `ROOT = ... parents[2]` | пересчитать от расположения скрипта |
| Возрастной guard / страница листинга | `REAP_MIN_AGE_MINUTES`, `PAGE` | обычно as-is |

## Грабли-референсы (сохранять поведение при адаптации)

- IdM может нормализовать username в lowercase (Keycloak) → генерация lowercase +
  матчинг в lower (`_new_username`, `list_for_task`, `reap`).
- `reap` страхуется строгим префикс-матчем: `search` IdM может зацепить чужие поля.
- Конфиг грузится от `ROOT`, не от cwd — CLI зовётся и из ворктри.
