# Схема реестра стендов (config.yaml) — референс one-web

Конфиг проекта: плоский словарь `env → описание стенда`. Читатели: conftest тест-стека
(через config-loader; референс one-web — vendored `autocore.test.config.get_config()`),
research_user.py, selenoid-семейство (`adapters/browser-driver/reference-selenoid/`),
резолв дефолтного стенда.

```yaml
<env-имя-стенда>:            # напр. at-test-1-one; ключ = значение --env раннера
  name: <env-имя-стенда>
  admin-realm: <realm администрирования IdM>     # референс: master
  web-realm: <realm пользователей продукта>      # референс: IVA
  credentials:               # ⚠ значения — секреты → secrets.yaml (зеркальная секция)
    admin:
      username: <админ стенда>
      password: <...>
    mail_user:               # [опционально] спец-юзеры проекта (референс: LDAP/mail-юзер)
      username: <...>
      password: <...>
  web_url: https://<хост клиента продукта>
  admin_url: https://<хост IdM/админки>
  iva-one-client-secret: <client-secret IdM>     # ⚠ секрет → secrets.yaml
  selenoid: <IP грида lin>                       # [browser-driver] карта гридов:
  new-win-selenoid: <IP грида win>               #   ключи маппятся SELENOID_KEY
  mac-selenoid: <IP грида mac>                   #   (reference-selenoid/README.md)
```

- Стендов может быть несколько (референс one-web: два постоянных под dual-line-линии
  + отдельный gamma); дефолт — `{{DEFAULT_ENV}}`, явный `--env` перекрывает.
- **Секреты** (`credentials.*.password`, client-secret) в git-tracked config.yaml —
  переходное состояние референс-инсталляции (вынос — one-web TODO-058): в целевом
  проекте с первого дня — «схема в git, значения вне git» (DESIGN §1): в config.yaml —
  форма/несекретное, значения секретов — gitignored `secrets.yaml` зеркальной
  структуры + env-override.
- URL стендов и IP гридов — адреса тестовой инфраструктуры, не секреты.
