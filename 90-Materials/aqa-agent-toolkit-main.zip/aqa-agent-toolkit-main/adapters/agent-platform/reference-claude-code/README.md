# Референс agent-platform: Claude Code

Ядро тулкита **написано в механиках Claude Code** — этот референс не содержит
конвертационного слоя: раскладка `core/claude/` → `.claude/` проекта по `INSTALL.md`
и есть реализация оси.

Маппинг операций контракта → механики CC (для сверки при эволюции ядра):

| Операция контракта | Механика | Где в ядре |
|---|---|---|
| Инструкции проекта | `CLAUDE.md` (автозагрузка) | `core/CLAUDE.template.md` |
| Скиллы | `.claude/skills/*/SKILL.md`, frontmatter `name`/`description`/`allowed-tools`, автотриггер + слэш | `core/claude/skills/` |
| Субагенты | `.claude/agents/*.md`, спаун Task-tool | `core/claude/agents/` |
| Hooks | settings.json → PostToolUse + скрипт | `core/claude/hooks/detect-dep-commit.py`, `core/claude/settings.template.json` |
| Rules | `.claude/rules/*.md` c paths-frontmatter (автоподгрузка по glob редактируемого файла) | `core/claude/rules/` |
| Permissions | settings.json permissions (заполняется на проекте) | `core/claude/settings.template.json` |
| Файловая память | нативная авто-память CC (каталог памяти + MEMORY.md) | `core/memory-format.md` |
| Вопрос пользователю | AskUserQuestion | развилки в текстах скиллов |
| Headless | `claude -p` | delivery-tail / CI (по потребности проекта) |
