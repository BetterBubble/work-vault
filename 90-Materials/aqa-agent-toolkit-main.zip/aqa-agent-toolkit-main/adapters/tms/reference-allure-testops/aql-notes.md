# Allure TestOps: фильтры, AQL и upload — заметки для скиллов ядра

> Референс реализации контракта `adapters/tms/CONTRACT.md` — Allure TestOps.
> Донесено при порте `/batch-autotest` (одна из точек использования — его `phases.md` §0.1);
> сам CLI-клиент (референс one-web) — рабочий пакет `testops/` рядом, поставляется как агентский инструмент `.claude/scripts/testops/` (развёртка — README референса).
> Грабли выстраданы живыми сессиями one-web — при bootstrap на другую TMS заменить
> аналогичными заметками своего языка запросов.

## Фильтр-URL

URL вида `https://<testops>/project/{N}/test-cases?filterId=...&search=<base64>`:
параметр `search` — **base64-кодированный** JSON активных фильтров. Раскодировать и выписать
все фильтры (id поля + значение + label) — их может быть несколько (тег + тип + feature),
пропуск любого даёт не тот набор TC (механика сверки — batch-autotest `phases.md` §0.1).

## AQL-синтаксис (для операции `search '<AQL>'`)

Рабочие формы:

| Что | Как | Пример |
|---|---|---|
| Тег | `tag = "..."` / `tag in [...]` / `tag is "..."` | `tag = "RFA"` |
| Custom field | `cf["Имя поля"] = "..."` | `cf["Feature"] = "Чаты"` |
| Комбинация | `and` | `tag = "RFA" and cf["Feature"] = "Чаты"` |

**Грабли:**
- `tags[...]` и `customField[...]` — НЕ работают, дают `invalid.aql`. Только `tag = ...`
  и `cf["..."]`.
- Поле `automated` в AQL **не поддерживается** — если фильтр включает «не автоматизировано»,
  отфильтруй клиентски по полю `automated` в выдаче (`search ... --json`).
- AQL не справился (синтаксис / неподдержанное поле) → fallback: список ID вручную
  от пользователя (копирует из UI).

## Чтение TC (операция `get <N>`)

`get <N>` возвращает имя, описание, шаги блоком `Steps:` (**shared steps раскрыты**), теги,
custom fields (Feature/Story/Suite/Owner), Issues — одним вызовом. Отдельные запросы на
precondition/scenarioSteps не нужны. Структурированные custom fields отдельно — `cfv <N>`.

## Upload результатов и статусы TC

Загрузка результатов прогона — allurectl (ось ci-vcs), **только по явному запросу
пользователя**:

```bash
allurectl upload --endpoint https://<testops>/ --token <TOKEN> --project-id <N> \
  --launch-name "<batch>-<date>" ./<каталог сырых результатов>/
```

Статусы TC «Готов к автоматизации» → «Automated» TestOps переключает **автоматически**
после upload (матчинг по allure-id теста). Вручную статусы в TestOps не менять.
