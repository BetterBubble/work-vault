# reference-allure-testops — референс TMS-порта (Allure TestOps)

Реализация контракта `adapters/tms/CONTRACT.md` из референс-инсталляции one-web:
рабочий read-only REST-пакет `testops/` + шпаргалки для скиллов-читателей
(`testops-api.md`, `aql-notes.md`, `launch-parser.md`).

## Развёртка в целевой проект

Пакет — **агентский инструмент** (зовёт только агент, человеку напрямую не нужен),
поэтому едет в агентскую зону `.claude/`, не в проектное дерево `tools/`.

1. Каталог `testops/` скопировать в проект как `.claude/scripts/testops/` (рядом с
   `backlog_dashboard.py` / `worktree_bootstrap.sh` — агентские скрипты ядра).
2. Значение плейсхолдера анкеты **`{{TMS_CLI}}`** (команда-префикс вызова обёртки),
   референс: `PYTHONPATH=.claude/scripts {{PYTHON}} -m testops`. `PYTHONPATH` находит
   модуль `testops` в `.claude/scripts`; cwd остаётся корнем проекта (оттуда читается
   `secrets.yaml`). Скиллы ядра зовут обёртку как `{{TMS_CLI}} <op> ...`.
3. Зависимости: `requests`, `pyyaml` (оба обычно уже есть в окружении тест-стека).
4. Секреты — по принципу ядра (DESIGN §1), литералов в коде нет:
   env `TESTOPS_ENDPOINT` / `TESTOPS_TOKEN` / `TESTOPS_PROJECT_ID` → секция
   `testops:` в gitignored `./secrets.yaml` (форма — `secrets.yaml.example` рядом,
   скопировать в корень проекта; читается из cwd = корень). Неполный конфиг →
   `TestOpsError` с подсказкой.
5. Проверка: `{{TMS_CLI}} get <id>` из корня проекта.

## Что маппится при адаптации (словарь проекта)

| Точка | Где | Референс one-web |
|---|---|---|
| Тег «решено не автоматизировать» | `testcase.py: WONT_AUTOMATE_TAG` | `wont-automate` (словарь тегов — CONTRACT.md) |
| Пропускаемые вложения ланча | `launch.py: _SKIP_ATTACHMENTS` | `("Видео",)` — мёртвая ссылка при выключенной записи |
| Схема browser-маркера прогона | `launch.py: _BROWSER_MARKER_RE` | `browser_<os>_<browser>` из тегов ланча (кладёт allurectl) |

Подсказка «вход fix-батча» в `flake` (`__main__.py: _print_flake`) больше **не** точка
адаптации — интерпретатор берётся из `sys.executable`, префикс `PYTHONPATH=.claude/scripts`
и модуль `testops` инвариантны. Пакет копируется as-is; правятся только доменные словари выше.

Контракт `to_plain` (plain-выдача `get`) — интерфейс скиллов-парсеров ядра:
изменение формата = регресс всех читателей (см. CONTRACT.md «Формат выдачи»).

## Отличия от оригинала one-web (порт, волна 4)

- `client.py`: константы `ENDPOINT`/`TOKEN`/`PROJECT_ID` (в one-web — хардкод с
  боевым токеном) заменены резолвером
  `resolve_settings()`: env → secrets.yaml → ошибка. Сигнатуры публичного API
  сохранены (`TestOpsClient()` без аргументов работает), `to_plain` резолвит
  endpoint сам, если не передан.
- `__main__.py`: конструктор клиента перенесён внутрь `try` — ошибка неполного
  конфига печатается как обычная `Ошибка TestOps: ...`, не traceback.
- Внедрение того же принципа в сам one-web — его TODO-058 (референс-инсталляция
  в переходном состоянии).
- Переклассификация в агентский инструмент (TODO 007, 2026-07-05): модуль
  `tools.testops` → `testops`, зона поставки `tools/testops/` → `.claude/scripts/testops/`,
  вызов через `{{TMS_CLI}}` (PYTHONPATH-механизм). Self-импорты пакета относительные —
  правки кода только косметические (докстринги, `prog`, самоопределяющаяся подсказка
  `flake`). Миграция существующих развёрток — INSTALL.md §7.
