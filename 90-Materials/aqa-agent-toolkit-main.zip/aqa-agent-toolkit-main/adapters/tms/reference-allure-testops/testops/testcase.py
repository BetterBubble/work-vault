"""Чтение тест-кейсов Allure TestOps через REST — аналоги read-only инструментов
MCP-сервера `testops`.

Соответствие MCP -> функции этого модуля:
  get_test_case_details        -> get_test_case        (overview + развёрнутый сценарий)
  get_test_case_custom_fields  -> get_custom_fields
  search_test_cases (AQL)      -> search_test_cases     (rql=<AQL>)
  list_test_cases              -> list_test_cases

Формат `to_plain` повторяет компактное представление MCP (output_format="plain"):
текст шагов и шапка совпадают байт-в-байт, чтобы скиллы-парсеры (write-autotest /
batch-autotest / fix-failed-test) читали вывод без переделки. Сверх MCP в plain
добавлены строки Owner (из members) и Issues (Jira) — отдельными полями, парсер
они не ломают; для TC в корзине строка Status получает суффикс «В КОРЗИНЕ
(deleted)» — иначе удалённый TC неотличим от живого (status остаётся Draft/Active);
вложения шагов в plain НЕ выводятся (как у MCP), но сохранены в
JSON-структуре сценария (поля attachments / expected_attachments).

Эндпоинты (подтверждены разведкой на референс-инсталляции one-web):
  GET /api/rs/testcase/{id}/overview   — name, description, tags, customFields,
                                         members (Owner), issues (Jira), status...
  GET /api/rs/testcase/{id}/step       — дерево шагов сценария (см. _build_scenario)
  GET /api/rs/testcase/__search?rql=   — поиск по AQL (rql)
  GET /api/rs/testcase?projectId=      — листинг проекта (без фильтра)
"""
from .client import resolve_settings


# --- низкоуровневые запросы -----------------------------------------------

def _overview(client, tc_id):
    return client.get(f"/api/rs/testcase/{tc_id}/overview")


def _steps_raw(client, tc_id):
    return client.get(f"/api/rs/testcase/{tc_id}/step")


# --- реконструкция дерева шагов -------------------------------------------
# /step отдаёт root.children (порядок шагов верхнего уровня) и плоскую карту
# scenarioSteps {id: {body, expectedResultId, children, attachmentId}}. Ожидаемый
# результат шага — отдельный псевдошаг (body == "Expected Result"), на который
# указывает expectedResultId; его children содержат тексты/вложения ожидаемого.
#
# Шаренный шаг встроен как узел-ссылка {id, sharedStepId} (без body/children) —
# его содержимое лежит в sharedSteps[sharedStepId] (заголовок + children), а сами
# под-шаги и их ожидаемые результаты — в sharedStepScenarioSteps. Вложения шагов и
# шаренных шагов — в attachments / sharedStepAttachments.

def _text(step):
    return (step.get("body") or "").strip()


def _attachment_name(step, attachments):
    attachment_id = step.get("attachmentId")
    if attachment_id is None:
        return None
    return attachments.get(str(attachment_id), {}).get("name", str(attachment_id))


def _empty_node(step_id, action):
    return {"id": step_id, "action": action,
            "attachments": [], "substeps": [], "expected": [], "expected_attachments": []}


def _fill_expected(node, step, steps, attachments):
    """Заполнить expected / expected_attachments из псевдошага expectedResultId."""
    expected_id = step.get("expectedResultId")
    if expected_id is None:
        return
    expected = steps.get(str(expected_id), {})
    for child_id in expected.get("children", []):
        child = steps.get(str(child_id), {})
        text = _text(child)
        if text:
            node["expected"].append(text)
        attachment = _attachment_name(child, attachments)
        if attachment:
            node["expected_attachments"].append(attachment)


def _build_node(step_id, steps, shared_steps, attachments):
    step = steps.get(str(step_id))
    if step is None:
        return _empty_node(step_id, f"[шаг {step_id} не найден]")

    # Узел-ссылка на шаренный шаг: раскрываем его заголовок и под-шаги.
    shared_id = step.get("sharedStepId")
    if shared_id is not None:
        shared = shared_steps.get(str(shared_id), {})
        node = _empty_node(step.get("id"), _text(shared) or f"[shared step {shared_id}]")
        node["shared_step_id"] = shared_id
        node["substeps"] = [_build_node(child, steps, shared_steps, attachments)
                            for child in shared.get("children", [])]
        own_attachment = _attachment_name(shared, attachments)
        if own_attachment:
            node["attachments"].append(own_attachment)
        _fill_expected(node, shared, steps, attachments)
        return node

    node = _empty_node(step.get("id"), _text(step))
    node["substeps"] = [_build_node(child, steps, shared_steps, attachments)
                        for child in step.get("children", [])]
    own_attachment = _attachment_name(step, attachments)
    if own_attachment:
        node["attachments"].append(own_attachment)
    _fill_expected(node, step, steps, attachments)
    return node


def _build_scenario(raw):
    """Из ответа /step собрать упорядоченный список шагов верхнего уровня.

    Учитывает обычные и шаренные шаги (раскрывая последние через sharedSteps) и
    их вложения; `root.children` задаёт порядок верхнего уровня.
    """
    steps = {}
    steps.update(raw.get("scenarioSteps") or {})
    steps.update(raw.get("sharedStepScenarioSteps") or {})
    shared_steps = raw.get("sharedSteps") or {}
    attachments = {}
    attachments.update(raw.get("attachments") or {})
    attachments.update(raw.get("sharedStepAttachments") or {})
    root_children = (raw.get("root") or {}).get("children", [])
    return [_build_node(child, steps, shared_steps, attachments) for child in root_children]


# --- custom fields / owner ------------------------------------------------

def _custom_fields(tc):
    """{имя_поля: 'значение' | 'знач1, знач2'} из overview.customFields."""
    grouped = {}
    for entry in tc.get("customFields") or []:
        field = (entry.get("customField") or {}).get("name")
        if field:
            grouped.setdefault(field, []).append(entry.get("name"))
    return {field: ", ".join(values) for field, values in grouped.items()}


def _owner(tc):
    """Имя участника с ролью Owner (в Allure это не CF, а member.role)."""
    for member in tc.get("members") or []:
        if (member.get("role") or {}).get("name") == "Owner":
            return member.get("name")
    return None


# --- публичный API --------------------------------------------------------

def get_test_case(client, tc_id):
    """Полные данные TC: overview + развёрнутый сценарий (ключ ``scenario``).

    Аналог MCP ``get_test_case_details``. Возвращает dict.
    """
    tc = _overview(client, tc_id)
    tc["scenario"] = _build_scenario(_steps_raw(client, tc_id))
    return tc


def get_custom_fields(client, tc_id):
    """Custom fields + Owner. Аналог MCP ``get_test_case_custom_fields``. Возвращает dict."""
    tc = _overview(client, tc_id)
    fields = _custom_fields(tc)
    owner = _owner(tc)
    if owner:
        fields["Owner"] = owner
    return fields


def search_test_cases(client, rql, page=0, size=20):
    """Поиск TC по AQL-выражению (передаётся в параметр ``rql`` эндпоинта __search).

    Аналог MCP ``search_test_cases(aql=...)``. Рабочие на стенде поля/операторы:
      ``name ~= "конференц"``               — вхождение в имя
      ``id = 52275``                        — точный id
      ``tag = "web"``                       — по тегу
      ``status = "Active"``                 — по статусу (Active / Draft / ...)
      ``name ~= "почта" and tag = "web"``   — комбинация (and / or)
      ``issue = "VCSAT-1234"``              — связанные с Jira-issue (интеграция TestOps↔Jira)
    (поле ``automated`` на этом стенде в AQL не поддерживается — даёт invalid.aql.)

    Возвращает страницу: dict с ``content[]``, ``totalElements``, ``totalPages``...
    """
    return client.get(
        "/api/rs/testcase/__search",
        projectId=client.project_id, rql=rql, page=page, size=size,
    )


# Тег, которым человек помечает кейс «связан с задачей, но осознанно решено НЕ
# автоматизировать» (вопрос к бэкенду / нет способа сетапа / прочее). Такие кейсы
# не должны попадать в список кандидатов на автоматизацию (--unautomated).
WONT_AUTOMATE_TAG = "wont-automate"


def linked_test_cases(client, issue_key, only_unautomated=False, only_automated=False, page_size=100):
    """TC, связанные с Jira-issue (через интеграцию TestOps↔Jira; AQL ``issue = "KEY"``).

    Связь хранится в TestOps (поле ``issues`` каждого TC) — в саму Jira ходить не нужно.
    Фильтры (поле ``automated`` в AQL не поддерживается, поэтому клиентские):
      ``only_unautomated=True`` -> только не-автоматизированные, БЕЗ кейсов с тегом
        ``wont-automate`` (осознанно решено не автоматизировать — не кандидаты на автоматизацию);
      ``only_automated=True``   -> только автоматизированные (вход для retest-прогона).
    Флаги взаимоисключающи (оба False -> весь связанный набор).
    Возвращает список dict: id, name, automated, status, tags (список имён тегов).
    """
    rql = f'issue = "{issue_key}"'
    cases = []
    page = 0
    while True:
        result = search_test_cases(client, rql, page=page, size=page_size)
        for tc in result.get("content", []):
            automated = bool(tc.get("automated"))
            tags = [t.get("name", "") for t in (tc.get("tags") or [])]
            if only_automated and not automated:
                continue
            if only_unautomated and (automated or WONT_AUTOMATE_TAG in tags):
                continue
            cases.append({
                "id": tc.get("id"),
                "name": tc.get("name", ""),
                "automated": automated,
                "status": (tc.get("status") or {}).get("name", ""),
                "tags": tags,
            })
        if result.get("last", True):
            break
        page += 1
    return cases


def list_test_cases(client, page=0, size=20):
    """Листинг всех TC проекта без фильтра. Аналог MCP ``list_test_cases``.

    Возвращает страницу: dict с ``content[]``, ``totalElements``...
    """
    return client.get(
        "/api/rs/testcase",
        projectId=client.project_id, page=page, size=size,
    )


# --- человекочитаемый формат (как MCP output_format="plain") --------------

def _render_steps(scenario, prefix=""):
    lines = []
    for index, step in enumerate(scenario, 1):
        number = f"{prefix}{index}"
        line = f"{number}. {step['action']}".rstrip()
        if step.get("expected"):
            line += " → " + "; ".join(step["expected"])
        lines.append(line)
        if step.get("substeps"):
            lines.extend(_render_steps(step["substeps"], prefix=f"{number}."))
    return lines


def to_plain(tc, endpoint=None):
    """Компактное человекочитаемое представление TC (как MCP output_format='plain').

    `endpoint` нужен только для строки Test Case URL; не передан — резолвится
    как в клиенте (env → secrets.yaml).
    """
    if endpoint is None:
        endpoint = resolve_settings()[0]
    header = [
        f"**Test Case #{tc.get('id')}: {tc.get('name', '')}**",
        f"Test Case URL: {endpoint}/project/{tc.get('projectId')}/test-cases/{tc.get('id')}",
        f"Status: {(tc.get('status') or {}).get('name', '')} | "
        f"Automation: {'Automated' if tc.get('automated') else 'Manual'}"
        + (" | В КОРЗИНЕ (deleted)" if tc.get("deleted") else ""),
    ]

    # Секции, разделённые пустой строкой (как у MCP: пусто перед Steps и перед Tags).
    sections = []
    if tc.get("description"):
        sections.append("**Description:**\n" + tc["description"])

    scenario = tc.get("scenario") or []
    if scenario:
        sections.append("**Steps:**\n" + "\n".join(_render_steps(scenario)))

    meta = []
    tags = ", ".join(tag.get("name", "") for tag in (tc.get("tags") or []))
    if tags:
        meta.append(f"**Tags:** {tags}")
    fields = _custom_fields(tc)
    owner = _owner(tc)
    if owner:
        fields["Owner"] = owner
    if fields:
        meta.append("**Custom Fields:** " + ", ".join(f"{key}={value}" for key, value in fields.items()))
    issues = ", ".join(issue.get("name", "") for issue in (tc.get("issues") or []))
    if issues:
        meta.append(f"**Issues:** {issues}")
    if meta:
        sections.append("\n".join(meta))

    return "\n".join(header) + "\n" + "\n\n".join(sections)
