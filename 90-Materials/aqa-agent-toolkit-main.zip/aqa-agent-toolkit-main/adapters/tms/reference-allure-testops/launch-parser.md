# Парсинг ланча Allure TestOps (референс-реализация TMS-порта, ветка `launch-parse`)

Референс-реализация операции `launch` контракта `adapters/tms/CONTRACT.md`; исходник —
one-web (read-only REST-модуль Allure TestOps `testops`, поставляется как агентский
инструмент — `.claude/scripts/testops/`). Читатели — скиллы ядра `launch-parse`
(read-only сводка) и `fix-failed-test` (фикс-пайплайн; ссылки вида `batch-discovery.md` /
`xfail-verification.md` — на файлы `core/claude/skills/fix-failed-test/references/`;
`allure-raw-parser.md` — сосед по адаптеру test-stack:
`adapters/test-stack/reference-pytest-selenium/`).

Вход — URL ланча {{TMS}} или `launch <id>`. Локальных сырых результатов нет: результаты и вложения читаются read-only из TMS через CLI-обёртку (тот же токен, что у upload-инструмента пайплайна; секреты — по инварианту контракта «схема в git, значения вне git»). Это аналог `allure-raw-parser.md`, но источник — ланч в TMS, а не каталог на диске.

## Команда

```bash
{{TMS_CLI}} launch <id> --attachments .tasks/work/batch-{ts}/launch-att --json
```

- `<id>` — число или полный URL (парсер id принимает оба).
- `--attachments DIR` — скачать вложения каждого не-зелёного результата в `DIR` (скриншот PNG + `log`; **видео не качается** — в проекте-референсе запись сессий выключена, ссылка мёртвая).
- `--json` — машинный вывод. Без `--all` отдаются **только не-зелёные** (`status != passed`).
- Человекочитаемый вид (без `--json`) удобен, чтобы показать пользователю сводку перед `AskUserQuestion`.

## Формат JSON

```json
{
  "launch": { "id": 726, "name": "<продукт>: suite_smoke / browser_lin_chrome @ <env>",
              "closed": false, "tags": [...], "issues": [...] },
  "results": [
    {
      "result_id": 81598,
      "allure_id": 1391,
      "test_name": "test_upload_profile_avatar",
      "test_path": "tests/test_profile.py",
      "title": "Загрузить аватар профиля",
      "status": "broken",
      "kind": "broken",
      "xfail_reason": "",
      "exception_class": "selenium.common.exceptions.NoSuchElementException",
      "exception_message": "Message: no such element: ...",
      "trace": "Traceback (most recent call last): ...",
      "start": 1751971200000,
      "stop": 1751971264000,
      "parameters": [{"name": "users_factory", "value": "2"}],
      "flaky": false, "muted": false, "known": false,
      "attachments": [".tasks/work/batch-.../launch-att/81598-190870-...png",
                      ".tasks/work/batch-.../launch-att/81598-190869-log.log"]
    }
  ]
}
```

Поля уже нормализованы TMS-модулем — парсить сырой API TestOps не нужно. Соответствие с `allure-raw-parser`: `test_name`/`test_path`/`allure_id`/`exception_class`/`exception_message`/`trace` — те же; добавлены `kind`, `xfail_reason`, `status`, `parameters`, `attachments`, `start`/`stop` (мс epoch; результаты отсортированы по `start` — хронология прогона).

## Окна по времени (детект деградации стенда)

До раздачи тестов по пайплайну — взгляд на **хронологию**: сгруппируй не-зелёные по `start`
(результаты уже отсортированы; человекочитаемый вывод печатает `HH:MM:SS`).
Кластер падений в узком интервале (минуты) + деградационные симптомы в evidence
(всплески 502/503, пустые страницы IdP, зависшие спиннеры) — гипотеза **окна деградации
стенда**: см. категорию `STAND_INCIDENT` (`failure-taxonomy.md` скилла). Зафиксируй границы
окна (`start` первого и `stop` последнего падения кластера) — Phase 1 repro-PASS вне окна
подтвердит категорию, полный фикс-пайплайн таким тестам не нужен.

## Сверка ревизий: ланч vs локальный код

Ланч бежит по ветке CI (обычно интеграционной), а разбор может идти в задачной ветке/ворктри
**впереди** неё — с уже сделанными, но недоставленными фиксами. Тогда Phase 1 repro-PASS
означает не «флак», а «падение покрыто недоставленным фиксом», и «стабилизация» уже
починенного кода в Phase 6 бессмысленна.

Шаг перед раздачей тестов:
1. Определи ветку ланча: из имени/тегов ланча (`launch.tags`; CI кладёт их при запуске)
   либо спроси пользователя, если тега нет.
2. Сверь локальное состояние с ней (пути тест-слоя — по контракту test-stack; референс
   one-web: `tests/`, `tools/`):
   ```bash
   git fetch origin && git log origin/<branch>..HEAD --oneline -- tests/ tools/
   ```
3. Список непуст → локальный код впереди: флаг `local_ahead=true` в `state.md` (+ список
   недоставленных коммитов). Каждый repro в Phase 1 идёт «не на том коде, что в CI» —
   развилка исхода PASS описана в `SKILL.md` Phase 1 (корзина «покрыто недоставленным
   фиксом» при пересечении недоставленных коммитов с файлами теста/эпицентра).
4. В финальном отчёте — напоминание доставить фиксы (MR/merge) перед следующим CI-прогоном.

## Развилка по `kind`

`kind` уже посчитан модулем (как allure-pytest кодирует исход в TestOps):

| `kind` | Что это | Куда в пайплайне |
|---|---|---|
| `failed` | `AssertionError` (наш assert не сошёлся) | обычный фикс-пайплайн (Phase 1+) |
| `broken` | любое другое исключение (Timeout/NoSuchElement/HTTPError/…) — **это тоже падение** | обычный фикс-пайплайн (Phase 1+) |
| `xpass` | xfail-тест неожиданно прошёл (при strict-режиме xfail → `status=failed`, `XPASS` в message) | сигнал «баг закрыт / маркер пора снимать» — см. `xfail-verification.md` |
| `xfail` | xfail-тест ожидаемо упал (`status=skipped`, message `XFAIL <reason>`) | **верификация места падения** — см. `xfail-verification.md`, НЕ обычный фикс |
| `skipped` | обычный `skip`-маркер | только в список (no-op); действий не предпринимаем |

`failed`/`broken` распределяются по таксономии (`failure-taxonomy.md` скилла) **по тексту exception**, а не по `status` (как в allure-raw-ветке): `broken+TimeoutException` → чаще `DOM_CHANGED`/`FLAKY_TIMING`; `failed+AssertionError` → `PRODUCT_BUG`/`UX_FLOW_CHANGED`/`WEBDRIVER_QUIRK`.

## Что извлекать в failure-bundle

Для каждого `failed`/`broken`/`xpass` результата заполняем `fix-{test_name}-failure.md` теми же полями, что и в allure-raw-ветке:
- `test_name`, `test_path`, `allure_id` — из записи напрямую;
- `exception_class` + `exception_message`, полный `trace`;
- **скриншот** и **log** — из `attachments` (пути уже скачаны). Лог сканировать так же, как в `allure-raw-parser.md` секция «Сканирование log-attachment» (grep по `Текущий url\|Response\|WARN\|TIMEOUT`), это evidence до фазы локализации;
- источник: `launch-parse` + `launch_id` + `result_id`.

Инвариант 4 источников evidence (прецедент-референс one-web: stack+steps+log+screenshot перекрёстно, до root-cause) выполняется: trace + (шаги TMS доступны в UI ланча) + log + скриншот.

## Target marker и was_local

- `target_marker` = **браузер из тегов ланча** (конфигурационный маркер словаря проекта, референс: `browser_<os>_<browser>`). Ланч — один браузер; тег браузера кладёт upload-инструмент при запуске (референс one-web: allurectl, `ALLURE_LAUNCH_TAGS`). Берём его из `launch.tags` — модуль уже отдаёт готовое значение в поле `browser_marker` (CLI печатает строку «Браузер (target_marker): …»; в `--json` — ключ `browser_marker`). Это маркер, на котором тест **реально упал**. Если тег браузера не найден — дефолтная верификационная конфигурация проекта (референс: `browser_win_chrome`).
- **Отладка vs финальная верификация:** ковыряться в падении можно на быстрой дефолтной конфигурации, но Phase 1 (repro) и Phase 5 (cross-browser/финал) должны идти на **браузере ланча** — иначе «починили» можем не на той платформе. Если `browser_marker` совпадает с дефолтной конфигурацией — отдельный прогон не нужен.
- `was_local` = `false` всегда (ланч — это CI-прогон на grid'е, не локальный).

Phase 1 (Reproduce on target) стартует от `test_name` + `target_marker` (браузер ланча) (как ветка `pytest-run`): локальных сырых результатов нет, поэтому trace/скриншот/log из ланча идут как evidence, а воспроизведение — перезапуском раннера.

## Несколько не-зелёных в ланче

Это batch-вход (как сырые результаты с N>1). Показать пользователю сводку (`launch <id>` без `--json` даёт готовый список с `[kind]`/`TC #`/exception) и спросить через `AskUserQuestion` («все по очереди» — дефолт; xfail-результаты идут в ветку верификации, а не фикса). Дальше — `batch-discovery.md` скилла.

## Если ланч недоступен / пустой

- Модуль вернул ошибку (сеть/токен/нет ланча) → сообщить пользователю, не выдумывать (инвариант контракта: ошибка модуля → сообщить и предложить fallback). Токен и endpoint — из конфигурации TMS-модуля проекта.
- В ланче нет не-зелёных (всё `passed`) → «в ланче #{id} все тесты зелёные, нечего разбирать».
