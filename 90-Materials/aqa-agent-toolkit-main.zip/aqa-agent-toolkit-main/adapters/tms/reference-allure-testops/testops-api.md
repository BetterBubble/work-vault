<!-- Референс-реализация операции `get` контракта adapters/tms/CONTRACT.md — one-web:
Allure TestOps, read-only модуль `testops` (агентский инструмент, `.claude/scripts/testops/`).
Скиллы ядра (write-autotest шаги 1–2)
ссылаются на этот файл как «чтение TC — адаптер tms». При bootstrap на другую TMS файл
заменяется своим, сохраняя структуру разделов: извлечение id из URL · вызов CLI · plain-формат
ответа · маппинг полей → input.md · обработка ошибок · CSV-fallback. Имена хостов, команды
и юзеры ниже — референс one-web целиком; секреты (endpoint/token) —
по принципу «схема в git, значения вне git» (DESIGN §1); в референсе one-web так же
(секреты вынесены из кода в `secrets.yaml`). -->

# Получение тест-кейса из Allure TestOps через REST-модуль `testops` (референс one-web)

## Когда использовать

Когда пользователь дал URL вида `https://<testops-хост>/project/{project_id}/test-cases/{tc_id}`.

Чтение идёт через собственный read-only REST-модуль `testops` (агентский инструмент тулкита, `.claude/scripts/testops/`). MCP-сервер TestOps **не используется** — модуль точнее (раскрывает shared steps и sub-steps, которые MCP терял), контролируем и работает на том же токене Allure TestOps, что и allurectl. Сырой REST/`curl` дёргать тоже не нужно — всё через модуль.

## Как извлечь TC-id

Из URL парсится последний сегмент после `test-cases/`. Например:
- `https://<testops-хост>/project/5/test-cases/2393` → `tc_id = 2393`
- `https://<testops-хост>/project/5/test-cases/2393?param=x` → `tc_id = 2393`

Если URL не соответствует шаблону — выйти и попросить пользователя проверить ссылку.

## Вызов модуля

Из корня проекта (`{{TMS_CLI}}` — команда-префикс обёртки, анкета; референс:
`PYTHONPATH=.claude/scripts {{PYTHON}} -m testops`):

```
{{TMS_CLI}} get <tc_id>
```

По умолчанию печатается компактное человекочитаемое представление (`plain`): имя, описание, шаги, теги, custom fields, Owner, Issues — этого хватает для парсинга в `input.md` (`.tasks/work/tc-{id}/`). Для сырого JSON (со структурой шагов, вложениями) — флаг `--json`.

Прочие команды модуля (на будущее, для batch): `search '<AQL>'`, `list`, `cfv <id>`. Подробности — `testops/__init__.py` и docstring'и.

> Endpoint/token/project — секреты вне git: env `TESTOPS_*` → gitignored `secrets.yaml` (реализовано в `testops/client.py` пакета рядом; в референсе one-web так же — секреты вынесены из кода в `secrets.yaml`).

## Что приходит в ответе (plain-формат)

```
**Test Case #<id>: <name>**
Test Case URL: https://<testops-хост>/project/<project_id>/test-cases/<id>
Status: <status> | Automation: <Manual|Automated>
**Description:**
<description>

**Steps:**
1. <step 1>
1.1. <step 1.1> → <expected 1.1.1>
2. <step 2>
...

**Tags:** tag1, tag2
**Custom Fields:** Feature=<...>, Story=<...>, Suite=<...>, Owner=<...>
**Issues:** <ISSUE-12345>
```

Формат шагов и шапки совпадает с тем, что раньше отдавал MCP (`output_format="plain"`) — парсинг не меняется. Сверх MCP модуль добавляет `Owner` (из участников с ролью Owner) и строку `**Issues:**` (issue-трекер), а **shared steps раскрывает целиком** (MCP на них отдавал заглушку `1. Step`). Вложения шагов в `plain` не выводятся (как и у MCP), но доступны в `--json` (поля `attachments` / `expected_attachments`).

## Мапинг полей ответа → input.md

| Источник в ответе | Поле в `input.md` (`.tasks/work/tc-{id}/`) |
|---|---|
| `Test Case #<id>` | `allure_id` |
| `: <name>` после `#<id>` | `name`, заголовок `# TC-{id}: {name}` |
| `Custom Fields: Feature=...` | `feature` |
| `Custom Fields: Story=...` | `story` |
| `Custom Fields: Suite=...` | `suite` |
| `Custom Fields: Owner=...` | `owner` |
| `Tags:` (через запятую) | `tags` |
| `Issues:` (или Links в Description) | `jira` |
| `Steps:` (нумерованный список + `→ <expected>`) | секция `## Бизнес-шаги сценария` после нормализации в `[step N]` / `[step N.M]` / `[expected N.M.K]` |

Шаги в plain-ответе идут в формате `N.M. <action> → <expected>`. Нормализуй в общий формат:
- верхнеуровневый `N.` → `[step N]`
- вложенный `N.M.` → `[step N.M]`
- то, что после `→` → `[expected N.M.K]` (счётчик K сам, обычно `1`)

Перед записью в `input.md` — **обязательная санитизация** (`references/sanitization.md` скилла write-autotest): URL стенда → `{stand_url}` активного стенда, креды → white-list общих тест-юзеров, динамические значения → `<generate: ...>`.

## Обработка ошибок

Модуль печатает ошибку в stderr (`Ошибка TestOps: ...`) и завершается с кодом `1`. Разбор по тексту/коду:

| Ситуация | Признак | Действие |
|---|---|---|
| TC не найден | `404: Not Found`, exit 1 | Сообщить «TC #{id} не найден в TestOps». Остановиться. |
| Нет доступа / токен невалиден | `401`/`403`, exit 1 | Сообщить «нет доступа к TC #{id} через REST». Предложить fallback на CSV. |
| Сеть/стенд недоступен | `Не удалось подключиться`, exit 1 | Сообщить причину. Предложить fallback на CSV. |
| Ответ без шагов | `**Steps:**` отсутствует в выводе | Сообщить «у TC #{id} нет шагов сценария». Спросить, продолжать ли по описанию или подождать заполнения TC. |

## Fallback на ручной CSV

Если модуль по любой причине вернул ошибку (нет доступа / TC не найден / стенд недоступен / TC пустой) — сообщить пользователю:

```
Чтение TestOps через модуль testops не удалось (<причина>). Скачайте CSV вручную из TestOps UI:
  Allure TestOps → Test Cases → выбрать TC → Export → CSV
И запустите skill заново с путём к скачанному файлу.
```

## Почему свой REST-модуль (а не MCP)

- **Полнота:** раскрывает shared steps и sub-steps, отдаёт вложения шагов и связанные issue — MCP всё это терял (`1. Step` вместо блока, `attachments:[]`).
- **Контроль и доверие:** прозрачный GET к документированным эндпоинтам (`/api/rs/testcase/{id}/overview` + `/step`, `__search?rql=<AQL>`), а не чёрный ящик.
- **Единый доступ:** тот же endpoint и токен Allure TestOps, что и у allurectl (CI-операции) — один источник доступа на весь стек.
- **Только чтение:** модуль делает лишь GET (+ обмен api-token на JWT). Никаких create/update/delete — TC и launch'ами управляет человек.
