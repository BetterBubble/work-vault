# Запуск раннера из skill fix-failed-test (референс-реализация: pytest + Selenium/selenoid)

Референс-реализация контракта `adapters/test-stack/CONTRACT.md` («Запуск») для стека
pytest+Selenium; исходник — one-web (браузеры — на selenoid-хостах, драйвер-слой — в
vendored-библиотеке {{DEP}}). Читатель — скилл ядра `fix-failed-test` (ссылки вида
`reproduce-phases.md` — на файлы `core/claude/skills/fix-failed-test/references/`).
Словарь маркеров `browser_<os>_<browser>` — референс one-web, маппится на проект при bootstrap.

Используется в ветке `pytest-run` (Phase 0) и **всегда** на верификации (Phase 5).

## Команда (дефолт верификации — lin_chrome)

```bash
{{RUNNER}} -k <test_name> --env {{DEFAULT_ENV}} --tb=native --showlocals -p no:randomly
```

## Флаги — почему именно эти

| Флаг | Зачем |
|---|---|
| `-k <test_name>` | Запускает только нужный тест (нам не нужен весь suite) |
| `-m browser_<os>_<name>` | Нужен, **только** чтобы прогнать в конкретном браузере (например, в том, где падал тест). Для дефолтной верификации маркер **НЕ ставим** — драйвер-фабрика берёт дефолт (референс one-web: `lin_chrome`). См. таблицу браузерных маркеров ниже. |
| `--env {{DEFAULT_ENV}}` | Стенд активной линии (`{env}` из state.md). [dual-line] — стенд второй линии для её ветки |
| `--browser-tag current` | Тег версии браузера — нужен **только для win-браузеров**; для lin/mac не требуется (референс one-web: `current` рекомендован для локальных прогонов в селеноиде; дефолт `min` — для CI) |
| `--tb=native` | Полный stack trace в `traceback`-формате Python — проще парсить |
| `--showlocals` | Локальные переменные кадра — помогает понять контекст падения |
| `-p no:randomly` | Отключает `pytest-randomly`, чтобы порядок не влиял на воспроизводимость |

## Браузерные маркеры (словарь-референс one-web)

Браузер выбирается через `-m browser_<os>_<name>`. Маркер один (не комбинируется). Без маркера тест идёт в дефолтном браузере драйвер-фабрики (референс one-web: `lin_chrome`) — это и есть дефолт верификации; маркер нужен, только когда надо воспроизвести падение в конкретном браузере.

| Маркер | Где запускается |
|---|---|
| `browser_win_chrome` | Chrome на Windows-grid-хосте |
| `browser_win_firefox` | Firefox на Windows-grid-хосте |
| `browser_win_msedge` | Microsoft Edge на Windows-grid-хосте |
| `browser_win_ya` | Yandex Browser на Windows-grid-хосте |
| `browser_lin_chrome` | Chrome на linux-grid-хосте |
| `browser_mac_safari` | Safari на mac-grid-хосте — только для single-session тестов |

`--local` **НЕ ставим** при работе с любым grid-хостом (включая локальные win/mac grid-хосты — флаг всегда уводит на локальный Chrome dev-машины, конкретный браузер grid'а так не получить). Реальное действие флага шире, чем «директория для тестовых данных»: в референс-реализации при `local=True` драйвер-фабрика создаёт **локальный Chrome dev-машины без grid'а** (референс one-web: `CustomChromeWebDriver(options=opts)` в драйвер-слое {{DEP}}). Параметры grid'а и `browserName` capabilities игнорируются. Дополнительно каталог тестовых данных браузера переключается на локальный. Используется в Phase 2 «Reproduce locally» (см. `reproduce-phases.md` скилла).

## Выбор браузера для верификации

1. **Если падение в сырых результатах найдено в нескольких браузерах одинаково** → верифицируем в дефолтной конфигурации `lin_chrome` (без `-m`) — Chromium, самый быстрый. Если pass — рекомендовать пользователю догнать в остальных.
2. **Если падение только в конкретном браузере** (например, только Firefox или только Safari) → верифицировать **в том же браузере** (с его `-m`-маркером), иначе фикс не валидируется.
3. **Если skill вызван по имени теста без attached падения** (ветка `pytest-run`) → `lin_chrome` по умолчанию (без `-m`).

## Примеры

```bash
# lin_chrome — дефолт верификации (без -m)
{{RUNNER}} -k test_group_chat_send_message --env {{DEFAULT_ENV}} --tb=native --showlocals -p no:randomly

# Firefox — если падение только в Firefox
{{RUNNER}} -k test_chat_edit_link_message -m browser_win_firefox --env {{DEFAULT_ENV}} --browser-tag current --tb=native --showlocals -p no:randomly

# Safari — если падение только в Safari (требует mac-grid-хоста из конфига)
{{RUNNER}} -k test_group_chat_send_message -m browser_mac_safari --env {{DEFAULT_ENV}} --browser-tag current --tb=native --showlocals -p no:randomly
```

## Local-mode command (Phase 2 — Reproduce locally)

В Phase 2 (`reproduce-phases.md` скилла) skill перезапускает тест **без grid'а** на локальном Chrome dev-машины:

```bash
{{RUNNER}} -k <test_name> --env {{DEFAULT_ENV}} --local --tb=native --showlocals -p no:randomly
```

**Важно:** **никаких `-m browser_*` маркеров**. При `--local` драйвер-фабрика собирает локальный Chrome, маркеры игнорируются. `--browser-tag current` тоже не обязателен (опция читается, но не влияет в local-режиме). Эта команда воспроизводит сценарий «Запуск локально» из README проекта-референса.

Skip Phase 2: если изначальный прогон был запущен с `--local` (`was_local=true` из `allure-raw-parser.md` секции «Local-mode detection»).

Конфиг раннера уже добавляет `--alluredir=./allure-raw` (референс: `pytest.ini`), поэтому сырые результаты пишутся автоматически.

## Таймаут

Передавать `timeout=300000` (5 минут) в параметрах Bash-вызова. Если тест не уложился — это ещё один сигнал (вероятно `FLAKY_TIMING` или `DOM_CHANGED`).

## Как читать вывод

После завершения:

1. **Exit code** Bash-вызова:
   - `0` — тест прошёл (если это Phase 0/1 — тогда падения нет; если это верификация — фикс сработал)
   - не `0` — тест упал

2. **stdout/stderr** — pytest пишет туда:
   - имя теста и `PASSED`/`FAILED`
   - блок `FAILED tests/...::test_xxx - <ExceptionClass>: <message>`
   - полный stack trace (благодаря `--tb=native`)

3. **allure-raw/** — после прогона там появятся свежие `*-result.json`. Парсить по `allure-raw-parser.md`.

## Извлечение данных для fix-{test_name}-failure.md

Из stdout раннера вытащить:
- `exception_class` — из строки `FAILED tests/...::test_xxx - <ExceptionClass>: <message>`
- `exception_message` — оттуда же, после двоеточия
- полный traceback — между строкой `FAILED ...` и следующим разделителем (`====` или конец)
- `test_path`, `test_name` — из строки `FAILED tests/test_chat.py::test_channel_edit_avatar_visible`

Дополнительно прочитать `allure-raw/*-result.json` для этого теста (поиск по `name == test_name`) — оттуда:
- ID шага, на котором упал тест (`steps[].status == "failed"`)
- attachments (скриншоты)

## Что НЕ запускать

- ❌ Полный прогон без `-k` — это многочасовая операция, не нужна.
- ❌ Верификация не в том браузере — если падение было browser-specific (например, только Firefox), прогон без `-m` (= дефолт `lin_chrome`) его не воспроизведёт. Тогда ставь `-m`-маркер нужного браузера (см. «Выбор браузера для верификации»).
- ❌ Прогон сразу в нескольких браузерах через `-m "browser_win_chrome or browser_win_firefox"` — выбирается только один маркер; для нескольких браузеров нужны отдельные запуски.
- ❌ `--collect-only` — только для проверки синтаксиса, не для верификации фикса.

## Если окружение не собрано

Команда использует интерпретатор окружения проекта напрямую (`{{PYTHON}}`) — это работает без активации venv. Если раннер всё равно не находится — значит, у пользователя не установлены зависимости. Сообщить пользователю команду установки из README проекта (референс: `pip install -r requirements.txt` с индексом пакетов проекта).

И **не пытаться** ставить пакеты от его имени.
