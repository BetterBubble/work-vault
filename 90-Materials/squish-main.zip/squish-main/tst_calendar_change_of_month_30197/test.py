# -*- coding: utf-8 -*-
from utils.decorators import with_setup
from utils.page_helpers import set_server, user_auth, go_to
from chunks.calendar import PageCalendar


@with_setup
def main(): 
    server_addres = "gamma-one.ivcs.su" 
    user_name = "t.morozova"
    user_pass = "testtest"
    #server_addres = "at-test-1-one.ivcs.su" 
    #user_name = "gitlab"
    #user_pass = "1"
    
    set_server(server_addres)
    user_auth(user_name, user_pass)
    go_to('calendar')
       
    calendar = PageCalendar() 
    current_month_text = calendar.get_current_month_text()
    current_month, current_year = calendar.parse_month_year(current_month_text)
    calendar.click_next_month()
    next_month_text = calendar.get_current_month_text()
    next_month, next_year = calendar.parse_month_year(next_month_text)
   
    calendar.check_next_month(next_month, next_year, current_month, current_year)