# -*- coding: utf-8 -*-
from utils.decorators import with_setup
from chunks.prelogin_page import PreLoginPage


@with_setup
def main():
    prelogin_window = PreLoginPage()
    prelogin_window.is_prelogin_successful()

