# -*- coding: utf-8 -*-
from utils.decorators import with_setup
from chunks.prelogin_page import PreLoginPage
from chunks.login_page import LoginPage

@with_setup
def main(): 
    server_addres = "at-test-1-one.ivcs.su" 
    #server_addres = "gamma-one.ivcs.su" 
    
    prelogin_window = PreLoginPage() 
    prelogin_window.is_prelogin_successful()
    prelogin_window.enter_server(server_addres) 
    prelogin_window.click_continue_btn() 
    
    login_window = LoginPage() 
    login_window.is_login_page_loaded() 

    