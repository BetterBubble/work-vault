# -*- coding: utf-8 -*-
from utils.decorators import with_setup
from utils.page_helpers import set_server, user_auth, go_to
from chunks.calls import PageCalls


@with_setup
def main(): 
    server_addres = "at-test-1-one.ivcs.su" 
    user_name = "t.user@dropjar.com"
    user_pass = "DnUx0o"
    
    set_server(server_addres)
    user_auth(user_name, user_pass)
    go_to('calls')
       
    calls = PageCalls() 
    calls.click_dropdown_btn()
    calls.select_calls_menu_item('incoming')
    calls.check_calls_dropdown_menu_title('incoming')
    calls.get_text_call_history_item()
    
    calls.click_dropdown_btn()
    calls.select_calls_menu_item('outgoing')
    calls.check_calls_dropdown_menu_title('outgoing')
    calls.click_dropdown_btn()
    calls.select_calls_menu_item('missed')
    calls.check_calls_dropdown_menu_title('missed')
    calls.click_dropdown_btn()
    calls.select_calls_menu_item('canceled')
    calls.check_calls_dropdown_menu_title('canceled')
    calls.click_dropdown_btn()
    calls.select_calls_menu_item('rejected')
    calls.check_calls_dropdown_menu_title('rejected')