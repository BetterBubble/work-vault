# encoding: UTF-8

mainWindow_MainWindow = {"name": "MainWindow", "type": "MainWindow", "visible": 1}
mainWindow_stackedWidget_QStackedWidget = {"name": "stackedWidget", "type": "QStackedWidget", "visible": 1, "window": mainWindow_MainWindow}
stackedWidget_stackedWidget_QStackedWidget = {"container": mainWindow_stackedWidget_QStackedWidget, "name": "stackedWidget", "type": "QStackedWidget", "visible": 1}
stackedWidget_QWebEngineView = {"container": stackedWidget_stackedWidget_QStackedWidget, "type": "QWebEngineView", "unnamed": 1, "visible": 1}
stackedWidget_CalendarGridForm = {"container": stackedWidget_stackedWidget_QStackedWidget, "type": "CalendarGridForm", "unnamed": 1, "visible": 1}
mainWindow_IvaCallForm = {"type": "IvaCallForm", "unnamed": 1, "visible": 1, "window": mainWindow_MainWindow}
o_Overlay = {"container": mainWindow_IvaCallForm, "type": "Overlay", "unnamed": 1, "visible": True}
stackedWidget_IvaChatForm = {"container": stackedWidget_stackedWidget_QStackedWidget, "type": "IvaChatForm", "unnamed": 1, "visible": 1}
chatsView_ChatsView = {"container": stackedWidget_IvaChatForm, "objectName": "chatsView", "type": "ChatsView", "visible": True}
chatsView_viewHeader_ChatsViewHeader = {"container": chatsView_ChatsView, "id": "viewHeader", "type": "ChatsViewHeader", "unnamed": 1, "visible": True}
chatsView_921f4676_c42e_4c69_983f_7582c1f4e29e_ChatDelegate = {"container": chatsView_ChatsView, "id": "921f4676-c42e-4c69-983f-7582c1f4e29e", "index": 2, "type": "ChatDelegate", "unnamed": 1, "visible": True}
messagesView_MessagesView = {"container": stackedWidget_IvaChatForm, "objectName": "messagesView", "type": "MessagesView", "visible": True}
messagesView_1772777841350_MessageDelegate = {"container": messagesView_MessagesView, "id": "1772777841350", "index": 0, "type": "MessageDelegate", "unnamed": 1, "visible": True}
chatsView_921f4676_c42e_4c69_983f_7582c1f4e29e_ChatDelegate_2 = {"container": chatsView_ChatsView, "id": "921f4676-c42e-4c69-983f-7582c1f4e29e", "index": 3, "type": "ChatDelegate", "unnamed": 1, "visible": True}
o921f4676_c42e_4c69_983f_7582c1f4e29e_chatName_ChatName = {"container": chatsView_921f4676_c42e_4c69_983f_7582c1f4e29e_ChatDelegate_2, "id": "chatName", "type": "ChatName", "unnamed": 1, "visible": True}
