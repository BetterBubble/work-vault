# -*- coding: utf-8 -*-
CHAT_PAGE_WINDOW = "MainWindow.centralwidget.stackedWidget.PluginSplitWidget2.splitter.stackedWidget.IvaChatForm1.pluginPage_0.rowLayout_1"
CHAT_LEFT_SIDEBAR = {
    "container": CHAT_PAGE_WINDOW,
    "objectName": "chatsView", 
    "type": "ChatsView", 
    "visible": True
     }

CHAT_PAGE = {
     "container": CHAT_PAGE_WINDOW,
     "objectName": "chatPage",
     "type": "SelectedChatPage",
     }

CHAT = {
     "container": ":chatsView_921f4676_c42e_4c69_983f_7582c1f4e29e_ChatDelegate_2",
     "id": "bgRect",
     "type": "LoadingRectangle",
     }

ACTIVE_CHAT_NAME = {
     "container": CHAT_PAGE,
     "id": "chatName",
     "type": "SelectableText"
    }

MESSAGE_TEXT = {
     "container": CHAT_PAGE,
     "id": "messageText",
     "type": "MessageTextComponent",
    }
