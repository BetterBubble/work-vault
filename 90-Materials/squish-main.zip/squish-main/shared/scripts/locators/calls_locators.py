# -*- coding: utf-8 -*-
#{"container": stackedWidget_CalendarGridForm, "id": "gridViewModeComboBox", "type": "AppComboBox", "unnamed": 1, "visible": True}
#GRID_VIEW_BUTTON = "{container=':stackedWidget_CalendarGridForm' type='AppComboBox' id='gridViewModeComboBox'}"

POPUP = {
    "container": ":o_Overlay",
    "type": "PopupItem",
    "visible": True
    }

DROPDOWN_MENU_TITLE = {
    "container": ":o_Overlay",
    "id": "textField",
    "type": "AppTextField",
    "visible": True
    }

DROPDOWN_BTN = {
    "container": ":o_Overlay",
    "id": "indicatorButton",
    "type": "AppToolButton",
    "visible": True
    }

INCOMING_DROPDOWN_MENU_ITEM = {
    "container": ":o_Overlay",
    "text": "Входящие звонки",
    "type": "Text",
    "visible": True
    }

OUTGOING_DROPDOWN_MENU_ITEM = {
    "container": ":o_Overlay",
    "text": "Исходящие звонки",
    "type": "Text",
    "visible": True
    }

MISSED_DROPDOWN_MENU_ITEM = {
    "container": ":o_Overlay",
    "text": "Пропущенные звонки",
    "type": "Text",
    "visible": True
    }

CANCELED_DROPDOWN_MENU_ITEM = {
    "container": ":o_Overlay",
    "text": "Отменённые звонки",
    "type": "Text",
    "visible": True
    }

REJECTED_DROPDOWN_MENU_ITEM = {
    "container": ":o_Overlay",
    "text": "Отклонённые звонки",
    "type": "Text",
    "visible": True
    }

CALL_IN_HISTORY = {
    "container": ":o_Overlay",
    "id": "contentBg", 
    "type": "LoadingRectangle"
    }

CALL_ITEM_NAME = {
    "container": CALL_IN_HISTORY, 
    "type": "AppText"
    }
