# -*- coding: utf-8 -*-

CALENDAR_GRID_FORM = "MainWindow.centralwidget.stackedWidget.PluginSplitWidget.splitter.stackedWidget.CalendarGridForm1"

GRID_VIEW_BUTTON = {
     "container": CALENDAR_GRID_FORM,
     "id": "gridViewModeComboBox",
     "type": "AppComboBox",
     }

TODAY_BUTTON = {
     "container": CALENDAR_GRID_FORM,
     "id": "todayButton",
     "type": "AppButton"
     }

DATE_ROW = {
    "container": CALENDAR_GRID_FORM,
    "id": "dateRow",
    "type": "Row"
}

CURRENT_DATE_TEXT = {
    "container": DATE_ROW,
    "type": "AppText"
}

def month_day_text(day: int):
    return {
        "container": CALENDAR_GRID_FORM,
        "text": str(day),
        "type": "Text"
    }  

MONTH_PICKER_LAYOUT = {
    "container": CALENDAR_GRID_FORM,
    "id": "monthPickerLayout",
    "type": "RowLayout"
    }

CURRENT_MONTH_TEXT = {
    "container": MONTH_PICKER_LAYOUT,
    "type": "Text"
}
    
    
NEXT_MONTH_BTN = {
    "container": CALENDAR_GRID_FORM,
    "id": "nextMonthButton", 
    "type": "IconButton"
    }  
