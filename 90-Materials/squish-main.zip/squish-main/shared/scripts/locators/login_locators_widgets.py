WEB_VIEW = "MainWindow.centralwidget.stackedWidget.AuthMainWidget.stackedWidget.QWebEngineView1"

HEADER = f"{WEB_VIEW}.DOCUMENT.HTML1.BODY1.DIV1.DIV2.HEADER1"    

LOGIN_FIELD = {
    "container": WEB_VIEW,
    "form": "kc-form-login",
    "id": "username",
    "name": "username",
    "tagName": "INPUT",
    "type": "text",
    "visible": True
}

PASSWORD_FIELD = {
    "container": WEB_VIEW,
    "form": "kc-form-login",
    "id": "password",
    "name": "password",
    "tagName": "INPUT",
    "type": "password",
    "visible": True
}

ENTER_BUTTON = {
    "container": WEB_VIEW,
    "form": "kc-form-login",
    "id": "kc-login",
    "name": "login",
    "tagName": "INPUT",
    "type": "submit",
    "visible": True
}


