# -*- coding: utf-8 -*-

TOOL_BAR = {
    "name": "toolBar",
    "type": "QToolBar",
    "visible": True,
    "window": ":mainWindow_MainWindow"
}

TOOL_BAR_MAIL = {
    "text": "IvaMail.MailPlugin",
    "type": "QToolButton"
}

TOOL_BAR_CALENDAR = {
    "text": "Календарная сетка",
    "type": "QToolButton"
}

TOOL_BAR_CONTACTS = {
    "text": "IvaContactPlugin",
    "type": "QToolButton"
}

TOOL_BAR_CHATS = {
    "text": "IvaChatPlugin",
    "type": "QToolButton"
}

TOOL_BAR_CALLS = {
    "text": "IvaCallPlugin",
    "type": "QToolButton"
}