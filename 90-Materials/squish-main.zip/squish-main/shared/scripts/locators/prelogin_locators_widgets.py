SERVER_FIELD = {
    "type": "QLineEdit"
}

LOGIN_BUTTON = {
    "name": "buttonPrimary",
    "type": "QToolButton"
}

