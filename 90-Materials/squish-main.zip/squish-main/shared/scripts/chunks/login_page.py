from chunks.base_page import BasePage
from locators.login_locators_widgets import HEADER, LOGIN_FIELD, PASSWORD_FIELD, ENTER_BUTTON
from utils.asserts import Asserts


class LoginPage(BasePage):
    PRIMARY_LOCATOR = HEADER
    READY_LOCATORS = [LOGIN_FIELD, PASSWORD_FIELD, ENTER_BUTTON]
    
    def login(self, usr, psw):
        try:
            self._set_login(usr)
            self._set_password(psw)
            self._click_enter_btn()
        except Exception as e:
            self.test_step_log(f'Ошибка при логине: {str(e)}')


    def _set_login(self, username):
        #field = squish.waitForObjectExists(LOGIN_FIELD, 20000)
        field = self.wait_for(LOGIN_FIELD)
        field.focus()
        field.value = ''
        field.value = username
        self.test_step_log(f'DOM логин: {field.value}')


    def _set_password(self, password):
        #field = squish.waitForObjectExists(PASSWORD_FIELD, 20000)
        field = self.wait_for(PASSWORD_FIELD)
        field.focus()
        field.value = ''
        field.value = password
        self.test_step_log(f'DOM пароль: {field.value}')


    def _click_enter_btn(self):
        #btn = squish.waitForObject(ENTER_BUTTON, 20000)
        btn = self.wait_for(ENTER_BUTTON)
        click_x = btn.x + btn.width // 2
        click_y = btn.y + btn.height // 2
        self.test_step_log(f'Нажимаем "Вход": ({click_x}, {click_y})')
        self.left_click_coordinates(click_x, click_y)
        self.pause(1)
        #squish.nativeMouseClick(click_x, click_y, 1)
        #squish.snooze(1)

        
    def is_login_page_loaded(self):
        self.pause(5) 
        Asserts.assert_visible(HEADER, "Окно авторизации загрузилось")