from chunks.base_page import BasePage
from locators.prelogin_locators_widgets import LOGIN_BUTTON, SERVER_FIELD
from utils.asserts import Asserts


class PreLoginPage(BasePage):
    def enter_server(self, server_address):
        self.enter_text(SERVER_FIELD, server_address)

    def click_continue_btn(self):
        self.click(LOGIN_BUTTON)
        self.pause(1)

    def is_prelogin_successful(self):
        Asserts.assert_visible(SERVER_FIELD, "Окно выбора сервера загрузилось")

    def login(self, server_address):
        self.enter_server(server_address)
        self.click_login()
        return self.is_login_successful()