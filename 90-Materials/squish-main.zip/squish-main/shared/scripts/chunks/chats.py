# -*- coding: utf-8 -*-
from chunks.base_page import BasePage
from locators.chats_locators import CHAT_LEFT_SIDEBAR, CHAT_PAGE, CHAT, ACTIVE_CHAT_NAME, MESSAGE_TEXT
from utils.asserts import Asserts


class PageChats(BasePage): 
    PRIMARY_LOCATOR = CHAT_LEFT_SIDEBAR
    READY_LOCATORS = []
    
    def select_chat(self):
        self.test_step_log(f'Выбираем чат')
        self.click(CHAT)
        self.pause(1)   
        
    def is_chat_loaded(self):    
        self.pause(5) 
        Asserts.assert_visible(CHAT_PAGE, "Чат загрузилося")
        
    def get_current_chat_name_text(self):   
        actual_text = self.get_text(ACTIVE_CHAT_NAME)
        self.test_step_log(f'actual_title {actual_text}')
        return actual_text    
    
    def get_current_chat_messages_text(self):
        actual_text = self.get_text(MESSAGE_TEXT)
        self.test_step_log(f'actual_msgt {actual_text}')
        return actual_text 