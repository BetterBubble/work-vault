# -*- coding: utf-8 -*-
from chunks.base_page import BasePage
from locators.calls_locators import (POPUP, DROPDOWN_BTN, DROPDOWN_MENU_TITLE, INCOMING_DROPDOWN_MENU_ITEM, OUTGOING_DROPDOWN_MENU_ITEM,
                                    MISSED_DROPDOWN_MENU_ITEM, CANCELED_DROPDOWN_MENU_ITEM, REJECTED_DROPDOWN_MENU_ITEM, CALL_IN_HISTORY, CALL_ITEM_NAME)
from utils.asserts import Asserts


class PageCalls(BasePage): 
    PRIMARY_LOCATOR = POPUP
    READY_LOCATORS = []
    
    def click_dropdown_btn(self):
        self.test_step_log(f'Нажимаем стрелку выподающего меню')
        self.click(DROPDOWN_BTN)
        self.pause(1)  
        
    def _get_ative_menu_item_text(self):   
        current_title = self.wait_for(DROPDOWN_MENU_TITLE).text
        self.test_step_log(f'Текст в заголовке меню: {current_title}')
        return current_title     
    
    def select_calls_menu_item(self, call_type):
        if call_type is 'incoming':
            self.test_step_log(f'Выбираем пункт выподающего меню "Входящие звонки"')
            self.click(INCOMING_DROPDOWN_MENU_ITEM)
        if call_type is 'outgoing':
            self.test_step_log(f'Выбираем пункт выподающего меню "Исходящие звонки"')
            self.click(OUTGOING_DROPDOWN_MENU_ITEM)
        if call_type is 'missed':
            self.test_step_log(f'Выбираем пункт выподающего меню "Пропущенные звонки"')
            self.click(MISSED_DROPDOWN_MENU_ITEM)
        if call_type is 'canceled':
            self.test_step_log(f'Выбираем пункт выподающего меню "Отмененные звонки"')
            self.click(CANCELED_DROPDOWN_MENU_ITEM)    
        if call_type is 'rejected':
            self.test_step_log(f'Выбираем пункт выподающего меню "Отклоненные звонки"')
            self.click(REJECTED_DROPDOWN_MENU_ITEM)        
        self.pause(1)
            
    def check_calls_dropdown_menu_title(self, call_type):  
        if call_type is 'incoming': 
            exp_result = "Входящие звонки"
        if call_type is 'outgoing':    
            exp_result = "Исходящие звонки"
        if call_type is 'missed':    
            exp_result = "Пропущенные звонки"
        if call_type is 'canceled':    
            exp_result = "Отменённые звонки"
        if call_type is 'rejected':    
            exp_result = "Отклонённые звонки"    
        act_result = self._get_ative_menu_item_text()
        Asserts.assert_equal(exp_result, act_result, f'Выбран пункт "{act_result}"')
        
    def get_text_call_history_item(self):    
        current_name = self.wait_for(CALL_ITEM_NAME).text
        self.test_step_log(f'Текст в заголовке меню: {current_name}')
        return current_name 