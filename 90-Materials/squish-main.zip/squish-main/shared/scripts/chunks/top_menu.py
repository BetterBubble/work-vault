# -*- coding: utf-8 -*-
from chunks.base_page import BasePage
from locators.top_menu_locators import TOOL_BAR, TOOL_BAR_MAIL, TOOL_BAR_CALENDAR, TOOL_BAR_CONTACTS, TOOL_BAR_CHATS, TOOL_BAR_CALLS


class TopMenu(BasePage): 
    PRIMARY_LOCATOR = TOOL_BAR
    READY_LOCATORS = []
    
            
    def click_mail_btn(self):
        self.test_step_log(f'Нажимаем кнопку "Почта"')
        self.click(TOOL_BAR_MAIL)
        self.pause(1)       
                   
    def click_calendar_btn(self):
        self.test_step_log(f'Нажимаем кнопку "Календарь"')
        self.click(TOOL_BAR_CALENDAR)
        self.pause(1)       
                  
    def click_contacts_btn(self):
        self.test_step_log(f'Нажимаем кнопку "Контакты"')
        self.click(TOOL_BAR_CONTACTS)
        self.pause(1)          
               
    def click_chats_btn(self):
        self.test_step_log(f'Нажимаем кнопку "Чаты"')
        self.click(TOOL_BAR_CHATS)
        self.pause(1)              
           
    def click_calls_btn(self):
        self.test_step_log(f'Нажимаем кнопку "Звонки"')
        self.click(TOOL_BAR_CALLS)
        self.pause(1)                 