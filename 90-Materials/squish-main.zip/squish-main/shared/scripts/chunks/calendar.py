# -*- coding: utf-8 -*-
from chunks.base_page import BasePage
from locators.calendar_locators import GRID_VIEW_BUTTON, TODAY_BUTTON, CURRENT_DATE_TEXT, month_day_text, CURRENT_MONTH_TEXT, NEXT_MONTH_BTN
from datetime import datetime, timedelta
from utils.asserts import Asserts
from const import MONTHS


class PageCalendar(BasePage): 
    PRIMARY_LOCATOR = CURRENT_DATE_TEXT
    READY_LOCATORS = [GRID_VIEW_BUTTON, TODAY_BUTTON]
    
    def click_grid_view_mode_btn(self):  
        self.click(GRID_VIEW_BUTTON)
        self.pause(1)
        
    def click_today_btn(self):
        self.test_step_log(f'Нажимаем кнопку "Сегодня"')
        self.click(TODAY_BUTTON)
        self.pause(1)        
    
    def _day_locator(self, day_offset):
        target_date = datetime.now() + timedelta(days=day_offset)
        day = target_date.day
        self.test_step_log(f'Выбираем {day} число')
        return month_day_text(day)
        
    def get_current_date_text(self):   
        actual_text = self.wait_for(CURRENT_DATE_TEXT).text
        return actual_text
         
    def click_day(self, day_offset):
        locator = self._day_locator(day_offset)
        self.click(locator)
        self.pause(1)
    
    def check_yesterday_date(self):
        actual_result = self.get_current_date_text()
        yesterday = datetime.now() - timedelta(days=1)
        expected_result = yesterday.day
        Asserts.assert_contains(actual_result, expected_result, f'Календарь отображает вчерашнее число "{expected_result}" (сегодня {datetime.now().strftime("%d.%m.%Y")})')
        
    def check_tomorrow_date(self):
        actual_result = self.get_current_date_text()
        tomorrow = datetime.now() + timedelta(days=1)
        expected_result = str(tomorrow.day)
        Asserts.assert_contains(actual_result, expected_result, f'Календарь отображает завтрашнее число "{expected_result}" (сегодня {datetime.now().strftime("%d.%m.%Y")})')        
        
    def click_next_month(self):
        self.test_step_log(f'Нажимаем на стрелку ">" (следующий месяц)')
        self.click(NEXT_MONTH_BTN)
        self.pause(1)
            
    def get_current_month_text(self):   
        current_month = self.wait_for(CURRENT_MONTH_TEXT).text
        self.test_step_log(f'Выбран месяц: {current_month}')
        return current_month    
    
    def parse_month_year(self, text):
        parts = str(text).lower().split()
        month_str = parts[0]
        year = int(parts[1])
        month_index = MONTHS.index(month_str)  # 0–11
        return month_index, year
    
    def check_next_month(self, next_m, next_y, current_m, current_y):
        if current_m == 11:  # декабрь
            expected_month = 0
            expected_year = current_y + 1
        else:
            expected_month = current_m + 1
            expected_year = current_y
        Asserts.assert_equal((next_m, next_y), (expected_month, expected_year),
                             f'Ожидали переход: {MONTHS[current_m]} {current_y} → '
                             f'{MONTHS[expected_month]} {expected_year}, '
                             f'получили: {MONTHS[next_m]} {next_y}') 