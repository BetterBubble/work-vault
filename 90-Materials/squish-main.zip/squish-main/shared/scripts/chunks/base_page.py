from utils.waits import wait_visible, wait_exists
from const import SPECIAL_CHARS
import squish
import re



class BasePage:
    PRIMARY_LOCATOR = None
    READY_LOCATORS = []

    def __init__(self):
        self._wait_page_ready()

    def _wait_page_ready(self):
        if not self.PRIMARY_LOCATOR and not self.READY_LOCATORS:
            return
        try:
            if self.PRIMARY_LOCATOR:
                obj = squish.waitForObject(self.PRIMARY_LOCATOR, 20000)
                #squish.test.log(f"Primary ready: {obj}")
    
            for locator in self.READY_LOCATORS:
                obj = squish.waitForObject(locator, 20000)
                #squish.test.log(f"Ready: {obj}")
    
            squish.snooze(0.5)
    
        except Exception as e:
            squish.test.log(f"Page not ready: {str(e)}")
            raise

    def click(self, locator):
        obj = wait_visible(locator)
        squish.mouseClick(obj)

    def click_button(self, locator):
        btn = wait_visible(locator)
        squish.clickButton(btn)

    def enter_text(self, locator, text):
        field = wait_visible(locator)
        field.text = text

    def is_visible(self, locator):
        return wait_visible(locator) is not None
    
    def is_exist(self, locator):
        return wait_exists(locator)

    def wait_for(self, locator):
        return wait_visible(locator)
    
    def send_text(self, text):        
        for char in text:
            if char.isupper():
                self._press_with_shift(char.lower())
            elif char in SPECIAL_CHARS:
                self._press_with_shift(SPECIAL_CHARS[char])
            elif char == ' ':
                squish.keyPress('<Space>')
            elif char == '\t':
                squish.keyPress('<Tab>')
            elif char == '\n':
                squish.keyPress('<Return>')
            else:
                squish.keyPress(char)    
                
    def _press_with_shift(self, key):
        squish.keyPress('<Shift>')
        squish.keyPress(key)
        squish.keyRelease('<Shift>')
        
    def pause(self, time):
        squish.snooze(time)        
    
    def press_tab_btn(self):
        squish.keyPress('<Tab>')
        squish.keyRelease('<Tab>')
        
    def press_enter_btn(self):    
        squish.keyPress('<Return>')
        squish.keyRelease('<Return>')

    def check_locator(self, locator):    
        wait_visible(locator)
        #obj = wait_visible(locator)
        #return squish.test.log(f"container found: {obj}")
    
    def test_step_log(self, log_msg):
        class_name = self.__class__.__name__
        squish.test.log(f"[{class_name}] {log_msg}")
    
    def left_click_coordinates(self, x_coord, y_coord):
        squish.nativeMouseClick(x_coord, y_coord, 1)
        
    def get_text(self, locator):
        obj = wait_exists(locator)
        plain = str(getattr(obj, "plainText", "")).strip()
        original = str(getattr(obj, "originalText", "")).strip()
        text = str(getattr(obj, "text", "")).strip()
        result = plain or original or text
        result = re.sub(r"<[^>]+>", "", result).strip()
        self.test_step_log(f"[get_text] result: {result}")
        return result