# -*- coding: utf-8 -*-

import squish


class Asserts:

    @staticmethod
    def _resolve(value):
        if isinstance(value, dict):
            obj = squish.waitForObject(value, 10000)
            return getattr(obj, "text", str(obj))
        return value

    @staticmethod
    def assert_equal(actual, expected, msg=None):
        actual_val = Asserts._resolve(actual)
        expected_val = Asserts._resolve(expected)

        #squish.test.log(f"[ASSERT EQUAL] actual: {actual_val}")
        #squish.test.log(f"[ASSERT EQUAL] expected: {expected_val}")

        if msg is None:
            msg = f"Ожидали '{expected_val}', получили '{actual_val}'"

        squish.test.compare(actual_val, expected_val, msg)

    @staticmethod
    def assert_contains(container, item, msg=None):
        container_val = Asserts._resolve(container)
        item_val = Asserts._resolve(item)

        #squish.test.log(f"[ASSERT CONTAINS] container: {container_val}")
        #squish.test.log(f"[ASSERT CONTAINS] item: {item_val}")

        result = str(item_val) in str(container_val)

        if msg is None:
            msg = f"'{item_val}' не найдено в '{container_val}'"

        squish.test.verify(result, msg)
        
    @staticmethod
    def assert_visible(locator, msg=None):
        try:
            obj = squish.waitForObject(locator, 10000)
            visible = getattr(obj, "visible", True)

            #squish.test.log(f"[ASSERT VISIBLE] object: {obj}")
            #squish.test.log(f"[ASSERT VISIBLE] visible: {visible}")

            if msg is None:
                msg = f"Объект не виден: {locator}"

            squish.test.verify(visible, msg)

        except Exception as e:
            if msg is None:
                msg = f"Объект не найден: {locator}"

            squish.test.log(f"[ASSERT VISIBLE] error: {e}")
            squish.test.fail(msg)        