# -*- coding: utf-8 -*-
import time
import locale
import os
import subprocess
import squish
import sys
from const import APP_NAME, APP_NAME_LINUX, RESET_WIN_CLIENT_BAT, CONFIG_LINUX_FILE_PATH, DARWIN_DATA_FOLDER, DARWIN_IVAONE_PREF


def _get_platform():
    return sys.platform.lower()
    

def _set_russian_locale():
    variants = [
        "ru_RU.UTF-8",
        "ru_RU",
        "Russian_Russia.1251",
        "Russian_Russia",
    ]
    for loc in variants:
        try:
            locale.setlocale(locale.LC_TIME, loc)
            squish.test.log(f"Locale set: {loc}")
            return
        except Exception:
            pass
    squish.test.log("Не удалось установить русскую локаль")
    
    
def _clear_linux_data():
    try:
        subprocess.run(["pkill", "-15", "-f", "CoreDesktopShell"], check=False)
        squish.snooze(1)
        subprocess.run(["pkill", "-9", "-f", "CoreDesktopShell"], check=False)
        
        if os.path.isfile(CONFIG_LINUX_FILE_PATH):
            os.remove(CONFIG_LINUX_FILE_PATH)
    except Exception as e:
        squish.test.warning(f"Can't clear data or kill process.\n{e}")   
        
        
def _clear_darwin_data():
    time.sleep(2) # Wait end process
    data_folder = os.path.expanduser(DARWIN_DATA_FOLDER)
    #data_folder = '/Users/gitlab/Library/Application Support/IVA-Tech'
    if not os.path.exists(data_folder):
        squish.test.log(f"Papka s dannimi ne naydena poputi: {data_folder}")
    else:
        for root, dirs, files in os.walk(data_folder, topdown=False):
            for name in files:
                path = os.path.join(root, name)
                try:
                    os.remove(path)
                    #squish.test.log(f'removed {path}')
                except Exception as e:
                    squish.test.log(f'Ne udalos udalit file {path}.\n{e}')
            for name in dirs:
                path = os.path.join(root, name)
                try:
                    os.rmdir(path)
                    #squish.test.log(f'removed {path}')
                except Exception as e:
                    squish.test.log(f'Ne udalos udalit papku {path}.\n{e}')  
        try:
            os.rmdir(data_folder) 
            squish.test.log(f'removed {data_folder}')
        except Exception as e:
            squish.test.log(f'Ne udalos udalit papku {data_folder}.\n{e}')                       
    try:
        service = 'IvaOneDesktop.app'
        check_pass_command = ['security', 'find-generic-password', '-s', service]
        check_pass = subprocess.run(check_pass_command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL) 
        if check_pass.returncode != 0:
            squis.test.log('Password not found')
            return
        subprocess.run(['security', 'delete-generic-password', '-s', service], 
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
        verify_no_pass = subprocess.run(check_pass_command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if verify_no_pass !=0:
            squish.test.log('Password has been successfully removed ')
        else:   
            squish.test.log('Password has not been removed ')
    except Exception as e:
        squish.test.log(f'Ne udalos udalit generic password.\n{e}') 
    try:
        plist_path = os.path.expanduser(DARWIN_IVAONE_PREF)
        if os.path.exists(plist_path):
            os.remove(plist_path)
    except Exception as e:
        squish.test.log(f'Ne udalos udalit {DARWIN_IVAONE_PREF}.\n{e}')        


def _reset_client_state():
    platform = _get_platform()
    squish.test.log(f"platform {platform}")
    _kill_ivaone()
    if platform.startswith('win'):
        if not os.path.isfile(RESET_WIN_CLIENT_BAT):
            raise FileNotFoundError(f"BAT file not found: {RESET_WIN_CLIENT_BAT}")
        squish.test.log(f"Запуск BAT для сброса состояния: {RESET_WIN_CLIENT_BAT}")
        result = subprocess.run(RESET_WIN_CLIENT_BAT, shell=True, capture_output=True, text=True)
        if result.returncode != 0:
            raise RuntimeError(f"Ошибка сброса состояния клиента: {result.returncode}")
    elif platform == 'linux':
        _clear_linux_data()
    elif platform == 'darwin':
        _clear_darwin_data()
    else:
        raise NotImplementedError("Ne udalos sbrosit sostoyanie clienta")    
    squish.test.log("Состояние клиента успешно сброшено")
    
    
def _kill_ivaone():
    platform = _get_platform()
    try:
        if platform.startswith('win'):
            result = subprocess.run(["taskkill", "/F", "/IM", APP_NAME])
        elif platform in ("linux", "darwin"):
            result = subprocess.run(["pkill", "-f", APP_NAME], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
        if result.returncode == 0:
            squish.test.log(f"{APP_NAME} zaversheno")
            return True
        else:
            squish.test.log(f"{APP_NAME} ne nayden ily ne zavershen")
            return False
    except Exception as e:
        squish.test.log(f'Ne udalos zavershit {APP_NAME}.\n{e}')  
        

def _start_app():
    platform = _get_platform()
    string_app = ''
    if platform == 'linux':
        string_app = APP_NAME_LINUX
    else:     
        string_app = APP_NAME
    squish.startApplication(string_app)
    squish.test.log(f"Application started: {string_app}")


def run_setup():
    squish.test.log("=== SETUP START ===")
    squish.testSettings.throwOnFailure = True
    _reset_client_state()
    _set_russian_locale()
    _start_app()
    squish.test.log("=== SETUP END ===")