# -*- coding: utf-8 -*-
from chunks.prelogin_page import PreLoginPage
from chunks.login_page import LoginPage
from chunks.top_menu import TopMenu



def set_server(server_addr):
    prelogin_window = PreLoginPage() 
    prelogin_window.enter_server(server_addr) 
    prelogin_window.click_continue_btn() 
    
def user_auth(user_name, user_pass):  
    login_window = LoginPage()
    login_window.login(user_name, user_pass)
    
def go_to(item):  
    top_menu = TopMenu()
    if item is 'mail':
        top_menu.click_mail_btn() 
    if item is 'calendar':
        top_menu.click_calendar_btn()     
    if item is 'contacts':
        top_menu.click_contacts_btn()
    if item is 'chats':
        top_menu.click_chats_btn()
    if item is 'calls':
        top_menu.click_calls_btn()       