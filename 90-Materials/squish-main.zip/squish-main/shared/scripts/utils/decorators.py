# -*- coding: utf-8 -*-
from utils.suite_setup import run_setup

def with_setup(func):
    def wrapper(*args, **kwargs):
        run_setup()
        return func(*args, **kwargs)
    return wrapper