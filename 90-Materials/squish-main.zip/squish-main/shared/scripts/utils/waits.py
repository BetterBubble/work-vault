import squish
import time

def wait_visible(locator, timeout=20000):
    """Ждём появления объекта"""
    return squish.waitForObject(locator, timeout)

def wait_exists(locator, timeout=15000):
    """Ждём существование объекта"""
    start = time.time()
    last_error = None

    while (time.time() - start) * 1000 <= timeout:
        try:
            obj = squish.waitForObjectExists(locator)
            if obj is not None:
                return obj
        except Exception as e:
            last_error = e

        time.sleep(0.1)

    squish.test.log(f"wait_exists timeout for locator: {locator}")
    if last_error:
        squish.test.log(f"Последняя ошибка: {last_error}")

    raise LookupError(f"Object not found within {timeout} ms: {locator}")
