APP_NAME = "CoreDesktopShell"
APP_NAME_LINUX = "run_ivaone_clean.sh"

RESET_WIN_CLIENT_BAT = r"C:\Users\gitlab.AUTO\clear_userdata.bat"
CONFIG_LINUX_FILE_PATH = r"/home/gitlab/.config/IVA-Tech/IvaOneDesktop.conf"
DARWIN_DATA_FOLDER = "/Users/gitlab/Library/Application Support/IVA-Tech"
DARWIN_IVAONE_PREF = "~/Library/Preferences/com.iva-tech.IvaOneDesktop.plist"

SPECIAL_CHARS = {
                    '@': '2', '!': '1', '#': '3', '$': '4', '%': '5', '^': '6',
                    '&': '7', '*': '8', '(': '9', ')': '0', '_': '-', '+': '=',
                    '{': '[', '}': ']', ':': ';', '"': "'", '<': ',', '>': '.',
                    '?': '/', '|': '\\', '~': '`',
                }

MONTHS = [
    "январь", "февраль", "март", "апрель",
    "май", "июнь", "июль", "август",
    "сентябрь", "октябрь", "ноябрь", "декабрь"
]
