# -*- coding: utf-8 -*-
from utils.decorators import with_setup
from utils.page_helpers import set_server, user_auth
from chunks.calendar import PageCalendar


@with_setup
def main(): 
    server_addres = "gamma-one.ivcs.su" 
    user_name = "t.morozova"
    user_pass = "testtest"
    #server_addres = "at-test-1-one.ivcs.su" 
    #user_name = "gitlab"
    #user_pass = "1"
    
    set_server(server_addres)
    user_auth(user_name, user_pass)
       
    calendar = PageCalendar() 
    calendar.click_day(-1)
    calendar.check_yesterday_date()


    
    
