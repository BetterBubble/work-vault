from tests import pages


def login(driver, version, lang, username, password, welcome_popup=True):
    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.set_language(lang)
    # reinitiate PageObject to appropriate language
    login_page = pages.get_page(version, 'login')(driver, lang=lang, open_page=False)
    login_page.login(username, password)

    if welcome_popup:
        welcome_popup = pages.get_page(version, 'welcome_popup')(driver, lang=lang, open_page=False)
        welcome_popup.dont_show()
        welcome_popup.close_ok()

