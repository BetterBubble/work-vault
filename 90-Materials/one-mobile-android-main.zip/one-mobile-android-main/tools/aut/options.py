from selenium import webdriver

from autocore.test.logger import get_log
from autocore.test.config import get_from_pipeline

log = get_log()

OPTIONS_CHROME_DEBUG = [
    '--auto-open-devtools-for-tabs',
]

OPTIONS_CHROME_CAMERA = [
    '--use-fake-device-for-media-stream',
    '--use-fake-ui-for-media-stream',
    '--incognito',
]


def generate_chrome_options():
    options = webdriver.ChromeOptions()
    options_list = []
    options_list += OPTIONS_CHROME_CAMERA
    options.add_argument('ignore-certificate-errors')
    options.add_argument('allow-running-insecure-content')
    if get_from_pipeline():
        options_list += OPTIONS_CHROME_IN_DOCKER

    log.info(f'Set Chrome options: {",".join(options_list)}')
    [options.add_argument(el) for el in options_list]
    return options
