import os
import consts

from appium.options.android import UiAutomator2Options
from appium import webdriver

from tests.pages import browser
from . import options
from tools.utils import is_real_device, ipa_reinstall, apk_reinstall, apk_remove
from autocore.test.logger import get_log
from autocore.test.config import get_env
from autocore.test.config import get_config
from autocore.clients import ssh
from appium.webdriver.common.appiumby import AppiumBy


env = get_env()
config = get_config()
log = get_log()


def start(device_os, device_host, device_name, is_pd, dp, sp):
    device_ip, device_port = device_host.split(':')
    if device_ip == 'local':
        device_ip = '0.0.0.0'

    if device_os == 'Android':
        options = UiAutomator2Options()
        caps = {
            # "appium:app": "https://files.hi-tech.org/mobile/android/ucim/releases/17.0/ucim-17.0.1973.apk",
            "platformName": "android",
            "appium:appPackage": "su.ivcs.kmp",
            # "appium:appActivity": "su.ivcs.ucim.presentationLayer.screens.rootScreen.view.RootScreenActivity",
            "appium:deviceName": device_name,
            "appium:udid": device_name,
            "appium:automationName": "UIAutomator2",
            # "appium:appWaitActivity": "su.ivcs.ucim.presentationLayer.screens.loginScreen.view.LoginScreenActivity",
            "autoGrantPermissions": True
            # "appium:noReset": True
        }
        options.load_capabilities(caps)
        return webdriver.Remote(f'http://{device_ip}:{device_port}', options=options)

    caps = {
        # "appium:app": "~/Library/Developer/Xcode/DerivedData/Ucim.app",
        "platformName": "ios",
        "appium:udid": device_name,
        "appium:wdaLocalPort": dp,
        "appium:systemPort": sp,
        # "appium:noReset": False,
        "appium:allowProvisioningDeviceRegistration": True,
        "appium:automationName": "XCUITest",
        "appium:autoGrantPermissions": True,
        "appium:includeSafariInWebviews": True,
        "appium:newCommandTimeout": 0 # during debug - not to close driver session
    }
    if device_os == 'iOS' and is_pd:
        caps["appium:bundleId"] = "su.ivcs.ucim"
    else:
        caps["appium:bundleId"] = "su.ivcs.ucim"

    return webdriver.Remote(f'http://{device_ip}:{device_port}', caps)


def clear_data(device_os, device_host, device_name, is_pd):
    device_ip, device_port = device_host.split(':')

    if device_os == 'iOS':
        if not is_pd:
            if device_ip == 'local':
                app_path = f'{os.getcwd()}/Ucim.ipa'
            else:
                app_path = '/Users/user/ios_builds/Ucim.app'
            ssh.exec_shell(f'xcrun simctl install {device_name} {app_path}', server=device_ip,
                           user=consts.CI_USER, password=consts.CI_PASSWORD)

        else:
            if device_ip == 'local':
                app_path = f'{os.getcwd()}/Ucim.ipa'
            else:
                app_path = '/Users/user/ios_builds/Ucim.ipa'
            ipa_reinstall(device_name, app_path, server=device_ip, user=consts.CI_USER, password=consts.CI_PASSWORD)
    else:
        if device_ip == 'local':
            app_path = f'{os.getcwd()}/one.apk'
        else:
            app_path = '/Users/user/android_builds/one.apk'
        #log.step(f'Installing for {device_name}', where='IVA Mobile Клиент')
        apk_reinstall(device_name, app_path,server=device_ip, user=consts.CI_USER, password=consts.CI_PASSWORD)


# def open_browser(driver, device_os, url, lang):
#     if device_os == "Android":
#         driver.execute_script('mobile: shell', {'command': f'am start -a android.intent.action.VIEW -d {url}'})
#
#         # Разрешим уведомления браузеру
#         driver.switch_to.context('NATIVE_APP')
#         try:
#             # "Воспользуйтесь преимуществами уведомлений в Chrome", разрешим
#             driver.find_element(by=AppiumBy.XPATH,
#                                 value='//android.widget.Button[@resource-id="com.android.chrome:id/positive_button"]').click()
#         except:
#             log.info('No alert window found')
#
#         try:
#             # "Разрешить Chrome отправлять уведомления?", разрешим
#             driver.find_element(by=AppiumBy.XPATH,
#                                 value='//android.widget.Button[@resource-id="com.android.permissioncontroller:id/permission_allow_button"]').click()
#         except:
#             log.info('No alert window found')
#
#         try:
#             # "С сайта ххх.hi-tech.org поступил запрос на отправку уведомлений", разрешим
#             driver.find_element(by=AppiumBy.XPATH,
#                                 value='//android.widget.Button[@resource-id="com.android.chrome:id/positive_button"]').click()
#         except:
#             log.info('No alert window found')
#
#     else:
#         driver.get(url)
#
#     browser_activity = browser.get_browser(device_os)(driver, lang=lang)
#     browser_activity.continue_in_app()
#
# def close_browser(driver, device_os):
#     if device_os == "Android" and len(driver.contexts) > 1:
#         driver.switch_to.context(driver.contexts[-1])
#         for handle in driver.window_handles:
#             driver.switch_to.window(handle)
#             driver.close()