import consts
from autocore.clients import ssh
from autocore.test.logger import get_log

log = get_log()
android_package = 'su.ivcs.kmp'


def restore_adb_uiautomator(device_ip, device_name):
    uninstall_uiautomator2_server = f'adb -s {device_name} shell pm uninstall io.appium.uiautomator2.server'
    ssh.exec_shell(uninstall_uiautomator2_server, server=device_ip,
            user=consts.CI_USER, password=consts.CI_PASSWORD)

    uninstall_uiautomator2_test = f'adb -s {device_name} shell pm uninstall io.appium.uiautomator2.server.test'
    ssh.exec_shell(uninstall_uiautomator2_test, server=device_ip,
            user=consts.CI_USER, password=consts.CI_PASSWORD)


def is_real_device(device_os, device_name, device_ip, user='', password=''):
    if device_os == 'Android':
        if 'emulator' in device_name:
            return False
        return True
    if device_os == 'iOS':
        stdout = ssh.exec_shell(f'xcrun simctl list | grep {device_name}',
                                server=device_ip, user=user, password=password)
        # Если out пуст, значит мы работаем на физ. устройстве
        if stdout:
            return False
        return True


def ipa_install(device_name, app_path, server='', user='', password=''):
    log.info(f'Installing ad hoc ipa.. {app_path}')
    stdout, stderr = ssh.exec_shell(f'xcrun devicectl device install app --device {device_name} {app_path}', server=server,
                         user=user, password=password, stderr=True)
    if stderr:
        log.warn(f'stderr: {stderr}')
        raise Exception('Something went wrong during installation *.ipa')
    log.info('Installation finished')


def ipa_remove(device_name, server='', user='', password=''):
    log.info(f'Uninstalling ad hoc ipa..')
    ssh.exec_shell(f'xcrun devicectl device uninstall app --device {device_name} su.ivcs.ucim', server=server,
                   user=user,
                   password=password)


def ipa_reinstall(device_name, app_path, server='', user='', password=''):
    ipa_remove(device_name, server, user, password)
    ipa_install(device_name, app_path, server, user, password)


def apk_remove(device_name, server='', user='', password=''):
    uninstall_cmds = [
        f'adb -s {device_name} shell pm clear {android_package}',
        f'adb -s {device_name} shell pm uninstall {android_package}'
    ]
    for cmd in uninstall_cmds:
        try:
            log.info(f'Remove previous version: {cmd}')
            ssh.exec_shell(cmd, server=server, user=user, password=password)
        except Exception as exc:
            log.step(f'"{cmd}" failed, exception: "{exc}"', where='IVA Mobile Клиент')


def apk_install(device_name, app_path, server='', user='', password=''):
    cmd = f'adb -s {device_name} install {app_path}'
    log.info(f'Installing apk: {cmd}')
    ssh.exec_shell(cmd, server=server, user=user, password=password)
    log.info('Installation finished')


def apk_reinstall(device_name, app_path, server='', user='', password=''):
    apk_remove(device_name, server, user, password)
    apk_install(device_name, app_path, server, user, password)
