import re
import consts
import time
from autocore import stands
from autocore.test.logger import get_log

log = get_log()


def generate_inbox_name():
    return f'{int(time.time())}@ivaat.domain'


def get_recovery_link():
    log.step('Получить ссылку для восстановления пароля', where='Почтовый ящик')
    message = stands.read_exim_queued_message_by_id()
    link = re.findall('(https[^\n]+)', message)[0]
    log.info(f'Ссылка получена: {link}')
    return link


def get_confirm_code():
    log.step('Получить код подтверждения', where='Почтовый ящик')
    message = stands.read_exim_queued_message_by_id()
    code = re.findall('Код подтверждения входа: (\d+).', message)[0]
    log.info(f'Код получен: {code}')
    return code


def get_registration_password():
    log.step('Получить пароль', where='Почтовый ящик')
    message = stands.read_exim_queued_message_by_id()
    password = re.findall('Ваш пароль: (\S+)', message)[0]
    log.info(f'Пароль получен: {password}')
    return password
