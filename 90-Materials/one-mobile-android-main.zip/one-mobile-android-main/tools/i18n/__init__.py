import consts
from .strings import strings


supported_langs = [consts.LANG_RU, consts.LANG_EN]


def is_supported(lang):
    return lang in supported_langs


def get_str(str_key, lang):
    if not is_supported(lang):
        raise Exception(f'Language is not supported: {lang}')
    return strings[str_key][lang]
