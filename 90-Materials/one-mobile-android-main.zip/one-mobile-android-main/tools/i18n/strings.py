import consts


strings = {
    'password_input': {
        consts.LANG_RU: 'Введите пароль',
        consts.LANG_EN: 'Enter password',
    },
    'login_btn_login': {
        consts.LANG_RU: 'Войти',
        consts.LANG_EN: 'TODO',
    },
    'pick_server_btn_continue': {
        consts.LANG_RU: 'Продолжить',
        consts.LANG_EN: 'TODO',
    },
    'home_bottom_panel': {
        consts.LANG_RU: 'Панель вкладок',
        consts.LANG_EN: 'TODO',
    },
    'incorrect_server_message': {
        consts.LANG_RU: 'Неверный формат адреса сервера',
        consts.LANG_EN: 'TODO',
    },
    'not_found_server_message': {
        consts.LANG_RU: 'Сервер не найден',
        consts.LANG_EN: 'TODO',
    },
    'incorrect_login_details_message': {
        consts.LANG_RU: 'Вы ввели неверный логин или пароль',
        consts.LANG_EN: 'TODO',
    },
    'header_server_selection': {
        consts.LANG_RU: 'Выбор сервера',
        consts.LANG_EN: 'TODO',
    },
    'login_password_field': {
        consts.LANG_RU: 'Введите пароль',
        consts.LANG_EN: 'TODO',
    },
    'add_server_button': {  #TODO: Понаблюдать несколько версий и привести к одному локатору add_server_button iOS & Android
      consts.LANG_RU: 'Добавить новый',
      consts.LANG_EN: 'TODO',
    },
    'ios_add_server_button': {
      consts.LANG_RU: 'Добавить новый',
      consts.LANG_EN: 'TODO',
    },
    'confirm_code_input': {
        consts.LANG_RU: 'Введите код',
        consts.LANG_EN: 'TODO',
    },
    'confirm_code_send_message': {
        consts.LANG_RU: 'Включена проверка безопасности. Код подтверждения входа отправлен на',
        consts.LANG_EN: 'TODO',
    },
    'back_previous_step': {
        consts.LANG_RU: 'Вернуться к предыдущему шагу',
        consts.LANG_EN: 'TODO',
    },
    'invalid_code_message': {
        consts.LANG_RU: 'Введен неверный код',
        consts.LANG_EN: 'TODO',
    },
    'login_window_title': {
        consts.LANG_RU: 'Вход в систему',
        consts.LANG_EN: 'TODO',
    },
    'chats_window_title': {
        consts.LANG_RU: 'Чаты',
        consts.LANG_EN: 'TODO',
    },
    'new_chat_window_title': {
        consts.LANG_RU: 'Новый чат',
        consts.LANG_EN: 'TODO',
    },
    'group_chat_members_count_title': {
        consts.LANG_RU: 'Участников',
        consts.LANG_EN: 'TODO',
    },
    'group_chat_in_list': {
        consts.LANG_RU: 'групповой чат',
        consts.LANG_EN: 'TODO',
    },
    'chat_message_input': {
        consts.LANG_RU: 'Написать сообщение...',
        consts.LANG_EN: 'TODO',
    },
    'chat_add_image_caption': {
        consts.LANG_RU: 'Добавление изображения',
        consts.LANG_EN: 'TODO',
    },
    'chat_status_caption_typing': {
        consts.LANG_RU: 'печатает...',
        consts.LANG_EN: 'TODO',
    },
    'contacts_chat_search_input': {
        consts.LANG_RU: 'Имя, email или телефон',
        consts.LANG_EN: 'TODO',
    },
    'chat_cancel_add_contact': {
        consts.LANG_RU: 'Back Normal',
        consts.LANG_EN: 'TODO',
    },
    'chat_status_typing_title': {
        consts.LANG_RU: 'печатает',
        consts.LANG_EN: 'TODO',
    },
    'chat_select_last_photo_button': {
        consts.LANG_RU: 'Последнее фото',
        consts.LANG_EN: 'TODO',
    },
    'chat_select_file_button': {
        consts.LANG_RU: 'Выбрать файл',
        consts.LANG_EN: 'TODO',
    },
    'chat_select_document_button': {
        consts.LANG_RU: 'Документ',
        consts.LANG_EN: 'TODO',
    },
    'chat_send_attachment_photo_button': {
        consts.LANG_RU: 'Добавление изображения',
        consts.LANG_EN: 'TODO',
    },
    'chat_send_attachment_document_button': {
        consts.LANG_RU: 'Добавление файла',
        consts.LANG_EN: 'TODO',
    },
    'chat_accept_full_access_media_button': {
        consts.LANG_RU: 'Разрешить полный доступ',
        consts.LANG_EN: 'TODO',
    },
    'chat_gallery_media_button': {
        consts.LANG_RU: 'МЕДИА',
        consts.LANG_EN: 'TODO',
    },
    'chat_gallery_documents_button': {
        consts.LANG_RU: 'ДОКУМЕНТЫ',
        consts.LANG_EN: 'TODO',
    },
    'chat_answer_call_button': {
        consts.LANG_RU: 'Ответить',
        consts.LANG_EN: 'TODO',
    },
    'chat_join_to_call_button': {
        consts.LANG_RU: 'Присоединиться',
        consts.LANG_EN: 'TODO',
    },
    'add_to_call_title': {
        consts.LANG_RU: 'Добавление участников',
        consts.LANG_EN: 'TODO',
    },
    'contacts_clear_text_button': {
        consts.LANG_RU: 'Очистить текст',
        consts.LANG_EN: 'TODO',
    },
    'contacts_window_title': {
        consts.LANG_RU: 'Контакты',
        consts.LANG_EN: 'TODO',
    },
    'contacts_search_input': {
        consts.LANG_RU: 'Имя, e-mail, телефон или адрес VVoIP-устройства',
        consts.LANG_EN: 'TODO',
    },
    'contacts_cancel_button': {
        consts.LANG_RU: 'ОТМЕНА',
        consts.LANG_EN: 'TODO',
    },
    'header_settings': {
        consts.LANG_RU: 'Настройки',
        consts.LANG_EN: 'TODO',
    },
    'bottom_menu_chats_button': {
        consts.LANG_RU: 'Чаты',
        consts.LANG_EN: 'TODO',
    },
    'bottom_menu_meetings_button': {
        consts.LANG_RU: 'Мероприятия',
        consts.LANG_EN: 'TODO',
    },
    'bottom_menu_rooms_button': {
        consts.LANG_RU: 'Комнаты',
        consts.LANG_EN: 'TODO',
    },
    'room_name_field': {
        consts.LANG_RU: 'Новая комната',
        consts.LANG_EN: 'TODO',
    },
    'new_room_header': {
        consts.LANG_RU: 'Создание комнаты',
        consts.LANG_EN: 'TODO',
    },
    'enter_room_button': {
        consts.LANG_RU: 'Войти',
        consts.LANG_EN: 'TODO',
    },
    'about_room_caption': {
        consts.LANG_RU: 'О комнате',
        consts.LANG_EN: 'TODO',
    },
    'confirm_delete_room_button': {
        consts.LANG_RU: 'Удалить',
        consts.LANG_EN: 'TODO',
    },
    'meeting_start_now_button': {
        consts.LANG_RU: 'Начать сейчас',
        consts.LANG_EN: 'TODO',
    },
    'meeting_start_scheduled_button': {
        consts.LANG_RU: 'Запланировать',
        consts.LANG_EN: 'TODO',
    },
    'scheduled_meeting_name_field': {
        consts.LANG_RU: 'Новое мероприятие',
        consts.LANG_EN: 'TODO',
    },
    'scheduled_meeting_agenda_field': {
        consts.LANG_RU: 'Повестка мероприятия',
        consts.LANG_EN: 'TODO',
    },
    'scheduled_meeting_start_date_field': {
        consts.LANG_RU: 'Дата начала',
        consts.LANG_EN: 'TODO',
    },
    'scheduled_meeting_start_time_field': {
        consts.LANG_RU: 'Время начала',
        consts.LANG_EN: 'TODO',
    },
    'scheduled_meeting_end_time_field': {
        consts.LANG_RU: 'Время окончания',
        consts.LANG_EN: 'TODO',
    },
    'scheduled_meeting_duration_field': {
        consts.LANG_RU: 'Длительность',
        consts.LANG_EN: 'TODO',
    },
    'scheduled_meeting_template_field': {
        consts.LANG_RU: 'Шаблон',
        consts.LANG_EN: 'TODO',
    },
    'scheduled_meeting_periodicity_field': {
        consts.LANG_RU: 'Периодичность',
        consts.LANG_EN: 'TODO',
    },
    'schedule_meeting_header': {
        consts.LANG_RU: 'Планирование мероприятия',
        consts.LANG_EN: 'TODO',
    },
    'edit_schedule_meeting_header': {
        consts.LANG_RU: 'Редактирование мероприятия',
        consts.LANG_EN: 'TODO',
    },
    'meeting_template_hd_conference': {
        consts.LANG_RU: 'HD Conference',
        consts.LANG_EN: 'TODO',
    },
    'meeting_id_textfield': {
        consts.LANG_RU: 'Введите ID мероприятия',
        consts.LANG_EN: 'TODO',
    },
    'meeting_about_caption': {
        consts.LANG_RU: 'О мероприятии',
        consts.LANG_EN: 'TODO',
    },
    'bottom_menu_contacts_button': {
        consts.LANG_RU: 'Контакты',
        consts.LANG_EN: 'TODO',
    },
    'bottom_menu_settings_button': {
        consts.LANG_RU: 'Настройки',
        consts.LANG_EN: 'TODO',
    },
    'profile_change_password_button': {
        consts.LANG_RU: 'Изменить пароль',
        consts.LANG_EN: 'TODO',
    },
    'header_profile_edit': {
        consts.LANG_RU: 'ИЗМЕНЕНИЕ ПРОФИЛЯ',
        consts.LANG_EN: 'TODO',
    },
    'number_failed_attempts_exceeded_message': {
        consts.LANG_RU: 'Превышено число неудачных попыток ввода. Повторите попытку позднее.',
        consts.LANG_EN: 'TODO',
    },
    'incorrect_meeting_id_message': {
        consts.LANG_RU: 'Вы ввели неверный ID мероприятия',
        consts.LANG_EN: 'TODO',
    },
    'enter_meeting_id_header': {
        consts.LANG_RU: 'Вход в мероприятие',
    },
    'send_code_on_email_again': {
        consts.LANG_RU: 'Отправить повторно',
        consts.LANG_EN: 'TODO'
    },
    'resend_code_after_message': {
        consts.LANG_RU: 'Отправить код повторно через',
        consts.LANG_EN: 'TODO'
    },
    'login_by_adfs_server1_link': {
        consts.LANG_RU: 'Войти через ADFS SSO server #1',
        consts.LANG_EN: 'TODO'
    },
    'browser_continue_in_app_button': {
        consts.LANG_RU: 'Открыть в приложении',
        consts.LANG_EN: 'TODO'
    },
    'browser_open_in_app_button': {
        consts.LANG_RU: 'Открыть',
        consts.LANG_EN: 'TODO'
    },
    'browser_page_caption': {
        consts.LANG_RU: 'Сегодня',
        consts.LANG_EN: 'TODO'
    },
    'enter_conference_button': {
        consts.LANG_RU: 'Продолжить',
        consts.LANG_EN: 'TODO'
    },
    'enter_conference_caption': {
        consts.LANG_RU: 'Вход в мероприятие',
        consts.LANG_EN: 'TODO'
    },
    'connect_to_conference_button': {
        consts.LANG_RU: 'Подключиться',
        consts.LANG_EN: 'TODO'
    },
    'switch_to_registered_tab': {
        consts.LANG_RU: 'Зарегистрированный',
        consts.LANG_EN: 'TODO'
    },
    'enter_via_iva_connect_button': {
        consts.LANG_RU: 'Войти через IVA Connect',
        consts.LANG_EN: 'TODO'
    },
    'kmp_sign_in_title': {
        consts.LANG_RU: 'Вход в систему',
        consts.LANG_EN: 'Sign in'
    },
    'kmp_sign_in_button': {
        consts.LANG_RU: 'Войти',
        consts.LANG_EN: 'Sign in'
    },
    'kmp_server_description': {
        consts.LANG_RU: 'Укажите сервер, чтобы подключиться к рабочему пространству вашей организации',
        consts.LANG_EN: "Specify a server to connect to your organization's workspace"
    },
    'kmp_build_label': {
        consts.LANG_RU: 'Сборка ',
        consts.LANG_EN: 'Build '
    },
    'kmp_login_back_button': {
        consts.LANG_RU: 'Назад',
        consts.LANG_EN: 'Back'
    },
    'kmp_login_page_title': {
        consts.LANG_RU: 'Вход в учетную запись',
        consts.LANG_EN: 'Sign in to your account'
    },
    'kmp_login_username_input': {
        consts.LANG_RU: 'Имя пользователя или E-mail',
        consts.LANG_EN: 'Username or E-mail'
    },
    'kmp_login_password_input': {
        consts.LANG_RU: 'Пароль',
        consts.LANG_EN: 'Password'
    },
    'kmp_login_show_password_button': {
        consts.LANG_RU: 'Показать пароль',
        consts.LANG_EN: 'Show password'
    },
    'kmp_login_submit_button': {
        consts.LANG_RU: 'Вход',
        consts.LANG_EN: 'Sign in'
    },
    'kmp_passcode_set_up_title': {
        consts.LANG_RU: 'Придумайте код для входа в приложение',
        consts.LANG_EN: 'Set up a passcode'
    },
    'kmp_passcode_set_up_description': {
        consts.LANG_RU: 'Не используйте простые числа и свою дату рождения, их легко угадать',
        consts.LANG_EN: 'Avoid simple sequence of numbers and your birth date'
    },
    'kmp_passcode_verify_title': {
        consts.LANG_RU: 'Подтвердите код',
        consts.LANG_EN: 'Verify code'
    },
    'kmp_passcode_verify_description': {
        consts.LANG_RU: 'Повторите код для подтверждения',
        consts.LANG_EN: 'Enter confirmation code'
    },
    'kmp_next_button': {
        consts.LANG_RU: 'Далее',
        consts.LANG_EN: 'Next'
    },
    'kmp_bottom_menu_mail_button': {
        consts.LANG_RU: 'Почта',
        consts.LANG_EN: 'Mail'
    },
    'kmp_bottom_menu_calls_button': {
        consts.LANG_RU: 'Звонки',
        consts.LANG_EN: 'Calls'
    },
    'kmp_bottom_menu_calendar_button': {
        consts.LANG_RU: 'Календарь',
        consts.LANG_EN: 'Calendar'
    },
    'kmp_bottom_menu_more_button': {
        consts.LANG_RU: 'Ещё',
        consts.LANG_EN: 'More'
    },
    'kmp_search_placeholder': {
        consts.LANG_RU: 'Поиск',
        consts.LANG_EN: 'Search'
    },
    'kmp_chat_filter_all': {
        consts.LANG_RU: 'Все',
        consts.LANG_EN: 'All'
    },
    'kmp_chat_filter_direct': {
        consts.LANG_RU: 'Личные',
        consts.LANG_EN: 'Direct'
    },
    'kmp_chat_filter_groups': {
        consts.LANG_RU: 'Группы',
        consts.LANG_EN: 'Groups'
    },
    'kmp_chat_filter_threads': {
        consts.LANG_RU: 'Треды',
        consts.LANG_EN: 'Threads'
    },
    'kmp_create_folder_button': {
        consts.LANG_RU: 'Создать папку',
        consts.LANG_EN: 'Create folder'
    },
    'kmp_import_folder_button': {
        consts.LANG_RU: 'Импортировать папку',
        consts.LANG_EN: 'Import folder'
    },
    'kmp_no_messages': {
        consts.LANG_RU: 'Нет сообщений',
        consts.LANG_EN: 'No messages'
    },
    'kmp_photo_preview': {
        consts.LANG_RU: 'Фотография',
        consts.LANG_EN: 'Photo'
    },
    'kmp_calls_title': {
        consts.LANG_RU: 'Все звонки',
        consts.LANG_EN: 'All calls'
    },
    'kmp_calls_today_group': {
        consts.LANG_RU: 'Сегодня',
        consts.LANG_EN: 'Today'
    },
    'kmp_call_missed_status': {
        consts.LANG_RU: 'Пропущенный',
        consts.LANG_EN: 'Missed'
    },
    'kmp_contacts_title': {
        consts.LANG_RU: 'Все контакты',
        consts.LANG_EN: 'All contacts'
    },
    'kmp_more_tasks_button': {
        consts.LANG_RU: 'Задачи',
        consts.LANG_EN: 'Tasks'
    },
    'kmp_more_rooms_button': {
        consts.LANG_RU: 'Комнаты',
        consts.LANG_EN: 'Rooms'
    },
    'kmp_more_conferences_button': {
        consts.LANG_RU: 'Конференции',
        consts.LANG_EN: 'Conferences'
    },
    'kmp_more_services_button': {
        consts.LANG_RU: 'Сервисы',
        consts.LANG_EN: 'Services'
    },
    'kmp_more_mcu_chats_button': {
        consts.LANG_RU: 'MCU-чаты',
        consts.LANG_EN: 'MCU chats'
    },
    'kmp_more_disk_button': {
        consts.LANG_RU: 'Диск',
        consts.LANG_EN: 'Disk'
    }
}
