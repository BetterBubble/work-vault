import pytest

from autocore.test.logger import get_log
from tests.pages import PAndroidKmpAuth, PAndroidKmpChats, PAndroidKmpPasscode

log = get_log()


@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.android
def test_one_user_authorization_opens_chats(setup_aut, teardown):
    lang = setup_aut['setup']['cmd']['lang']
    login_creds = setup_aut['setup']['config']['credentials']['user1']
    server = setup_aut['setup']['config']['server']
    driver = setup_aut['driver']

    log.tc('468')

    teardown.append(lambda: driver.quit())

    auth_page = PAndroidKmpAuth(driver, lang=lang)
    auth_page.set_server(server)
    auth_page.assert_server_formatted_and_sign_in_enabled()
    auth_page.submit_server()
    auth_page.assert_login_page_opened()
    auth_page.login(**login_creds)

    passcode_page = PAndroidKmpPasscode(driver, lang=lang)
    passcode_page.set_up_passcode()

    _ = PAndroidKmpChats(driver, lang=lang)
