from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver import ActionChains
from selenium.common.exceptions import TimeoutException
from selenium.common.exceptions import NoSuchElementException
import allure
from allure_commons.types import AttachmentType

from autocore.test.config import get_config
from autocore.test.config import get_env
from autocore.test.logger import get_log
from autocore.test.assertions import assert_fn
import time


log = get_log()


def get_env_url():
    conf = get_config()
    env = get_env()
    return conf[env]['web_url']


class _PBase:
    def __init__(self, driver, lang, check_primary_element=True, version=''):
        self.version = version
        self.driver = driver
        self.driver.implicitly_wait(0)
        self.env_url = get_env_url()
        if check_primary_element:
            self.wait_presence(self.primary_element)

    def wait_presence(self, locator, timeout=15, message='', mode='raise', ec_func='presence_of_element_located'):
        if locator is None:
            return True
        log.debug(f'Start waiting presence of element "{locator}"')
        try:
            _ = WebDriverWait(self.driver, timeout).until(
                getattr(EC, ec_func)(locator)
            )
        except TimeoutException:  # add message for TimeoutException
            _msg = message or f'No such element: {locator[1]}'
            if mode == 'raise':
                raise TimeoutException(_msg)
            if mode == 'return':
                return False
        log.debug(f'Finished waiting presence of element "{locator}"')
        return True

    def wait_absence(self, locator, timeout=5):
        for _ in range(timeout):
            is_present = self.wait_presence(locator, timeout=1, mode='return')
            if is_present == False: # element disappeared
                return True
            else: # element is found and found instantly
                time.sleep(1)
        log.warning(f'Element has not gone for {timeout} seconds')
        return False

    def get_object(self, locator, multiple=False, timeout=35, wait_clickable=False):
        kwargs = {}
        if wait_clickable:
            # for example, button may be disabled, while data gets loaded
            # if test tries to wait_presence() such element and click() - click will not actually happen
            # and no exception will occur, though click() method will return
            # this will lead to an unexpected test state
            kwargs['ec_func'] = 'element_to_be_clickable'
        self.wait_presence(locator, timeout=timeout, **kwargs)
        meth = self.driver.find_elements if multiple else self.driver.find_element
        try:
            result = meth(*locator)
        except NoSuchElementException:
            log.warning(f"Web element with locator '{locator}' doesn't exist")
            raise
        return result

    def assert_presence(self, locator, message):
        fn = lambda: self.wait_presence(locator, message=message, mode='return')
        assert_fn(fn, message)

    def assert_absense(self, locator, message):
        fn = lambda: self.wait_absence(locator)
        assert_fn(fn, message)

    def assert_input_length(self, input, length):
        long_string = '1' * length
        input.send_keys(long_string)
        input.send_keys('x')
        assert_fn(lambda: 'x' not in input.get_attribute('value'), f'Нельзя ввести больше {length} символов в поле')
        input.send_keys(Keys.BACKSPACE * length)

    def move_to_element(self, locator):
        result = self.get_object(locator)
        action = ActionChains(self.driver)
        action.move_to_element(result).perform()

    def clear_input(self, locator):
        self.get_object(locator).clear()

    def take_screenshot(self, driver, message=''):
        try:
            allure.attach(driver.get_screenshot_as_png(), name=f"Device-{driver.session['udid']}-{message}",
                          attachment_type=AttachmentType.PNG)
        except:
            log.warning('Something went wrong with driver session during screenshot')