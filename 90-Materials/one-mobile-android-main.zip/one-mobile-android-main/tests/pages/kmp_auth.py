from autocore.test.assertions import assert_fn
from autocore.test.logger import get_log

from tests.pages.base import _PBase
from tests.pages.locators.Android.KMP import LKmpAuth


log = get_log()


class PAndroidKmpAuth(_PBase, LKmpAuth):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_I18N_SERVER_HEADER(self.lang)
        super().__init__(*args, **kwargs)

    def set_server(self, server):
        log.step('Ввести адрес сервера', where='IVA One Mobile')
        server = server.removeprefix('https://').removeprefix('http://').rstrip('/')
        server_input = self.get_object(self.L_SERVER_INPUT())
        server_input.clear()
        server_input.send_keys(server)

    def assert_server_formatted_and_sign_in_enabled(self):
        self.assert_presence(
            locator=self.L_SERVER_PROTOCOL_PREFIX(),
            message='Адрес сервера отформатирован с протоколом https://',
        )
        sign_in_button = self.get_object(
            self.L_I18N_SERVER_SIGN_IN_BUTTON(self.lang),
            wait_clickable=True,
        )
        assert_fn(lambda: sign_in_button.get_attribute('enabled') == 'true',
                  'Кнопка входа активна после ввода сервера')

    def submit_server(self):
        log.step('Нажать кнопку входа на экране выбора сервера', where='IVA One Mobile')
        self.get_object(self.L_I18N_SERVER_SIGN_IN_BUTTON(self.lang), wait_clickable=True).click()

    def assert_login_page_opened(self):
        self.assert_presence(
            locator=self.L_I18N_LOGIN_PAGE_TITLE(self.lang),
            message='Открыт экран авторизации',
        )

    def login(self, username, password):
        log.step('Авторизоваться', where='IVA One Mobile')
        self.get_object(self.L_LOGIN_USERNAME_INPUT()).send_keys(username)
        self.get_object(self.L_LOGIN_PASSWORD_INPUT()).send_keys(password)
        self.get_object(self.L_I18N_LOGIN_SUBMIT_BUTTON(self.lang), wait_clickable=True).click()
