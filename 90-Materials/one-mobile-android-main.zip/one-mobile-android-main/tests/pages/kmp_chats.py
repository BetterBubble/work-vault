from tests.pages.base import _PBase
from tests.pages.locators.Android.KMP import LKmpChats


class PAndroidKmpChats(_PBase, LKmpChats):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_I18N_HEADER(self.lang)
        super().__init__(*args, **kwargs)
