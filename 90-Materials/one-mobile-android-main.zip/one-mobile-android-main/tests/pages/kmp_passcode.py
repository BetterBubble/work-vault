from autocore.test.logger import get_log

from tests.pages.base import _PBase
from tests.pages.locators.Android.KMP import LKmpPasscode


log = get_log()


class PAndroidKmpPasscode(_PBase, LKmpPasscode):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_I18N_SET_UP_HEADER(self.lang)
        super().__init__(*args, **kwargs)

    def set_up_passcode(self, pin='1357'):
        log.step('Создать код для входа в приложение', where='IVA One Mobile')
        self._enter_pin(pin)
        self._tap_next_if_present()
        self.wait_presence(self.L_I18N_VERIFY_HEADER(self.lang))
        self._enter_pin(pin)
        self._tap_next_if_present()

    def _enter_pin(self, pin):
        for digit in pin:
            self.get_object(self.L_PIN_DIGIT(digit), wait_clickable=True).click()

    def _tap_next_if_present(self):
        if self.wait_presence(self.L_I18N_NEXT_BUTTON(self.lang), timeout=2, mode='return'):
            self.get_object(self.L_I18N_NEXT_BUTTON(self.lang), wait_clickable=True).click()
