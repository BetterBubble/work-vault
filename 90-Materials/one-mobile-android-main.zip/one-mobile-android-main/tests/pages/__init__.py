from .kmp_auth import PAndroidKmpAuth
from .kmp_chats import PAndroidKmpChats
from .kmp_passcode import PAndroidKmpPasscode


def get_page(platform, page_name):
    if platform == 'Android':
        pages = {
            'kmp_auth': PAndroidKmpAuth,
            'kmp_chats': PAndroidKmpChats,
            'kmp_passcode': PAndroidKmpPasscode,
        }
        return pages.get(page_name)
