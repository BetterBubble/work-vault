import consts

from .common import LKmpCommon


class LKmpPasscode(LKmpCommon):
    @staticmethod
    def L_I18N_SET_UP_HEADER(lang=consts.LANG_RU):
        return LKmpCommon.L_I18N_TEXT('kmp_passcode_set_up_title', lang=lang)

    @staticmethod
    def L_I18N_SET_UP_DESCRIPTION(lang=consts.LANG_RU):
        return LKmpCommon.L_I18N_TEXT('kmp_passcode_set_up_description', lang=lang)

    @staticmethod
    def L_I18N_VERIFY_HEADER(lang=consts.LANG_RU):
        return LKmpCommon.L_I18N_TEXT('kmp_passcode_verify_title', lang=lang)

    @staticmethod
    def L_I18N_VERIFY_DESCRIPTION(lang=consts.LANG_RU):
        return LKmpCommon.L_I18N_TEXT('kmp_passcode_verify_description', lang=lang)

    @staticmethod
    def L_BACK_BUTTON():
        return ('xpath', '//android.view.View[@clickable="true" and @bounds="[42,63][168,189]"]')

    @staticmethod
    def L_PIN_DIGIT(digit):
        return ('xpath', f'//android.view.View[@clickable="true" and .//android.widget.TextView[@text="{digit}"]]')

    @staticmethod
    def L_I18N_NEXT_BUTTON(lang=consts.LANG_RU):
        i18n_str = LKmpCommon.I18N('kmp_next_button', lang=lang)
        return ('xpath', f'//android.view.View[@clickable="true" and .//android.widget.TextView[@text="{i18n_str}"]]')

    @staticmethod
    def L_DELETE_DIGIT_BUTTON():
        return ('xpath', '//android.view.View[@clickable="true" and @bounds="[912,840][1059,987]"]')
