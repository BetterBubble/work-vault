import consts

from .common import LKmpCommon


class LKmpContacts(LKmpCommon):
    @staticmethod
    def L_I18N_HEADER(lang=consts.LANG_RU):
        return LKmpCommon.L_I18N_TEXT('kmp_contacts_title', lang=lang)

    @staticmethod
    def L_BACK_BUTTON():
        return ('xpath', '//android.widget.Button[@bounds="[37,90][163,216]"]')

    @staticmethod
    def L_ACTION_BUTTON():
        return ('xpath', '//android.widget.Button[@bounds="[917,90][1043,216]"]')

    @staticmethod
    def L_SEARCH_INPUT():
        return ('xpath', '//android.widget.EditText')

    @staticmethod
    def L_I18N_SEARCH_PLACEHOLDER(lang=consts.LANG_RU):
        return LKmpCommon.L_I18N_TEXT('kmp_search_placeholder', lang=lang)

    @staticmethod
    def L_CONTACT_SECTION(letter):
        return ('xpath', f'//android.widget.TextView[@text="{letter}"]')

    @staticmethod
    def L_CONTACT_ITEM_BY_NAME(name):
        return ('xpath', f'//android.widget.TextView[@text="{name}"]')

    @staticmethod
    def L_CONTACT_COMPANY(company='IVA Technologies'):
        return ('xpath', f'//android.widget.TextView[@text="{company}"]')
