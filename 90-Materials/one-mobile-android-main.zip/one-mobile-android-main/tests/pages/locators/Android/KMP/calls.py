import consts

from .common import LKmpCommon


class LKmpCalls(LKmpCommon):
    @staticmethod
    def L_I18N_HEADER(lang=consts.LANG_RU):
        return LKmpCommon.L_I18N_TEXT('kmp_calls_title', lang=lang)

    @staticmethod
    def L_PROFILE_AVATAR():
        return ('xpath', '//android.view.View[@clickable="true" and @bounds="[21,74][147,200]"]')

    @staticmethod
    def L_ACTION_BUTTON():
        return ('xpath', '//android.widget.Button[@bounds="[917,74][1043,200]"]')

    @staticmethod
    def L_DATE_GROUP(label):
        return ('xpath', f'//android.widget.TextView[@text="{label}"]')

    @staticmethod
    def L_I18N_TODAY_GROUP(lang=consts.LANG_RU):
        return LKmpCommon.L_I18N_TEXT('kmp_calls_today_group', lang=lang)

    @staticmethod
    def L_CALL_ITEM_BY_NAME(name):
        return ('xpath', f'//android.widget.TextView[@text="{name}"]')

    @staticmethod
    def L_I18N_MISSED_STATUS(lang=consts.LANG_RU):
        return LKmpCommon.L_I18N_TEXT('kmp_call_missed_status', lang=lang)

    @staticmethod
    def L_CALL_BACK_BUTTON_BY_ROW_TIME(time):
        return ('xpath', f'//android.widget.TextView[@text="{time}"]/following::android.view.View[@clickable="true"][1]')
