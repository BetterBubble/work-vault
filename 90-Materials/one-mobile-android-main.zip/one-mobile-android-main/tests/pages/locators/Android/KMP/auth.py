import consts

from .common import LKmpCommon


class LKmpAuth(LKmpCommon):
    @staticmethod
    def L_I18N_SERVER_HEADER(lang=consts.LANG_RU):
        return LKmpCommon.L_I18N_TEXT('kmp_sign_in_title', lang=lang)

    @staticmethod
    def L_I18N_SERVER_DESCRIPTION(lang=consts.LANG_RU):
        return LKmpCommon.L_I18N_TEXT('kmp_server_description', lang=lang)

    @staticmethod
    def L_SERVER_PROTOCOL_PREFIX():
        return ('xpath', '//android.widget.TextView[@text="https://"]')

    @staticmethod
    def L_SERVER_INPUT():
        return ('xpath', '//android.widget.EditText')

    @staticmethod
    def L_CLEAR_SERVER_BUTTON():
        return ('xpath', '//android.view.View[@clickable="true" and @bounds="[902,1317][1028,1443]"]')

    @staticmethod
    def L_I18N_SERVER_SIGN_IN_BUTTON(lang=consts.LANG_RU):
        i18n_str = LKmpCommon.I18N('kmp_sign_in_button', lang=lang)
        return ('xpath', f'//android.view.View[@clickable="true" and .//android.widget.TextView[@text="{i18n_str}"]]')

    @staticmethod
    def L_I18N_BUILD_LABEL(lang=consts.LANG_RU):
        i18n_str = LKmpCommon.I18N('kmp_build_label', lang=lang)
        return ('xpath', f'//android.widget.TextView[starts-with(@text, "{i18n_str}")]')

    @staticmethod
    def L_PRODUCT_LABEL():
        return ('xpath', '//android.widget.TextView[@text="IVA Mail "]')

    @staticmethod
    def L_LOGIN_WEBVIEW():
        return ('xpath', '//android.webkit.WebView')

    @staticmethod
    def L_I18N_LOGIN_BACK_BUTTON(lang=consts.LANG_RU):
        i18n_str = LKmpCommon.I18N('kmp_login_back_button', lang=lang)
        return ('xpath', f'//android.view.View[@clickable="true" and .//android.widget.TextView[@text="{i18n_str}"]]')

    @staticmethod
    def L_I18N_LOGIN_PAGE_TITLE(lang=consts.LANG_RU):
        i18n_str = LKmpCommon.I18N('kmp_login_page_title', lang=lang)
        return ('xpath', f'//android.widget.TextView[@resource-id="kc-page-title" and @text="{i18n_str}"]')

    @staticmethod
    def L_LOGIN_USERNAME_INPUT():
        return ('xpath', '//android.widget.EditText[@resource-id="username"]')

    @staticmethod
    def L_LOGIN_PASSWORD_INPUT():
        return ('xpath', '//android.widget.EditText[@resource-id="password"]')

    @staticmethod
    def L_I18N_LOGIN_SHOW_PASSWORD_BUTTON(lang=consts.LANG_RU):
        i18n_str = LKmpCommon.I18N('kmp_login_show_password_button', lang=lang)
        return ('xpath', f'//android.widget.Button[@text="{i18n_str}"]')

    @staticmethod
    def L_I18N_LOGIN_SUBMIT_BUTTON(lang=consts.LANG_RU):
        i18n_str = LKmpCommon.I18N('kmp_login_submit_button', lang=lang)
        return ('xpath', f'//android.widget.Button[@resource-id="kc-login" and @text="{i18n_str}"]')
