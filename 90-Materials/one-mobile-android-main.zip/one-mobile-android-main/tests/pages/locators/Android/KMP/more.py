import consts

from .common import LKmpCommon


class LKmpMore(LKmpCommon):
    @staticmethod
    def L_MENU_ROOT():
        return ('xpath', '//android.view.ViewGroup[@resource-id="android:id/content"]')

    @staticmethod
    def L_I18N_TASKS_BUTTON(lang=consts.LANG_RU):
        return LKmpCommon.L_I18N_TEXT('kmp_more_tasks_button', lang=lang)

    @staticmethod
    def L_I18N_ROOMS_BUTTON(lang=consts.LANG_RU):
        return LKmpCommon.L_I18N_TEXT('kmp_more_rooms_button', lang=lang)

    @staticmethod
    def L_I18N_CONFERENCES_BUTTON(lang=consts.LANG_RU):
        return LKmpCommon.L_I18N_TEXT('kmp_more_conferences_button', lang=lang)

    @staticmethod
    def L_I18N_SERVICES_BUTTON(lang=consts.LANG_RU):
        return LKmpCommon.L_I18N_TEXT('kmp_more_services_button', lang=lang)

    @staticmethod
    def L_I18N_MCU_CHATS_BUTTON(lang=consts.LANG_RU):
        return LKmpCommon.L_I18N_TEXT('kmp_more_mcu_chats_button', lang=lang)

    @staticmethod
    def L_I18N_DISK_BUTTON(lang=consts.LANG_RU):
        return LKmpCommon.L_I18N_TEXT('kmp_more_disk_button', lang=lang)
