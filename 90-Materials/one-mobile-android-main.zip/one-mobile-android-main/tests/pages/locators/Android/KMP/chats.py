import consts

from .common import LKmpCommon


class LKmpChats(LKmpCommon):
    @staticmethod
    def L_I18N_HEADER(lang=consts.LANG_RU):
        return LKmpCommon.L_I18N_TEXT('chats_window_title', lang=lang)

    @staticmethod
    def L_PROFILE_AVATAR():
        return ('xpath', '//android.view.View[@clickable="true" and @bounds="[22,84][148,210]"]')

    @staticmethod
    def L_CREATE_CHAT_BUTTON():
        return ('xpath', '//android.widget.Button[@bounds="[940,84][1066,210]"]')

    @staticmethod
    def L_I18N_SEARCH_FIELD(lang=consts.LANG_RU):
        i18n_str = LKmpCommon.I18N('kmp_search_placeholder', lang=lang)
        return ('xpath', f'//android.view.View[@clickable="true" and .//android.widget.TextView[@text="{i18n_str}"]]')

    @staticmethod
    def L_I18N_FILTER_ALL(lang=consts.LANG_RU):
        return LKmpCommon.L_I18N_TEXT('kmp_chat_filter_all', lang=lang)

    @staticmethod
    def L_I18N_FILTER_DIRECT(lang=consts.LANG_RU):
        return LKmpCommon.L_I18N_TEXT('kmp_chat_filter_direct', lang=lang)

    @staticmethod
    def L_I18N_FILTER_GROUPS(lang=consts.LANG_RU):
        return LKmpCommon.L_I18N_TEXT('kmp_chat_filter_groups', lang=lang)

    @staticmethod
    def L_I18N_FILTER_THREADS(lang=consts.LANG_RU):
        return LKmpCommon.L_I18N_TEXT('kmp_chat_filter_threads', lang=lang)

    @staticmethod
    def L_I18N_CREATE_FOLDER_BUTTON(lang=consts.LANG_RU):
        i18n_str = LKmpCommon.I18N('kmp_create_folder_button', lang=lang)
        return ('xpath', f'//android.view.View[@content-desc="{i18n_str}"]')

    @staticmethod
    def L_I18N_IMPORT_FOLDER_BUTTON(lang=consts.LANG_RU):
        i18n_str = LKmpCommon.I18N('kmp_import_folder_button', lang=lang)
        return ('xpath', f'//android.view.View[@content-desc="{i18n_str}"]')

    @staticmethod
    def L_CHAT_ITEM_BY_TITLE(title):
        return ('xpath', f'//android.widget.TextView[@text="{title}"]')

    @staticmethod
    def L_CHAT_ITEM_BY_PREVIEW(preview):
        return ('xpath', f'//android.widget.TextView[contains(@text, "{preview}")]')

    @staticmethod
    def L_CHAT_UNREAD_BADGE(count):
        return ('xpath', f'//android.widget.TextView[@text="{count}"]')

    @staticmethod
    def L_I18N_NO_MESSAGES(lang=consts.LANG_RU):
        return LKmpCommon.L_I18N_TEXT('kmp_no_messages', lang=lang)

    @staticmethod
    def L_I18N_PHOTO_PREVIEW(lang=consts.LANG_RU):
        return LKmpCommon.L_I18N_TEXT('kmp_photo_preview', lang=lang)
