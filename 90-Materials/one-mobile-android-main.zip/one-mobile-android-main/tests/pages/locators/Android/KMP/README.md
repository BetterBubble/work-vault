# Android KMP locator research

APK: `one.apk`
Application id: `su.ivcs.kmp`
Launch activity: `su.ivcs.messenger.MainActivity`
Observed build: `1.2.10`
Observed language: `ru`
Server used for research: `https://gamma-one.ivcs.su/`

The app is rendered mostly through Compose/KMP. Most controls expose only
`android.widget.TextView`, `android.view.View`, or `android.widget.Button`
without stable resource ids. Because of that, locators in this package prefer:

1. `id` when a stable Android id exists.
2. `content-desc` when exposed by the app.
3. exact visible text through `tools.i18n` with `consts.LANG_RU` defaults.
4. `bounds` only for controls that do not expose a better attribute.

Known research limits:

- The login form is inside `android.webkit.WebView`. On the Russian UI,
  UIAutomator exposes useful native WebView nodes such as `username`,
  `password`, `kc-login`, and `kc-page-title`; these are used where available.
- The Mail and Calendar tabs crashed the researched build on
  `emulator-5554`, so screen-level locators for those tabs are intentionally
  not added yet.
- Coordinate/bounds locators are resolution-sensitive and should be replaced
  with accessibility ids or test tags when the KMP app exposes them.
