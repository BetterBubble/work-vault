import consts

from .common import LKmpCommon


class LKmpBottomMenu(LKmpCommon):
    @staticmethod
    def L_ROOT():
        return ('xpath', '//android.view.View[@clickable="true" and @bounds="[0,2200][1080,2400]"]')

    @staticmethod
    def L_I18N_MAIL_BUTTON(lang=consts.LANG_RU):
        return LKmpCommon.L_I18N_TEXT('kmp_bottom_menu_mail_button', lang=lang)

    @staticmethod
    def L_I18N_CALLS_BUTTON(lang=consts.LANG_RU):
        return LKmpCommon.L_I18N_TEXT('kmp_bottom_menu_calls_button', lang=lang)

    @staticmethod
    def L_I18N_CHATS_BUTTON(lang=consts.LANG_RU):
        return LKmpCommon.L_I18N_TEXT('bottom_menu_chats_button', lang=lang)

    @staticmethod
    def L_I18N_CALENDAR_BUTTON(lang=consts.LANG_RU):
        return LKmpCommon.L_I18N_TEXT('kmp_bottom_menu_calendar_button', lang=lang)

    @staticmethod
    def L_I18N_CONTACTS_BUTTON(lang=consts.LANG_RU):
        return LKmpCommon.L_I18N_TEXT('bottom_menu_contacts_button', lang=lang)

    @staticmethod
    def L_I18N_MORE_BUTTON(lang=consts.LANG_RU):
        return LKmpCommon.L_I18N_TEXT('kmp_bottom_menu_more_button', lang=lang)

    @staticmethod
    def L_CALLS_UNREAD_BADGE():
        calls = LKmpCommon.I18N('kmp_bottom_menu_calls_button', lang=consts.LANG_RU)
        return ('xpath', f'//android.widget.TextView[@text="{calls}"]/preceding::android.widget.TextView[@text="1"][1]')
