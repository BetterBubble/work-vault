import consts
from tools import i18n


class LKmpCommon:
    @staticmethod
    def I18N(str_key, lang=consts.LANG_RU):
        return i18n.get_str(str_key, lang=lang)

    @staticmethod
    def L_APP_ROOT():
        return ('id', 'su.ivcs.kmp:id/action_bar_root')

    @staticmethod
    def L_CONTENT_ROOT():
        return ('id', 'android:id/content')

    @staticmethod
    def L_TEXT(text):
        return ('xpath', f'//android.widget.TextView[@text="{text}"]')

    @staticmethod
    def L_TEXT_CONTAINS(text):
        return ('xpath', f'//android.widget.TextView[contains(@text, "{text}")]')

    @staticmethod
    def L_I18N_TEXT(str_key, lang=consts.LANG_RU):
        i18n_str = LKmpCommon.I18N(str_key, lang=lang)
        return LKmpCommon.L_TEXT(i18n_str)

    @staticmethod
    def L_I18N_TEXT_CONTAINS(str_key, lang=consts.LANG_RU):
        i18n_str = LKmpCommon.I18N(str_key, lang=lang)
        return LKmpCommon.L_TEXT_CONTAINS(i18n_str)

    @staticmethod
    def L_CLICKABLE_VIEW_BY_BOUNDS(bounds):
        return ('xpath', f'//android.view.View[@clickable="true" and @bounds="{bounds}"]')
