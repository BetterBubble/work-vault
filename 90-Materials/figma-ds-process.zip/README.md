# Figma ↔ код: процесс работы с дизайн-системой (комплект ТЗ)

Пакет документов для разработчика, который подхватывает работу над связкой
«дизайн-система Figma → компоненты в коде» для агентов Tacticum. Всё, что нужно,
собрано здесь; порядок чтения — ниже.

## С чего начать

1. **[figma-ds-process-tz.md](figma-ds-process-tz.md)** — сводное ТЗ. Точка входа:
   участники, общие правила, все 4 сценария кратко, таблица статусов «что уже
   готово / что построить». Прочитать первым.
2. **[figma-ds-multirepo-and-selection.md](figma-ds-multirepo-and-selection.md)** —
   кросс-сквозная инфраструктура: какой репозиторий/поверхность использует какую
   ДС (iva-one → `@iva/design-system`, конференция/iva-connect → `iva-core`), и как
   задача работает с двумя репозиториями (исходный + целевой). От этого зависят
   все сценарии.

## Сценарии (детальные ТЗ)

Единая структура каждого: когда → кто что делает → пошагово → что читает агент →
гардрейлы → критерий приёмки → зависимости.

- **[figma-ds-scenario-1-library.md](figma-ds-scenario-1-library.md)** — наполнение
  библиотеки UI-компонентов (в Figma есть компонент, в коде нет → реализовать).
- **[figma-ds-scenario-2-new-screen.md](figma-ds-scenario-2-new-screen.md)** — новый
  экран по макету Figma (собрать из готовых компонентов, а не самоделки).
- **[figma-ds-scenario-3-migration.md](figma-ds-scenario-3-migration.md)** — перевод
  репозитория на новую дизайн-систему (живой пример — `ui-kit`→новая ДС в iva-one).
- **[figma-ds-scenario-4-kmp-port.md](figma-ds-scenario-4-kmp-port.md)** — перенос
  экрана iva-one (Angular) → KMP (Compose) по образцу + Figma.

## Обоснование и аналитика (почему так)

- **[figma-ds-best-practices-research.md](figma-ds-best-practices-research.md)** —
  research лучших практик (токен-пайплайны, Code Connect, AI-воркфлоу,
  безопасность); что перенять / что у нас уже так / чего не делать.
- **[figma-mapping-multirepo-research.md](figma-mapping-multirepo-research.md)** —
  анализ UI-репозиториев IVA (web/iOS/KMP/Qt): применим ли подход, порядок захода.
- **[figma-ds-review-report.md](figma-ds-review-report.md)** — ревью реальной ДС IVA
  в Figma против критериев ТЗ (что готово, что дефицитно).
- **[figma-web-profile-enrichment-plan.md](figma-web-profile-enrichment-plan.md)** —
  план обогащения web-профиля агента (правила использования компонентов, `.mdx`).
- **[figma-component-mapping-pilot.md](figma-component-mapping-pilot.md)** — как
  устроен пилот словаря code-bindings (уже задеплоен для iva-web).

## Организационное (для встреч и согласований)

- **[designers-meeting-asks.md](designers-meeting-asks.md)** — что нужно от
  дизайнеров (просьбы, чек-лист дизайнера, git-sync токенов, вопросы).
- **[letter-to-iva-one-dev.md](letter-to-iva-one-dev.md)** — письмо разработчику
  iva-one с согласованием подхода (образец коммуникации).

## Внешние артефакты (в этом же репозитории, вне папки)

- Инструмент ревью ДС: `../scripts/figma_ds_review.py` (read-only, по токену Figma).
- Quickstart для разработчика iva-one:
  `../docs/user_manuals/iva-web-figma-mapping-quickstart.md`.
- Живой словарь: `../design-systems/iva-web/tokens.json` →
  `$extensions."dev.tacticum.code-bindings"` (прод-версия ДС 0.3.0).

## Статус на 2026-07-24 (коротко)

Пилот словаря для iva-web **задеплоен на прод** (49 компонентов, 32 со стабильными
Figma-ключами), quickstart готов. Дальше по плану: словарь v1 (типизация пропсов,
mdx-ссылки) → заход на KMP → выбор ДС по репо/поверхности → отдельная ДС `iva-core`
→ мульти-репо в workflow. Детали и приоритеты — в таблице статусов сводного ТЗ.
