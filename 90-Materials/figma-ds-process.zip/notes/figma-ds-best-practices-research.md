# Лучшие практики интеграции Figma DS в код — сводка исследования (2026-07-23)

Четыре параллельных веб-исследования (токен-пайплайны; компонентный маппинг;
AI design-to-code воркфлоу; пер-стек специфика + безопасность). Полные отчёты с
источниками — в транскриптах сессии; здесь выжимка, отсортированная на
«подтверждает наш подход» / «улучшения» / «не делать». Контекст: пилот
code-bindings для iva-web задеплоен; на очереди kmp → jump → mcuplugins → iOS
(figma-mapping-multirepo-research.md).

## 1. Что подтвердилось (менять не нужно)

- **Серверный словарь через MCP — правильная архитектура, с эмпирикой.**
  Atlassian померила три способа отдать DS агентам: MCP on-demand vs жирный
  DESIGN.md vs «агент сам сканирует код». MCP выиграл по всем метрикам
  (−34% времени, −16% токенов, +4.9% точности); DESIGN.md — на 92% дороже по
  токенам и в 2.7 раза нестабильнее. Наш `design_get_tokens` + bindings = их
  выигравшая схема.
- **Ниша реально пуста.** Ровно нашего продукта (мульти-стек курируемый реестр
  Figma→код через MCP, включая QML) в open source нет. Ближайшее — Storybook
  Component Manifests + Storybook MCP (React-only, preview) и Code Connect
  (закрыт планами Figma, не покрывает Qt/KMP).
- **DTCG-хранилище токенов** = теперь хранение *стабильного* стандарта
  (первая стабильная спека 2025.10, октябрь 2025; 84% команд используют токены).
  Двухуровневая архитектура primitive→semantic + light/dark как modes — канон
  (Nathan Curtis / Figma Variables model).
- **Наш флоу чтения макета** (get_metadata → точечные вызовы → get_code_connect_map
  оппортунистически) совпадает с официальными рекомендациями Figma по квоте.
- **Отказ от ставки на Code Connect для Compose Multiplatform** подтверждён:
  их Compose-парсер заточен под Android-Gradle-модули, KMP `commonMain` не
  поддержан (issues #282, #211); Google Relay закрыт в апреле 2025.

## 2. Улучшения — рекомендую принять

### 2.1 Схема словаря (bindings v0 → v1)

1. **Ключ = стабильный `component key` Figma, имя — только для отображения**
   (имена переименовываются; уже в плане — подтверждено как критичное).
2. **Типизированный маппинг пропсов** вместо плоского списка: enum-map /
   bool-map / instance-slot / nested-prop — словарь Code Connect, который
   агенты уже «знают».
3. **Variant-predicate**: один Figma component set → несколько биндингов по
   значениям вариантов (Button set → PrimaryButton/GhostButton), опциональный
   фильтр `variant: {Type: "Primary"}` на записи.
4. **`stack`-метка как first-class ключ** (angular / compose-mp / swiftui / qml /
   qt-widgets) — аналог `--label` в Code Connect; один Figma-компонент → N
   стеков.
5. **`example` — канонический сниппет использования** на компонент (паттерн IBM
   Carbon MCP: примеры якорят выбор пропсов лучше, чем список пропсов).
6. **`agent_instructions` — свободный текст на запись** («не сочетать X и Y»,
   a11y-нюансы) — аналог custom instructions в Code Connect.
7. **Shape-совместимость** со схемами Code Connect parse-response и Storybook
   manifest — дешёвый будущий экспорт в оба формата, к которым стандартизируется
   агентский тулинг.

### 2.2 Процесс

8. **Словарь генерируется, а не ведётся руками** (урок Atlassian: «доки,
   отстающие от кода, хуже их отсутствия»). Автогенерация extraction в RE-репо —
   уже наш план; добавить: CI-проверку что селектор/класс/путь из биндинга
   существует в коде (аналог `figma connect publish --dry-run` на PR).
9. **Drift-detection для токенов**: хранить hash+timestamp импорта (уже есть в
   DesignSystemImport), добавить staleness-флаг в админке + договориться о
   git-sync из Tokens Studio плагина вместо ручного экспорта.
10. **Конформанс-проверка импортёра на DTCG 2025.10** (object-valued dimension,
    структурный color) — мы сейчас потребляем диалект Tokens Studio, не строгий
    стандарт.
11. **Preflight-гейт макета перед кодогенерацией**: проверить что фрейм на
    auto layout и инстансы резолвятся — дешёвейшая защита от худшего класса
    ошибок (свалка абсолютно позиционированных div). Добавить в skill.
12. **Правила формулировать конкретно**: «цвета — из tokens, файл X, импорт Y»
    + префикс «IMPORTANT:» для жёстких запретов; негативное правило («не
    выдумывай компоненты») — само по себе load-bearing. Прогонять официальный
    скилл Figma `create-design-system-rules` для бутстрапа репо-правил.

### 2.3 Верификация результата (усиление ui-mockup-match)

13. **Числовые дельты вместо «на глаз»**: Playwright читает
    getComputedStyle/getBoundingClientRect и отдаёт агенту конкретику
    («gap 4px, надо 8px») — самый высокосигнальный опубликованный приём.
    Наш ui-mockup-match уже этой формы — усилить численными дельтами.
14. **Метрики из uiMatch** (open source): pixel ratio + ΔE2000 цветовой дифф +
    style diffs + композитный Design Fidelity Score 0-100, exit-code как
    CI-гейт. Минимум — украсть набор метрик.
15. **Допуски обязательны**: 0% pixel diff недостижим (антиалиасинг);
    фиксировать viewport, ждать шрифты. VLM-судья — только как tie-breaker
    поверх числовых диффов.

### 2.4 Безопасность (jump, mcuplugins — срочно)

16. **Ревокнуть** захардкоженные Figma-токены (ротации мало — они в git-истории),
    перевыпустить со scope только `file_content:read` (старый полный `files:read`
    deprecated), инжектить из CI-секретов, без дефолтного значения в скрипте.
17. Рассмотреть **plan access tokens** (org-level, до 1 года, allowlist ресурсов) —
    Figma сама рекомендует их для CI вместо личных.
18. Альтернатива для иконок — **push-модель** (паттерн icona): плагин Figma сам
    открывает PR с SVG → токен Figma вообще исчезает из CI. Стеко-нейтрально.

### 2.5 Пер-стек заметки для следующих заходов

- **Qt (jump/mcuplugins):** у Qt вышли официальные **агентские скиллы «Figma
  Design System Extraction»** (июнь 2026): Figma Variables → QML pragma-синглтоны
  (Colors/Typography/Spacing/Radii/Shadows/Motion) + `design-tokens.json` +
  DS*-компоненты, доставка через MCP. Взять их выходной контракт как целевую
  структуру для jump/mcuplugins (даже без их агентской части). DTCG→C++ для
  Qt Widgets — DIY (маленький собственный эмиттер из нашего DTCG).
- **iOS:** figma-export (RedMadRobot) закрывает цвета+иконки+типографику одним
  инструментом (asset catalogs для цветов, generated Swift для остального);
  SwiftGen в 2026 не добавлять (Xcode 15+ генерит символы сам). Галерея —
  обычный preview-target.
- **Compose MP:** Showkase не поддерживает CMP (открытый #364) — галерея руками
  в commonMain; DTCG→Compose — Style Dictionary v5 (DTCG-native) с
  compose/object форматом.
- **Angular:** добавить @storybook/addon-designs (Storybook 9, embed v2) —
  тривиально линкует стори на Figma-фрейм.
- **Style Dictionary v5** — дефолтный трансформер если начнём генерить пер-стек
  выходы из нашего DTCG-хранилища; Terrazzo — watch-item.

## 3. Не делать

- **Qt Bridge for Figma / «Figma to Qt»** — генерация greenfield-QML экранов,
  не маппинг на существующий код; Bridge объявлен legacy (до 2030).
- **Google Relay** — закрыт 2025-04.
- **Figma Variables REST API как основа** — Enterprise-only, для нас закрыт
  (подтверждено ещё раз).
- **Жирный DESIGN.md вместо MCP** — эмпирически хуже (Atlassian).
- **Hosted token-SaaS зависимость** — Specify закрылся в 2024; своё хранилище
  правильнее (у нас уже так).
- **Blanket component-токены** (третий уровень на всё) — взрыв имён; добавлять
  точечно, где агенту реально нужно.

## 4. Что вносим в план заходов (дельта к multirepo-research)

| Улучшение | Когда |
|---|---|
| bindings v1 (key, typed props, variant, stack, example, instructions) | до захода на kmp — чтобы новые словари сразу в v1 |
| CI-проверка биндингов (identifier существует) | вместе с автогенерацией в RE |
| Preflight-гейт макета + «IMPORTANT:»-формулировки | в quickstart/skill сейчас (правка текста) |
| Числовые дельты + метрики uiMatch в ui-mockup-match | отдельная задача, после kmp |
| Security-фикс Figma-токенов | передать командам jump/mcuplugins немедленно |
| Qt tokens-контракт (по образцу Qt-скиллов) | при заходе на jump |
| DTCG 2025.10 конформанс + staleness токенов | бэклог design-контекста (E27) |
