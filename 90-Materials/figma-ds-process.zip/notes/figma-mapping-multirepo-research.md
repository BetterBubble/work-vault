# Figma ↔ код: исследование UI-репозиториев IVA (2026-07-23)

Контекст: пилот «словарь Figma-компонент → код-компонент» запущен для веба
(iva-one, DS `iva-web` 0.2.0, см. figma-component-mapping-pilot.md). Вопрос:
переносится ли подход на остальные UI-стеки. Исследованы локальные клоны:
`D:\iva\messenger` (iOS/Swift), `D:\iva\kmp` (Compose Multiplatform),
`D:\iva\jump` (C++/Qt desktop), `D:\iva\mcuplugins` (Qt Quick плагины).

## Главный вывод

Подход переносится на **все четыре** репозитория — нигде UI не «ад-хок», везде
есть слой переиспользуемых компонентов, на который ложится словарь. Различается
только зрелость и объём подготовки. Два repo (jump, mcuplugins) уже сами
используют Figma как источник правды для токенов/иконок через самописные скрипты —
там компонентный словарь просто «следующий этаж» существующего конвейера.

## Сводная таблица

| | iva-one (web, база) | kmp | jump (desktop) | mcuplugins | messenger (iOS) |
|---|---|---|---|---|---|
| Стек | Angular | Compose MP (android/ios/desktop/web) | C++/Qt Widgets (+QML legacy) | Qt Quick/QML | SwiftUI |
| Выделенный DS-модуль | ✅ libs/design-system | ✅ :core:design-system | ✅ LibUi | ✅ UiToolKit (+legacy Controls) | ⚠️ размазан (CommonViews/Design/Core) |
| Компоненты для маппинга | 49 (в bindings) | 123 `Iva*` composables | ~40 классов LibUi | ~136 QML (Core+Extra) | ~20-30 кураторских из ~267 view |
| Токены | ✅ DTCG в Tacticum | ✅ двухуровневые в коде | ✅ **Figma-generated** (color-tokens.json + codegen C++) | ✅ Figma-аннотированные QML-синглтоны | ⚠️ только цвета; шрифты/отступы не токенизированы |
| Витрина компонентов | Storybook (iva-ui.ivcs.su) | @Preview (35 файлов), без каталога | ✅ **свой Storybook.exe** | нет | нет (3 preview) |
| Figma-интеграция сегодня | пилот bindings | комменты-ссылки | ✅ **codegen из Figma API** (палитра, типографика, иконки) | ✅ скрипт выгрузки иконок из Figma API | нет |
| Tacticum-профиль/скиллы | ✅ iva-web-brownfield | ✅ iva-kmp-brownfield | ✅ CLAUDE.md + design-скиллы | ❌ **нет вообще** (нет даже AGENTS.md) | ✅ iva-ios-brownfield |
| Готовность к bindings | **сделано** | **высокая** | **высокая** | средняя | ниже средней |

## По репозиториям — что обнаружено и что делать

### 1. kmp — рекомендуемый следующий (готовность высокая)

- HEAD 2026-07-20, активная разработка. Единый модуль `:core:design-system`
  (`su.ivcs.messenger.designsystem`): **123 композабла `Iva*`** в ~45 семействах
  (IvaAvatar, IvaBadge, IvaBottomSheet, IvaSearchBar, IvaIconButton…), двухуровневые
  токены (примитивы `IvaMessengerColors` → семантика `AppColors`/`AppTypography`/`AppDimensions`),
  тема `IvaMessengerTheme`.
- В AGENTS.md уже жёсткое правило «no raw hex — только токены через tacticum-mcp»,
  скиллы design-system-discovery / design-token-usage стоят.
- **Что делать:** повторить пилот 1-в-1 — bindings в `$extensions` DS (вопрос: в
  `iva-mobile` DS или отдельная `iva-kmp` — решить при заходе; identifiers =
  имена композаблов + module path). Извлечение почти автоматом (`grep "fun Iva"`).
- Трение: имена отступов идиосинкразные (`paddingSuperMediumLittle`) — на авто-матч
  с Figma-spacing не рассчитывать; legacy `feature/ucim` вне `Iva*`-слоя.

### 2. jump — самый «профигмленный» repo (готовность высокая)

- Двойной UI: новый **LibUi (C++ Widgets)** и legacy QML (Controls/UiToolKit).
  Маппить надо LibUi: ~40 компонентов (Button, Chip, Badge, Avatar, Toggle, Tabs,
  Toast, Calendar…) c **собственным Storybook.exe** — по странице на компонент,
  готовый каталог вариантов.
- **Figma уже source of truth:** `color-tokens.json` (1514 строк, семантические
  пути `bg/accent-primary`, light+dark) → codegen-скрипты (`Tools/CodeGen/`)
  генерируют C++ `PaletteV2`/`TypographyV2` и иконки **напрямую из Figma REST API**
  (FILE_ID запинен в скриптах).
- **Что делать:** (а) импортировать их `color-tokens.json` как новую DS в Tacticum
  (конверсия в DTCG тривиальна — формат уже плоский семантический с двумя темами);
  (б) bindings: класс LibUi + Storybook-страница как reference. Их Figma-file-id
  уже известен из скриптов.
- Трение: QML-слой в процессе миграции (hex захардкожен, ThemeManager закомментирован) —
  в словарь не брать, пометить legacy.

### 3. mcuplugins — применимо, но сначала базовая гигиена

- Вопреки названию — **полноценный Qt Quick UI** (295 QML): плагины чат/контакты/
  встречи/комнаты для десктоп-клиента. UI-кит `UiToolKit` (общий с jump через
  commonlibs!): ~136 компонентов (AppButton, ChipUser, Avatar, BadgeStatus…),
  цвета-синглтоны **с путями Figma-токенов в комментариях**, скрипт выгрузки иконок
  из Figma API.
- **Что делать:** словарь для UiToolKit один на оба repo (jump QML + mcuplugins) —
  сначала синхронизировать судьбу UiToolKit vs LibUi с командой. Но прежде здесь
  нужен базовый агентский каркас: **нет ни AGENTS.md, ни профиля Tacticum** —
  без этого словарь некому потреблять.
- Трение: двойная система (UiToolKit новый / Controls+ThemeManager legacy),
  миграция не завершена.

### 4. messenger (iOS) — применимо частично, нужна подготовка

- SwiftUI, цветовые токены есть и семантичны (`IVAColor.Background.mPrimary`,
  asset catalog light/dark), НО: типографика и отступы не токенизированы (сырые
  размеры), компонентный слой не оформлен в модуль — ~267 view, из них реальных
  переиспользуемых атомов ~20-30 (AvatarView, ChipView, ActionButton, FormCell,
  CounterBadge…) в `CommonViews`/`Design`/`Core/Views`.
- Figma-интеграции ноль; дизайн-контекст уже идёт через Tacticum
  (профиль iva-ios-brownfield, скиллы стоят). Нюанс имён: Figma/Tacticum-токены
  с `+`-префиксом (`bg.+primary`) vs код `m`-префикс (`mPrimary`) — словарю нужна
  переводная таблица и для токенов.
- **Что делать:** маппить кураторское подмножество (~20-30 view) + токен-алиасы
  `bg.+primary ↔ IVAColor.Background.mPrimary`. Полную отдачу даст только после
  токенизации шрифтов/отступов — это уже задача команде iOS, не Tacticum.

## Сквозные находки

1. **Паттерн словаря универсален.** Формат bindings из пилота стеко-независим —
   меняется только тип идентификатора: Angular-селектор / имя композабла /
   C++-класс / QML-тип / SwiftUI-struct. Схему `tacticum-code-bindings/v0`
   менять не нужно, достаточно поля `kind`.
2. **⚠️ Security: захардкоженные Figma-токены доступа в git.** В обоих
   Qt-репозиториях личные `X-Figma-Token` лежат прямо в исходниках скриптов
   (`jump/Tools/CodeGen/generate-typography-v2.py`,
   `mcuplugins/.../fetch-svg-icons-from-figma-v3.py` и др.). Чем грозит: любой
   с доступом к repo (и вся git-история) получает доступ к Figma-файлам от имени
   владельца токена. Что делать: сообщить командам — ревокнуть токены, перевести
   скрипты на env-переменную.
3. **Tacticum уже канал доставки дизайн-контекста в 3 из 4 репо** (messenger, kmp,
   jump имеют профили/скиллы design_*). mcuplugins — белое пятно: нет даже AGENTS.md.
4. **UiToolKit общий для jump и mcuplugins** (commonlibs) — один словарь может
   обслужить оба, но нужно решение команды о судьбе UiToolKit vs LibUi.
5. **Тела словарей сильно готовы к автогенерации** — во всех репо компоненты
   извлекаются grep-ом по стабильному префиксу/каталогу (как в пилоте для веба).
   Подтверждает план: автоматизация extraction в репозитории RE.

## Рекомендуемый порядок захода

1. **kmp** — копия веб-пилота, минимальная подготовка, профиль уже стоит.
2. **jump** — импорт их готовых Figma-токенов как DS + bindings на LibUi
   (+ отдать команде security-фикс токенов).
3. **mcuplugins** — сначала AGENTS.md + профиль Tacticum, затем общий с jump
   словарь UiToolKit.
4. **messenger (iOS)** — кураторское подмножество сейчас, полноценно — после
   токенизации типографики/отступов командой iOS.

Все четыре — тем же серверным механизмом `$extensions` без правок бэкенда;
выделенный `design_get_code_binding` и автогенерация в RE остаются общим
следующим шагом (как и для веба).
