# Пилот: связь Figma DS ↔ компоненты iva-one (2026-07-22)

Статус: **словарь реализован server-side** — по решению owner'а пилот идёт сразу на
сервере, минуя файловый этап. После валидации пилота extraction автоматизируется
в репозитории RE, а словарь получает выделенный MCP-тул (`design_get_code_binding`,
слот запланирован в ADR-0027/0028).

## Как реализовано

Словарь = блок `$extensions."dev.tacticum.code-bindings"` в корне токен-дерева
`design-systems/iva-web/tokens.json`, версия DS **0.2.0** (bump 0.1.0 → 0.2.0,
версии иммутабельны). 49 компонентов, собраны руками из свежего iva-one
(`daf1424ad`, 2026-07-20): селекторы, пути к исходникам, storybook-ids, ключевые
inputs (чипсы — детально). DTCG-валидация `$`-ключи игнорирует, `design_get_tokens`
отдаёт блок агентам как есть — **ноль правок бэкенда**.

- PR: https://github.com/TacticumApps/dev/pull/122 — **смержен, задеплоен 2026-07-22**:
  VPS pull → `seed_runner` (one-off контейнер, status `created`) → пин workspace
  `base` (`c9f28fcf…`) переведён на 0.2.0 (+ запись в admin_audit). E2E проверено
  через боевой MCP: `design_get_tokens("iva-web")` от installation `7c5854f6…`
  (iva-one) возвращает version 0.2.0 и 49 компонентов в bindings.

## Схема резолва (dual-mode, дешёвый план Figma по умолчанию)

1. Агент получает ссылку на макет (`fileKey` + `node-id`).
2. Через локальный Figma MCP (desktop, `127.0.0.1:3845/mcp`) пробует
   `get_code_connect_map` — если аккаунт внезапно Organization/Enterprise с Code
   Connect, использует готовые сниппеты. Ожидаемо пусто → шаг 3.
3. `get_metadata` — структура узла + имена инстансов мастер-компонентов.
4. `design_get_tokens(design_system_id="iva-web")` → в ответе
   `tokens.$extensions."dev.tacticum.code-bindings"` — резолв инстансов по `match`
   (нормализация: lowercase, без пробелов/дефисов).
5. `get_variable_defs` — только именованные токены DS, никаких хардкод-hex.
6. `get_design_context` — только layout-подсказки; это React+Tailwind
   промежуточка — переводить в Angular по словарю, разметку не копировать.
7. Не замаплено → стоп, доложить «компонент X не найден в bindings», не выдумывать.

Дисциплина квоты (общий Figma-аккаунт ~200 запросов/день): сначала `get_metadata`
на узел, потом точечные вызовы по под-узлам.

## Настройка у разработчика (один раз, ~10 минут)

> Оформлено как quickstart для конечного разработчика:
> [docs/user_manuals/iva-web-figma-mapping-quickstart.md](../../docs/user_manuals/iva-web-figma-mapping-quickstart.md)
> (Часть A — Codex, Часть B — Claude Code, sanity-чеки, troubleshooting).
> Ниже — краткая версия для контекста.

Предпосылки: установлен профиль `iva-web-brownfield` (tacticum-mcp уже настроен
через installation — `design_get_tokens` доступен), есть Figma desktop под общим
аккаунтом с Dev Mode.

1. **Figma desktop MCP.** В Figma desktop открыть Dev Mode → inspect-панель →
   секция «MCP» → Server status: **Enabled** (у команды уже включено). Сервер
   слушает `http://127.0.0.1:3845/mcp`. Приложение Figma должно быть запущено,
   пока работает агент.
2. **Подключить Figma MCP к агенту** (в репо iva-one):
   - Claude Code: `claude mcp add --transport http figma-desktop http://127.0.0.1:3845/mcp`
   - Codex CLI: в `~/.codex/config.toml`:
     `[mcp_servers.figma-desktop]` / `url = "http://127.0.0.1:3845/mcp"`
   Проверка: в новой сессии агента спросить «какие тулы у figma-desktop» — должны
   быть `get_metadata`, `get_design_context`, `get_variable_defs`, `get_code_connect_map`.
3. **Разовое правило в репо** — добавить в `AGENTS.md`/`CLAUDE.md` iva-one секцию
   (после этого в задачах достаточно ссылки на макет, никаких спец-промптов):

```markdown
## Макеты Figma → компоненты дизайн-системы

Если в задаче есть ссылка на макет Figma (figma.com/design/...):
1. Вызови design_get_tokens(design_system_id="iva-web") (tacticum-mcp) и возьми
   из ответа tokens["$extensions"]["dev.tacticum.code-bindings"] — словарь
   соответствия Figma-компонентов Angular-компонентам @iva/design-system.
   Следуй его полю usage.
2. Через figma-desktop MCP: сначала get_code_connect_map по узлу из ссылки
   (если непусто — используй его сниппеты как есть); иначе get_metadata →
   имена инстансов → резолв по словарю bindings.
3. Перед использованием компонента прочитай его source-файл из словаря
   (libs/design-system/src/lib/components/<source>) — точные inputs/outputs
   оттуда, не угадывай.
4. Цвета/типографика — только именованные токены DS (get_variable_defs +
   design_get_tokens), хардкод hex/px запрещён.
5. Квота Figma MCP общая (~200 запросов/день): один get_metadata на узел,
   затем точечные вызовы по под-узлам; не запрашивай целые страницы.
6. Инстанс не найден в словаре → остановись и сообщи «компонент X не замаплен
   в code-bindings», не верстай вручную.
```

## Как запускается сценарий

Никакого отдельного флоу: разработчик пишет обычное ТЗ и **просто указывает ссылку
на макет** (с `node-id` конкретного фрейма — в Figma: правый клик по фрейму →
Copy link to selection):

> Сделать список участников встречи в виде чипсов, макет:
> https://www.figma.com/design/AG11paSthGC7zSoovfjip0/...?node-id=123-456

Агент по репо-правилу сам: достаёт словарь с сервера Tacticum → читает макет через
Figma MCP → собирает вёрстку из готовых `<iva-*>`-компонентов.

Ожидаемый результат пилотного сценария: `@for`-цикл с `<iva-chip-user>`
(closable по макету), токены из DS, ноль самодельной разметки чипа. Критерий
провала: самодельные div'ы со скруглениями вместо `iva-chip-user` или hex-цвета.

## Дальше (после пилота)

1. REST-токен Figma от разработчика IVA → выгрузить стабильные `component key`
   (`GET /v1/files/:key/components`), заполнить `figma_key` в bindings → матчинг
   по ключу вместо имени (0.3.0).
2. Автоматизация extraction в репозитории RE (selector/inputs/storybook из кода —
   уже отработано grep-пайплайном в этой сессии).
3. Оформить резолв-инструкцию как skill в `templates/iva-web-brownfield/`
   (заменит разовое репо-правило из настройки выше) + US в Taiga на выделенный
   `design_get_code_binding` (design-контекст, эпик E27).
4. Заметка: `framework_hint` у iva-web DS = `react` (историческое, от пилота
   client-shell) — при следующем ре-сиде решить, не сменить ли на `angular`.
