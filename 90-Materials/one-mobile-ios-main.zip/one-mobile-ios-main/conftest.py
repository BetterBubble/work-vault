import re
import pytest
import traceback
import allure
from allure_commons.types import AttachmentType

import consts as MC
from autocore import consts as CC
from selenium.common.exceptions import InvalidSessionIdException
from autocore.test.config import get_config, get_mobile_env
from autocore.test.logger import get_log
from autocore.clients.rest import set_admin_lang_ru
from autocore import stands
from tools import aut
from tools import utils
from tools.utils import is_real_device
from autocore import driver_sessions
from itertools import islice


log = get_log()
m_env = get_mobile_env()
option = None

@pytest.fixture(autouse=True)
def run_around_tests(request):
    test_case = re.findall('Function (.*?)>', str(request.keywords))[0]
    log.step(f'~~~~~START {test_case}~~~~~')
    if not option.no_exim_reset:
        stands.reset_exim_queue()

    if CC.DB_RESTORE_MODE != CC.DB_RESTORE_NONE:
        if not option.no_db_restore:
            stands.restore_db_snapshot()
            if CC.DB_RESTORE_MODE == CC.DB_RESTORE_TRUNCATE:
                set_admin_lang_ru()

    yield
    log.step(f'~~~~~END {test_case}~~~~~')


@pytest.fixture(scope='session')
def version_reporter():
    # TODO: report version
    log.info('Calling "version_reporter" fixture')


@pytest.fixture(scope='session')
def setup(version_reporter):
    log.info('Calling "setup" fixture')
    log.info(f'Using "{option.env}" environment, language "{option.lang}", {option.version}')
    return {
        'config': get_config()[option.env],
        'cmd': {
            'ver': option.ver,
            'lang': option.lang,
            'device_host': option.device_host,
            'device_os': option.device_os,
            'device_name': option.device_name
        }
    }

def prepare_driver(setup, need_device_count=1, device=None):
    do = setup['cmd']['device_os']
    if need_device_count >=2:
        dn = device['device_name']
        dh = device['device_host']
        dp = device['device_port']
        sp = device['system_port']
    else:
        dn = setup['cmd']['device_name']
        dh = setup['cmd']['device_host']
        dp = '8100'
        sp = '8200'
    device_ip = dh.split(':')[0]
    is_pd = is_real_device(do, dn, device_ip, user=MC.CI_USER, password=MC.CI_PASSWORD)
    do == 'Android' and utils.restore_adb_uiautomator(device_ip, dn)
    aut.clear_data(do, dh, dn, is_pd)
    driver = aut.start(do, dh, dn, is_pd, dp, sp)
    driver.at_device_os = do
    driver.is_real_device = is_pd
    driver.unlock()
    return driver

@pytest.fixture
def setup_aut(setup):
    driver = prepare_driver(setup)
    return {'driver': driver, 'setup': setup}


@pytest.fixture
def setup_multiple_auts(request, setup):
    def inner(aut_to_start: int = 2, _request = request):
        drivers = []
        do = setup['cmd']['device_os']
        for i in range(aut_to_start):
            if i > 0:
                platform_devices = m_env[do]['devices']
                devices = dict(islice(platform_devices.items(), aut_to_start))
                driver = prepare_driver(setup, need_device_count=aut_to_start, device=devices.get(f'device_{i}'))
            else:
                driver = prepare_driver(setup)
            driver.number = i + 1
            driver.from_tc = _request.function.__name__
            drivers.append(driver)
        return {'driver': drivers, 'setup': setup}
    yield inner


@pytest.fixture
def teardown():
    methods = []
    yield methods

    for method in methods:
        try:  # все методы нужно выполнить несмотря на возможные ошибки
            method()
        except Exception as exc:
            log.warn(f'teardown method failed with exception: "{exc}"')
        finally:
            if driver_sessions.multiple:
                driver_sessions.active_driver.clear()
                driver_sessions.multiple = False


def pytest_runtest_makereport(item, call):
    # fill env info for allure report
    env_info = [
        f'stand={option.env}\n',
        f'os={option.device_os}\n',
        f'device={option.device_name}\n',
    ]

    try:
        with open(f'{option.allure_report_dir}/environment.properties', 'w') as prop_file:
            prop_file.writelines(env_info)
    except Exception as e:
        log.error(f'An error occurred while writing to the allure properties file {e}')

    # logging each traceback to respective testcase
    if call.excinfo:
        tb_obj = call.excinfo.tb
        stack_summary = traceback.extract_tb(tb_obj)
        tb_strings = stack_summary.format()
        tb_string = ''.join(tb_strings)
        tb_string = call.excinfo.exconly() + '\n' + tb_string

        stack_summary_locals = stack_summary.extract(traceback.walk_tb(tb_obj), capture_locals = True)
        tb_strings_locals = stack_summary_locals.format()
        tb_string_locals = ''.join(tb_strings_locals)
        tb_string_locals = call.excinfo.exconly() + '\n' + tb_string_locals

        log.info(tb_string)
        log.debug(tb_string_locals)

        if 'setup_aut' in item.funcargs:
            driver = item.funcargs['setup_aut']['driver']
            try:
                allure.attach(driver.get_screenshot_as_png(), name=item.name, attachment_type=AttachmentType.PNG)
            except:
                log.warning('Something went wrong with driver session during screenshot')

        elif 'setup_multiple_auts' in item.funcargs:
            drivers = driver_sessions.active_driver
            try:
                for driver in drivers:
                    allure.attach(driver.get_screenshot_as_png(), name=f"Device-{driver.session['udid']}-{item.name}",
                                  attachment_type=AttachmentType.PNG)
            except InvalidSessionIdException:
                log.warning('Something went wrong with driver session during screenshot')
                if isinstance(drivers, list):
                    for driver in drivers:
                        hasattr(driver, 'number') and log.warning(f'Driver number {driver.number}')
                        hasattr(driver, 'from_tc') and log.warning(f'Driver from testcase "{driver.from_tc}"')


def pytest_addoption(parser):
    parser.addoption('--env', action='store', help='Environment name')
    parser.addoption('--ver', action='store', help='Version', default='Version2')
    parser.addoption('--lang', action='store', help='AUT UI language', default=MC.LANG_RU)
    parser.addoption('--from-pipeline', action='store_true', default=False)
    parser.addoption('--local', action='store_true', default=False)
    parser.addoption('--device-host', action='store', help='Appium host+port where device is connected')
    parser.addoption('--device-os', action='store', help='OS of device connected to Appium host+port')
    parser.addoption('--device-name', action='store', help='Name of device connected to Appium host+port')
    parser.addoption('--no-exim-reset', action='store_true', default=False)
    parser.addoption('--no-db-restore', action='store_true', default=False)


def pytest_configure(config):
    global option
    option = config.option
