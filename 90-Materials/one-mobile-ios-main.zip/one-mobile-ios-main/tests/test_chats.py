import pytest

from autocore.test.logger import get_log
from autocore.test.config import get_config
from tests import pages
from tests.pages import chunks
from autocore import driver_sessions, ocr


log = get_log()
conf = get_config()

@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.android
@pytest.mark.ios
def test_chat_add_VCSMOB_T13(setup_aut, teardown):
    lang = setup_aut['setup']['cmd']['lang']
    device_os = setup_aut['setup']['cmd']['device_os']
    creds = setup_aut['setup']['config']['credentials']
    login_creds = creds['user1']
    contact_1 = creds['user4']
    contact_2 = creds['user3']
    server = setup_aut['setup']['config']['server']
    driver = setup_aut['driver']

    log.tc('T13')

    teardown.append(lambda: driver.quit())

    server_page = pages.get_page(device_os, 'pick_server')(driver, lang=lang)
    server_page.pick(server)

    login_page = pages.get_page(device_os, 'login')(driver, lang=lang)
    login_page.login(login_creds['username'], login_creds['password'])
    main_menu = chunks.get_chunk(device_os, 'bottom_menu')(driver, lang=lang)

    main_menu.open_chats()
    chats = pages.get_page(device_os, 'chats')(driver, lang=lang)

    log.info('Добавим чат с контактом А1')
    chats.add_new_chat(contact_1['username'])
    chats.assert_chat_opened(contact_1['username'])

    log.info('Добавим чат с контактом А2')
    chats.add_new_chat(contact_2['username'])
    chats.assert_chat_opened(contact_2['username'])


@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.android
@pytest.mark.ios
def test_group_chat_add_VCSMOB_T14(setup_aut, teardown):
    lang = setup_aut['setup']['cmd']['lang']
    device_os = setup_aut['setup']['cmd']['device_os']
    creds = setup_aut['setup']['config']['credentials']
    login_creds = creds['user1']
    chat_members = [creds['user4'], creds['user3']]
    server = setup_aut['setup']['config']['server']
    driver = setup_aut['driver']

    log.tc('T14')

    teardown.append(lambda: driver.quit())

    server_page = pages.get_page(device_os, 'pick_server')(driver, lang=lang)
    server_page.pick(server)

    login_page = pages.get_page(device_os, 'login')(driver, lang=lang)
    login_page.login(login_creds['username'], login_creds['password'])
    main_menu = chunks.get_chunk(device_os, 'bottom_menu')(driver, lang=lang)

    main_menu.open_chats()
    chats = pages.get_page(device_os, 'chats')(driver, lang=lang)

    log.info('Добавим чат с контактом А1')
    chats.add_to_group_chat(users=chat_members)
    chats.assert_group_chat_opened(len(chat_members) + 1) # Количество приглашенных + организатор чата


@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.android
@pytest.mark.ios
def test_p2p_chat_message_VCSMOB_T15(setup_multiple_auts, teardown):
    '''
    + MK1 авторизуется, добавляет чат с МК2
    + МК2 авторизуется, открывает чат с МК1
    + МК1 начинает писать сообщение
    + МК2 наблюдает в заголовке окна "печатает..." (ш.1)
    + MK1 отправил сообщение, МК2 его получил (ш.2)
    + МК1 отправил картинку, МК2 ее получил (ш.3)
    -/+ МК1 отправил видео, МК2 ее получил (ш.4)
    + МК1 отправил документ, МК2 его получил (ш.5)
    + МК1 отправил ссылку, МК2 ее получил (ш.6)
    '''
    auts = setup_multiple_auts(2)
    lang = auts['setup']['cmd']['lang']
    device_os = auts['setup']['cmd']['device_os']
    creds = auts['setup']['config']['credentials']
    login_creds = creds['user1']
    contact_1 = creds['user4']
    test_message = 'Test message'
    test_message_link = 'https://iva.ru'
    server = auts['setup']['config']['server']
    driver_1, driver_2 = auts['driver']

    log.tc('T15')

    teardown.append(lambda: driver_1.quit())
    teardown.append(lambda: driver_2.quit())

    log.info('MK1 авторизуется, добавляет чат с МК2')
    driver_sessions.set_active(driver_1)
    server_page1 = pages.get_page(device_os, 'pick_server')(driver_1, lang=lang)
    server_page1.pick(server)

    mk1_login_page = pages.get_page(device_os, 'login')(driver_1, lang=lang)
    mk1_login_page.login(login_creds['username'], login_creds['password'])
    mk1_main_menu = chunks.get_chunk(device_os, 'bottom_menu')(driver_1, lang=lang)
    mk1_main_menu.open_chats()

    log.info('Добавим чат с контактом MK2')
    mk1_chats = pages.get_page(device_os, 'chats')(driver_1, lang=lang)
    mk1_chats.add_new_chat(contact_1['username'])

    log.info('МК2 авторизуется, открывает чат с МК1')
    driver_sessions.set_active(driver_2)
    server_page2 = pages.get_page(device_os, 'pick_server')(driver_2, lang=lang)
    server_page2.pick(server)
    mk2_login_page = pages.get_page(device_os, 'login')(driver_2, lang=lang)
    mk2_login_page.login(contact_1['username'], contact_1['password'])
    mk2_main_menu = chunks.get_chunk(device_os, 'bottom_menu')(driver_2, lang=lang)
    mk2_main_menu.open_chats()

    mk2_chats = pages.get_page(device_os, 'chats')(driver_2, lang=lang)
    mk2_chats.open_existing_chat(login_creds['username'])

    driver_sessions.set_active(driver_1)
    log.info('МК1 начинает писать сообщение')
    if driver_1.at_device_os == 'iOS':
        mk1_chats.type_chat_message(test_message)
    else:
        mk1_chats.type_chat_message(test_message, type_entire_line=False)
    log.info("МК2 наблюдает в заголовке окна 'печатает…'")
    driver_sessions.set_active(driver_2)
    mk2_chats.assert_chat_status_is('печатает')

    log.info('MK1 отправил сообщение, МК2 его получил')
    driver_sessions.set_active(driver_1)
    if driver_1.at_device_os == 'iOS':
        mk1_chats.send_chat_message(test_message)
    else:
        driver_sessions.set_active(driver_1)
        mk1_chats.type_chat_message(test_message)
        mk1_chats.send_chat_message(test_message)
    driver_sessions.set_active(driver_2)
    mk2_chats.assert_message_received(test_message)

    log.info('MK1 отправил фото, МК2 его получил')
    driver_sessions.set_active(driver_1)
    mk1_chats.send_chat_last_photo()
    mk1_chats.assert_photo_sent()
    driver_sessions.set_active(driver_2)
    mk2_chats.assert_photo_received()

    log.info('MK1 отправил файл, МК2 его получил')
    driver_sessions.set_active(driver_1)
    mk1_chats.send_chat_document()
    driver_sessions.set_active(driver_2)
    mk2_chats.assert_file_received()
    mk2_chats.assert_file_opens()

    log.info('MK1 отправил видео, МК2 его получил')
    driver_sessions.set_active(driver_1)
    mk1_chats.send_chat_video()
    driver_sessions.set_active(driver_2)
    mk2_chats.play_loaded_video()
    mk2_chats.assert_video_playing()

    log.info('MK1 отправил ссылку, МК2 ее получил')
    mk1_chats.type_chat_message(test_message_link)
    mk1_chats.send_chat_message(test_message_link)
    driver_sessions.set_active(driver_2)
    mk2_chats.assert_message_link_received(test_message_link)

@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.android
# @pytest.mark.ios
def test_p2p_chat_info_VCSMOB_T15_android(setup_aut, teardown):
    '''
    Кейсы только для Android, на iOS пока не реализованы. Т15, шаги 7-9
    '''
    lang = setup_aut['setup']['cmd']['lang']
    device_os = setup_aut['setup']['cmd']['device_os']

    creds = setup_aut['setup']['config']['credentials']
    login_creds = creds['user1']
    contact_1 = creds['user4']
    server = setup_aut['setup']['config']['server']
    driver = setup_aut['driver']

    log.tc('T15_android')

    teardown.append(lambda: driver.quit())

    server_page1 = pages.get_page(device_os, 'pick_server')(driver, lang=lang)
    server_page1.pick(server)

    mk1_login_page = pages.get_page(device_os, 'login')(driver, lang=lang)
    mk1_login_page.login(login_creds['username'], login_creds['password'])
    mk1_main_menu = chunks.get_chunk(device_os, 'bottom_menu')(driver, lang=lang)
    mk1_main_menu.open_chats()

    log.info('Добавим чат с контактом MK2')
    mk1_chats = pages.get_page(device_os, 'chats')(driver, lang=lang)
    mk1_chats.add_new_chat(contact_1['username'])

    mk1_chats.send_chat_last_photo()
    mk1_chats.assert_photo_sent()

    mk1_chats.open_chat_info()
    mk1_chat_about_page = pages.get_page(device_os, 'chat_about')(driver, lang=lang)
    mk1_chat_about_page.assert_chat_info_opened()

    mk1_chat_about_page.open_chat_gallery()
    mk1_chat_about_page.assert_chat_documents_button_presence()
    mk1_chat_about_page.assert_chat_media_button_presence()
    mk1_chat_about_page.assert_chat_sent_image_presence()


# @pytest.mark.suite_smoke
# @pytest.mark.suite_regress
#TODO: disabled until additional devices are purchased
@pytest.mark.android
@pytest.mark.ios
def test_p2p_group_chat_message_VCSMOB_T16(setup_multiple_auts, teardown):
    auts = setup_multiple_auts(3)
    lang = auts['setup']['cmd']['lang']
    device_os = auts['setup']['cmd']['device_os']

    creds = auts['setup']['config']['credentials']
    login_creds = creds['user1']
    test_message = 'Test message'
    chat_members = [creds['user4'], creds['user3']]
    server = auts['setup']['config']['server']
    driver_1, driver_2, driver_3 = auts['driver']

    log.tc('T16')

    teardown.append(lambda: driver_1.quit())
    teardown.append(lambda: driver_2.quit())
    teardown.append(lambda: driver_3.quit())

    log.info('MK1 авторизуется, добавляет чат с МК2')
    driver_sessions.set_active(driver_1)
    server_page1 = pages.get_page(device_os, 'pick_server')(driver_1, lang=lang)
    server_page1.pick(server)

    mk1_login_page = pages.get_page(device_os, 'login')(driver_1, lang=lang)
    mk1_login_page.login(**login_creds)
    mk1_main_menu = chunks.get_chunk(device_os, 'bottom_menu')(driver_1, lang=lang)
    mk1_main_menu.open_chats()

    log.info('Добавим чат с контактами из списка')
    mk1_chats = pages.get_page(device_os, 'chats')(driver_1, lang=lang)
    mk1_chats.add_to_group_chat(users=chat_members)

    log.info('МК2 авторизуется, открывает групповой чат')
    driver_sessions.set_active(driver_2)
    server_page2 = pages.get_page(device_os, 'pick_server')(driver_2, lang=lang)
    server_page2.pick(server)
    mk2_login_page = pages.get_page(device_os, 'login')(driver_2, lang=lang)
    mk2_login_page.login(chat_members[0]['username'], chat_members[0]['password'])
    mk2_main_menu = chunks.get_chunk(device_os, 'bottom_menu')(driver_2, lang=lang)
    mk2_main_menu.open_chats()

    mk2_chats = pages.get_page(device_os, 'chats')(driver_2, lang=lang)
    mk2_chats.open_existing_group_chat()

    log.info('МК3 авторизуется, открывает групповой чат')
    driver_sessions.set_active(driver_3)
    server_page3 = pages.get_page(device_os, 'pick_server')(driver_3, lang=lang)
    server_page3.pick(server)
    mk3_login_page = pages.get_page(device_os, 'login')(driver_3, lang=lang)
    mk3_login_page.login(chat_members[1]['username'], chat_members[0]['password'])
    mk3_main_menu = chunks.get_chunk(device_os, 'bottom_menu')(driver_3, lang=lang)
    mk3_main_menu.open_chats()

    mk3_chats = pages.get_page(device_os, 'chats')(driver_3, lang=lang)
    mk3_chats.open_existing_group_chat()

    driver_sessions.set_active(driver_1)
    log.info('МК1 начинает писать сообщение')
    if driver_1.at_device_os == 'iOS':
        mk1_chats.type_chat_message(test_message)
    else:
        mk1_chats.type_chat_message(test_message, type_entire_line=False)
    log.info("МК2 наблюдает в заголовке окна 'печатает…'")
    driver_sessions.set_active(driver_2)
    mk2_chats.assert_chat_status_is('печатает')

    log.info("МК2 наблюдает в заголовке окна 'печатает…'")
    driver_sessions.set_active(driver_3)
    mk3_chats.assert_chat_status_is('печатает')

    log.info('MK1 отправил сообщение, МК2 и МК2 его получили')
    driver_sessions.set_active(driver_1)
    if driver_1.at_device_os == 'iOS':
        mk1_chats.send_chat_message(test_message)
    else:
        driver_sessions.set_active(driver_1)
        mk1_chats.type_chat_message(test_message)
        mk1_chats.send_chat_message(test_message)
    driver_sessions.set_active(driver_2)
    mk2_chats.assert_message_received(test_message)
    driver_sessions.set_active(driver_3)
    mk3_chats.assert_message_received(test_message)


@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.android
@pytest.mark.ios
def test_p2p_chat_call_VCSMOB_T24(setup_multiple_auts, teardown):
    auts = setup_multiple_auts(2)
    lang = auts['setup']['cmd']['lang']
    device_os = auts['setup']['cmd']['device_os']
    creds = auts['setup']['config']['credentials']
    login_creds = creds['user1']
    contact_1 = creds['user4']
    text_check_1 = 'HI-TECH'
    server = auts['setup']['config']['server']
    driver_1, driver_2 = auts['driver']

    log.tc('T24')

    teardown.append(lambda: driver_1.quit())
    teardown.append(lambda: driver_2.quit())

    log.info('MK1 авторизуется, добавляет чат с МК2')
    driver_sessions.set_active(driver_1)
    server_page1 = pages.get_page(device_os, 'pick_server')(driver_1, lang=lang)
    server_page1.pick(server)

    mk1_login_page = pages.get_page(device_os, 'login')(driver_1, lang=lang)
    mk1_login_page.login(login_creds['username'], login_creds['password'])
    mk1_main_menu = chunks.get_chunk(device_os, 'bottom_menu')(driver_1, lang=lang)
    mk1_main_menu.open_chats()

    log.info('Добавим чат с контактом MK2')
    mk1_chats = pages.get_page(device_os, 'chats')(driver_1, lang=lang)
    mk1_chats.add_new_chat(contact_1['username'])

    log.info('МК2 авторизуется, открывает чат с МК1')
    driver_sessions.set_active(driver_2)
    server_page2 = pages.get_page(device_os, 'pick_server')(driver_2, lang=lang)
    server_page2.pick(server)
    mk2_login_page = pages.get_page(device_os, 'login')(driver_2, lang=lang)
    mk2_login_page.login(contact_1['username'], contact_1['password'])
    mk2_main_menu = chunks.get_chunk(device_os, 'bottom_menu')(driver_2, lang=lang)
    mk2_main_menu.open_chats()

    mk2_chats = pages.get_page(device_os, 'chats')(driver_2, lang=lang)
    mk2_chats.open_existing_chat(login_creds['username'])

    driver_sessions.set_active(driver_1)
    log.info('МК1 звонит по видеозвоноку МК2')
    mk1_chats.start_video_call()

    log.info('МК2 отвечает на видеозвонок от МК1')
    driver_sessions.set_active(driver_2)
    mk2_chats.join_video_call()

    mk2_chats.assert_video_is_streaming(driver_2, text_check_1)

# @pytest.mark.suite_smoke
# @pytest.mark.suite_regress
#TODO: disabled until additional devices are purchased
@pytest.mark.android
@pytest.mark.ios
def test_p2p_chat_call_VCSMOB_T29(setup_multiple_auts, teardown):
    auts = setup_multiple_auts(3)
    lang = auts['setup']['cmd']['lang']
    device_os = auts['setup']['cmd']['device_os']

    creds = auts['setup']['config']['credentials']
    login_creds = creds['user1']
    call_members = [creds['user4'], creds['user3']]
    text_check_1 = 'HI-TECH'
    text_check_2 = 'Stand'
    server = auts['setup']['config']['server']
    driver_1, driver_2, driver_3 = auts['driver']

    log.tc('T29')

    teardown.append(lambda: driver_1.quit())
    teardown.append(lambda: driver_2.quit())
    teardown.append(lambda: driver_3.quit())

    log.info('MK1 авторизуется, добавляет чат с МК2')
    driver_sessions.set_active(driver_1)
    server_page1 = pages.get_page(device_os, 'pick_server')(driver_1, lang=lang)
    server_page1.pick(server)

    mk1_login_page = pages.get_page(device_os, 'login')(driver_1, lang=lang)
    mk1_login_page.login(login_creds['username'], login_creds['password'])
    mk1_main_menu = chunks.get_chunk(device_os, 'bottom_menu')(driver_1, lang=lang)
    mk1_main_menu.open_chats()

    log.info('Добавим чат с контактом MK2')
    mk1_chats = pages.get_page(device_os, 'chats')(driver_1, lang=lang)
    mk1_chats.add_new_chat(call_members[0]['username'])

    log.info('МК2 авторизуется, открывает чат с МК1')
    driver_sessions.set_active(driver_2)
    server_page2 = pages.get_page(device_os, 'pick_server')(driver_2, lang=lang)
    server_page2.pick(server)
    mk2_login_page = pages.get_page(device_os, 'login')(driver_2, lang=lang)
    mk2_login_page.login(call_members[0]['username'], call_members[0]['password'])
    mk2_main_menu = chunks.get_chunk(device_os, 'bottom_menu')(driver_2, lang=lang)
    mk2_main_menu.open_chats()

    mk2_chats = pages.get_page(device_os, 'chats')(driver_2, lang=lang)
    mk2_chats.open_existing_chat(login_creds['username'])

    log.info('МК3 авторизуется, открывает чат с МК1')
    driver_sessions.set_active(driver_3)
    server_page3 = pages.get_page(device_os, 'pick_server')(driver_3, lang=lang)
    server_page3.pick(server)
    mk3_login_page = pages.get_page(device_os, 'login')(driver_3, lang=lang)
    mk3_login_page.login(call_members[1]['username'], call_members[1]['password'])
    mk3_main_menu = chunks.get_chunk(device_os, 'bottom_menu')(driver_3, lang=lang)
    mk3_main_menu.open_chats()
    mk3_chats = pages.get_page(device_os, 'chats')(driver_3, lang=lang)

    log.info('МК1 звонит по видеозвоноку МК2')
    driver_sessions.set_active(driver_1)
    mk1_chats.start_video_call()

    log.info('МК2 отвечает на видеозвонок от МК1')
    driver_sessions.set_active(driver_2)
    mk2_chats.join_video_call()

    log.info('МК1 добавляет МК3 в видеозвонок')
    mk1_chats.add_call_participant(call_members[1]['username'])

    log.info('МК3 отвечает на видеозвонок от МК1')
    driver_sessions.set_active(driver_3)
    mk3_chats.join_video_call()

    mk2_chats.assert_video_is_streaming(driver_2, text_check_1)
    mk3_chats.assert_video_is_streaming(driver_3, text_check_2)
