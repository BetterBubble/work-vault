import pytest

from autocore.test.logger import get_log
from autocore.test.config import get_config
from autocore.clients import rest

from tests.pages import chunks
from tests import pages

log = get_log()
conf = get_config()

@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.ios
@pytest.mark.android
@pytest.mark.qaauto_smoke
def test_create_room_VCSMOB_T949(setup_aut, teardown):
    lang = setup_aut['setup']['cmd']['lang']
    device_os = setup_aut['setup']['cmd']['device_os']

    creds = setup_aut['setup']['config']['credentials']
    login_creds = creds['user1']
    participiant = creds['user4']
    room_name = 'Test automation room'
    room_agenda = 'Test automation agenda'
    room_type = 'Конференция (встреча)'
    driver = setup_aut['driver']
    server = setup_aut['setup']['config']['server']
    teardown.append(lambda: driver.quit())

    log.tc('T949')

    server_page = pages.get_page(device_os, 'pick_server')(driver, lang=lang)
    server_page.pick(server)

    login_page = pages.get_page(device_os, 'login')(driver, lang=lang)
    login_page.login(**login_creds)

    main_menu = chunks.get_chunk(device_os, 'bottom_menu')(driver, lang=lang)
    main_menu.open_rooms()

    rooms = pages.get_page(device_os, 'rooms')(driver, lang=lang)
    rooms.create_new_room()

    rooms.fill_room_params_and_create(name=room_name, agenda=room_agenda, participiant=participiant['username'])
    rooms.check_room_name_present(room_name)
    rooms.check_room_agenda_present(room_agenda)
    rooms.check_room_type(room_type)
    rooms.join_room()
    rooms.leave_room()
    _ = pages.get_page(device_os, 'rooms')(driver, lang=lang)


@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.ios
# @pytest.mark.android
@pytest.mark.qaauto_smoke
def test_delete_room_VCSMOB_T658(setup_aut, teardown):
    lang = setup_aut['setup']['cmd']['lang']
    device_os = setup_aut['setup']['cmd']['device_os']

    creds = setup_aut['setup']['config']['credentials']
    user_reg = 'user1'
    login_creds = creds[user_reg]
    room_name = 'Test automation room(API)'
    driver = setup_aut['driver']
    server = setup_aut['setup']['config']['server']
    teardown.append(lambda: driver.quit())

    log.tc('T658')

    rest.create_room(conf_user=user_reg, room_name=room_name)

    server_page = pages.get_page(device_os, 'pick_server')(driver, lang=lang)
    server_page.pick(server)

    login_page = pages.get_page(device_os, 'login')(driver, lang=lang)
    login_page.login(**login_creds)

    main_menu = chunks.get_chunk(device_os, 'bottom_menu')(driver, lang=lang)
    main_menu.open_rooms()

    rooms = pages.get_page(device_os, 'rooms')(driver, lang=lang)
    rooms.delete_existing_room(room_name)
    rooms.check_room_absense(room_name)