from datetime import datetime

import pytest

from autocore.test.logger import get_log
from autocore.test.config import get_config
from autocore.clients import rest

from tests.pages import chunks
from tests import pages

log = get_log()
conf = get_config()

@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.ios
@pytest.mark.android
@pytest.mark.qaauto_smoke
def test_enter_by_id_VCSMOB_T20(setup_aut, teardown):
    lang = setup_aut['setup']['cmd']['lang']
    device_os = setup_aut['setup']['cmd']['device_os']

    creds = setup_aut['setup']['config']['credentials']
    user_reg_1, user_reg_2 = 'user1', 'user3'
    login_creds = creds[user_reg_2]
    driver = setup_aut['driver']
    server = setup_aut['setup']['config']['server']
    teardown.append(lambda: driver.quit())

    log.tc('T20')

    server_page = pages.get_page(device_os, 'pick_server')(driver, lang=lang)
    server_page.pick(server)

    login_page = pages.get_page(device_os, 'login')(driver, lang=lang)
    login_page.login(**login_creds)

    main_menu = chunks.get_chunk(device_os, 'bottom_menu')(driver, lang=lang)
    main_menu.open_meetings()

    meetings = pages.get_page(device_os, 'meetings')(driver, lang=lang)
    meetings.login_by_id()
    meeting_id = rest.create_meeting(user_reg_1, guest_user=[user_reg_2], get_conf_number=True)
    meetings.connect_to_meeting_by_id(meeting_id)

    meeting = pages.get_page(device_os, 'meeting')(driver, lang=lang)
    meeting.leave()


@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.ios
@pytest.mark.android
@pytest.mark.qaauto_smoke
def test_create_instant_meeting_VCSMOB_T914(setup_aut, teardown):
    lang = setup_aut['setup']['cmd']['lang']
    device_os = setup_aut['setup']['cmd']['device_os']

    creds = setup_aut['setup']['config']['credentials']
    login_creds = creds['user1']
    driver = setup_aut['driver']
    server = setup_aut['setup']['config']['server']
    teardown.append(lambda: driver.quit())

    log.tc('T914')

    server_page = pages.get_page(device_os, 'pick_server')(driver, lang=lang)
    server_page.pick(server)

    login_page = pages.get_page(device_os, 'login')(driver, lang=lang)
    login_page.login(**login_creds)

    main_menu = chunks.get_chunk(device_os, 'bottom_menu')(driver, lang=lang)
    main_menu.open_meetings()

    meetings = pages.get_page(device_os, 'meetings')(driver, lang=lang)
    meeting_start_time = meetings.create_new_instant_meeting()

    meeting = pages.get_page(device_os, 'meeting')(driver, lang=lang)
    meeting.leave()

    meetings.check_is_hd_conference()
    meetings.check_organizer_present(login_creds['username'])
    meetings.check_meeting_duration()

    if device_os == 'iOS':
        pytest.xfail("Fails due VCSMOB-8796")
    meetings.check_meeting_start_time(meeting_start_time)


@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.ios
@pytest.mark.android
@pytest.mark.qaauto_smoke
def test_create_scheduled_meeting_VCSMOB_T913(setup_aut, teardown):
    lang = setup_aut['setup']['cmd']['lang']
    device_os = setup_aut['setup']['cmd']['device_os']

    creds = setup_aut['setup']['config']['credentials']
    login_creds = creds['user1']
    participiant = creds['user4']

    driver = setup_aut['driver']
    server = setup_aut['setup']['config']['server']
    teardown.append(lambda: driver.quit())

    log.tc('T913')

    server_page = pages.get_page(device_os, 'pick_server')(driver, lang=lang)
    server_page.pick(server)

    login_page = pages.get_page(device_os, 'login')(driver, lang=lang)
    login_page.login(**login_creds)

    main_menu = chunks.get_chunk(device_os, 'bottom_menu')(driver, lang=lang)
    main_menu.open_meetings()

    meetings = pages.get_page(device_os, 'meetings')(driver, lang=lang)
    meetings.create_new_scheduled_meeting()

    scheduled_meeting = pages.get_page(device_os, 'schedule_meeting')(driver, lang=lang)

    scheduled_meeting.check_meeting_name_present()
    scheduled_meeting.check_meeting_agenda_present()
    scheduled_meeting.check_meeting_start_date_present()
    scheduled_meeting.check_meeting_start_time_present()
    scheduled_meeting.check_meeting_end_time_present()
    scheduled_meeting.check_meeting_duratiun_present()
    scheduled_meeting.check_meeting_template_present()
    scheduled_meeting.check_meeting_periodicity_present()
    scheduled_meeting.check_meeting_participant_add_present()
    scheduled_meeting.check_meeting_participants_list_present(login_creds['username'])

    meeting_name = 'Test automation meeting'
    meeting_agenda = 'Test automation agenda'
    current_hour = datetime.now().hour
    scheduled_meeting.fill_scheduled_meeting_params_and_start(name=meeting_name, agenda=meeting_agenda,
                                                              participiant=participiant['username'],
                                                              current_hour=current_hour)

    meetings.check_meeting_name_is(meeting_name)
    meetings.check_organizer_present(login_creds['username'])
    meetings.check_participants_count()
    meetings.check_meeting_duration()


@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.ios
@pytest.mark.android
@pytest.mark.qaauto_smoke
def test_edit_scheduled_meeting_VCSMOB_T699(setup_aut, teardown):
    '''
    - Создадим запланированное мероприятие с временем начала +1 час от текущего
    - Изменим время начала на +1 час от запланированного
    - Проверим, что актуальное время начала мероприятия +2 часа от начального
    '''
    lang = setup_aut['setup']['cmd']['lang']
    device_os = setup_aut['setup']['cmd']['device_os']

    creds = setup_aut['setup']['config']['credentials']
    login_creds = creds['user1']

    driver = setup_aut['driver']
    server = setup_aut['setup']['config']['server']
    teardown.append(lambda: driver.quit())

    log.tc('T699')

    server_page = pages.get_page(device_os, 'pick_server')(driver, lang=lang)
    server_page.pick(server)

    login_page = pages.get_page(device_os, 'login')(driver, lang=lang)
    login_page.login(**login_creds)

    main_menu = chunks.get_chunk(device_os, 'bottom_menu')(driver, lang=lang)
    main_menu.open_meetings()

    meetings = pages.get_page(device_os, 'meetings')(driver, lang=lang)
    meetings.create_new_scheduled_meeting()

    scheduled_meeting = pages.get_page(device_os, 'schedule_meeting')(driver, lang=lang)

    meeting_name = 'Test automation meeting'
    meeting_agenda = 'Test automation agenda'
    current_hour = datetime.now().hour
    scheduled_meeting.fill_scheduled_meeting_params_and_start(name=meeting_name, agenda=meeting_agenda, current_hour=current_hour)

    meetings.open_and_edit_existing_meeting(meeting_name=meeting_name)

    edit_scheduled_meeting = pages.get_page(device_os, 'edit_schedule_meeting')(driver, lang=lang)
    edit_scheduled_meeting.change_start_time()
    meetings.check_meeting_start_time(real_start_time=str(current_hour + 2))
