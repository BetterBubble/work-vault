import pytest

from autocore.test.logger import get_log
from autocore.test.config import get_config
from tests import pages
from tests.pages import chunks
from autocore import stands

log = get_log()
conf = get_config()

@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.ios
@pytest.mark.android
@pytest.mark.requiredb
def test_contact_add_VCSMOB_T33(setup_aut, teardown):
    lang = setup_aut['setup']['cmd']['lang']
    device_os = setup_aut['setup']['cmd']['device_os']
    if device_os == 'Android':
        pytest.xfail("Fails due VCSAT-726")

    creds = setup_aut['setup']['config']['credentials']
    login_creds = creds['user1']
    contact_1 = creds['user2']
    contact_2 = creds['user3']
    contact_3 = creds['user4']
    server = setup_aut['setup']['config']['server']
    driver = setup_aut['driver']

    log.tc('T33')

    teardown.append(lambda: driver.quit())

    server_page = pages.get_page(device_os, 'pick_server')(driver, lang=lang)
    server_page.pick(server)

    login_page = pages.get_page(device_os, 'login')(driver, lang=lang)
    login_page.login(login_creds['username'], login_creds['password'])
    main_menu = chunks.get_chunk(device_os, 'bottom_menu')(driver, lang=lang)
    main_menu.open_contacts()
    contacts = pages.get_page(device_os, 'contacts')(driver, lang=lang)

    log.info('Найдем контакт по имени')
    contacts.add_new_contact(contact_1['name'])
    contacts.assert_contact_added(contact_1['name'])

    log.info('Найдем контакт по e-mail')
    contacts.add_new_contact(contact_2['username'])
    contacts.assert_contact_added(contact_2['username'])

    log.info('Найдем контакт по номеру телефона')
    contacts.add_new_contact(contact_3['phone'])
    contacts.assert_contact_added(contact_3['username'])
