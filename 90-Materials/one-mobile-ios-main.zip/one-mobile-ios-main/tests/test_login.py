import time

import pytest

from autocore.test.logger import get_log
from autocore.test.config import get_config
from tests import pages
from tests.pages import chunks
from autocore.clients import rest
from autocore import stands
from autocore.test.generate_data import get_str_timestamp

log = get_log()
conf = get_config()


#@pytest.mark.suite_smoke
def test_login_tr4212(setup_aut, teardown):
    lang = setup_aut['setup']['cmd']['lang']
    device_os = setup_aut['setup']['cmd']['device_os']
    login_creds = setup_aut['setup']['config']['credentials']['user1']
    server = setup_aut['setup']['config']['server']
    driver = setup_aut['driver']
    teardown.append(lambda: driver.quit())

    log.tc('1729')

    server_page = pages.get_page(device_os, 'pick_server')(driver, lang=lang)
    server_page.pick(server)

    login_page = pages.get_page(device_os, 'login')(driver, lang=lang)
    login_page.login(**login_creds)

    _ = pages.get_page(device_os, 'home')(driver, lang=lang)


@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.ios
@pytest.mark.android
def test_authorization_VCSMOB_T5(setup_aut, teardown):
    lang = setup_aut['setup']['cmd']['lang']
    device_os = setup_aut['setup']['cmd']['device_os']
    login_creds = setup_aut['setup']['config']['credentials']['user1']
    server = setup_aut['setup']['config']['server']
    driver = setup_aut['driver']
    random_string = get_str_timestamp()

    log.tc('T5')

    teardown.append(lambda: driver.quit())

    message = ['некорректный логин', 'некорректный пароль', 'корректные данные входа']
    for i, user_login_password in enumerate([[server, login_creds['username'] + random_string, login_creds['password']],
                                             [server, login_creds['username'], login_creds['password'] + random_string],
                                             [server, login_creds['username'], login_creds['password']]]):
        log.step(f'Кейс №{i + 2} - {message[i]}', where='IVA Mobile Клиент')
        server_page = pages.get_page(device_os, 'pick_server')(driver, lang=lang)
        server_page.pick(user_login_password[0])
        login_page = pages.get_page(device_os, 'login')(driver, lang=lang)
        login_page.login(user_login_password[1], user_login_password[2])
        if i < 2:
            login_page.assert_incorrect_login_details_message()
            login_page.open_server_select_popup()
            server_selection = pages.get_page(device_os, 'server_selection_popup')(driver, lang=lang)
            server_selection.add_new_server()
        if i == 2:
            _ = pages.get_page(device_os, 'home')(driver, lang=lang)


#@pytest.mark.suite_smoke
def test_server_list_tr2818(setup_aut, teardown):
    lang = setup_aut['setup']['cmd']['lang']
    device_os = setup_aut['setup']['cmd']['device_os']
    server_dev = setup_aut['setup']['config']['server']
    server_prod = conf['prod']['web_url']
    driver = setup_aut['driver']

    log.tc('2818')

    teardown.append(lambda: driver.quit())

    server_page = pages.get_page(device_os, 'pick_server')(driver, lang=lang)
    server_page.pick(server_prod[8:])
    login_page = pages.get_page(device_os, 'login')(driver, lang=lang)
    login_page.open_server_select_popup()
    server_selection = pages.get_page(device_os, 'server_selection_popup')(driver, lang=lang)
    server_selection.add_new_server()
    server_page.pick(server_dev, check_continue_button=True)
    login_page.check_server_correct(server_dev)


#@pytest.mark.suite_smoke
def test_server_switch_tr2819(setup_aut, teardown):
    lang = setup_aut['setup']['cmd']['lang']
    device_os = setup_aut['setup']['cmd']['device_os']
    server_dev = setup_aut['setup']['config']['server']
    server_prod = conf['prod']['web_url'][8:]
    driver = setup_aut['driver']
    header_prod_name = "IVA Technologies"

    log.tc('2819')

    teardown.append(lambda: driver.quit())

    server_page = pages.get_page(device_os, 'pick_server')(driver, lang=lang)
    server_page.pick(server_dev)
    login_page = pages.get_page(device_os, 'login')(driver, lang=lang)
    login_page.open_server_select_popup()
    server_selection = pages.get_page(device_os, 'server_selection_popup')(driver, lang=lang)
    server_selection.add_new_server()
    server_page.pick(server_prod)
    login_page.check_server_correct(header_prod_name)

    login_page.open_server_select_popup()
    server_selection.switch_to_server(server_dev)
    login_page.check_server_correct(server_dev)


@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.ios
@pytest.mark.android
def test_login_ldap_VCSMOB_T7(setup_aut, teardown):
    lang = setup_aut['setup']['cmd']['lang']
    device_os = setup_aut['setup']['cmd']['device_os']
    login_creds = setup_aut['setup']['config']['credentials']['user1-ldap']
    server = setup_aut['setup']['config']['server']
    driver = setup_aut['driver']

    log.tc('T7')

    teardown.append(lambda: driver.quit())

    server_page = pages.get_page(device_os, 'pick_server')(driver, lang=lang)
    server_page.pick(server)

    login_page = pages.get_page(device_os, 'login')(driver, lang=lang)
    login_page.login(**login_creds)
    main_menu = chunks.get_chunk(device_os, 'bottom_menu')(driver, lang=lang)
    main_menu.open_settings()
    settings = pages.get_page(device_os, 'view_settings_list')(driver, lang=lang)
    settings.check_user_cant_edit_profile()


@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.requiredb
@pytest.mark.ios
@pytest.mark.android
def test_login_2fa_VCSMOB_T6(setup_aut, teardown):
    stands.toggle_2fa(True)
    teardown.append(lambda: stands.toggle_2fa(False))

    lang = setup_aut['setup']['cmd']['lang']
    server = setup_aut['setup']['config']['server']
    device_os = setup_aut['setup']['cmd']['device_os']
    login_creds = setup_aut['setup']['config']['credentials']['user1']
    driver = setup_aut['driver']
    teardown.append(lambda: driver.quit())

    log.tc('T6')

    server_page = pages.get_page(device_os, 'pick_server')(driver, lang=lang)
    server_page.pick(server)
    login_page = pages.get_page(device_os, 'login')(driver, lang=lang)
    login_page.login(**login_creds)

    login_confirm_code_page = pages.get_page(device_os, 'login_confirm_code')(driver, lang=lang)
    login_confirm_code_page.check_elements_params(login_creds['username'])
    login_confirm_code_page.enter_invalid_code()
    login_confirm_code_page.enter_valid_code()
    _ = pages.get_page(device_os, 'home')(driver, lang=lang)


@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.ios
@pytest.mark.android
def test_login_adfs_VCSMOB_T8(setup_aut, teardown):
    lang = setup_aut['setup']['cmd']['lang']
    device_os = setup_aut['setup']['cmd']['device_os']
    login_creds = setup_aut['setup']['config']['credentials']['user1-adfs']
    server = setup_aut['setup']['config']['server']
    driver = setup_aut['driver']

    teardown.append(lambda: driver.quit())

    log.tc('T8')

    server_page = pages.get_page(device_os, 'pick_server')(driver, lang=lang)
    server_page.pick(server)

    login_page = pages.get_page(device_os, 'login')(driver, lang=lang)
    login_page.login_adfs(login_creds['username'], login_creds['password'])
    _ = pages.get_page(device_os, 'home')(driver, lang=lang)


#@pytest.mark.suite_smoke
def test_authorization_incorrect_password_tr2382(setup_aut, teardown):  # TODO "reason": VCSAT-188
    lang = setup_aut['setup']['cmd']['lang']
    device_os = setup_aut['setup']['cmd']['device_os']
    server = setup_aut['setup']['config']['server']
    driver = setup_aut['driver']
    username = setup_aut['setup']['config']['credentials']['user1-pwd-case']['username']

    log.tc('2382')

    teardown.append(lambda: driver.quit())

    server_page = pages.get_page(device_os, 'pick_server')(driver, lang=lang)
    server_page.pick(server)

    login_page = pages.get_page(device_os, 'login')(driver, lang=lang)
    login_page.try_login_incorrect_password(3, username)


#@pytest.mark.suite_smoke
def test_login_by_id_tr2833(setup_aut, teardown):
    lang = setup_aut['setup']['cmd']['lang']
    server = setup_aut['setup']['config']['server']
    device_os = setup_aut['setup']['cmd']['device_os']
    driver = setup_aut['driver']

    log.tc('2833')

    teardown.append(lambda: driver.quit())

    meeting_response = rest.create_meeting('user1', get_conf_number=False)
    meeting_id = meeting_response['conferenceNumber']
    conf_id = meeting_response['conferenceId']

    teardown.append(lambda: rest.delete_meeting('user1', conf_id))

    server_page = pages.get_page(device_os, 'pick_server')(driver, lang=lang)
    server_page.pick(server)
    login_page = pages.get_page(device_os, 'login')(driver, lang=lang)
    login_page.check_incorrect_meeting_id()
    login_page.login_by_id(meeting_id)
    meeting_info = pages.get_page(device_os, 'meeting_login_info')(driver, lang=lang)
    meeting_info.click_enter_conference_button()
    meeting_login = pages.get_page(device_os, 'meeting_login')(driver, lang=lang)
    meeting_login.enter_guest()
    meeting = pages.get_page(device_os, 'meeting')(driver, lang=lang)
    meeting.leave()
