from .mobile_browser import PIOSMobileBrowser
from .mobile_browser import PAndroidMobileBrowser

def get_browser(platform):
    if platform == 'Android':
        return PAndroidMobileBrowser

    if platform == 'iOS':
        return PIOSMobileBrowser
