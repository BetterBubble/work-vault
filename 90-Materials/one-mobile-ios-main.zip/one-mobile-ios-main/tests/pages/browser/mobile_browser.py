import time

from tests.pages.base import _PBase
from tests.pages.locators.iOS.browser import mobile_browser as iOSLocators
from tests.pages.locators.Android.browser import mobile_browser as AndroidLocators
from autocore.test.logger import get_log

log = get_log()


class _PBaseMobileBrowser(_PBase):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = None
        super().__init__(*args, **kwargs)


class PAndroidMobileBrowser(_PBaseMobileBrowser, AndroidLocators.LMobileBrowser):
    def continue_in_app(self):
        log.step('Продолжим в приложении', where='IVA Mobile Web Клиент')
        self.get_object(self.L_I18N_CONTINUE_IN_APP_BUTTON(self.lang)).click()

        log.step('Войдем через IVA Connect', where='IVA Mobile Web Клиент')
        self.get_object(self.L_I18N_ENTER_VIA_IVA_CONNECT(self.lang)).click()

class PIOSMobileBrowser(_PBaseMobileBrowser, iOSLocators.LMobileBrowser):
    def continue_in_app(self):
        log.step('Продолжим в приложении', where='IVA Mobile Web Клиент')
        if self.driver.is_real_device:
            # On a physical device we need to wait some time after opening a conference in a browser
            time.sleep(5)
            self.accept_wireless_data()
        self.get_object(self.L_I18N_CONTINUE_IN_APP_BUTTON(self.lang)).click()
        self.get_object(self.L_I18N_OPEN_IN_APP_BUTTON(self.lang)).click()

    def accept_wireless_data(self):
        # Ввиду возможной загрузки системы popup не успевает появиться, дадим ему шанс
        try:
            self.driver.execute_script('mobile: alert', {"action": "accept", "buttonLabel": "Только WLAN"})

        except:
            log.info('No alert window found')

        else:
            log.step('Accept use wireless data alert', where='IVA Mobile Клиент')