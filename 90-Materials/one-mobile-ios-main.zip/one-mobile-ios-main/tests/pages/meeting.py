from .base import _PBase
from .locators import Android as AndroidLocators
from .locators import iOS as iOSLocators
from autocore.test.logger import get_log

log = get_log()


class _PBaseMeeting(_PBase):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = None
        super().__init__(*args, **kwargs)

    def leave(self):
        log.step('Выход из мероприятия', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_REJECT_CALL_BUTTON(self.lang)).click()

    def show_participants(self):
        log.step('Посмотрим список участников', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_CONF_MEMBERS_BUTTON(self.lang)).click()

    def assert_role_present(self, role=''):
        self.assert_presence(locator=self.L_I18N_USER_ROLE_CAPTION(self.lang, role),
                             message=f"У пользователя Роль: {role}")

class PAndroidMeeting(_PBaseMeeting, AndroidLocators.LMeeting):
    pass

class PIOSMeeting(_PBaseMeeting, iOSLocators.LMeeting):
    pass
