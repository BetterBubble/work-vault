from .base import _PBase
from .locators import Android as AndroidLocators
from .locators import iOS as iOSLocators
from autocore.test.logger import get_log

log = get_log()


class _PBaseServerSelectionPopup(_PBase):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_I18N_HEADER(self.lang)
        super().__init__(*args, **kwargs)

    def add_new_server(self):
        log.step('Добавить новый сервер', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_ADD_SERVER_BUTTON(self.lang)).click()

    def switch_to_server(self, server_address):
        log.step(f'Переключиться на сервер {server_address}', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_SERVER_ADDRESS_ITEM(server_address)).click()


class PAndroidServerSelectionPopup(_PBaseServerSelectionPopup, AndroidLocators.LServerSelectionPopup):
    pass

class PIOSServerSelectionPopup(_PBaseServerSelectionPopup, iOSLocators.LServerSelectionPopup):
    pass