import os
import time

from .base import _PBase
from .locators import Android as AndroidLocators
from .locators import iOS as iOSLocators

from autocore.test.logger import get_log
from autocore.test.assertions import assert_fn
from autocore import ocr

log = get_log()

class _PBaseChats(_PBase):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_I18N_TEXTFIELD_HEADER(self.lang)
        super().__init__(*args, **kwargs)


    def assert_group_chat_opened(self, members_count):
        fact_members_count = self.get_object(self.L_I18N_GROUP_CHAT_CAPTION(self.lang)).text[-1]
        assert_fn(lambda: str(members_count) == fact_members_count,
                  f'Групповой чат c {members_count} участниками открылся.')

    def add_to_group_chat(self, users):
        log.step('Создаем групповой чат', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_ADD_NEW_CHAT_BUTTON(self.lang)).click()
        for user in users:
            log.step(f'Добавим в чат {user["username"]}', where='IVA Mobile Клиент')
            self.get_object(self.L_I18N_SEARCH_CHAT_INPUT(self.lang)).send_keys(user['username'])
            self.get_object(self.L_I18N_SELECT_SEARCHED_CONTACT(self.lang, user['username'])).click()
            self.get_object(self.L_I18N_CLEAR_TEXT_BUTTON(self.lang)).click()

        self.get_object(self.L_I18N_CONFIRM_ADD_CHAT_BUTTON(self.lang)).click()

    def add_new_chat(self, username=''):
        log.step(f'Добавляем чат с {username}', where='IVA Mobile Клиент')
        log.info(f'Контакт: {username}')

        self.get_object(self.L_I18N_ADD_NEW_CHAT_BUTTON(self.lang)).click()
        self.get_object(self.L_I18N_SEARCH_CHAT_INPUT(self.lang)).send_keys(username)
        self.get_object(self.L_I18N_SELECT_SEARCHED_CONTACT(self.lang, username)).click()
        self.get_object(self.L_I18N_CONFIRM_ADD_CHAT_BUTTON(self.lang)).click()

    def assert_chat_opened(self, username=''):
        self.assert_presence(locator=self.L_I18N_ADDED_CHAT_LIST(self.lang, username),
                             message=f"Чат с {username} открылся")
        self.go_back()

    def assert_message_received(self, message):
        log.step('Проверим, что сообщение доставлено"', where='IVA Mobile Клиент')
        self.wait_presence(self.L_I18N_CHAT_MESSAGE_RECEIVED(self.lang, message), timeout=3)
        message_received = self.get_object(self.L_I18N_CHAT_MESSAGE_RECEIVED(self.lang, message))
        fact_message_received_text = message_received.text
        assert_fn(lambda: message == fact_message_received_text,
                      f'Текст полученного сообщения соответствует отправленному.')

    def assert_photo_received(self):
        log.step('Проверим, что фото доставлено"', where='IVA Mobile Клиент')
        photo_received = self.wait_presence(self.L_I18N_CHAT_PHOTO_RECEIVED(self.lang), timeout=15)
        assert_fn(lambda: photo_received is True, 'Фото отправлено')

    def assert_file_received(self):
        log.step('Проверим, что документ доставлен"', where='IVA Mobile Клиент')
        self.assert_presence(locator=self.L_I18N_CHAT_FILE_RECEIVED(self.lang),
                             message="Докумен доставлен")


    def assert_photo_sent(self):
        log.step('Проверим, что фото отправлено"', where='IVA Mobile Клиент')
        photo_sent = self.wait_absence(self.L_I18N_CHAT_PHOTO_SENDING(self.lang), timeout=15)
        assert_fn(lambda: photo_sent is True, 'Фото отправлено')

    def assert_video_sent(self):
        log.step('Проверим, что видео отправлено"', where='IVA Mobile Клиент')
        photo_sent = self.wait_absence(self.L_I18N_CHAT_VIDEO_SENDING(self.lang), timeout=15)
        assert_fn(lambda: photo_sent is True, 'Видео отправлено')

    def type_chat_message(self, message, type_entire_line=True):
        log.step(f'Напечатаем в чат сообщение "{message}"', where='IVA Mobile Клиент')
        message_input = self.get_object(self.L_I18N_CHAT_MESSAGE_INPUT(self.lang))
        message_input.clear()
        message_input.click()
        if not type_entire_line:
            # "Разогреем" клиент-сервер для установления статуса "печатает...". Нужно для Android устройств
            # message_input.click()
            for char in message:
                message_input.set_text(char)
                time.sleep(.1)
        else:
            # Просто напечатаем строку
            message_input.send_keys(message)

    def send_chat_message(self, message):
        log.step(f'Отправим в чат сообщение "{message}"', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_CHAT_SEND_MESSAGE_BUTTON(self.lang)).click()

    def open_existing_chat(self, username):
        log.step(f'Откроем существующий чат с "{username}"', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_ADDED_CHAT_LIST(self.lang, username)).click()

    def open_existing_group_chat(self):
        log.step(f'Откроем существующий групповой чат', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_ADDED_GROUP_CHAT_LIST(self.lang)).click()

    def assert_chat_status_is(self, chat_status):
        fact_chat_status = self.get_object(self.L_I18N_CHAT_STATUS_CAPTION_TYPING(self.lang))
        fact_chat_status_text = fact_chat_status.text
        assert_fn(lambda: fact_chat_status_text.count(chat_status) > 0,
                  f'Статус чата - {chat_status}')

    def open_chat_info(self):
        log.step('Откроем информацию о чате "', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_CHAT_AVATAR(self.lang)).click()

    def play_loaded_video(self):
        log.step(f'Воспроизведем полученное видео', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_CHAT_PLAY_VIDEO_BUTTON(self.lang)).click()

    def start_video_call(self):
        log.step('Начнем видеозвонок', where='IVA Mobile Клиент')
        self.take_screenshot(self.driver, '[MK1] before call outcoming')
        self.get_object(self.L_I18N_CHAT_START_VIDEO_CALL_BUTTON(self.lang), timeout=5).click()
        # Дадим немного времени для загрузки окна исходящего звонка. wait_presence использовать не возможно, ввиду того, что 1 секунды мало, а 2 много
        time.sleep(.5)
        self.take_screenshot(self.driver, '[MK1] after call outcoming')

    def answer_video_call(self):
        log.step('Ответим на видеозвонок', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_CHAT_ANSWER_CALL_BUTTON(self.lang)).click()


    def add_call_participant(self, username):
        log.step('Добавим в видеозвонок участника', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_CHAT_ADD_PARTICIPANT_TO_CALL_BUTTON(self.lang)).click()
        self.add_to_call(username)

    def turn_on_camera(self):
        log.step('Включим камеру', where='IVA Mobile Клиент')
        #Проверим, что камера выключена
        if self.wait_absence(self.L_I18N_TURN_OFF_CAMERA_BUTTON(self.lang)):
            self.get_object(self.L_I18N_TURN_ON_CAMERA_BUTTON(self.lang)).click()


class PAndroidChats(_PBaseChats, AndroidLocators.LChats):
    def assert_file_opens(self):
        log.step('Проверим, что документ открывается"', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_CHAT_FILE_RECEIVED(self.lang)).click()
        download_button = self.wait_presence(self.L_I18N_CHAT_FILE_DOWNLOAD_BUTTON(self.lang))
        assert_fn(lambda: download_button is True,
                             message="Документ открылся")
        self.go_back()
    def assert_message_link_received(self, message):
        log.step('Проверим, что сообщение-ссылка доставлено"', where='IVA Mobile Клиент')
        fact_message_link_received = self.get_object(self.L_I18N_CHAT_MESSAGE_LINK_RECEIVED(self.lang, message))
        fact_message_link_received.click()
        st_time = time.time()
        while time.time() - st_time < 15:
            # iteratively call driver.context
            # somehow only after several calls webview appears in list of contexts
            if len(self.driver.contexts) > 1:
                web_view_possible = True
                break
            time.sleep(1)
        else:
            web_view_possible = False
        assert_fn(lambda: web_view_possible is True, f'Сообщение-ссылка "{message}" получено.')

    def send_chat_document(self):
        log.step(f'Отправим в чат файл-документ', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_CHAT_ADD_ATTACHMENT_BUTTON(self.lang)).click()
        self.get_object(self.L_I18N_CHAT_SELECT_FILE_BUTTON(self.lang)).click()
        self.get_object(self.L_I18N_CHAT_FILE_TO_SEND(self.lang)).click()
        self.get_object(self.L_I18N_CHAT_SEND_ATTACHMENT_BUTTON(self.lang)).click()

    def send_chat_video(self):
        log.step(f'Отправим в чат видео', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_CHAT_ADD_ATTACHMENT_BUTTON(self.lang)).click()
        self.get_object(self.L_I18N_CHAT_SELECT_FILE_BUTTON(self.lang)).click()
        self.get_object(self.L_I18N_CHAT_SELECT_VIDEO_TO_SEND(self.lang)).click()
        self.get_object(self.L_I18N_CHAT_SEND_ATTACHMENT_BUTTON(self.lang)).click()

    def send_chat_last_photo(self):
        log.step(f'Отправим в чат фото', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_CHAT_ADD_ATTACHMENT_BUTTON(self.lang)).click()
        self.get_object(self.L_I18N_CHAT_SELECT_LAST_PHOTO_BUTTON(self.lang)).click()
        log.step('Вернемся назад', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_CHAT_SEND_ATTACHMENT_BUTTON(self.lang)).click()

    def go_back(self):
        log.step('Вернемся назад', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_PREVIOUSE_STEP_BUTTON(self.lang)).click()

    def tap_to_screen(self):
        log.step('Тапнем по экрану', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_MAIN_VIDEO_SCREEN(self.lang), timeout=5).click()

    def assert_video_playing(self, username=''):
        self.assert_presence(locator=self.L_I18N_CHAT_PAUSE_VIDEO_BUTTON(self.lang),
                             message=f"Видео воспроизводится")
        self.tap_to_screen()
        self.go_back()

    def assert_video_is_streaming(self, driver, origin_text=''):
        # После включения камеры дадим время для начала трансляции видео потока
        time.sleep(7)
        # В Android нужно тапнуть по экрану для вывода на передний план видео звонящего
        self.get_object(self.L_I18N_CHAT_VIDEO_AREA(self.lang)).click()

        png_name = f'{os.getcwd()}/{driver.from_tc.split("_")[-1]}.png'
        driver.get_screenshot_as_file(png_name)
        text = ocr.read_image(png_name)
        log.info(f'Captured text: {text}')
        assert_fn(lambda: origin_text in text, message="MK видит МК1")

    def join_video_call(self):
        self.take_screenshot(self.driver, '[MK2] awaiting call')
        log.step('Ответим на видеозвонок', where='IVA Mobile Клиент')
        self.take_screenshot(self.driver, '[MK2] incomming call')
        self.get_object(self.L_I18N_CHAT_JOIN_TO_CALL_BUTTON(self.lang)).click()

    def add_to_call(self, username):
        log.info(f'Контакт: {username}')
        self.get_object(self.L_I18N_SEARCH_CHAT_INPUT(self.lang)).send_keys(username)
        self.get_object(self.L_I18N_SELECT_SEARCHED_CONTACT(self.lang, username)).click()
        self.get_object(self.L_I18N_CONFIRM_ADD_CHAT_BUTTON(self.lang)).click()



class PIOSChats(_PBaseChats, iOSLocators.LChats):
    def accept_media_access(self):
        # Ввиду возможной загрузки системы popup не успевает появиться, дадим ему шанс
        time.sleep(1)
        try:
            self.driver.execute_script('mobile: alert', {"action": "accept", "buttonLabel": "Разрешить полный доступ"})

        except:
            log.info('No alert window found')

        else:
            log.step('Accept iOS media access alert', where='IVA Mobile Клиент')

    def assert_file_opens(self):
        log.step('Проверим, что документ открывается"', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_CHAT_FILE_RECEIVED(self.lang)).click()
        download_button = self.wait_presence(self.L_I18N_CHAT_FILE_DOWNLOAD_BUTTON(self.lang))
        assert_fn(lambda: download_button is True,
                             message="Документ открылся")
        self.press_done_button()

    def assert_message_link_received(self, message):
        log.step('Проверим, что сообщение-ссылка доставлено"', where='IVA Mobile Клиент')
        fact_message_link_received = self.get_object(self.L_I18N_CHAT_MESSAGE_LINK_RECEIVED(self.lang, message)).text
        assert_fn(lambda: message == fact_message_link_received,
                  f'Сообщение-ссылка "{message}" получено.')

    def send_chat_document(self):
        log.step(f'Отправим в чат файл-документ', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_CHAT_ADD_ATTACHMENT_BUTTON(self.lang)).click()
        self.get_object(self.L_I18N_CHAT_SELECT_FILE_BUTTON(self.lang)).click()
        self.get_object(self.L_I18N_CHAT_FILE_TO_SEND(self.lang)).click()
        self.get_object(self.L_I18N_CHAT_SEND_ATTACHMENT_FILE_BUTTON(self.lang)).click()

    def send_chat_last_photo(self):
        log.step(f'Отправим в чат фото', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_CHAT_ADD_ATTACHMENT_BUTTON(self.lang)).click()
        self.get_object(self.L_I18N_CHAT_SELECT_LAST_PHOTO_BUTTON(self.lang)).click()
        self.accept_media_access()
        self.get_object(self.L_I18N_CHAT_SEND_ATTACHMENT_PHOTO_BUTTON(self.lang)).click()

    def press_done_button(self):
        log.step('Нажмем кнопку "Готово"', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_DONE_BUTTON(self.lang)).click()

    def go_back(self):
        log.step('Вернемся назад', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_PREVIOUSE_STEP_BUTTON(self.lang)).click()

    def come_back_from_player(self):
        log.step('Вернемся назад из проигрывателя', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_CHAT_COME_BACK_FROM_PLAYER_BUTTON(self.lang)).click()

    def send_chat_video(self):
        log.step(f'Отправим в чат видео', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_CHAT_ADD_ATTACHMENT_BUTTON(self.lang)).click()
        self.get_object(self.L_I18N_CHAT_SELECT_PHOTO_VIDEO_BUTTON(self.lang)).click()
        self.get_object(self.L_I18N_CHAT_SELECT_VIDEO_TO_SEND(self.lang)).click()
        self.get_object(self.L_I18N_CHAT_CHOOSE_SELECTED_VIDEO_BUTTON(self.lang)).click()
        self.get_object(self.L_I18N_CHAT_SEND_ATTACHMENT_FILE_BUTTON(self.lang)).click()

    def assert_video_playing(self, username=''):
        self.assert_presence(locator=self.L_I18N_CHAT_PAUSE_VIDEO_BUTTON(self.lang),
                             message=f"Видео воспроизводится")
        self.come_back_from_player()

    def assert_video_is_streaming(self, driver, origin_text=''):
        # После включения камеры дадим время для начала трансляции видео потока
        time.sleep(3)
        # Кликнем по значку звонка, для вывода на передний план видео звонящего
        self.get_object(self.L_I18N_CHAT_INCOMING_CALL_IMAGE(self.lang)).click()
        png_name = f'{os.getcwd()}/{driver.from_tc.split("_")[-1]}.png'
        driver.get_screenshot_as_file(png_name)
        text = ocr.read_image(png_name)
        assert_fn(lambda: origin_text in text, message="MK видит МК1")

    def join_video_call(self):
        log.step('Ответим на видеозвонок', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_CHAT_SYSTEM_ANSWER_VIDEO_CALL_BUTTON(self.lang)).click()

    def add_to_call(self, username):
        log.info(f'Контакт: {username}')
        self.get_object(self.L_I18N_SEARCH_CHAT_INPUT(self.lang)).send_keys(username)
        self.get_object(self.L_I18N_SELECT_SEARCHED_CONTACT(self.lang, username)).click()
        self.get_object(self.L_I18N_CONFIRM_ADD_TO_CALL_BUTTON(self.lang)).click()