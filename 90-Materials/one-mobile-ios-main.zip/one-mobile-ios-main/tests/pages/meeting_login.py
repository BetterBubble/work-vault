from .base import _PBase
from .locators import Android as AndroidLocators
from .locators import iOS as iOSLocators
from autocore.test.logger import get_log

log = get_log()


class _PBaseMeetingLogin(_PBase):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_I18N_ENTER_MEETING_HEADER(self.lang)
        super().__init__(*args, **kwargs)

    def enter_guest(self, guest_name='IamAutomationScript'):
        log.step('Вход гостем', where='IVA Mobile Клиент')
        log.info(f'Логин: {guest_name}')
        self.get_object(self.L_I18N_LOGIN_INPUT(self.lang)).send_keys(guest_name)
        self.get_object(self.L_I18N_ENTER_BUTTON(self.lang)).click()
        self.accept_alerts()
        self.accept_alerts()

    def login_meeting_invitee(self, username='', password=''):
        # Вход по ссылке для приглашенных(есть таба только для авторизации зарегистрированного, гостевой табы нет)
        log.step('Входим как зарегистрированный пользователь', where='IVA Mobile Клиент')
        log.info(f'Логин: {username}')
        self.get_object(self.L_I18N_LOGIN_INPUT(self.lang)).send_keys(username)
        self.get_object(self.L_I18N_TEXTFIELD_PASSWORD(self.lang)).send_keys(password)
        self.get_object(self.L_I18N_ENTER_BUTTON(self.lang)).click()
        self.accept_alerts()

    def accept_alerts(self, alerts=3):
        # Разрешим отправку уведомлений, доступ к микрофону и камере
        for _ in range(alerts):
            try:
                self.driver.switch_to.alert.accept()
            except:
                log.info('No alert window found')
            else:
                log.step('Accept alert', where='IVA Mobile Клиент')

class PAndroidMeetingLogin(_PBaseMeetingLogin, AndroidLocators.LMeetingLogin):
    def enter_as_registered(self, username='', password=''):
        # Вход по гостевой ссылке(есть таба для гостя и для зарегистрированного)
        log.step('Входим как зарегистрированный пользователь', where='IVA Mobile Клиент')
        log.info(f'Логин: {username}')
        self.get_object(self.L_I18N_REGISTERED_TAB(self.lang)).click()
        self.get_object(self.L_I18N_LOGIN_INPUT(self.lang)).send_keys(username)
        self.get_object(self.L_I18N_TEXTFIELD_PASSWORD(self.lang)).send_keys(password)
        self.driver.scroll(self.get_object(self.L_I18N_TEXTFIELD_PASSWORD(self.lang)),
                           self.get_object(self.L_I18N_ENTER_MEETING_HEADER(self.lang)))
        self.get_object(self.L_I18N_ENTER_BUTTON(self.lang)).click()
        self.accept_alerts()

class PIOSMeetingLogin(_PBaseMeetingLogin, iOSLocators.LMeetingLogin):
    def enter_as_registered(self, username='', password=''):
        # Вход по гостевой ссылке(есть таба для гостя и для зарегистрированного)
        log.step('Входим как зарегистрированный пользователь', where='IVA Mobile Клиент')
        log.info(f'Логин: {username}')
        self.get_object(self.L_I18N_REGISTERED_TAB(self.lang)).click()
        self.get_object(self.L_I18N_LOGIN_INPUT(self.lang)).send_keys(username)
        self.get_object(self.L_I18N_TEXTFIELD_PASSWORD(self.lang)).send_keys(password)
        # Сделано для симуляторов, на физ. телефоне не актуально, но пока оставлю
        # self.driver.scroll(self.get_object(self.L_I18N_TEXTFIELD_PASSWORD(self.lang)),
        #                     self.get_object(self.L_I18N_ENTER_MEETING_HEADER(self.lang)))
        self.get_object(self.L_I18N_ENTER_BUTTON(self.lang)).click()
        self.accept_alerts()

    def accept_alerts(self, alerts=3):
        # Разрешим отправку уведомлений, доступ к микрофону и камере
        for _ in range(alerts):
            try:
                self.driver.switch_to.alert.accept()
            except:
                log.info('No alert window found')
            else:
                log.step('Accept alert', where='IVA Mobile Клиент')