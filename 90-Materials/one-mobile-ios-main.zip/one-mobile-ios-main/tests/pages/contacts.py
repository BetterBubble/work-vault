from .base import _PBase
from .locators import Android as AndroidLocators
from .locators import iOS as iOSLocators
from autocore.test.logger import get_log

log = get_log()


class _PBaseContacts(_PBase):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_I18N_TEXTFIELD_HEADER(self.lang)
        super().__init__(*args, **kwargs)


    def assert_contact_added(self, username=''):
        self.assert_presence(locator=self.L_I18N_ADDED_CONTACT_LIST(self.lang, username),
                             message=f"Контакт {username} добавлен и отображается в списке")


class PAndroidContacts(_PBaseContacts, AndroidLocators.LContacts):
    def go_back(self):
        log.step('Вернемся на шаг назад', where='IVA Mobile Клиент')
        # Необходимо 2 раза нажать "<-"
        self.get_object(self.L_I18N_PREVIOUSE_STEP_BUTTON(self.lang)).click()
        self.get_object(self.L_I18N_PREVIOUSE_STEP_BUTTON(self.lang)).click()
    def add_new_contact(self, username=''):
        log.step(f'Добавляем контакт {username}', where='IVA Mobile Клиент')
        log.info(f'Контакт: {username}')

        self.get_object(self.L_I18N_ADD_CONTACT_BUTTON(self.lang)).click()
        self.get_object(self.L_I18N_SEARCH_CONTACT_BUTTON(self.lang)).click()
        self.get_object(self.L_I18N_SEARCH_CONTACT_INPUT(self.lang)).click()
        self.get_object(self.L_I18N_SEARCH_CONTACT_INPUT(self.lang)).send_keys(username)
        self.get_object(self.L_I18N_ADD_SEARCHED_CONTACT_BUTTON(self.lang)).click()
        self.go_back()

class PIOSContacts(_PBaseContacts, iOSLocators.LContacts):
    def go_back(self):
        log.step('Вернемся на шаг назад', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_PREVIOUSE_STEP_BUTTON(self.lang)).click()

    def add_new_contact(self, username=''):
        log.step(f'Добавляем контакт {username}', where='IVA Mobile Клиент')
        log.info(f'Контакт: {username}')

        self.get_object(self.L_I18N_ADD_CONTACT_BUTTON(self.lang)).click()
        self.get_object(self.L_I18N_SEARCH_CONTACT_INPUT(self.lang)).send_keys(username)
        self.get_object(self.L_I18N_ADD_SEARCHED_CONTACT_BUTTON(self.lang)).click()
        self.get_object(self.L_I18N_CLOSE_WINDOW_BUTTON(self.lang)).click()