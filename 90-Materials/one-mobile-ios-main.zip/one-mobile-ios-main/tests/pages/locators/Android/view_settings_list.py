from tools import i18n


class LViewSettingsList:
    @staticmethod
    def L_I18N_HEADER_SETTINGS(lang):
        i18n_str = i18n.get_str('header_settings', lang)
        return ('xpath', f'//*[@text="{i18n_str}"]')

    @staticmethod
    def L_I18N_USERNAME(lang=''):
        return ('id', 'user_name')

    @staticmethod
    def L_I18N_CHANGE_PASSWORD_BUTTON(lang=''):
        return ('id', 'change_password_button')

    @staticmethod
    def L_I18N_EDIT_PROFILE_BUTTON(lang=''):
        return ('id', 'edit_icon')