'''
Экран задания параметров запланированного мероприятия
'''
from tools import i18n

class LEditScheduleMeeting:
    @staticmethod
    def L_I18N_EDIT_SCHEDULE_MEETING_HEADER(lang=''):
        i18n_str = i18n.get_str('edit_schedule_meeting_header', lang=lang)
        return ('xpath', f'//android.widget.TextView[@text="{i18n_str}"]')

    @staticmethod
    def L_I18N_SCHEDULE_MEETING_CONFIRM_START_BUTTON(lang=''):
        return ('xpath', '//android.view.View[@content-desc="Done"]')

    @staticmethod
    def L_I18N_SCHEDULE_GOBACK_MEETING_LIST_BUTTON(lang=''):
        return ('id', 'su.ivcs.ucim:id/back_icon')

    @staticmethod
    def L_I18N_SCHEDULE_MEETING_START_TIME(lang=''):
        i18n_str = i18n.get_str('scheduled_meeting_start_time_field', lang=lang)
        return ('xpath', f'//android.widget.TextView[@text="{i18n_str}"]')

    @staticmethod
    def L_I18N_SCHEDULE_DATE_TIME_PICKER(lang=''):
        return ('xpath', '//android.widget.EditText')

    @staticmethod
    def L_I18N_SCHEDULE_SET_TIME_KEYBOARD_BUTTON(lang=''):
        return ('xpath', '//android.view.View[@content-desc="Add participants"]')

    @staticmethod
    def L_I18N_SCHEDULE_CONFIRM_SET_TIME_BUTTON(lang='', time=''):
        return ('xpath', '//android.widget.TextView[@text="OK"]')