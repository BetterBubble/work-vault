from tools import i18n


class LPickServer:
    @staticmethod
    def L_I18N_TEXTFIELD_SERVER(lang=''):
        return ('id', 'serversText')

    @staticmethod
    def L_I18N_BTN_CONTINUE(lang=''):
        return ('id', 'continueButton')

    @staticmethod
    def L_I18N_INCORRECT_SERVER_MESSAGE(lang):
        i18n_str = i18n.get_str('incorrect_server_message', lang)
        return ('xpath', f'//*[@text="{i18n_str}"]')