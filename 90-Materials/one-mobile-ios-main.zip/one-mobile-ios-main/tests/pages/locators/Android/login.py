from tools import i18n


class LLogin:
    @staticmethod
    def L_I18N_TEXTFIELD_LOGIN(lang=''):
        return ('id', 'loginText')

    @staticmethod
    def L_I18N_TEXTFIELD_PASSWORD(lang):
        i18n_str = i18n.get_str('password_input', lang)
        return ('xpath', f'//*[@hint="{i18n_str}"]')

    @staticmethod
    def L_I18N_TEXTFIELD_SERVER(lang=''):
        return ('id', 'serversText')

    @staticmethod
    def L_I18N_BTN_LOGIN(lang=''):
        return ('id', 'signInButton')

    @staticmethod
    def L_I18N_INCORRECT_LOGIN_DETAILS_MESSAGE(lang):
        i18n_str = i18n.get_str('incorrect_login_details_message', lang)
        return ('xpath', f'//*[@text="{i18n_str}"]')

    @staticmethod
    def L_I18N_SERVERS_BUTTON(lang=''):
        return ('id', 'serversButton')

    @staticmethod
    def L_I18N_HEADER_SERVER_NAME(lang=''):
        return ('id', 'logoText')

    @staticmethod
    def L_LOGIN_BY_ADFS_SSO_SERVER1(lang=''):
        return ('id', 'adfsProviderNameFirst')

    @staticmethod
    def L_I18N_NUMBER_FAILED_ATTEMPTS_EXCEEDED_MESSAGE(lang):
        i18n_str = i18n.get_str('number_failed_attempts_exceeded_message', lang)
        return ('xpath', f'//*[@text="{i18n_str}"]')

    @staticmethod
    def L_I18N_LOGIN_BY_ID_LINK(lang=''):
        return ('id', 'enterByIdButton')

    @staticmethod
    def L_I18N_MEETING_ID_INPUT(lang=''):
        return ('id', 'eventIdText')

    @staticmethod
    def L_I18N_LOGIN_BY_ID_BTN(lang=''):
        return ('id', 'joinButton')

    @staticmethod
    def L_I18N_INCORRECT_MEETING_ID_MESSAGE(lang):
        i18n_str = i18n.get_str('incorrect_meeting_id_message', lang)
        return ('xpath', f'//*[@text="{i18n_str}"]')
