from tools import i18n


class LServerSelectionPopup:

    @staticmethod
    def L_I18N_HEADER(lang):
        i18n_str = i18n.get_str('header_server_selection', lang)
        return ('xpath', f'//*[@text="{i18n_str}"]')

    @staticmethod
    def L_I18N_ADD_SERVER_BUTTON(lang):
        i18n_str = i18n.get_str('add_server_button', lang)
        return ('xpath', f'//*[@text="{i18n_str}"]')

    @staticmethod
    def L_I18N_SERVER_ADDRESS_ITEM(server_address, lang=''):
        return ('xpath', f'//*[@text="{server_address}"]')