from tools import i18n


class LMeetingLoginInfo:
    @staticmethod
    def L_I18N_ENTER_CONFERENCE_CONTAINER(lang=''):
        return ('id', 'enter_conference_info')

    @staticmethod
    def L_I18N_ENTER_CONFERENCE_BUTTON(lang=''):
        return ('id', 'enter_conference_button')