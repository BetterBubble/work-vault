from tools import i18n


class LMeeting:
    @staticmethod
    def L_I18N_REJECT_CALL_BUTTON(lang=''):
        return ('id', 'reject_call_btn')

    @staticmethod
    def L_I18N_MAIN_CONTAINER(lang=''):
        return ('id', 'main_surface_container')

    @staticmethod
    def L_I18N_CONF_MEMBERS_BUTTON(lang=''):
        return ('xpath', '(//android.widget.ImageView[@resource-id="su.ivcs.ucim:id/icon"])[1]')

    @staticmethod
    def L_I18N_USER_ROLE_CAPTION(lang='', role=''):
        return ('xpath', f'//android.widget.TextView[@resource-id="su.ivcs.ucim:id/role_participant" and @text="{role}"]')