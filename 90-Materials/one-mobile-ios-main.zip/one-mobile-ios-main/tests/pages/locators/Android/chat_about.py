from tools import i18n

class LChatAbout:
    @staticmethod
    def L_I18N_CLEAR_CHAT_BUTTON(lang=''):
        return ('id', 'su.ivcs.ucim:id/clear_button')

    @staticmethod
    def L_I18N_DELETE_CHAT_BUTTON(lang=''):
        return ('id', 'su.ivcs.ucim:id/delete_chat_button')

    @staticmethod
    def L_I18N_CHAT_GALLERY_BUTTON(lang=''):
        return ('id', 'su.ivcs.ucim:id/chat_gallery_button')

    @staticmethod
    def L_I18N_CHAT_MEDIA_BUTTON(lang=''):
        i18n_str = i18n.get_str('chat_gallery_media_button', lang=lang)
        return ('xpath', f'//android.widget.TextView[@text="{i18n_str}"]')

    @staticmethod
    def L_I18N_CHAT_DOCUMENTS_BUTTON(lang=''):
        i18n_str = i18n.get_str('chat_gallery_documents_button', lang=lang)
        return ('xpath', f'//android.widget.TextView[@text="{i18n_str}"]')

    @staticmethod
    def L_I18N_CHAT_GALLERY_ATTACHED_IMAGE(lang=''):
        return ('id', 'su.ivcs.ucim:id/attached_image')