from tools import i18n


class LBottomMenu:
    @staticmethod
    def L_I18N_SETTINGS_BUTTON(lang=''):
        return ('id', 'menu_item_settings')

    @staticmethod
    def L_I18N_CONTACTS_BUTTON(lang=''):
        return ('id', 'menu_item_contacts')

    @staticmethod
    def L_I18N_CHATS_BUTTON(lang=''):
        i18n_str = i18n.get_str('bottom_menu_chats_button', lang=lang)
        return ('xpath', f'//android.widget.FrameLayout[@content-desc="{i18n_str}"]')

    @staticmethod
    def L_I18N_MEETINGS_BUTTON(lang=''):
        i18n_str = i18n.get_str('bottom_menu_meetings_button', lang=lang)
        return ('xpath', f'//android.widget.FrameLayout[@content-desc="{i18n_str}"]')

    @staticmethod
    def L_I18N_ROOMS_BUTTON(lang=''):
        return ('id', 'menu_item_rooms')

