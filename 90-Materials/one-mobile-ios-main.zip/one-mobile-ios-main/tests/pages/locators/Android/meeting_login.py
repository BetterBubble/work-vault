from tools import i18n


class LMeetingLogin:
    @staticmethod
    def L_I18N_ENTER_MEETING_HEADER(lang):
        i18n_str = i18n.get_str('enter_meeting_id_header', lang)
        return ('xpath', f'//*[@text="{i18n_str}"]')

    @staticmethod
    def L_I18N_LOGIN_INPUT(lang=''):
        return ('id', 'login_et')

    @staticmethod
    def L_I18N_TEXTFIELD_PASSWORD(lang=''):
        return ('id', 'password_et')

    @staticmethod
    def L_I18N_ENTER_BUTTON(lang=''):
        return ('id', 'enter_conference_button')

    @staticmethod
    def L_I18N_REGISTERED_TAB(lang=''):
        i18n_str = i18n.get_str('switch_to_registered_tab', lang)
        return ('xpath', f'//android.widget.LinearLayout[@content-desc="{i18n_str}"]')