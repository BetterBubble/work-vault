from tools import i18n


class LLoginConfirmCodePage:
    @staticmethod
    def L_I18N_LOGIN_WINDOW_TITLE(lang=''):
        return ('id', 'titleLabel')

    @staticmethod
    def L_I18N_CONFIRM_CODE_INPUT(lang):
        return ('id', 'code_text')

    @staticmethod
    def L_I18N_CONFIRM_CODE_SEND_MESSAGE(lang):
        i18n_str = i18n.get_str('confirm_code_send_message', lang)
        return ('xpath', f'//*[@text="{i18n_str}"]')

    @staticmethod
    def L_I18N_INFO_MAIL_TEXT(lang=''):
        return ('id', 'info_email_text')

    @staticmethod
    def L_I18N_RESEND_CODE_AFTER_MESSAGE(lang=''):
        return ('id', 'send_again_in_min_text')

    @staticmethod
    def L_I18N_ENTER_BUTTON(lang=''):
        return ('id', 'signInButton')

    @staticmethod
    def L_I18N_BACK_PREVIOUS_STEP(lang):
        i18n_str = i18n.get_str('back_previous_step', lang)
        return ('xpath', f'//*[@text="{i18n_str}"]')

    @staticmethod
    def L_I18N_INVALID_CODE_MESSAGE(lang):
        i18n_str = i18n.get_str('invalid_code_message', lang)
        return ('xpath', f'//*[@text="{i18n_str}"]')
