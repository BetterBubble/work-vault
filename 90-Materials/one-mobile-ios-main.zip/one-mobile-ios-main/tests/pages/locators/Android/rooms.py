'''
Экран вкладки Комнаты
'''
from tools import i18n

class LRooms:
    @staticmethod
    def L_I18N_TEXTFIELD_ROOMS(lang=''):
        return ('id', 'su.ivcs.ucim:id/header_text')

    @staticmethod
    def L_I18N_ADD_NEW_ROOM_BUTTON(lang=''):
        return ('id', 'su.ivcs.ucim:id/add_icon')

    @staticmethod
    def L_I18N_ADD_NEW_PARTICIPIANT_BUTTON(lang=''):
        return ('xpath', '//android.view.View[@content-desc="Add participants"]')

    @staticmethod
    def L_I18N_SCHEDULE_MEETING_ADD_PARTICIPANT_INPUT(lang='', username=''):
        return ('xpath', '//android.widget.EditText')

    @staticmethod
    def L_I18N_SELECT_SEARCHED_PARTICIPIANT(lang='', participiant=''):
        return ('xpath', f'//android.widget.TextView[@text="{participiant}"]')

    @staticmethod
    def L_I18N_CONFIRM_ADD_PARTICIPIANT_BUTTON(lang=''):
        return ('xpath', '//android.view.View[@content-desc="Done"]')

    @staticmethod
    def L_I18N_ROOM_PARTICIPANT(lang='', username=''):
        return ('xpath', f'//android.widget.TextView[@text="{username}"]')

    @staticmethod
    def L_I18N_ROOM_NAME_FIELD(lang=''):
        i18n_str = i18n.get_str('room_name_field', lang=lang)
        return ('xpath', f'//android.widget.EditText[@text="{i18n_str}"]')

    @staticmethod
    def L_I18N_NEW_MEETING_NAME_FIELD(lang=''):
        return ('xpath', '//android.widget.ScrollView/android.widget.EditText[1]')

    @staticmethod
    def L_I18N_ROOM_AGENDA_FIELD(lang=''):
        i18n_str = i18n.get_str('scheduled_meeting_agenda_field', lang=lang)
        return ('xpath', '//android.widget.ScrollView/android.widget.EditText[2]')

    @staticmethod
    def L_I18N_ROOM_CONFIRM_CREATE_BUTTON(lang=''):
        return ('xpath', '//android.view.View[@content-desc="Done"]')

    @staticmethod
    def L_I18N_ROOM_NAME_CAPTION(lang='', name=''):
        return ('xpath', f'//android.widget.TextView[@resource-id="su.ivcs.ucim:id/conferenceName" and contains(@text, "{name}")]')

    @staticmethod
    def L_I18N_ENTER_ROOM_BUTTON(lang=''):
        return ('id', 'su.ivcs.ucim:id/enter_conference_button')

    @staticmethod
    def L_I18N_LEAVE_ROOM_BUTTON(lang=''):
        return ('id', 'su.ivcs.ucim:id/reject_call_btn')

    @staticmethod
    def L_I18N_ROOM_AGENDA_CAPTION(lang='', agenda=''):
        return ('xpath', f'//android.widget.TextView[@resource-id="su.ivcs.ucim:id/description" and contains(@text, "{agenda}")]')

    @staticmethod
    def L_I18N_ROOM_TYPE_CAPTION(lang='', type=''):
        return ('xpath', f'//android.widget.TextView[@resource-id="su.ivcs.ucim:id/type" and contains(@text, "{type}")]')


