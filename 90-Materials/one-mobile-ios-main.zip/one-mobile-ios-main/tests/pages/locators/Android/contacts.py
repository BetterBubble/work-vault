from tools import i18n

class LContacts:
    @staticmethod
    def L_I18N_TEXTFIELD_HEADER(lang=''):
        return ('id', 'header_text')

    @staticmethod
    def L_I18N_ADD_CONTACT_BUTTON(lang=''):
        return ('id', 'add_icon')

    @staticmethod
    def L_I18N_SEARCH_CONTACT_BUTTON(lang=''):
        return ('id', 'su.ivcs.ucim:id/search_icon')

    @staticmethod
    def L_I18N_SEARCH_CONTACT_INPUT(lang=''):
        return ('id', 'search_text')

    @staticmethod
    def L_I18N_ADD_SEARCHED_CONTACT_BUTTON(lang=''):
        return ('id', 'add_button')

    @staticmethod
    def L_I18N_CLOSE_WINDOW_BUTTON(lang=''):
        return ('id', 'reset_icon')

    @staticmethod
    def L_I18N_PREVIOUSE_STEP_BUTTON(lang=''):
        return ('id', 'su.ivcs.ucim:id/back_icon')

    @staticmethod
    def L_I18N_ADDED_CONTACT_LIST(lang='', contact=''):
        return ('xpath', f'//android.widget.TextView[@resource-id="su.ivcs.ucim:id/name" and @text="{contact}"]')