'''
Экран вкладки Мероприятия
'''
from tools import i18n

class LMeetings:
    @staticmethod
    def L_I18N_TEXTFIELD_MEETINGS(lang=''):
        return ('id', 'su.ivcs.ucim:id/header_text')

    @staticmethod
    def L_I18N_BY_ID_BUTTON(lang=''):
        return ('id', 'su.ivcs.ucim:id/action_icon')

    @staticmethod
    def L_I18N_TEXTFIELD_MEETING_ID(lang=''):
        return ('id', 'su.ivcs.ucim:id/input_field')

    @staticmethod
    def L_I18N_CONNECT_MEETING_BUTTON(lang=''):
        return ('id', 'su.ivcs.ucim:id/accept_button')

    @staticmethod
    def L_I18N_ADD_NEW_MEETING_BUTTON(lang=''):
        return ('id', 'su.ivcs.ucim:id/add_icon')

    @staticmethod
    def L_I18N_MEETING_START_NOW_BUTTON(lang=''):
        i18n_str = i18n.get_str('meeting_start_now_button', lang=lang)
        return ('xpath', f'//android.widget.TextView[@resource-id="su.ivcs.ucim:id/item_text" and @text="{i18n_str}"]')

    @staticmethod
    def L_I18N_MEETING_START_SCHEDULED_BUTTON(lang=''):
        i18n_str = i18n.get_str('meeting_start_scheduled_button', lang=lang)
        return ('xpath', f'//android.widget.TextView[@resource-id="su.ivcs.ucim:id/item_text" and @text="{i18n_str}"]')

    @staticmethod
    def L_I18N_MEETING_TYPE_HD_CONFERENCE(lang=''):
        i18n_str = i18n.get_str('meeting_template_hd_conference', lang=lang)
        return ('xpath', f'//android.widget.TextView[@resource-id="su.ivcs.ucim:id/item_text" and @text="{i18n_str}"]')

    @staticmethod
    def L_I18N_MEETING_TYPE_CAPTION(lang=''):
        i18n_str = i18n.get_str('meeting_template_hd_conference', lang=lang)
        return ('xpath', f'//android.widget.TextView[@resource-id="su.ivcs.ucim:id/conferenceListItemConferenceNameTv" and @text="{i18n_str}"]')

    @staticmethod
    def L_I18N_MEETING_PARTICIPANT(lang='', username=''):
        return ('xpath', f'//android.widget.TextView[@resource-id="su.ivcs.ucim:id/conference_author_name" and @text="{username}"]')

    @staticmethod
    def L_I18N_MEETING_DURATION_ONE_HOUR(lang=''):
        return ('xpath', '//android.widget.TextView[@resource-id="su.ivcs.ucim:id/itemTitleDurationText" and @text="1 ч"]')

    @staticmethod
    def L_I18N_MEETING_START_TIME(lang='', time=''):
        return ('xpath', f'//android.widget.TextView[@resource-id="su.ivcs.ucim:id/itemTitleConferenceStartTimeText" and contains(@text, "{time}")]')

    @staticmethod
    def L_I18N_MEETING_NAME(lang='', meeting_name=''):
        return ('xpath', f'//android.widget.TextView[@resource-id="su.ivcs.ucim:id/conferenceListItemConferenceNameTv" and @text="{meeting_name}"]')

    @staticmethod
    def L_I18N_MEETING_PARTICIPANTS_COUNT(lang=''):
        return ('xpath', '//android.widget.TextView[@resource-id="su.ivcs.ucim:id/conferenceListItemConferenceParticipantsCountTv" and @text="2 участника"]')

    @staticmethod
    def L_I18N_MORE_MENU_BUTTON(lang=''):
        return ('id', 'su.ivcs.ucim:id/dots_icon')

    @staticmethod
    def L_I18N_MEETING_EDIT_MENU_BUTTON(lang=''):
        return ('id', 'su.ivcs.ucim:id/row_text')