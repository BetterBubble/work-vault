from tools import i18n

class LChats:
    @staticmethod
    def L_I18N_TEXTFIELD_HEADER(lang=''):
        return ('id', 'su.ivcs.ucim:id/header_text')

    @staticmethod
    def L_I18N_ADD_NEW_CHAT_BUTTON(lang=''):
        return ('id', 'su.ivcs.ucim:id/add_icon')

    @staticmethod
    def L_I18N_SEARCH_CHAT_INPUT(lang=''):
        return ('xpath', '//android.widget.EditText')

    @staticmethod
    def L_I18N_SELECT_SEARCHED_CONTACT(lang='', contact=''):
        return ('xpath', f'//android.widget.TextView[@text="{contact}"]')

    @staticmethod
    def L_I18N_CLEAR_TEXT_BUTTON(lang=''):
        return ('xpath', '//android.widget.ImageView[@content-desc="Clear"]')

    @staticmethod
    def L_I18N_CONFIRM_ADD_CHAT_BUTTON(lang=''):
        return ('xpath', '//android.view.View[@content-desc="Done"]')

    @staticmethod
    def L_I18N_ADDED_CHAT_LIST(lang='', contact=''):
        return ('xpath', f'//android.widget.TextView[contains(@text, "{contact}")]')

    @staticmethod
    def L_I18N_ADDED_GROUP_CHAT_LIST(lang=''):
        i18_str = i18n.get_str('group_chat_in_list', lang=lang)
        return ('xpath', f'//android.widget.TextView[contains(@text, "{i18_str}")]')

    @staticmethod
    def L_I18N_GROUP_CHAT_CAPTION(lang=''):
        return ('id', 'su.ivcs.ucim:id/extra_info')

    @staticmethod
    def L_I18N_PREVIOUSE_STEP_BUTTON(lang=''):
        return ('id', 'su.ivcs.ucim:id/back_button')

    @staticmethod
    def L_I18N_MAIN_VIDEO_SCREEN(lang=''):
        return ('id', 'su.ivcs.ucim:id/pages_container')

    @staticmethod
    def L_I18N_CHAT_MESSAGE_INPUT(lang=''):
        return ('xpath', '//android.widget.EditText[@resource-id="su.ivcs.ucim:id/text_field"]')

    @staticmethod
    def L_I18N_CHAT_SEND_MESSAGE_BUTTON(lang=''):
        return ('id', 'su.ivcs.ucim:id/send_button')

    @staticmethod
    def L_I18N_CHAT_STATUS_CAPTION_TYPING(lang=''):
        return ('xpath', '//android.widget.TextView[@resource-id="su.ivcs.ucim:id/extra_info"]')

    @staticmethod
    def L_I18N_CHAT_MESSAGE_RECEIVED(lang='', message=''):
        return ('xpath', f'//android.widget.TextView[@resource-id="su.ivcs.ucim:id/message_text" and @text="{message}"]')

    @staticmethod
    def L_I18N_CHAT_MESSAGE_LINK_RECEIVED(lang='', link=''):
        return ('xpath', f'//android.widget.TextView[@resource-id="su.ivcs.ucim:id/message_text" and @text="{link}"]')

    @staticmethod
    def L_I18N_CHAT_ADD_ATTACHMENT_BUTTON(lang=''):
        return ('id', 'su.ivcs.ucim:id/add_attachment_button')

    @staticmethod
    def L_I18N_CHAT_SELECT_LAST_PHOTO_BUTTON(lang=''):
        i18_str = i18n.get_str('chat_select_last_photo_button', lang=lang)
        return ('xpath', f'//android.widget.TextView[@resource-id="android:id/text1" and @text="{i18_str}"]')

    @staticmethod
    def L_I18N_CHAT_SELECT_FILE_BUTTON(lang=''):
        i18_str = i18n.get_str('chat_select_file_button', lang=lang)
        return ('xpath', f'//android.widget.TextView[@resource-id="android:id/text1" and @text="{i18_str}"]')

    @staticmethod
    def L_I18N_CHAT_FILE_TO_SEND(lang=''):
        return ('xpath', '//android.widget.TextView[@resource-id="android:id/title" and @text="instruction.pdf"]')

    @staticmethod
    def L_I18N_CHAT_SEND_ATTACHMENT_BUTTON(lang=''):
        return ('id', 'su.ivcs.ucim:id/upload_button')

    @staticmethod
    def L_I18N_CHAT_PHOTO_SENDING(lang=''):
        return ('xpath', '//android.view.ViewGroup[@resource-id="su.ivcs.ucim:id/attachment_image" and @text="JPEG"]')

    @staticmethod
    def L_I18N_CHAT_VIDEO_SENDING(lang=''):
        return ('xpath', '//android.view.ViewGroup[@resource-id="su.ivcs.ucim:id/attachment_image" and @text="MP4"]')

    @staticmethod
    def L_I18N_CHAT_PHOTO_RECEIVED(lang=''):
        return ('id', 'su.ivcs.ucim:id/attachment_image')

    @staticmethod
    def L_I18N_CHAT_FILE_RECEIVED(lang=''):
        return ('xpath', '//android.widget.TextView[@resource-id="su.ivcs.ucim:id/file_size"]')

    @staticmethod
    def L_I18N_CHAT_FILE_DOWNLOAD_BUTTON(lang=''):
        return ('xpath', '//android.widget.ImageView[@resource-id="su.ivcs.ucim:id/download_button"]')

    @staticmethod
    def L_I18N_CHAT_AVATAR(lang=''):
        return ('id', 'su.ivcs.ucim:id/avatar')

    @staticmethod
    def L_I18N_CHAT_SELECT_VIDEO_TO_SEND(lang=''):
        return ('xpath', '//android.widget.TextView[contains(@text, "mp4")]')

    @staticmethod
    def L_I18N_CHAT_PAUSE_VIDEO_BUTTON(lang=''):
        return ('id', 'su.ivcs.ucim:id/actions_button')

    @staticmethod
    def L_I18N_CHAT_PLAY_VIDEO_BUTTON(lang=''):
        return ('id', 'su.ivcs.ucim:id/attachment_video')

    @staticmethod
    def L_I18N_CHAT_START_VIDEO_CALL_BUTTON(lang=''):
        return ('id', 'su.ivcs.ucim:id/video_call_button')

    @staticmethod
    def L_I18N_CHAT_JOIN_TO_CALL_BUTTON(lang=''):
        return ('id', 'su.ivcs.ucim:id/accept_call_button')

    @staticmethod
    def L_I18N_CHAT_VIDEO_AREA(lang=''):
        # return ('xpath', '//android.view.ViewGroup[@resource-id="su.ivcs.ucim:id/main_surface_container"]')
        return ('id', 'su.ivcs.ucim:id/title_text')

    @staticmethod
    def L_I18N_CHAT_SYSTEM_ANSWER_VIDEO_CALL_BUTTON(lang=''):
        return ('id', 'su.ivcs.ucim:id/accept_call_button')

    @staticmethod
    def L_I18N_CHAT_ADD_PARTICIPANT_TO_CALL_BUTTON(lang=''):
        return ('id', 'su.ivcs.ucim:id/add_people_button')