from tools import i18n


class LHome:
    @staticmethod
    def L_WIDGET_MAIN(lang=''):
        return ('id', 'menu_item_settings')
