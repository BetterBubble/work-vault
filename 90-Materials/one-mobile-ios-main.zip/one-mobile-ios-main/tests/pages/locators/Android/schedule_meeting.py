'''
Экран задания параметров запланированного мероприятия
'''
from tools import i18n

class LScheduleMeeting:
    @staticmethod
    def L_I18N_SCHEDULE_MEETING_HEADER(lang=''):
        i18n_str = i18n.get_str('schedule_meeting_header', lang=lang)
        return ('xpath', f'//android.widget.TextView[@text="{i18n_str}"]')

    @staticmethod
    def L_I18N_SCHEDULE_MEETING_CONFIRM_START_BUTTON(lang=''):
        return ('xpath', '//android.view.View[@content-desc="Done"]')

    @staticmethod
    def L_I18N_SCHEDULE_GOBACK_MEETING_LIST_BUTTON(lang=''):
        return ('id', 'su.ivcs.ucim:id/back_icon')

    @staticmethod
    def L_I18N_SCHEDULE_MEETING_NAME_FIELD(lang=''):
        return ('xpath', f'//android.widget.EditText[1]')

    @staticmethod
    def L_I18N_SCHEDULE_MEETING_AGENDA_FIELD(lang=''):
        return ('xpath', f'//android.widget.EditText[2]')

    @staticmethod
    def L_I18N_SCHEDULE_MEETING_START_DATE(lang=''):
        i18n_str = i18n.get_str('scheduled_meeting_start_date_field', lang=lang)
        return ('xpath', f'//android.widget.TextView[@text="{i18n_str}"]')

    @staticmethod
    def L_I18N_SCHEDULE_MEETING_START_TIME(lang=''):
        i18n_str = i18n.get_str('scheduled_meeting_start_time_field', lang=lang)
        return ('xpath', f'//android.widget.TextView[@text="{i18n_str}"]')

    @staticmethod
    def L_I18N_SCHEDULE_MEETING_END_TIME(lang=''):
        i18n_str = i18n.get_str('scheduled_meeting_end_time_field', lang=lang)
        return ('xpath', f'//android.widget.TextView[@text="{i18n_str}"]')

    @staticmethod
    def L_I18N_SCHEDULE_MEETING_DURATION(lang=''):
        i18n_str = i18n.get_str('scheduled_meeting_duration_field', lang=lang)
        return ('xpath', f'//android.widget.TextView[@text="{i18n_str}"]')

    @staticmethod
    def L_I18N_SCHEDULE_MEETING_TEMPLATE(lang=''):
        i18n_str = i18n.get_str('scheduled_meeting_template_field', lang=lang)
        return ('xpath', f'//android.widget.TextView[@text="{i18n_str}"]')

    @staticmethod
    def L_I18N_SCHEDULE_MEETING_PERIODICITY(lang=''):
        i18n_str = i18n.get_str('scheduled_meeting_periodicity_field', lang=lang)
        return ('xpath', f'//android.widget.TextView[@text="{i18n_str}"]')

    @staticmethod
    def L_I18N_SCHEDULE_MEETING_ADD_PARTICIPANT(lang=''):
        return ('xpath', '//android.view.View[@content-desc="Add participants"]')

    @staticmethod
    def L_I18N_SCHEDULE_MEETING_PARTICIPANTS(lang='', username=''):
        return ('xpath', f'//android.widget.TextView[@text="{username}"]')

    @staticmethod
    def L_I18N_SCHEDULE_MEETING_ADD_PARTICIPANT_INPUT(lang='', username=''):
        return ('xpath', '//android.widget.EditText')

    @staticmethod
    def L_I18N_SELECT_SEARCHED_PARTICIPIANT(lang='', participiant=''):
        return ('xpath', f'//android.widget.TextView[@text="{participiant}"]')

    @staticmethod
    def L_I18N_ADD_NEW_PARTICIPIANT_BUTTON(lang=''):
        return ('xpath', '//android.view.View[@content-desc="Add participants"]')

    @staticmethod
    def L_I18N_CONFIRM_ADD_PARTICIPIANT_BUTTON(lang=''):
        return ('xpath', '//android.view.View[@content-desc="Done"]')

    @staticmethod
    def L_I18N_SCHEDULE_DATE_TIME_PICKER(lang='', time=''):
        return ('xpath', f'//android.widget.EditText[@text="{time}"]')

    @staticmethod
    def L_I18N_SCHEDULE_CONFIRM_SET_TIME_BUTTON(lang='', time=''):
        return ('xpath', '//android.widget.TextView[@text="OK"]')

    @staticmethod
    def L_I18N_SCHEDULE_SET_TIME_KEYBOARD_BUTTON(lang=''):
        return ('xpath', '//android.view.View[@content-desc="Add participants"]')