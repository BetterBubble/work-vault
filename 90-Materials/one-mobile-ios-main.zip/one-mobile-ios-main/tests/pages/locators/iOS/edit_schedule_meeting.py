'''
Экран редактирования параметров запланированного мероприятия
'''
from tools import i18n

class LEditScheduleMeeting:
    @staticmethod
    def L_I18N_EDIT_SCHEDULE_MEETING_HEADER(lang=''):
        i18n_str = i18n.get_str('edit_schedule_meeting_header', lang=lang)
        return ('name', f'{i18n_str}')

    @staticmethod
    def L_I18N_SCHEDULE_MEETING_CONFIRM_START_BUTTON(lang=''):
        i18n_str = i18n.get_str('edit_schedule_meeting_header', lang=lang)
        return ('xpath', f'//*[child::XCUIElementTypeStaticText[@name="{i18n_str}"]]/XCUIElementTypeButton[2]')

    @staticmethod
    def L_I18N_SCHEDULE_GOBACK_MEETING_LIST_BUTTON(lang=''):
        return ('xpath', '//XCUIElementTypeApplication[@name="IVA Connect"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeButton[1]')

    @staticmethod
    def L_I18N_SCHEDULE_MEETING_START_TIME(lang=''):
        i18n_str = i18n.get_str('scheduled_meeting_start_time_field', lang=lang)
        return ('name', f'{i18n_str}')

    @staticmethod
    def L_I18N_SCHEDULE_DATE_TIME_PICKER(lang=''):
        return ('class name', 'XCUIElementTypePickerWheel')