'''
Экран вкладки Мероприятия
'''
from tools import i18n

class LMeetings:
    @staticmethod
    def L_I18N_TEXTFIELD_MEETINGS(lang=''):
        i18n_str = i18n.get_str('bottom_menu_meetings_button', lang=lang)
        return ('xpath', f'//XCUIElementTypeStaticText[@name="{i18n_str}"]')

    @staticmethod
    def L_I18N_BY_ID_BUTTON(lang=''):
        i18n_str = i18n.get_str('bottom_menu_meetings_button', lang=lang)
        return ('xpath', f'//XCUIElementTypeNavigationBar[@name="{i18n_str}"]//XCUIElementTypeButton[1]')

    @staticmethod
    def L_I18N_TEXTFIELD_MEETING_ID(lang=''):
        return ('accessibility id', 'Zero.meetIdInput')

    @staticmethod
    def L_I18N_CONNECT_MEETING_BUTTON(lang=''):
        return ('accessibility id', 'Zero.meetIdJoinButton')

    @staticmethod
    def L_I18N_ADD_NEW_MEETING_BUTTON(lang=''):
        i18n_str = i18n.get_str('bottom_menu_meetings_button', lang=lang)
        return ('xpath', f'//XCUIElementTypeNavigationBar[@name="{i18n_str}"]//XCUIElementTypeButton[2]')

    @staticmethod
    def L_I18N_MEETING_START_NOW_BUTTON(lang=''):
        return ('name', 'Zero.meetStarNowMeetButton')

    @staticmethod
    def L_I18N_MEETING_START_SCHEDULED_BUTTON(lang=''):
        i18n_str = i18n.get_str('meeting_start_scheduled_button', lang=lang)
        return ('name', f'{i18n_str}')

    @staticmethod
    def L_I18N_MEETING_TYPE_HD_CONFERENCE(lang=''):
        i18n_str = i18n.get_str('meeting_template_hd_conference', lang=lang)
        return ('xpath', f'//XCUIElementTypeButton[@label="{i18n_str}"]')

    @staticmethod
    def L_I18N_MEETING_TYPE_CAPTION(lang=''):
        i18n_str = i18n.get_str('meeting_template_hd_conference', lang=lang)
        return ('name', f'{i18n_str}')

    @staticmethod
    def L_I18N_MEETING_PARTICIPANT(lang='', username=''):
        return ('name', f'{username}')

    @staticmethod
    def L_I18N_MEETING_DURATION_ONE_HOUR(lang=''):
        return ('xpath', f'//XCUIElementTypeStaticText[contains(@name, "1 ч")]')

    @staticmethod
    def L_I18N_MEETING_START_TIME(lang='', time=''):
        return ('xpath', f'//XCUIElementTypeStaticText[contains(@name, "{time}")]')

    @staticmethod
    def L_I18N_MEETING_PARTICIPANTS_COUNT(lang=''):
        return ('xpath', '//XCUIElementTypeStaticText[@name="2 участника"]')

    @staticmethod
    def L_I18N_MEETING_NAME(lang='', meeting_name=''):
        return ('name', f'{meeting_name}')

    @staticmethod
    def L_I18N_MORE_MENU_BUTTON(lang=''):
        i18n_str = i18n.get_str('meeting_about_caption', lang=lang)
        return ('xpath', f'//*[child::XCUIElementTypeStaticText[@name="{i18n_str}"]]/XCUIElementTypeButton[2]/XCUIElementTypeButton/XCUIElementTypeOther/XCUIElementTypeImage')

    @staticmethod
    def L_I18N_MEETING_EDIT_MENU_BUTTON(lang=''):
        return ('xpath', '//XCUIElementTypeButton[@name="pencil.line"]')