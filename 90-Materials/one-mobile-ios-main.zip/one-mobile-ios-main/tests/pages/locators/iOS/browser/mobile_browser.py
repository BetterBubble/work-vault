from tools import i18n

class LMobileBrowser:
    @staticmethod
    def L_I18N_CONTINUE_IN_APP_BUTTON(lang=''):
        i18n_str = i18n.get_str('browser_continue_in_app_button', lang)
        return ('xpath', f'//XCUIElementTypeButton[@name="{i18n_str}"]')

    @staticmethod
    def L_I18N_MAIN_PAGE_CAPTION(lang=''):
        i18n_str = i18n.get_str('browser_page_caption', lang)
        return ('xpath', f'//XCUIElementTypeStaticText[@name="{i18n_str}"]')

    @staticmethod
    def L_I18N_OPEN_IN_APP_BUTTON(lang=''):
        i18n_str = i18n.get_str('browser_open_in_app_button', lang)
        return ('xpath', f'//XCUIElementTypeStaticText[@name="{i18n_str}"]')