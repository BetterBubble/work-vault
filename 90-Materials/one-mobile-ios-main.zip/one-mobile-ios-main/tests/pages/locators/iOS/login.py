from tools import i18n


class LLogin:
    @staticmethod
    def L_I18N_TEXTFIELD_LOGIN(lang=''):
        return ('accessibility id', 'Zero.authUsernameInput')

    def L_I18N_BTN_ADFS_LOGIN(lang):
        return ('xpath', '//XCUIElementTypeOther[contains(@name, "BrowserView?IsPageLoaded=true")]//XCUIElementTypeButton[@name="Вход"]')

    @staticmethod
    def L_I18N_TEXTFIELD_PASSWORD(lang=''):
        return ('name', 'Zero.authPasswordInput')

    @staticmethod
    def L_I18N_BTN_LOGIN(lang):
        return ('accessibility id', 'Zero.authLoginButton')

    @staticmethod
    def L_I18N_INCORRECT_LOGIN_DETAILS_MESSAGE(lang):
        i18n_str = i18n.get_str('incorrect_login_details_message', lang)
        return ('xpath', f'//XCUIElementTypeStaticText[@name="{i18n_str}"]')

    @staticmethod
    def L_I18N_SERVERS_BUTTON(lang=''):
        return ('accessibility id', 'id/serversButton')

    @staticmethod
    def L_LOGIN_BY_ADFS_SSO_SERVER1(lang):
        i18n_str = i18n.get_str('login_by_adfs_server1_link', lang)
        return ('xpath', f'//XCUIElementTypeButton[@name="{i18n_str}"]')
