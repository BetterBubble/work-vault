from tools import i18n


class LMeetingLoginInfo:
    @staticmethod
    def L_I18N_ENTER_CONFERENCE_CONTAINER(lang=''):
        i18n_str = i18n.get_str('enter_conference_caption', lang)
        return ('xpath', f'//XCUIElementTypeStaticText[@name="{i18n_str}"]')

    @staticmethod
    def L_I18N_ENTER_CONFERENCE_BUTTON(lang=''):
        return ('accessibility id', 'Zero.meetLinkJoinButton')
