'''
Экран задания параметров запланированного мероприятия
'''
from tools import i18n

class LScheduleMeeting:
    @staticmethod
    def L_I18N_SCHEDULE_MEETING_HEADER(lang=''):
        i18n_str = i18n.get_str('schedule_meeting_header', lang=lang)
        return ('name', f'{i18n_str}')

    @staticmethod
    def L_I18N_SCHEDULE_MEETING_CONFIRM_START_BUTTON(lang=''):
        i18n_str = i18n.get_str('schedule_meeting_header', lang=lang)
        return ('xpath', f'//*[child::XCUIElementTypeStaticText[@name="{i18n_str}"]]/XCUIElementTypeButton[2]')

    @staticmethod
    def L_I18N_SCHEDULE_GOBACK_MEETING_LIST_BUTTON(lang=''):
        return ('xpath', '//XCUIElementTypeApplication[@name="IVA Connect"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeButton[1]')

    @staticmethod
    def L_I18N_SCHEDULE_MEETING_NAME_FIELD(lang=''):
        i18n_str = i18n.get_str('scheduled_meeting_name_field', lang=lang)
        return ('xpath', f'//XCUIElementTypeTextField[@value="{i18n_str}"]')

    @staticmethod
    def L_I18N_SCHEDULE_MEETING_AGENDA_FIELD(lang=''):
        i18n_str = i18n.get_str('scheduled_meeting_agenda_field', lang=lang)
        return ('xpath', f'//XCUIElementTypeStaticText[@label="{i18n_str}"]')

    @staticmethod
    def L_I18N_SCHEDULE_MEETING_START_DATE(lang=''):
        i18n_str = i18n.get_str('scheduled_meeting_start_date_field', lang=lang)
        return ('xpath', f'//XCUIElementTypeButton[contains(@name, "{i18n_str}")]')

    @staticmethod
    def L_I18N_SCHEDULE_MEETING_START_TIME(lang=''):
        i18n_str = i18n.get_str('scheduled_meeting_start_time_field', lang=lang)
        return ('name', f'{i18n_str}')

    @staticmethod
    def L_I18N_SCHEDULE_MEETING_END_TIME(lang=''):
        i18n_str = i18n.get_str('scheduled_meeting_end_time_field', lang=lang)
        return ('name', f'{i18n_str}')

    @staticmethod
    def L_I18N_SCHEDULE_MEETING_DURATION(lang=''):
        i18n_str = i18n.get_str('scheduled_meeting_duration_field', lang=lang)
        return ('name', f'{i18n_str}')

    @staticmethod
    def L_I18N_SCHEDULE_MEETING_TEMPLATE(lang=''):
        i18n_str = i18n.get_str('scheduled_meeting_template_field', lang=lang)
        return ('name', f'{i18n_str}')

    @staticmethod
    def L_I18N_SCHEDULE_MEETING_PERIODICITY(lang=''):
        i18n_str = i18n.get_str('scheduled_meeting_periodicity_field', lang=lang)
        return ('name', f'{i18n_str}')

    @staticmethod
    def L_I18N_SCHEDULE_MEETING_ADD_PARTICIPANT(lang=''):
        return ('name', 'plus')

    @staticmethod
    def L_I18N_SCHEDULE_MEETING_PARTICIPANTS(lang='', username=''):
        return ('name', f'{username}')

    @staticmethod
    def L_I18N_SCHEDULE_MEETING_ADD_PARTICIPANT_INPUT(lang='', username=''):
        i18n_str = i18n.get_str('contacts_chat_search_input', lang=lang)
        return ('xpath', f'//XCUIElementTypeTextField[@value="{i18n_str}"]')

    @staticmethod
    def L_I18N_SELECT_SEARCHED_PARTICIPIANT(lang='', participiant=''):
        return ('xpath', f'//XCUIElementTypeStaticText[@name="{participiant}"]')

    @staticmethod
    def L_I18N_ADD_NEW_PARTICIPIANT_BUTTON(lang=''):
        return ('name', 'plus')

    @staticmethod
    def L_I18N_CONFIRM_ADD_PARTICIPIANT_BUTTON(lang=''):
        i18n_str = i18n.get_str('add_to_call_title', lang=lang)
        return ('xpath', f'//*[child::XCUIElementTypeStaticText[@name="{i18n_str}"]]/XCUIElementTypeButton[2]')

    @staticmethod
    def L_I18N_SCHEDULE_DATE_TIME_PICKER(lang=''):
        return ('class name', 'XCUIElementTypePickerWheel')