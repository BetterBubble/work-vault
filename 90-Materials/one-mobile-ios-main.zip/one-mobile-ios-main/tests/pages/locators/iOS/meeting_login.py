from tools import i18n


class LMeetingLogin:
    @staticmethod
    def L_I18N_ENTER_MEETING_HEADER(lang):
        i18n_str = i18n.get_str('enter_meeting_id_header', lang)
        return ('xpath', f'//XCUIElementTypeStaticText[@name="{i18n_str}"]')


    @staticmethod
    def L_I18N_LOGIN_INPUT(lang=''):
        # Поле логина по гостевой ссылке(есть таба для гостя и для зарегистрированного)
        return ('-ios predicate string', 'type == "XCUIElementTypeTextField"')


    @staticmethod
    def L_I18N_TEXTFIELD_PASSWORD(lang=''):
        return ('-ios predicate string', 'type == "XCUIElementTypeSecureTextField"')

    @staticmethod
    def L_I18N_ENTER_BUTTON(lang=''):
        return ('accessibility id', 'Zero.meetLinkJoinButton')

    @staticmethod
    def L_I18N_REGISTERED_TAB(lang=''):
        i18n_str = i18n.get_str('switch_to_registered_tab', lang)
        return ('xpath', f'//XCUIElementTypeButton[@name="{i18n_str}"]')