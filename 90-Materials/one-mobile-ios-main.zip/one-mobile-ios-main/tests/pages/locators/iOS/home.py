from tools import i18n


class LHome:
    @staticmethod
    def L_WIDGET_MAIN(lang=''):
        i18n_str = i18n.get_str('home_bottom_panel', lang)
        return ('accessibility id', f'{i18n_str}')
