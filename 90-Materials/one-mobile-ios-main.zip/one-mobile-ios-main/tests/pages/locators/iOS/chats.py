from tools import i18n

class LChats:
    @staticmethod
    def L_I18N_TEXTFIELD_HEADER(lang=''):
        i18n_str = i18n.get_str('chats_window_title', lang=lang)
        return ('xpath', f'//XCUIElementTypeStaticText[@name="{i18n_str}"]')

    @staticmethod
    def L_I18N_ADD_NEW_CHAT_BUTTON(lang=''):
        return ('accessibility id', 'CreateChat')

    @staticmethod
    def L_I18N_SEARCH_CHAT_INPUT(lang=''):
        i18n_str = i18n.get_str('contacts_chat_search_input', lang=lang)
        return ('xpath', f'//XCUIElementTypeTextField[@value="{i18n_str}"]')

    @staticmethod
    def L_I18N_SELECT_SEARCHED_CONTACT(lang='', contact=''):
        return ('xpath', f'//XCUIElementTypeStaticText[@name="{contact}"]')

    @staticmethod
    def L_I18N_CLEAR_TEXT_BUTTON(lang=''):
        i18_str = i18n.get_str('contacts_clear_text_button', lang=lang)
        return ('xpath', f'//XCUIElementTypeButton[@name="{i18_str}"]')

    @staticmethod
    def L_I18N_CONFIRM_ADD_CHAT_BUTTON(lang=''):
        i18n_str = i18n.get_str('new_chat_window_title', lang=lang)
        return ('xpath', f'//*[child::XCUIElementTypeStaticText[@name="{i18n_str}"]]/XCUIElementTypeButton[2]')

    @staticmethod
    def L_I18N_ADDED_CHAT_LIST(lang='', contact=''):
        return ('xpath', f'//XCUIElementTypeStaticText[contains(@name, "{contact}")]')

    @staticmethod
    def L_I18N_ADDED_GROUP_CHAT_LIST(lang=''):
        i18_str = i18n.get_str('group_chat_in_list', lang=lang)
        return ('xpath', f'//XCUIElementTypeStaticText[contains(@name, "{i18_str}")]')

    @staticmethod
    def L_I18N_GROUP_CHAT_CAPTION(lang=''):
        i18_str = i18n.get_str('group_chat_members_count_title', lang=lang)
        return ('xpath', f'//XCUIElementTypeStaticText[contains(@name, "{i18_str}")]')

    @staticmethod
    def L_I18N_PREVIOUSE_STEP_BUTTON(lang=''):
        return ('xpath', '//*[child::XCUIElementTypeStaticText[@name="I"]]/XCUIElementTypeButton[1]')

    @staticmethod
    def L_I18N_CHAT_MESSAGE_INPUT(lang=''):
        return ('xpath', '//XCUIElementTypeTextView[not(@value) and not(@label)]')

    @staticmethod
    def L_I18N_CHAT_STATUS_CAPTION_TYPING(lang=''):
        i18_str = i18n.get_str('chat_status_typing_title', lang=lang)
        return ('xpath', f'//XCUIElementTypeStaticText[contains(@name, "{i18_str}")]')

    @staticmethod
    def L_I18N_CHAT_SEND_MESSAGE_BUTTON(lang=''):
        return ('xpath', '//*[child::XCUIElementTypeStaticText[@name="I"]]/XCUIElementTypeButton[7]')

    @staticmethod
    def L_I18N_CHAT_MESSAGE_RECEIVED(lang='', message=''):
        return ('xpath', f'(//XCUIElementTypeStaticText[@name="{message}"])[1]')

    @staticmethod
    def L_I18N_CHAT_MESSAGE_LINK_RECEIVED(lang='', link=''):
        return ('xpath', f'(//XCUIElementTypeStaticText[@name="{link}"])[1]')

    @staticmethod
    def L_I18N_CHAT_ADD_ATTACHMENT_BUTTON(lang=''):
        return ('xpath', '//XCUIElementTypeApplication[@name="IVA Connect"]//XCUIElementTypeButton[position()=6]')

    @staticmethod
    def L_I18N_CHAT_SELECT_LAST_PHOTO_BUTTON(lang=''):
        i18_str = i18n.get_str('chat_select_last_photo_button', lang=lang)
        return ('name', f'{i18_str}')

    @staticmethod
    def L_I18N_CHAT_SEND_ATTACHMENT_PHOTO_BUTTON(lang=''):
        i18_str = i18n.get_str('chat_send_attachment_photo_button', lang=lang)
        return ('xpath', f'//*[child::XCUIElementTypeStaticText[@name="{i18_str}"]]/XCUIElementTypeButton[2]')

    @staticmethod
    def L_I18N_CHAT_SEND_ATTACHMENT_FILE_BUTTON(lang=''):
        i18_str = i18n.get_str('chat_send_attachment_document_button', lang=lang)
        return ('xpath', f'//*[child::XCUIElementTypeStaticText[@name="{i18_str}"]]/XCUIElementTypeButton[2]')

    @staticmethod
    def L_I18N_CHAT_PHOTO_RECEIVED(lang=''):
        return ('xpath', '//XCUIElementTypeCollectionView[@name="Zero.chatMessagesList"]/XCUIElementTypeCell/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeImage[1]')

    @staticmethod
    def L_I18N_CHAT_PHOTO_SENDING(lang=''):
        return ('xpath', '//XCUIElementTypeStaticText[@name="PNG"]')

    @staticmethod
    def L_I18N_CHAT_SELECT_FILE_BUTTON(lang=''):
        i18_str = i18n.get_str('chat_select_document_button', lang=lang)
        return ('xpath', f'//XCUIElementTypeButton[@name="{i18_str}"]')

    @staticmethod
    def L_I18N_CHAT_FILE_TO_SEND(lang=''):
        return ('xpath', '//XCUIElementTypeCell[@name="instruction, pdf"]')

    @staticmethod
    def L_I18N_CHAT_FILE_RECEIVED(lang=''):
        return ('accessibility id', 'instruction.pdf')

    @staticmethod
    def L_I18N_CHAT_FILE_DOWNLOAD_BUTTON(lang=''):
        return ('xpath', '//XCUIElementTypeButton[@name="QLOverlayDefaultActionButtonAccessibilityIdentifier"]')

    @staticmethod
    def L_I18N_DONE_BUTTON(lang=''):
        return ('xpath', '//XCUIElementTypeButton[@name="QLOverlayDoneButtonAccessibilityIdentifier"]')

    @staticmethod
    def L_I18N_CHAT_SELECT_VIDEO_TO_SEND(lang=''):
        return ('xpath', '//XCUIElementTypeOther[contains(@name, "Видео")]/XCUIElementTypeImage[contains(@name, "Видео")]')

    @staticmethod
    def L_I18N_CHAT_CHOOSE_SELECTED_VIDEO_BUTTON(lang=''):
        return ('xpath', '//XCUIElementTypeButton[@name="Done"]')

    @staticmethod
    def L_I18N_CHAT_SELECT_PHOTO_VIDEO_BUTTON(lang=''):
        return ('xpath', '//XCUIElementTypeButton[@name="Фото/Видео"]')

    @staticmethod
    def L_I18N_CHAT_PAUSE_VIDEO_BUTTON(lang=''):
        return ('xpath', '//XCUIElementTypeButton[@name="MediaGalleryModule Pause Norma"]')

    @staticmethod
    def L_I18N_CHAT_PLAY_VIDEO_BUTTON(lang=''):
        return ('xpath', '//XCUIElementTypeCollectionView[@name="Zero.chatMessagesList"]/XCUIElementTypeCell/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeButton')

    @staticmethod
    def L_I18N_CHAT_COME_BACK_FROM_PLAYER_BUTTON(lang=''):
        return ('xpath', '(//XCUIElementTypeButton[@name=" "])[1]')

    @staticmethod
    def L_I18N_CHAT_ACCEPT_FULL_ACCESS_MEDIA_BUTTON(lang=''):
        i18_str = i18n.get_str('chat_accept_full_access_media_button', lang=lang)
        return ('xpath', f'(//XCUIElementTypeButton[@name="{i18_str}"]')

    @staticmethod
    def L_I18N_CHAT_START_VIDEO_CALL_BUTTON(lang=''):
        return ('xpath', '//*[child::XCUIElementTypeStaticText[@name="I"]]/XCUIElementTypeButton[3]')

    @staticmethod
    def L_I18N_CHAT_START_AUDIO_CALL_BUTTON(lang=''):
        return ('name', 'AudioCall_Button_Normal')

    @staticmethod
    def L_I18N_CHAT_ANSWER_CALL_BUTTON(lang=''):
        i18n_str = i18n.get_str('chat_answer_call_button', lang=lang)
        return ('name', f'{i18n_str}')

    @staticmethod
    def L_I18N_CHAT_JOIN_TO_CALL_BUTTON(lang=''):
        return ('name', 'ChatModule_Handset')

    @staticmethod
    def L_I18N_CHAT_SYSTEM_ANSWER_VIDEO_CALL_BUTTON(lang=''):
        return ('xpath', '//XCUIElementTypeButton[@name="Ответить"][1]')

    @staticmethod
    def L_I18N_CHAT_INCOMING_CALL_IMAGE(lang=''):
        return ('name', 'CallUI.Incoming')

    @staticmethod
    def L_I18N_CHAT_START_AUDIO_CALL_BUTTON(lang=''):
        return ('name', 'AudioCall_Button_Normal')

    @staticmethod
    def L_I18N_CHAT_ANSWER_CALL_BUTTON(lang=''):
        i18n_str = i18n.get_str('chat_answer_call_button', lang=lang)
        return ('name', f'{i18n_str}')

    @staticmethod
    def L_I18N_CHAT_JOIN_TO_CALL_BUTTON(lang=''):
        return ('name', 'ChatModule_Handset')

    @staticmethod
    def L_I18N_CHAT_ADD_PARTICIPANT_TO_CALL_BUTTON(lang=''):
        return ('name', 'CallUI.Add.Participant')

    @staticmethod
    def L_I18N_CONFIRM_ADD_TO_CALL_BUTTON(lang=''):
        i18n_str = i18n.get_str('add_to_call_title', lang=lang)
        return ('xpath', f'//*[child::XCUIElementTypeStaticText[@name="{i18n_str}"]]/XCUIElementTypeButton[2]')

    #Иденификаторы кнопки Вкл/выкл камеру отражают текущее ее состояние, не действие!!
    @staticmethod
    def L_I18N_TURN_ON_CAMERA_BUTTON(lang=''):
        return ('name', 'CallUI.Cam.Off')

    @staticmethod
    def L_I18N_TURN_OFF_CAMERA_BUTTON(lang=''):
        return ('name', 'CallUI.Cam.On')

