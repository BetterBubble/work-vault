from tools import i18n


class LPickServer:
    @staticmethod
    def L_I18N_TEXTFIELD_SERVER(lang=''):
        return ('xpath', '//XCUIElementTypeApplication[@name="IVA Connect"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeScrollView/XCUIElementTypeOther[1]/XCUIElementTypeTextField')
        return ('-ios predicate string', 'type == "XCUIElementTypeTextField"')

    @staticmethod
    def L_I18N_BTN_CONTINUE(lang=''):
        i18n_str = i18n.get_str('pick_server_btn_continue', lang)
        return ('-ios class chain', f'**/XCUIElementTypeButton[`label == "{i18n_str}"`]')

    @staticmethod
    def L_I18N_INCORRECT_SERVER_MESSAGE(lang):
        i18n_str = i18n.get_str('not_found_server_message', lang)
        return ('xpath', f'//XCUIElementTypeStaticText[@name="{i18n_str}"]')



