from tools import i18n

class LContacts:
    @staticmethod
    def L_I18N_TEXTFIELD_HEADER(lang=''):
        i18n_str = i18n.get_str('contacts_window_title', lang=lang)
        return ('xpath', f'//XCUIElementTypeStaticText[@name="{i18n_str}"]')

    @staticmethod
    def L_I18N_ADD_CONTACT_BUTTON(lang=''):
        return ('accessibility id', 'Add contact')

    @staticmethod
    def L_I18N_SEARCH_CONTACT_INPUT(lang=''):
        i18n_str = i18n.get_str('contacts_search_input', lang=lang)
        return ('xpath', f'//XCUIElementTypeTextField[@value="{i18n_str}"]')

    @staticmethod
    def L_I18N_ADD_SEARCHED_CONTACT_BUTTON(lang=''):
        return ('xpath', '//XCUIElementTypeCell/XCUIElementTypeImage')

    @staticmethod
    def L_I18N_CLOSE_WINDOW_BUTTON(lang=''):
        i18n_str = i18n.get_str('contacts_cancel_button', lang=lang)
        return ('xpath', f'//XCUIElementTypeButton[@name="{i18n_str}"]')

    @staticmethod
    def L_I18N_ADDED_CONTACT_LIST(lang='', contact=''):
        # i18n_str = i18n.get_str('contacts_cancel_button', lang=lang)
        return ('xpath', f'//XCUIElementTypeStaticText[@name="{contact}"]')