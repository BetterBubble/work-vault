from tools import i18n


class LBottomMenu:
    @staticmethod
    def L_I18N_SETTINGS_BUTTON(lang=''):
        return ('accessibility id', 'Zero.settTabBarButton')

    @staticmethod
    def L_I18N_CONTACTS_BUTTON(lang=''):
        return ('name', 'Контакты')

    @staticmethod
    def L_I18N_CHATS_BUTTON(lang=''):
        return ('accessibility id', 'Чаты')

    @staticmethod
    def L_I18N_MEETINGS_BUTTON(lang=''):
        return ('accessibility id', 'Zero.meetTabBarButton')

    @staticmethod
    def L_I18N_ROOMS_BUTTON(lang=''):
        return ('accessibility id', 'Zero.roomTabBarButton')