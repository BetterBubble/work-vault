from tools import i18n


class LMeeting:
    @staticmethod
    def L_I18N_REJECT_CALL_BUTTON(lang=''):
        #TODO: завести таску на разработчиков
        return ('xpath', '//*[child::XCUIElementTypeButton[@name="MeetupCallOverlay.Menu"]]/XCUIElementTypeButton[8]')

    @staticmethod
    def L_I18N_MAIN_CONTAINER(lang=''):
        return ('xpath', '//*[child::XCUIElementTypeButton[@name="MeetupCallOverlay.Menu"]]')

    @staticmethod
    def L_I18N_CONF_MEMBERS_BUTTON(lang=''):
        return ('accessibility id', 'Zero.meetParticipants')

    @staticmethod
    def L_I18N_USER_ROLE_CAPTION(lang='', role=''):
        return ('xpath', f'//XCUIElementTypeStaticText[@name="{role}"]')