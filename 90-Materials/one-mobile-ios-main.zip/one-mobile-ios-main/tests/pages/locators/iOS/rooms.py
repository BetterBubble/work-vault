'''
Экран вкладки Комнаты
'''
from tools import i18n

class LRooms:
    @staticmethod
    def L_I18N_TEXTFIELD_ROOMS(lang=''):
        i18n_str = i18n.get_str('bottom_menu_rooms_button', lang=lang)
        return ('name', f'{i18n_str}')

    @staticmethod
    def L_I18N_ADD_NEW_ROOM_BUTTON(lang=''):
        i18n_str = i18n.get_str('bottom_menu_rooms_button', lang=lang)
        return ('xpath', f'//XCUIElementTypeNavigationBar[@name="{i18n_str}"]//XCUIElementTypeButton[2]')

    @staticmethod
    def L_I18N_ADD_NEW_PARTICIPIANT_BUTTON(lang=''):
        return ('name', 'plus')

    @staticmethod
    def L_I18N_ROOM_ADD_PARTICIPANT_INPUT(lang='', username=''):
        i18n_str = i18n.get_str('contacts_chat_search_input', lang=lang)
        return ('xpath', f'//XCUIElementTypeTextField[@value="{i18n_str}"]')

    @staticmethod
    def L_I18N_SELECT_SEARCHED_PARTICIPIANT(lang='', participiant=''):
        return ('xpath', f'//XCUIElementTypeStaticText[@name="{participiant}"]')

    @staticmethod
    def L_I18N_CONFIRM_ADD_PARTICIPIANT_BUTTON(lang=''):
        i18n_str = i18n.get_str('add_to_call_title', lang=lang)
        return ('xpath', f'//*[child::XCUIElementTypeStaticText[@name="{i18n_str}"]]/XCUIElementTypeButton[2]')

    @staticmethod
    def L_I18N_SCHEDULE_MEETING_ADD_PARTICIPANT_INPUT(lang='', username=''):
        i18n_str = i18n.get_str('contacts_chat_search_input', lang=lang)
        return ('xpath', f'//XCUIElementTypeTextField[@value="{i18n_str}"]')

    @staticmethod
    def L_I18N_ROOM_NAME_FIELD(lang=''):
        i18n_str = i18n.get_str('room_name_field', lang=lang)
        return ('xpath', f'//XCUIElementTypeTextField[@value="{i18n_str}"]')

    @staticmethod
    def L_I18N_NEW_MEETING_NAME_FIELD(lang=''):
        i18n_str = i18n.get_str('scheduled_meeting_name_field', lang=lang)
        return ('xpath', f'//XCUIElementTypeTextField[@value="{i18n_str}"]')

    @staticmethod
    def L_I18N_ROOM_AGENDA_FIELD(lang=''):
        i18n_str = i18n.get_str('scheduled_meeting_agenda_field', lang=lang)
        return ('xpath', f'//XCUIElementTypeStaticText[@name="Zero.roomDescriptionInput" and @label="{i18n_str}"]')

    @staticmethod
    def L_I18N_ROOM_CONFIRM_CREATE_BUTTON(lang=''):
        return ('accessibility id', 'Zero.roomCreateButtonCheckMark')

    @staticmethod
    def L_I18N_GOBACK_ROOMS_LIST_BUTTON(lang=''):
        return ('xpath', '//XCUIElementTypeApplication[@name="IVA Connect"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeButton[1]')

    @staticmethod
    def L_I18N_ROOM_PARTICIPANT(lang='', username=''):
        return ('name', f'{username}')

    @staticmethod
    def L_I18N_ROOM_NAME_CAPTION(lang='', name=''):
        return ('name', f'{name}')

    @staticmethod
    def L_I18N_ROOM_AGENDA_CAPTION(lang='', agenda=''):
        return ('name', f'{agenda}')

    @staticmethod
    def L_I18N_ROOM_TYPE_CAPTION(lang='', type=''):
        return ('name', f'{type}')

    @staticmethod
    def L_I18N_ENTER_ROOM_BUTTON(lang=''):
        return ('accessibility id', 'Zero.meetEnterButton')

    @staticmethod
    def L_I18N_LEAVE_ROOM_BUTTON(lang='', agenda=''):
        return ('xpath', '//XCUIElementTypeApplication[@name="IVA Connect"]//XCUIElementTypeButton[position()=8]')

    @staticmethod
    def L_I18N_OPEN_EXISTING_ROOM_ITEM(lang='', room_name=''):
        return ('name', f'{room_name}')

    @staticmethod
    def L_I18N_ROOM_ACTIONS_BUTTON(lang=''):
        i18n_str = i18n.get_str('about_room_caption', lang=lang)
        return ('xpath',
                f'//*[child::XCUIElementTypeStaticText[@name="{i18n_str}"]]/XCUIElementTypeButton[2]//XCUIElementTypeImage')

    @staticmethod
    def L_I18N_DELETE_ROOM_BUTTON(lang=''):
        return ('accessibility id', 'Zero.meetInfoDeleteButton')

    @staticmethod
    def L_I18N_CONFIRM_DELETE_ROOM_BUTTON(lang=''):
        return ('accessibility id', 'Zero.meetInfoDeleteConfirmatationButton')
