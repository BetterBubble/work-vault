from tools import i18n


class LViewSettingsList:
    @staticmethod
    def L_I18N_HEADER_SETTINGS(lang):
        i18n_str = i18n.get_str('header_settings', lang)
        return ('xpath', f'//XCUIElementTypeStaticText[@name="{i18n_str}"]')

    @staticmethod
    def L_I18N_CHANGE_PASSWORD_BUTTON(lang):
        i18n_str = i18n.get_str('profile_change_password_button', lang)
        return ('xpath', f'//XCUIElementTypeStaticText[@name="{i18n_str}"]')

    @staticmethod
    def L_I18N_EDIT_PROFILE_BUTTON(lang=''):
        return ('xpath', '//XCUIElementTypeImage[@name="Edit"]')