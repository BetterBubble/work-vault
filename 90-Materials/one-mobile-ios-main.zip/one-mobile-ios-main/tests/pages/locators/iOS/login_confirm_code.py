from tools import i18n


class LLoginConfirmCodePage:
    @staticmethod
    def L_I18N_LOGIN_WINDOW_TITLE(lang):
        i18n_str = i18n.get_str('login_window_title', lang)
        return ('xpath', f'//XCUIElementTypeStaticText[@name="{i18n_str}"]')

    @staticmethod
    def L_I18N_CONFIRM_CODE_INPUT(lang):
        return ('xpath', '//XCUIElementTypeTextField')

    @staticmethod
    def L_I18N_CONFIRM_CODE_SEND_MESSAGE(lang):
        i18n_str = i18n.get_str('confirm_code_send_message', lang)
        return ('xpath', f'//XCUIElementTypeStaticText[@name="{i18n_str} "]')

    @staticmethod
    def L_I18N_INFO_MAIL_TEXT(lang=''):
        return ('xpath', '//XCUIElementTypeStaticText[@name="iva***@dropjar.com"]')

    @staticmethod
    def L_I18N_RESEND_CODE_AFTER_MESSAGE(lang=''):
        i18n_str = i18n.get_str('resend_code_after_message', lang)
        return ('-ios predicate string', f'name BEGINSWITH[c] "{i18n_str}"')

    @staticmethod
    def L_I18N_ENTER_BUTTON(lang=''):
        return ('accessibility id', 'Zero.authLoginButton')

    @staticmethod
    def L_I18N_BACK_PREVIOUS_STEP(lang):
        i18n_str = i18n.get_str('back_previous_step', lang)
        return ('xpath', f'//XCUIElementTypeButton[@name="{i18n_str}"]')

    @staticmethod
    def L_I18N_INVALID_CODE_MESSAGE(lang):
        i18n_str = i18n.get_str('invalid_code_message', lang)
        return ('xpath', f'//XCUIElementTypeStaticText[@name="{i18n_str}"]')
