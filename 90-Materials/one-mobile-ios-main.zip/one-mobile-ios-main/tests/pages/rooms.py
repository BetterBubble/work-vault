from .base import _PBase
from .locators import Android as AndroidLocators
from .locators import iOS as iOSLocators
from autocore.test.logger import get_log
from datetime import datetime

log = get_log()

class _PBaseRooms(_PBase):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_I18N_TEXTFIELD_ROOMS(self.lang)
        super().__init__(*args, **kwargs)

    def create_new_room(self):
        log.step('Создадим комнату', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_ADD_NEW_ROOM_BUTTON(self.lang)).click()

    def open_existing_room(self, room_name):
        log.step(f'Откроем комнату {room_name}', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_OPEN_EXISTING_ROOM_ITEM(self.lang, room_name)).click()

    def delete_existing_room(self, room_name):
        log.step(f'Удалим комнату {room_name}', where='IVA Mobile Клиент')
        self.open_existing_room(room_name)
        self.get_object(self.L_I18N_ROOM_ACTIONS_BUTTON(self.lang)).click()
        self.get_object(self.L_I18N_DELETE_ROOM_BUTTON(self.lang)).click()
        self.get_object(self.L_I18N_CONFIRM_DELETE_ROOM_BUTTON(self.lang)).click()

    def fill_room_params_and_create(self, name='', agenda='', participiant=''):
        log.step(f'Добавим участника: {participiant}', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_ADD_NEW_PARTICIPIANT_BUTTON(self.lang)).click()
        self.get_object(self.L_I18N_SCHEDULE_MEETING_ADD_PARTICIPANT_INPUT(self.lang)).send_keys(participiant)
        self.get_object(self.L_I18N_SELECT_SEARCHED_PARTICIPIANT(self.lang, participiant)).click()
        self.get_object(self.L_I18N_CONFIRM_ADD_PARTICIPIANT_BUTTON(self.lang)).click()
        self.check_room_participants_list_present(participiant)

        log.step(f'Зададим название комнаты: {name}', where='IVA Mobile Клиент')
        self.clear_input(locator=self.L_I18N_ROOM_NAME_FIELD(self.lang))
        self.get_object(self.L_I18N_NEW_MEETING_NAME_FIELD(self.lang)).send_keys(name)
        log.step(f'Зададим повестку комнаты: {agenda}', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_ROOM_AGENDA_FIELD(self.lang)).send_keys(agenda)
        log.step('Подтвердим создание комнаты', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_ROOM_CONFIRM_CREATE_BUTTON(self.lang)).click()


    def join_room(self):
        self.get_object(self.L_I18N_ENTER_ROOM_BUTTON(self.lang)).click()

    def leave_room(self):
        self.get_object(self.L_I18N_LEAVE_ROOM_BUTTON(self.lang)).click()


    def check_room_participants_list_present(self, username=''):
        self.assert_presence(locator=self.L_I18N_ROOM_PARTICIPANT(self.lang, username),
                             message=f"Участник {username} присутствует в комнате")

    def check_room_name_present(self, name=''):
        self.assert_presence(locator=self.L_I18N_ROOM_NAME_CAPTION(self.lang, name),
                             message=f"Присутствует название комнаты")

    def check_room_absense(self, name=''):
        self.assert_absense(locator=self.L_I18N_ROOM_NAME_CAPTION(self.lang, name),
                             message=f"Комната отсутствует в списке")

    def check_room_agenda_present(self, agenda=''):
        self.assert_presence(locator=self.L_I18N_ROOM_AGENDA_CAPTION(self.lang, agenda),
                             message=f"Присутствует описание комнаты")

    def check_room_type(self, type=''):
        self.assert_presence(locator=self.L_I18N_ROOM_TYPE_CAPTION(self.lang, type),
                             message=f"Присутствует тип комнаты")


class PAndroidRooms(_PBaseRooms, AndroidLocators.LRooms):
    pass

class PIOSRooms(_PBaseRooms, iOSLocators.LRooms):
    pass