from .login import PAndroidLogin
from .login import PIOSLogin
from .home import PAndroidHome
from .home import PIOSHome
from .meetings import PIOSMeetings
from .meetings import PAndroidMeetings
from .pick_server import PIOSPickServer
from .pick_server import PAndroidPickServer
from .server_selection_popup import PAndroidServerSelectionPopup
from .server_selection_popup import PIOSServerSelectionPopup
from .view_settings_list import PAndroidViewSettingsList
from .view_settings_list import PIOSViewSettingsList
from .login_confirm_code import PAndroidLoginConfirmCodePage
from .login_confirm_code import PIOSLoginConfirmCodePage
from .meeting_login_info import PAndroidMeetingLoginInfo
from .meeting_login_info import PIOSMeetingLoginInfo
from .meeting_login import PIOSMeetingLogin
from .meeting_login import PAndroidMeetingLogin
from .meeting import PAndroidMeeting
from .meeting import PIOSMeeting
from .contacts import PAndroidContacts
from .contacts import PIOSContacts
from .chats import PIOSChats
from .chats import PAndroidChats
from .chat_about import PAndroidChatAbout
from .schedule_meeting import PIOSScheduleMeeting
from .schedule_meeting import PAndroidScheduleMeeting
from .edit_schedule_meeting import PIOSEditScheduleMeeting
from .edit_schedule_meeting import PAndroidEditScheduleMeeting
from .rooms import PIOSRooms
from .rooms import PAndroidRooms


def get_page(platform, page_name):
    if platform == 'Android':
        if page_name == 'pick_server':
            return PAndroidPickServer
        if page_name == 'login':
            return PAndroidLogin
        if page_name == 'home':
            return PAndroidHome
        if page_name == 'server_selection_popup':
            return PAndroidServerSelectionPopup
        if page_name == 'view_settings_list':
            return PAndroidViewSettingsList
        if page_name == 'login_confirm_code':
            return PAndroidLoginConfirmCodePage
        if page_name == 'meeting_login_info':
            return PAndroidMeetingLoginInfo
        if page_name == 'meeting_login':
            return PAndroidMeetingLogin
        if page_name == 'meeting':
            return PAndroidMeeting
        if page_name == 'contacts':
            return PAndroidContacts
        if page_name == 'chats':
            return PAndroidChats
        if page_name == 'chat_about':
            return PAndroidChatAbout
        if page_name == 'meetings':
            return PAndroidMeetings
        if page_name == 'schedule_meeting':
            return PAndroidScheduleMeeting
        if page_name == 'edit_schedule_meeting':
            return PAndroidEditScheduleMeeting
        if page_name == 'rooms':
            return PAndroidRooms
    if platform == 'iOS':
        if page_name == 'pick_server':
            return PIOSPickServer
        if page_name == 'login':
            return PIOSLogin
        if page_name == 'home':
            return PIOSHome
        if page_name == 'server_selection_popup':
            return PIOSServerSelectionPopup
        if page_name == 'login_confirm_code':
            return PIOSLoginConfirmCodePage
        if page_name == 'view_settings_list':
            return PIOSViewSettingsList
        if page_name == 'contacts':
            return PIOSContacts
        if page_name == 'chats':
            return PIOSChats
        if page_name == 'meeting_login_info':
            return PIOSMeetingLoginInfo
        if page_name == 'meeting_login':
            return PIOSMeetingLogin
        if page_name == 'meeting':
            return PIOSMeeting
        if page_name == 'meetings':
            return PIOSMeetings
        if page_name == 'schedule_meeting':
            return PIOSScheduleMeeting
        if page_name == 'edit_schedule_meeting':
            return PIOSEditScheduleMeeting
        if page_name == 'rooms':
            return PIOSRooms