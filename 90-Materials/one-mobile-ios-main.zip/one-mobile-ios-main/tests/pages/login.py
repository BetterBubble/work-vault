from .base import _PBase
from .locators import Android as AndroidLocators
from .locators import iOS as iOSLocators
from autocore.test.logger import get_log
from autocore.test.assertions import assert_fn
from autocore.test.generate_data import get_random_string
from autocore.test.generate_data import get_random_int
import time

log = get_log()


class _PBaseLogin(_PBase):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_I18N_TEXTFIELD_LOGIN(self.lang)
        super().__init__(*args, **kwargs)

    def login(self, username='', password=''):
        log.step('Авторизоваться', where='IVA Mobile Клиент')
        log.info(f'Логин: {username}, пароль: {password}')
        self.decline_update_app()
        self.clear_input(locator=self.L_I18N_TEXTFIELD_LOGIN(self.lang))
        self.get_object(self.L_I18N_TEXTFIELD_LOGIN(self.lang)).send_keys(username)
        self.get_object(self.L_I18N_TEXTFIELD_PASSWORD(self.lang)).click()
        self._enter_password(password)
        self.get_object(self.L_I18N_BTN_LOGIN(self.lang)).click()

        self.accept_alerts(alerts=3)
        self.decline_update_app()

    def assert_incorrect_login_details_message(self):
        self.assert_presence(locator=self.L_I18N_INCORRECT_LOGIN_DETAILS_MESSAGE(self.lang),
                             message="Отображение сообщения о некорректном вводе логина или пароля")

    def open_server_select_popup(self):
        log.step('Открыть pop-up выбора сервера', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_SERVERS_BUTTON(self.lang)).click()

    def check_server_correct(self, server_name):
        get_server_name = self.get_object(self.L_I18N_HEADER_SERVER_NAME(self.lang)).text
        assert_fn(lambda: server_name in get_server_name, f'Соответствие выбранного сервера {get_server_name} фактическому {server_name}')

    def assert_number_failed_attempts_exceeded_message(self):
        self.assert_presence(locator=self.L_I18N_NUMBER_FAILED_ATTEMPTS_EXCEEDED_MESSAGE(self.lang),
                             message="Отображение сообщения о превышении числа неудачных попыток ввода")

    def try_login_incorrect_password(self, number_times, username):
        for i in range(number_times):
            self.login(username, get_random_string(5))
            self.assert_incorrect_login_details_message()
        self.login(username, get_random_string(8))
        self.assert_number_failed_attempts_exceeded_message()

    def click_login_by_id_link(self):
        self.get_object(self.L_I18N_LOGIN_BY_ID_LINK()).click()

    def login_by_id(self, meeting_id):
        input = self.get_object(self.L_I18N_MEETING_ID_INPUT())
        input.send_keys(meeting_id)
        self.get_object(self.L_I18N_LOGIN_BY_ID_BTN()).click()

    def assert_incorrect_meeting_id_message(self):
        self.assert_presence(locator=self.L_I18N_INCORRECT_MEETING_ID_MESSAGE(self.lang),
                             message="Отображение сообщения о некорректном вводе логина или пароля")

    def check_incorrect_meeting_id(self):
        log.step('Проверить ввеод неверного ID мероприятия', where='IVA Mobile Клиент')
        self.click_login_by_id_link()
        self.login_by_id(get_random_int(6))
        self.assert_incorrect_meeting_id_message()


class PAndroidLogin(_PBaseLogin, AndroidLocators.LLogin):
    def _enter_password(self, password=''):
        self.get_object(self.L_I18N_TEXTFIELD_PASSWORD(self.lang)).send_keys(password)

    def login_adfs(self, username, password):
        log.step('Авторизоваться через ADFS', where='IVA Mobile Клиент')
        log.info(f'Логин: {username}, пароль: {password}')
        self.get_object(self.L_LOGIN_BY_ADFS_SSO_SERVER1(self.lang)).click()

        # эти объекты - часть стандартного интерфейса, не относящегося к нашему приложению
        # им не нужно быть в отдельном файле локаторов
        self.get_object(('xpath', '//*[@resource-id="android:id/button1"]')).click()
        self.get_object(('xpath', '//*[@resource-id="userNameInput"]')).send_keys(username)
        self.get_object(('xpath', '//*[@resource-id="passwordInput"]')).send_keys(password)
        self.get_object(('xpath', '//*[@resource-id="submitButton"]')).click()

    def accept_alerts(self, alerts=3):
        for _ in range(alerts):
            try:
                self.get_object(('xpath', '//android.widget.Button[@text="ОТМЕНА"]'),
                                timeout=1).click()
            except:
                log.info('No alert window found')

            else:
                log.step('Accept Android alert', where='IVA Mobile Клиент')

    def decline_update_app(self):
        pass

    def accept_wireless_data(self):
        pass


class PIOSLogin(_PBaseLogin, iOSLocators.LLogin):
    def _enter_password(self, password=''):
        # Вводим пароль по буквам, ввиду того, что iOS либо блокирует либо по особенному обрабатывает быстрый ввод в SecureTextField
        password_input = self.get_object(self.L_I18N_TEXTFIELD_PASSWORD(self.lang))
        for letter in password:
            password_input.send_keys(letter)
            time.sleep(.2)

    def login_adfs(self, username, password):
        log.step('Авторизоваться через ADFS', where='IVA Mobile Клиент')
        log.info(f'Логин: {username}, пароль: {password}')
        self.get_object(self.L_LOGIN_BY_ADFS_SSO_SERVER1(self.lang)).click()
        st_time = time.time()
        while time.time() - st_time < 5:
            # iteratively call driver.context
            # somehow only after several calls webview appears in list of contexts
            if len(self.driver.contexts) > 1:
                web_view_possible = True
                break
            time.sleep(1)
        else:
            web_view_possible = False
        if web_view_possible: #17.2
            # to webview
            self.driver.switch_to.context(self.driver.contexts[-1])
            l_login = ('xpath', '//input[@id="userNameInput"]')
            l_password = ('xpath', '//input[@id="passwordInput"]')
            l_enter = ('xpath', '//*[@id="submitButton"]')
        else: #iOS 18.1
            try:
                log.info('Try accept untrusted site')
                self.get_object('name', 'Подробнее').click()
                self.get_object('name', 'посетить этот веб‑сайт').click()
                self.get_object('name', 'Посетить веб‑сайт').click()
            except:
                log.info('we already been there')

            l_login = ('xpath', '//XCUIElementTypeOther[contains(@name, "BrowserView?IsPageLoaded=true")]//XCUIElementTypeTextField')
            l_password = ('xpath', '//XCUIElementTypeOther[contains(@name, "BrowserView?IsPageLoaded=true")]//XCUIElementTypeSecureTextField')
            l_enter = ('xpath', '//XCUIElementTypeOther[contains(@name, "BrowserView?IsPageLoaded=true")]//XCUIElementTypeButton[@name="Вход"]')
        self.get_object(l_password).send_keys(password)
        self.get_object(l_login).send_keys(username)
        self.get_object(l_enter).click()
        web_view_possible and self.driver.switch_to.context('NATIVE_APP')
        self.accept_alerts()

    def accept_alerts(self, alerts=3):
        for _ in range(alerts):
            try:
                # it takes a some time for the popup is appear, let's wait
                time.sleep(1)
                self.driver.switch_to.alert.accept()
            except:
                log.info('No alert window found')
            else:
                log.step('Accept iOS alert', where='IVA Mobile Клиент')

    def decline_update_app(self):
        if self.driver.is_real_device:
            try:
                self.driver.switch_to.alert.dismiss()
            except:
                log.info('No update app window found')
