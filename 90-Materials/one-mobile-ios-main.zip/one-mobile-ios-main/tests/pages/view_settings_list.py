from .base import _PBase
from .locators import Android as AndroidLocators
from .locators import iOS as iOSLocators
from autocore.test.logger import get_log
from tests import pages
from autocore.test.assertions import assert_fn

log = get_log()


class _PBaseViewSettingsList(_PBase):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_I18N_HEADER_SETTINGS(self.lang)
        super().__init__(*args, **kwargs)

    def check_password_edit_disabled(self):
        log.step('Проверить отсутствие кнопки "Изменить пароль"', where='IVA Mobile Клиент')
        change_password_absence = self.wait_absence(self.L_I18N_CHANGE_PASSWORD_BUTTON(self.lang))
        assert_fn(lambda: change_password_absence is True, 'Кнопка "Изменить пароль" отсутствует.')

    def check_edit_profile_button_disabled(self):
        log.step('Проверить отсутствие кнопки редактирования профиля пользователя', where='IVA Mobile Клиент')
        edit_profile_absence = self.wait_absence(self.L_I18N_EDIT_PROFILE_BUTTON())
        assert_fn(lambda: edit_profile_absence is True, 'Кнопка редактирования данных профиля отсутствует.')

    def check_user_cant_edit_profile(self):
        self.check_password_edit_disabled()
        self.check_edit_profile_button_disabled()


class PAndroidViewSettingsList(_PBaseViewSettingsList, AndroidLocators.LViewSettingsList):
    pass


class PIOSViewSettingsList(_PBaseViewSettingsList, iOSLocators.LViewSettingsList):
    pass
