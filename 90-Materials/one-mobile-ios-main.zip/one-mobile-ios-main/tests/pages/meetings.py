from .base import _PBase
from .locators import Android as AndroidLocators
from .locators import iOS as iOSLocators
from autocore.test.logger import get_log
from datetime import datetime

log = get_log()

class _PBaseMeetings(_PBase):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_I18N_TEXTFIELD_MEETINGS(self.lang)
        super().__init__(*args, **kwargs)

    def login_by_id(self):
        log.step('Войдем по ID', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_BY_ID_BUTTON(self.lang)).click()

    def connect_to_meeting_by_id(self, meeting_id=''):
        log.step(f'Введем ID: {meeting_id} и подключимся', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_TEXTFIELD_MEETING_ID(self.lang)).send_keys(meeting_id)
        self.get_object(self.L_I18N_CONNECT_MEETING_BUTTON(self.lang)).click()

    def create_new_instant_meeting(self):
        log.step('Создадим мгновенное мероприятие по шаблону HD Conference', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_ADD_NEW_MEETING_BUTTON(self.lang)).click()
        self.get_object(self.L_I18N_MEETING_START_NOW_BUTTON(self.lang)).click()
        self.get_object(self.L_I18N_MEETING_TYPE_HD_CONFERENCE(self.lang)).click()
        time = datetime.now().strftime('%H:%M')
        log.info(f'Время создания мероприятия: {time}')
        return time

    def create_new_scheduled_meeting(self):
        log.step('Создадим запланированное мероприятие по шаблону HD Conference', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_ADD_NEW_MEETING_BUTTON(self.lang)).click()
        self.get_object(self.L_I18N_MEETING_START_SCHEDULED_BUTTON(self.lang)).click()

    def check_meeting_start_time(self, real_start_time=''):
        self.assert_presence(locator=self.L_I18N_MEETING_START_TIME(self.lang, real_start_time),
                             message=f"Время начала мероприятия {real_start_time} соответствует фактическому")

    def check_is_hd_conference(self):
        self.assert_presence(locator=self.L_I18N_MEETING_TYPE_CAPTION(self.lang),
                             message="Мероприятие по шаблону HD Conference")

    def check_meeting_duration(self):
        self.assert_presence(locator=self.L_I18N_MEETING_DURATION_ONE_HOUR(self.lang),
                             message=f"Продолжительность мероприятия 1 час")

    def check_organizer_present(self, username=''):
        self.assert_presence(locator=self.L_I18N_MEETING_PARTICIPANT(self.lang, username),
                             message=f"Организатор мероприятия: {username}")

    def check_participants_count(self):
        self.assert_presence(locator=self.L_I18N_MEETING_PARTICIPANTS_COUNT(self.lang),
                             message=f"Количество участников: 2")

    def check_meeting_name_is(self, meeting_name=''):
        self.assert_presence(locator=self.L_I18N_MEETING_NAME(self.lang, meeting_name),
                             message=f"Название мероприятия: {meeting_name}")

    def open_and_edit_existing_meeting(self, meeting_name=''):
        log.step(f'Откроем мероприятие {meeting_name} для редактирования', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_MEETING_NAME(self.lang, meeting_name)).click()
        self.get_object(self.L_I18N_MORE_MENU_BUTTON(self.lang)).click()
        self.get_object(self.L_I18N_MEETING_EDIT_MENU_BUTTON(self.lang)).click()

class PAndroidMeetings(_PBaseMeetings, AndroidLocators.LMeetings):
    pass

class PIOSMeetings(_PBaseMeetings, iOSLocators.LMeetings):
    pass