'''
Экран редактирования параметров запланированного мероприятия
'''

from .base import _PBase
from .locators import Android as AndroidLocators
from .locators import iOS as iOSLocators
from autocore.test.logger import get_log
from datetime import datetime, timedelta

log = get_log()

class _PBaseEditScheduleMeeting(_PBase):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_I18N_EDIT_SCHEDULE_MEETING_HEADER(self.lang)
        super().__init__(*args, **kwargs)

    def change_start_time(self):
        log.step(f'Изменим время начала мероприятия: установленное + 1 час', where='IVA Mobile Клиент')
        self._set_start_meeting_time()
        log.step('Подтвердим изменение мероприятия', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_SCHEDULE_MEETING_CONFIRM_START_BUTTON(self.lang)).click()
        log.step('Вернемся к списку мероприятий', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_SCHEDULE_GOBACK_MEETING_LIST_BUTTON(self.lang)).click()


class PAndroidEditScheduleMeeting(_PBaseEditScheduleMeeting, AndroidLocators.LEditScheduleMeeting):
    def _set_start_meeting_time(self):
        self.get_object(self.L_I18N_SCHEDULE_MEETING_START_TIME(self.lang)).click()
        self.get_object(self.L_I18N_SCHEDULE_SET_TIME_KEYBOARD_BUTTON(self.lang)).click()
        time_picker = self.get_object(self.L_I18N_SCHEDULE_DATE_TIME_PICKER(self.lang))
        current_hour = int(time_picker.text)

        next_hour = (current_hour + 1) % 24

        formatted_next_hour = f"{next_hour:02d}"

        time_picker.clear()
        time_picker.set_value(formatted_next_hour)
        self.get_object(self.L_I18N_SCHEDULE_CONFIRM_SET_TIME_BUTTON(self.lang)).click()


class PIOSEditScheduleMeeting(_PBaseEditScheduleMeeting, iOSLocators.LEditScheduleMeeting):
    def _set_start_meeting_time(self):
        self.get_object(self.L_I18N_SCHEDULE_MEETING_START_TIME(self.lang)).click()
        time_picker = self.get_object(self.L_I18N_SCHEDULE_DATE_TIME_PICKER(self.lang))

        current_hour = int(time_picker.text.split(":")[-1])

        # Вычисляем следующий час с учетом перехода через midnight
        next_hour = (current_hour + 1) % 24

        # Форматируем час с ведущим нулем (например, "04" вместо "4")
        formatted_next_hour = f"{next_hour:02d}"

        time_picker.set_value(formatted_next_hour)
        self.driver.execute_script('mobile: scroll', {'direction': 'down'})