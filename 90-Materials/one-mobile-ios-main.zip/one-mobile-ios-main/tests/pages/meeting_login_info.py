from .base import _PBase
from .locators import Android as AndroidLocators
from .locators import iOS as iOSLocators
from autocore.test.logger import get_log

log = get_log()


class _PBaseMeetingLoginInfo(_PBase):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_I18N_ENTER_CONFERENCE_CONTAINER(self.lang)
        super().__init__(*args, **kwargs)

    def click_enter_conference_button(self):
        log.step('Перейти на страницу логина в мероприятие', where='IVA Mobile Клиент')
        self.accept_alerts()
        self.get_object(self.L_I18N_ENTER_CONFERENCE_BUTTON(self.lang), wait_clickable=True).click()


class PAndroidMeetingLoginInfo(_PBaseMeetingLoginInfo, AndroidLocators.LMeetingLoginInfo):
    def accept_alerts(self, alerts=3):
        for _ in range(alerts):
            try:
                self.get_object(('xpath', '//android.widget.Button[@text="ОТМЕНА"]'),
                                timeout=1).click()
            except:
                log.info('No alert window found')

            else:
                log.step('Accept Android alert', where='IVA Mobile Клиент')


class PIOSMeetingLoginInfo(_PBaseMeetingLoginInfo, iOSLocators.LMeetingLoginInfo):
    def accept_alerts(self, alerts=3):
        # Разрешим отправку уведомлений, доступ к микрофону и камере
        for _ in range(alerts):
            try:
                self.driver.switch_to.alert.accept()
            except:
                log.info('No alert window found')
            else:
                log.step('Accept alert', where='IVA Mobile Клиент')