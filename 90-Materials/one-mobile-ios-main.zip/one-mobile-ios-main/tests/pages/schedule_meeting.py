import time
from datetime import datetime

from .base import _PBase
from .locators import Android as AndroidLocators
from .locators import iOS as iOSLocators
from autocore.test.logger import get_log
from datetime import datetime, timedelta, time

log = get_log()

class _PBaseScheduleMeeting(_PBase):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_I18N_SCHEDULE_MEETING_HEADER(self.lang)
        super().__init__(*args, **kwargs)

    def check_meeting_name_present(self):
        self.assert_presence(locator=self.L_I18N_SCHEDULE_MEETING_NAME_FIELD(self.lang),
                             message=f"Присутствует поле Название мероприятия")

    def check_meeting_agenda_present(self):
        self.assert_presence(locator=self.L_I18N_SCHEDULE_MEETING_AGENDA_FIELD(self.lang),
                             message=f"Присутствует поле Повестка мероприятия")

    def check_meeting_start_date_present(self):
        self.assert_presence(locator=self.L_I18N_SCHEDULE_MEETING_START_DATE(self.lang),
                             message=f"Присутствует поле Дата начала")

    def check_meeting_start_time_present(self):
        self.assert_presence(locator=self.L_I18N_SCHEDULE_MEETING_START_TIME(self.lang),
                             message=f"Присутствует поле Время начала")

    def check_meeting_end_time_present(self):
        self.assert_presence(locator=self.L_I18N_SCHEDULE_MEETING_END_TIME(self.lang),
                             message=f"Присутствует поле Время окончания")

    def check_meeting_duratiun_present(self):
        self.assert_presence(locator=self.L_I18N_SCHEDULE_MEETING_DURATION(self.lang),
                             message=f"Присутствует поле Длительность")

    def check_meeting_template_present(self):
        self.assert_presence(locator=self.L_I18N_SCHEDULE_MEETING_TEMPLATE(self.lang),
                             message=f"Присутствует поле Шаблон")

    def check_meeting_periodicity_present(self):
        self.assert_presence(locator=self.L_I18N_SCHEDULE_MEETING_TEMPLATE(self.lang),
                             message=f"Присутствует поле Периодичность")

    def check_meeting_participant_add_present(self):
        self.assert_presence(locator=self.L_I18N_SCHEDULE_MEETING_ADD_PARTICIPANT(self.lang),
                             message=f"Присутствует кнопка Добавить участников")

    def check_meeting_participants_list_present(self, username=''):
        self.assert_presence(locator=self.L_I18N_SCHEDULE_MEETING_PARTICIPANTS(self.lang, username),
                             message=f"Присутствует список участников")

    def fill_scheduled_meeting_params_and_start(self, name='', agenda='', participiant='', current_hour=0):
        if participiant:
            log.step(f'Добавим участника: {participiant}', where='IVA Mobile Клиент')
            self.get_object(self.L_I18N_ADD_NEW_PARTICIPIANT_BUTTON(self.lang)).click()
            self.get_object(self.L_I18N_SCHEDULE_MEETING_ADD_PARTICIPANT_INPUT(self.lang)).send_keys(participiant)
            self.get_object(self.L_I18N_SELECT_SEARCHED_PARTICIPIANT(self.lang, participiant)).click()
            self.get_object(self.L_I18N_CONFIRM_ADD_PARTICIPIANT_BUTTON(self.lang)).click()

        self._set_start_meeting_time(current_hour)

        log.step(f'Зададим название мероприятия: {name}', where='IVA Mobile Клиент')
        self.clear_input(locator=self.L_I18N_SCHEDULE_MEETING_NAME_FIELD(self.lang))
        self.get_object(self.L_I18N_SCHEDULE_MEETING_NAME_FIELD(self.lang)).send_keys(name)
        log.step(f'Зададим повестку мероприятия: {agenda}', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_SCHEDULE_MEETING_AGENDA_FIELD(self.lang)).send_keys(agenda)

        # self._set_start_meeting_time(current_hour)

        log.step('Подтвердим изменение мероприятия', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_SCHEDULE_MEETING_CONFIRM_START_BUTTON(self.lang)).click()
        # time.sleep(5)
        log.step('Вернемся к списку мероприятий', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_SCHEDULE_GOBACK_MEETING_LIST_BUTTON(self.lang)).click()


class PAndroidScheduleMeeting(_PBaseScheduleMeeting, AndroidLocators.LScheduleMeeting):
    def _set_start_meeting_time(self, current_hour=0):
        log.step(f'Зададим время начала мероприятия: текущее + 1 час', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_SCHEDULE_MEETING_START_TIME(self.lang)).click()
        self.get_object(self.L_I18N_SCHEDULE_SET_TIME_KEYBOARD_BUTTON(self.lang)).click()

        if len(str(current_hour)) == 1:
            time_picker = self.get_object(self.L_I18N_SCHEDULE_DATE_TIME_PICKER(self.lang, time=str(0) + str(current_hour)))
        else:
            time_picker = self.get_object(self.L_I18N_SCHEDULE_DATE_TIME_PICKER(self.lang, time=current_hour))
        time_picker.clear()
        # Вычисляем следующее значение часа с учетом перехода от 23 к 00
        next_hour = (current_hour + 1) % 24

        formatted_next_hour = f"{next_hour:02d}"
        time_picker.set_value(formatted_next_hour)
        self.get_object(self.L_I18N_SCHEDULE_CONFIRM_SET_TIME_BUTTON(self.lang)).click()

class PIOSScheduleMeeting(_PBaseScheduleMeeting, iOSLocators.LScheduleMeeting):
    def _set_start_meeting_time(self, current_hour=''):
        log.step(f'Зададим время начала мероприятия: текущее + 1 час', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_SCHEDULE_MEETING_START_TIME(self.lang)).click()
        time_picker = self.get_object(self.L_I18N_SCHEDULE_DATE_TIME_PICKER(self.lang))

        current_hour = int(time_picker.text.split(":")[-1])

        # Вычисляем следующий час с учетом перехода через midnight
        next_hour = (current_hour + 1) % 24

        # Форматируем час с ведущим нулем (например, "04" вместо "4")
        formatted_next_hour = f"{next_hour:02d}"

        time_picker.set_value(formatted_next_hour)
        self.driver.execute_script('mobile: scroll', {'direction': 'down'})