from .bottom_menu import PAndroidBottomMenu, PIOSBottomMenu


def get_chunk(platform, chunk_name):
    if platform == 'Android':
        if chunk_name == 'bottom_menu':
            return PAndroidBottomMenu

    if platform == 'iOS':
        if chunk_name == 'bottom_menu':
            return PIOSBottomMenu
