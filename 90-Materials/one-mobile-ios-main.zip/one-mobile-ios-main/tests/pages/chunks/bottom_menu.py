from tests.pages.base import _PBase
from tests.pages.locators.Android.chunks import bottom_menu as AndroidLocators
from tests.pages.locators.iOS.chunks import bottom_menu as iOSLocators
from autocore.test.logger import get_log

log = get_log()


class _PBaseBottomMenu(_PBase):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_I18N_SETTINGS_BUTTON(self.lang)
        super().__init__(*args, **kwargs)

    def open_settings(self):
        log.step('Откроем вкладку "Настройки"', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_SETTINGS_BUTTON(self.lang)).click()

    def open_contacts(self):
        log.step('Откроем вкладку "Контакты"', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_CONTACTS_BUTTON(self.lang)).click()

    def open_chats(self):
        log.step('Откроем "Чаты"', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_CHATS_BUTTON(self.lang)).click()

    def open_meetings(self):
        log.step('Откроем "Мероприятия"', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_MEETINGS_BUTTON(self.lang)).click()

    def open_rooms(self):
        log.step('Откроем "Комнаты"', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_ROOMS_BUTTON(self.lang)).click()

class PAndroidBottomMenu(_PBaseBottomMenu, AndroidLocators.LBottomMenu):
    pass

class PIOSBottomMenu(_PBaseBottomMenu, iOSLocators.LBottomMenu):
    pass
