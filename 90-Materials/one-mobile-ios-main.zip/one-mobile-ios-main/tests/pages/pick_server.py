from datetime import time

from .base import _PBase
from .locators import Android as AndroidLocators
from .locators import iOS as iOSLocators
from autocore.test.logger import get_log
from autocore.test.assertions import assert_fn

log = get_log()


class _PBasePickServer(_PBase):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_I18N_TEXTFIELD_SERVER(self.lang)
        super().__init__(*args, **kwargs)

    def pick(self, server='', check_continue_button=False):
        self.accept_wireless_data()
        log.step('Выбрать сервер', where='IVA Mobile Клиент')
        self.clear_input(locator=self.L_I18N_TEXTFIELD_SERVER(self.lang))
        self.get_object(self.L_I18N_TEXTFIELD_SERVER(self.lang)).send_keys(server)
        continue_button = self.L_I18N_BTN_CONTINUE(self.lang)
        if check_continue_button:
            status_button_attribute = self.get_object(continue_button).get_attribute('enabled')
            assert_fn(lambda: status_button_attribute == 'true',
                      f"Проверка кнопки 'Продолжить' на доступность: {status_button_attribute}")
        self.get_object(continue_button).click()

    def assert_server_incorrect_message(self):
        self.assert_presence(locator=self.L_I18N_INCORRECT_SERVER_MESSAGE(self.lang),
                             message="Отображение сообщения о некорректном вводе сервера")


class PIOSPickServer(_PBasePickServer, iOSLocators.LPickServer):
    def accept_wireless_data(self):
        # Ввиду возможной загрузки системы popup не успевает появиться, дадим ему шанс
        try:
            self.driver.execute_script('mobile: alert', {"action": "accept", "buttonLabel": "Только WLAN"})

        except:
            log.info('No alert window found')

        else:
            log.step('Accept use wireless data alert', where='IVA Mobile Клиент')


class PAndroidPickServer(_PBasePickServer, AndroidLocators.LPickServer):
    def accept_wireless_data(self):
        pass
