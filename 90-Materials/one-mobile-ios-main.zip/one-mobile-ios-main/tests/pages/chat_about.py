from .base import _PBase
from .locators import Android as AndroidLocators
from .locators import iOS as iOSLocators

from autocore.test.logger import get_log

log = get_log()

class _PBaseChatAbout(_PBase):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_I18N_CLEAR_CHAT_BUTTON(self.lang)
        super().__init__(*args, **kwargs)


    def open_chat_gallery(self):
        log.step('Откроем галерею чата', where='IVA Mobile Клиент')
        self.get_object(self.L_I18N_CHAT_GALLERY_BUTTON(self.lang)).click()

    def assert_chat_info_opened(self):
        self.assert_presence(locator=self.L_I18N_CHAT_GALLERY_BUTTON(self.lang),
                             message='Информация о чате с открылась')

    def assert_chat_media_button_presence(self):
        self.assert_presence(locator=self.L_I18N_CHAT_MEDIA_BUTTON(self.lang),
                             message='Присутствует кнопка МЕДИА')

    def assert_chat_documents_button_presence(self):
        self.assert_presence(locator=self.L_I18N_CHAT_DOCUMENTS_BUTTON(self.lang),
                             message='Присутствует кнопка ДОКУМЕНТЫ')

    def assert_chat_sent_image_presence(self):
        self.assert_presence(locator=self.L_I18N_CHAT_GALLERY_ATTACHED_IMAGE(self.lang),
                             message='В галерее присутствует отправленное изображение')


class PAndroidChatAbout(_PBaseChatAbout, AndroidLocators.LChatAbout):
    pass

#TODO: for future
# class PIOSChatAbout(_PBaseChatAbout, iOSLocators.LChatAbout):
#    pass
