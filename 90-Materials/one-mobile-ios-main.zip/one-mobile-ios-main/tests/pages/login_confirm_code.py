import time

from .base import _PBase
from .locators import Android as AndroidLocators
from .locators import iOS as iOSLocators
from autocore.test.logger import get_log
from autocore.test.assertions import assert_fn
from tools import mail
from autocore.test.generate_data import get_random_int

log = get_log()


class _PBaseLoginConfirmCodePage(_PBase):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_I18N_CONFIRM_CODE_INPUT(self.lang)
        super().__init__(*args, **kwargs)

    def check_code_send_message(self, expected_email):
        self.assert_presence(locator=self.L_I18N_CONFIRM_CODE_SEND_MESSAGE(self.lang),
                             message="Отображение сообщения об успешной отправке кода на почту")
        mail_for_2fa = self.L_I18N_INFO_MAIL_TEXT(self.lang)
        get_mail_for_2fa = self.get_object(mail_for_2fa).text.rstrip()
        assert_fn(lambda: f'{expected_email[:3]}***@{expected_email.split("@")[1]}' == get_mail_for_2fa,
                  f'Письмо с кодом подтверждения отправлено на: {get_mail_for_2fa}')

    def check_resend_code_link_exist(self):
        log.step('Проверить наличие счетчика времени повторной отправки', where='IVA Mobile Клиент')
        resend_code_link_text = self.get_object(self.L_I18N_RESEND_CODE_AFTER_MESSAGE(self.lang)).text
        assert_fn(lambda: 'Отправить код повторно через' in resend_code_link_text, 'Отображение счетчика времени')

    def check_enter_button_disabled(self):
        log.step('Проверка доступности кнопки "Войти"', where='IVA Mobile Клиент')
        enter_button_status = self.get_object(self.L_I18N_ENTER_BUTTON(self.lang)).get_attribute('enabled')
        assert_fn(lambda: enter_button_status == 'false',
                  f"Проверка доступности кнопки 'Войти': {enter_button_status}")

    def assert_previous_step_link(self):
        self.assert_presence(locator=self.L_I18N_BACK_PREVIOUS_STEP(self.lang),
                             message="Отображение сообщения о возврате к предыдущему шагу")

    def fill_confirm_code(self, code):
        log.step('Введем код подтверждения из почты', where='IVA Mobile Клиент')
        self.clear_input(self.L_I18N_CONFIRM_CODE_INPUT(self.lang))
        code_input = self.get_object(self.L_I18N_CONFIRM_CODE_INPUT(self.lang))
        code_input.click()
        code_input.send_keys(code)
        self.driver.scroll(code_input,
                           self.get_object(self.L_I18N_LOGIN_WINDOW_TITLE(self.lang)))
        self.get_object(self.L_I18N_ENTER_BUTTON(self.lang)).click()

    def enter_invalid_code(self):
        log.step('Ввести невалидный код', where='IVA Mobile Клиент')
        self.fill_confirm_code(get_random_int(6))
        self.assert_presence(locator=self.L_I18N_INVALID_CODE_MESSAGE(self.lang),
                             message="Отображение сообщения о вводе некорректного кода")

    def enter_valid_code(self):
        log.step('Ввести валидный код из email', where='IVA Mobile Клиент')
        code = mail.get_confirm_code()
        self.fill_confirm_code(code)
        self.accept_alerts()

    def check_elements_params(self, expected_email):
        self.check_code_send_message(expected_email)
        self.check_enter_button_disabled()
        self.assert_previous_step_link()
        self.check_resend_code_link_exist()


class PAndroidLoginConfirmCodePage(_PBaseLoginConfirmCodePage, AndroidLocators.LLoginConfirmCodePage):
    def accept_alerts(self, alerts=3):
        for _ in range(alerts):
            try:
                self.get_object(('xpath', '//android.widget.Button[@text="ОТМЕНА"]'),
                                timeout=1).click()
            except:
                log.info('No alert window found')

            else:
                log.step('Accept Android alert', where='IVA Mobile Клиент')


class PIOSLoginConfirmCodePage(_PBaseLoginConfirmCodePage, iOSLocators.LLoginConfirmCodePage):
    def accept_alerts(self, alerts=3):
        for _ in range(alerts):
            try:
                self.driver.switch_to.alert.accept()
            except:
                log.info('No alert window found')
            else:
                log.step('Accept iOS alert', where='IVA Mobile Клиент')