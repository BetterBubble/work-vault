from .base import _PBase
from .locators import Android as AndroidLocators
from .locators import iOS as iOSLocators
from autocore.test.logger import get_log

log = get_log()


class _PBaseHome(_PBase):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_WIDGET_MAIN(self.lang)
        self.page_path = ''
        super().__init__(*args, **kwargs)


class PAndroidHome(_PBaseHome, AndroidLocators.LHome):
    pass


class PIOSHome(_PBaseHome, iOSLocators.LHome):
    pass

