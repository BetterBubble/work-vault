import pytest

from autocore.test.logger import get_log
from autocore.test.config import get_config
from autocore.test.generate_data import get_str_timestamp
from autocore.clients import rest

from tests.pages import chunks
from tools import mail
from tests import pages
from tools import aut

log = get_log()
conf = get_config()

@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.ios
@pytest.mark.android
def test_link_not_auth_VCSMOB_T40(setup_aut, teardown):
    lang = setup_aut['setup']['cmd']['lang']
    device_os = setup_aut['setup']['cmd']['device_os']

    driver = setup_aut['driver']
    teardown.append(lambda: driver.quit())

    log.tc('T40')

    meeting_response = rest.create_meeting('user1', get_conf_number=False)
    conf_session_id = meeting_response['conferenceSessionId']
    meeting_link = rest.get_link_guest('user1', conf_session_id)

    log.step('Переход по ссылке на мероприятие', where='IVA Mobile Web Клиент')
    aut.open_browser(driver, device_os, meeting_link, lang)

    meeting_info = pages.get_page(device_os, 'meeting_login_info')(driver, lang=lang)
    meeting_info.click_enter_conference_button()
    meeting_login = pages.get_page(device_os, 'meeting_login')(driver, lang=lang)
    meeting_login.enter_guest()

    meeting = pages.get_page(device_os, 'meeting')(driver, lang=lang)
    meeting.leave()
    aut.close_browser(driver, device_os)

    #TODO: https://jira.hi-tech.org/browse/VCSMOB-7195
    # if device_os == 'iOS':
    #     _ = pages.get_page(device_os, 'pick_server')(driver, lang=lang)
    # else:
    #     _ = pages.get_page(device_os, 'home')(driver, lang=lang)


@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.ios
@pytest.mark.android
def test_link_sid_not_auth_VCSMOB_T42(setup_aut, teardown):
    lang = setup_aut['setup']['cmd']['lang']
    device_os = setup_aut['setup']['cmd']['device_os']

    driver = setup_aut['driver']
    teardown.append(lambda: driver.quit())

    _ = rest.create_meeting('user1', guest_user="no_reg_user", get_conf_number=False)
    meeting_link = mail.get_recovery_link()

    log.tc('T42')

    log.step('Переход по ссылке на мероприятие', where='IVA Mobile Web Клиент')
    aut.open_browser(driver, device_os, meeting_link, lang)

    meeting_info = pages.get_page(device_os, 'meeting_login_info')(driver, lang=lang)
    meeting_info.click_enter_conference_button()

    meeting = pages.get_page(device_os, 'meeting')(driver, lang=lang)
    meeting.leave()
    aut.close_browser(driver, device_os)

    #TODO: https://jira.hi-tech.org/browse/VCSMOB-7195
    # if device_os == 'iOS':
    #     _ = pages.get_page(device_os, 'pick_server')(driver, lang=lang)
    # else:
    #     _ = pages.get_page(device_os, 'home')(driver, lang=lang)


@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.ios
@pytest.mark.android
def test_link_enter_as_registered_VCSMOB_T41(setup_aut, teardown):
    lang = setup_aut['setup']['cmd']['lang']
    device_os = setup_aut['setup']['cmd']['device_os']

    creds = setup_aut['setup']['config']['credentials']
    user = 'user1'
    login_creds = creds[user]
    driver = setup_aut['driver']
    teardown.append(lambda: driver.quit())

    meeting_response = rest.create_meeting(user, get_conf_number=False)
    conf_session_id = meeting_response['conferenceSessionId']
    meeting_link = rest.get_link_guest(user, conf_session_id)

    log.tc('T41')

    log.step('Переход по ссылке на мероприятие', where='IVA Mobile Web Клиент')
    aut.open_browser(driver, device_os, meeting_link, lang)

    meeting_info = pages.get_page(device_os, 'meeting_login_info')(driver, lang=lang)
    meeting_info.click_enter_conference_button()

    meeting_login = pages.get_page(device_os, 'meeting_login')(driver, lang=lang)
    meeting_login.enter_as_registered(login_creds['username'], login_creds['password'])

    meeting = pages.get_page(device_os, 'meeting')(driver, lang=lang)
    meeting.leave()
    aut.close_browser(driver, device_os)


@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.ios
@pytest.mark.android
def test_link_for_invitees_not_auth_VCSMOB_T43(setup_aut, teardown):
    lang = setup_aut['setup']['cmd']['lang']
    device_os = setup_aut['setup']['cmd']['device_os']

    creds = setup_aut['setup']['config']['credentials']
    user_reg_1, user_reg_2 = 'user1', 'user3'
    login_creds = creds[user_reg_1]
    driver = setup_aut['driver']
    teardown.append(lambda: driver.quit())

    log.tc('T43')

    _ = rest.create_meeting(user_reg_1, guest_user=[user_reg_2], get_conf_number=False)
    meeting_link = mail.get_recovery_link()

    log.step('Переход по ссылке на мероприятие', where='IVA Mobile Web Клиент')
    aut.open_browser(driver, device_os, meeting_link, lang)

    meeting_info = pages.get_page(device_os, 'meeting_login_info')(driver, lang=lang)
    meeting_info.click_enter_conference_button()

    meeting_login = pages.get_page(device_os, 'meeting_login')(driver, lang=lang)
    meeting_login.login_meeting_invitee(login_creds['username'], login_creds['password'])

    meeting = pages.get_page(device_os, 'meeting')(driver, lang=lang)
    meeting.leave()
    aut.close_browser(driver, device_os)

    #TODO: https://jira.hi-tech.org/browse/VCSMOB-7195
    # if device_os == 'iOS':
    #     _ = pages.get_page(device_os, 'pick_server')(driver, lang=lang)
    # else:
    #     _ = pages.get_page(device_os, 'home')(driver, lang=lang)


@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.ios
@pytest.mark.android
def test_link_for_invitees_with_auth_VCSMOB_T36(setup_aut, teardown):
    lang = setup_aut['setup']['cmd']['lang']
    device_os = setup_aut['setup']['cmd']['device_os']

    creds = setup_aut['setup']['config']['credentials']
    user_reg_1, user_reg_2 = 'user1', 'user3'
    login_creds = creds[user_reg_2]
    driver = setup_aut['driver']
    server = setup_aut['setup']['config']['server']
    teardown.append(lambda: driver.quit())

    log.tc('T36')

    server_page = pages.get_page(device_os, 'pick_server')(driver, lang=lang)
    server_page.pick(server)

    login_page = pages.get_page(device_os, 'login')(driver, lang=lang)
    login_page.login(**login_creds)

    _ = rest.create_meeting(user_reg_1, guest_user=[user_reg_2], get_conf_number=False)
    meeting_link = mail.get_recovery_link()

    log.step('Переход по ссылке на мероприятие', where='IVA Mobile Web Клиент')
    aut.open_browser(driver, device_os, meeting_link, lang)

    meeting_info = pages.get_page(device_os, 'meeting_login_info')(driver, lang=lang)
    meeting_info.click_enter_conference_button()

    meeting = pages.get_page(device_os, 'meeting')(driver, lang=lang)
    meeting.leave()
    aut.close_browser(driver, device_os)

    #TODO: #TODO: https://jira.hi-tech.org/browse/VCSMOB-7195
    # _ = pages.get_page(device_os, 'home')(driver, lang=lang)


@pytest.mark.parametrize("tr_id, link, role", [
        ('T45', 'speakerLink', 'Докладчик'),
        ('T44', 'moderatorLink', 'Модератор')
    ],
    ids=['speaker', 'moderator'])
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.ios
@pytest.mark.android
def test_link_VCSMOB_T44_VCSMOB_T45(setup_aut, teardown, tr_id, link, role):
    lang = setup_aut['setup']['cmd']['lang']
    device_os = setup_aut['setup']['cmd']['device_os']

    driver = setup_aut['driver']
    teardown.append(lambda: driver.quit())

    log.tc(tr_id)

    meeting_response = rest.create_meeting('user1', get_conf_number=False)
    conf_session_id = meeting_response['conferenceSessionId']
    meeting_link = rest.get_link_guest('user1', conf_session_id, link_id=False)[link]

    log.step('Переход по ссылке на мероприятие', where='IVA Mobile Web Клиент')
    aut.open_browser(driver, device_os, meeting_link, lang)

    meeting_info = pages.get_page(device_os, 'meeting_login_info')(driver, lang=lang)
    meeting_info.click_enter_conference_button()
    meeting_login = pages.get_page(device_os, 'meeting_login')(driver, lang=lang)
    meeting_login.enter_guest()

    meeting = pages.get_page(device_os, 'meeting')(driver, lang=lang)
    meeting.show_participants()
    meeting.assert_role_present(role)
    aut.close_browser(driver, device_os)


@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.ios
@pytest.mark.android
def test_link_with_auth_VCSMOB_T34(setup_aut, teardown):
    lang = setup_aut['setup']['cmd']['lang']
    device_os = setup_aut['setup']['cmd']['device_os']

    creds = setup_aut['setup']['config']['credentials']
    user_reg = 'user1'
    login_creds = creds[user_reg]
    server = setup_aut['setup']['config']['server']
    driver = setup_aut['driver']
    teardown.append(lambda: driver.quit())

    log.tc('T34')

    server_page = pages.get_page(device_os, 'pick_server')(driver, lang=lang)
    server_page.pick(server)

    login_page = pages.get_page(device_os, 'login')(driver, lang=lang)
    login_page.login(**login_creds)

    meeting_response = rest.create_meeting(user_reg, get_conf_number=False)
    conf_session_id = meeting_response['conferenceSessionId']
    meeting_link = rest.get_link_guest(user_reg, conf_session_id)

    log.step('Переход по ссылке на мероприятие', where='IVA Mobile Web Клиент')
    aut.open_browser(driver, device_os, meeting_link, lang)

    meeting_info = pages.get_page(device_os, 'meeting_login_info')(driver, lang=lang)
    meeting_info.click_enter_conference_button()

    meeting = pages.get_page(device_os, 'meeting')(driver, lang=lang)
    meeting.leave()
    aut.close_browser(driver, device_os)

    #TODO: #TODO: https://jira.hi-tech.org/browse/VCSMOB-7195
    # _ = pages.get_page(device_os, 'home')(driver, lang=lang)


@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.ios
@pytest.mark.android
def test_link_sid_with_auth_VCSMOB_T35(setup_aut, teardown):
    lang = setup_aut['setup']['cmd']['lang']
    device_os = setup_aut['setup']['cmd']['device_os']
    if device_os == 'iOS':
        pytest.xfail("Fails due VCSMOB-3178")

    creds = setup_aut['setup']['config']['credentials']
    server = setup_aut['setup']['config']['server']
    a1 = 'user3'
    mk1_creds = creds['user1']
    driver = setup_aut['driver']
    teardown.append(lambda: driver.quit())

    _ = rest.create_meeting(a1, guest_user="no_reg_user", get_conf_number=False)
    meeting_link = mail.get_recovery_link()

    log.tc('T35')

    server_page = pages.get_page(device_os, 'pick_server')(driver, lang=lang)
    server_page.pick(server)

    login_page = pages.get_page(device_os, 'login')(driver, lang=lang)
    login_page.login(**mk1_creds)

    log.step('Переход по ссылке на мероприятие', where='IVA Mobile Web Клиент')
    aut.open_browser(driver, device_os, meeting_link, lang)

    meeting_info = pages.get_page(device_os, 'meeting_login_info')(driver, lang=lang)
    meeting_info.click_enter_conference_button()

    meeting = pages.get_page(device_os, 'meeting')(driver, lang=lang)
    meeting.leave()
    aut.close_browser(driver, device_os)

    #TODO: #TODO: https://jira.hi-tech.org/browse/VCSMOB-7195
    # _ = pages.get_page(device_os, 'home')(driver, lang=lang)


@pytest.mark.parametrize("tr_id, link, role", [
        ('45', 'speakerLink', 'Докладчик'),
        ('44', 'moderatorLink', 'Модератор')
    ],
    ids=['speaker', 'moderator'])
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.ios
@pytest.mark.android
def test_link_with_auth_VCSMOB_T37_VCSMOB_T38(setup_aut, teardown, tr_id, link, role):
    lang = setup_aut['setup']['cmd']['lang']
    device_os = setup_aut['setup']['cmd']['device_os']

    driver = setup_aut['driver']
    creds = setup_aut['setup']['config']['credentials']
    server = setup_aut['setup']['config']['server']
    mk1 = 'user1'
    mk1_creds = creds[mk1]
    a1 = 'user3'
    teardown.append(lambda: driver.quit())

    log.tc(tr_id)

    server_page = pages.get_page(device_os, 'pick_server')(driver, lang=lang)
    server_page.pick(server)

    login_page = pages.get_page(device_os, 'login')(driver, lang=lang)
    login_page.login(**mk1_creds)

    meeting_response = rest.create_meeting(a1, get_conf_number=False)
    conf_session_id = meeting_response['conferenceSessionId']
    meeting_link = rest.get_link_guest(a1, conf_session_id, link_id=False)[link]

    log.step('Переход по ссылке на мероприятие', where='IVA Mobile Web Клиент')
    aut.open_browser(driver, device_os, meeting_link, lang)

    meeting_info = pages.get_page(device_os, 'meeting_login_info')(driver, lang=lang)
    meeting_info.click_enter_conference_button()

    meeting = pages.get_page(device_os, 'meeting')(driver, lang=lang)
    meeting.show_participants()
    meeting.assert_role_present(role)
    aut.close_browser(driver, device_os)