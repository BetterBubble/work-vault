# kit — инструкции для агентов

Каталог модулей агентской AQA-разработки и стандарт, на котором они собраны.
Репо — marketplace для Claude Code и Codex одновременно: канон — CC-формат
манифестов, нативные Codex-обёртки — генерат `scripts/render_codex.py`
(при соседстве Codex берёт нативный манифест, CC видит только свой).

## Структура

- `.claude-plugin/marketplace.json` — манифест каталога (список модулей), канон.
- `<модуль>/` — модуль: `.claude-plugin/plugin.json` + `skills/<имя>/SKILL.md`
  (канон — платформо-нейтральный Agent Skills).
- `.agents/plugins/marketplace.json` и `<модуль>/.codex-plugin/plugin.json` —
  нативные Codex-обёртки, **генерат** (руками не правятся). После любой правки
  CC-манифестов / добавления модуля: `python3 scripts/render_codex.py`
  (обязательный шаг публикации); `--check` — детект отставания/дрейфа.
- `base/` — базовый модуль: `scripts/render_base.py` (рендер тощей базы — каталога
  `.kit/` в репо потребителя — плюс `--init` и `--check`; stdlib, Python ≥ 3.11),
  `scripts/task_meta.py` (канонический CLI контракта меты: init — дом задачи
  `.tasks/work/<ключ>/` с `meta.json`, close — closed + снос scratch + архивация;
  stdlib, зовётся голым python3), `scripts/check_tasks_root.py` (детект элементов
  корня `.tasks/` вне карты зоны `.tasks/README.md` — ступень base:check и
  Phase 0 keep:retro), `templates/` (шаблоны схемы/answers/local),
  `CONTRACT.md` (контракт данных наблюдаемости: `events.jsonl` / `meta.json`,
  версия 1; потребитель — ivaqa/pulse), скиллы `install` (анкета-диалог), `check`
  (свежесть базы + инвариант корня `.tasks/` + детект отставания канала
  каталога), `update` (обновление
  каталога и модулей через CLI платформ, `scripts/update_kit.py`) и `contribute`
  (петля отдачи в ядро: доставка фидбэка по GitLab-issue на запись + инвентарь
  зрелых наработок; `scripts/deliver_feedback.py` / `scripts/inventory_local.py`).
  Генерат схемы детерминирован (без дат) — `--check` честно сравнивает байты.

## Ветки и поставка

- `main` — latest, полигон (первый потребитель — репо one-web-kmp, отделённый
  от one-web).
- `stable` — парк потребителей. Промоушен `main`→`stable` — явное действие владельца
  (человека) после обкатки; агент в `stable` не пушит.
- Пин тегом (`--ref <тег>`) — легальная опция осознанной заморозки у потребителя.

## План работ и контекст

- План заходов — issues этого репо (GitLab); каждый issue самодостаточен.
- Дом решений-источников — репо one-web-kmp (`~/Projects/AT/one-web-kmp`, ветка
  `at-creation-main`; полигон, отделённый от one-web):
  `.tasks/work/_archive/wayfinder-agent-env/` (копия архива осталась и в исходном
  one-web), тикеты 003 (роль/форма), 004 (дистрибуция), 005 (роли),
  011 (этапность), 014 (имена kit/base), 015 (кросс-вызов).
- Ядра для поглощения: старый тулкит `~/Projects/AT/aqa-agent-toolkit` (ветка `dev`)
  и агент-среда kmp (репо one-web-kmp); при расхождении kmp-версия — кандидат в канон.

## Констрейнты

- **Кроссплатформенность:** всё обязано работать под macOS и Windows минимум, Linux
  желательно — pathlib (оба разделителя), явный `encoding="utf-8"` при I/O, скрипты
  Python (не bash), локи/планировщики — только с платформо-нейтральной альтернативой.
- Коммиты на русском в стиле `git log --oneline` (глагол + что сделано).
- `glab` вне git-каталога целится в gitlab.com и падает «Unauthenticated» — запускать
  из этого каталога либо добавлять `-R ivaqa/kit`.
