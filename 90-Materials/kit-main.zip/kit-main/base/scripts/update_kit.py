#!/usr/bin/env python3
"""Обновление kit у потребителя: каталог + установленные модули через CLI платформ.

Часть модуля base каталога kit; живёт в кэше платформы, работает с реестрами
платформ в домашнем каталоге (не с репо проекта — запускать можно откуда угодно).
Автообновления у платформ нет, команды «обновить все модули» тоже — скрипт
собирает ручной четырёхшаговый цикл README («Обновление») в одно действие,
оставаясь тонкой обёрткой над CLI: логики минимум, поверхности чужие.

Платформы — по найденным реестрам (все, либо одна через --platform):
  cc     ~/.claude/plugins/known_marketplaces.json (git-клон каталога) +
         installed_plugins.json (модули <имя>@kit);
         команды: claude plugin marketplace update kit; claude plugin update <м>@kit
  codex  ~/.codex/config.toml ([marketplaces.kit] — снапшот, [plugins."<м>@kit"]);
         команды: codex plugin marketplace upgrade kit; codex plugin add <м>@kit
         (переустановка модуля из снапшота)

Режимы:
  --check       ничего не менять: детект отставания канала — git ls-remote к
                remote каталога против ревизии локального клона/снапшота (дёшево,
                read-only, без обновления клона). cc: голова канала-ветки клона;
                пин тегом (detached HEAD) отставанием не считается. codex: канал
                в конфиге не хранится — эвристика «ревизия снапшота среди
                голов/тегов remote».
  (без флагов)  обновить: каталог, затем каждый установленный модуль; сбой
                каталога останавливает платформу (модули со старого снапшота
                замаскировали бы проблему), сбои модулей копятся в сводку.
                Финал — директива: рестарт сессии (скрипт не может) + base:check
                в репо проекта. Запущенному из кэша скрипту обновление не мешает:
                новая версия модуля ложится в соседний каталог кэша.

Кроссплатформенный: stdlib (Python >= 3.11, tomllib), pathlib, явный utf-8,
CLI через subprocess списком аргументов (без shell; .cmd/.bat на Windows — через
cmd /c). Коды выхода: 0 — ок/свежо; 1 — check нашёл отставание либо были сбои
обновления; 2 — ошибка окружения (нет реестров с kit / нет git).
"""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path

try:
    import tomllib
except ModuleNotFoundError:  # Python < 3.11
    sys.stderr.write("update_kit: нужен Python >= 3.11 (модуль tomllib)\n")
    sys.exit(2)

MARKETPLACE = "kit"
# платформа -> (CLI, команда обновления каталога, команда обновления модуля)
PLATFORM_CLI = {
    "cc": ("claude",
           ["plugin", "marketplace", "update", MARKETPLACE],
           lambda m: ["plugin", "update", f"{m}@{MARKETPLACE}"]),
    "codex": ("codex",
              ["plugin", "marketplace", "upgrade", MARKETPLACE],
              lambda m: ["plugin", "add", f"{m}@{MARKETPLACE}"]),
}


def fail(msg: str) -> "sys.NoReturn":
    sys.stderr.write(f"update_kit: {msg}\n")
    sys.exit(2)


def git(*args: str) -> tuple[int, str, str]:
    """git как данные-подпроцесс -> (код, stdout, stderr)."""
    try:
        res = subprocess.run(["git", *args], capture_output=True, text=True,
                             encoding="utf-8", check=False)
    except OSError as e:
        fail(f"git недоступен: {e}")
    return res.returncode, res.stdout.strip(), res.stderr.strip()


def cc_registry() -> dict | None:
    """Маркетплейс kit в Claude Code: клон каталога + установленные модули."""
    root = Path.home() / ".claude" / "plugins"
    known = root / "known_marketplaces.json"
    if not known.is_file():
        return None
    mp = json.loads(known.read_text(encoding="utf-8")).get(MARKETPLACE)
    if not isinstance(mp, dict):
        return None
    source = mp.get("source", {})
    if source.get("source") == "git":
        url = source.get("url")
    elif source.get("source") == "github":
        url = f"https://github.com/{source.get('repo')}.git"
    else:
        url = None
    modules = []
    installed = root / "installed_plugins.json"
    if installed.is_file():
        plugins = json.loads(installed.read_text(encoding="utf-8")).get("plugins", {})
        modules = [key.split("@")[0] for key in plugins if key.endswith(f"@{MARKETPLACE}")]
    return {"platform": "cc", "url": url, "clone": mp.get("installLocation"), "modules": modules}


def codex_registry() -> dict | None:
    """Маркетплейс kit в Codex: снапшот каталога + установленные модули."""
    config = Path.home() / ".codex" / "config.toml"
    if not config.is_file():
        return None
    try:
        data = tomllib.loads(config.read_text(encoding="utf-8"))
    except tomllib.TOMLDecodeError as e:
        fail(f"{config} не парсится как TOML: {e}")
    mp = data.get("marketplaces", {}).get(MARKETPLACE)
    if not isinstance(mp, dict):
        return None
    modules = [key.split("@")[0] for key in data.get("plugins", {}) if key.endswith(f"@{MARKETPLACE}")]
    return {"platform": "codex", "url": mp.get("source"),
            "revision": mp.get("last_revision"), "modules": modules}


def check_cc(reg: dict) -> tuple[str, bool]:
    """(строка отчёта, отстал ли). Голова канала-ветки клона против remote."""
    clone = reg.get("clone") or ""
    rc, head, err = git("-C", clone, "rev-parse", "HEAD")
    if rc:
        return f"ПРОВЕРКА НЕ УДАЛАСЬ (cc): клон каталога {clone or '<нет installLocation>'} не читается: {err}", False
    rc, branch, _ = git("-C", clone, "rev-parse", "--abbrev-ref", "HEAD")
    if rc == 0 and branch == "HEAD":
        return (f"OK (cc): клон каталога запинен не-веткой (тег/ревизия, {head[:9]}) — "
                "осознанная заморозка, отставание не считается"), False
    if not reg.get("url"):
        return "ПРОВЕРКА НЕ УДАЛАСЬ (cc): неизвестный тип source маркетплейса — URL remote не определить", False
    rc, out, err = git("ls-remote", reg["url"], f"refs/heads/{branch}")
    if rc:
        return f"ПРОВЕРКА НЕ УДАЛАСЬ (cc): git ls-remote {reg['url']}: {err}", False
    if not out:
        return f"ПРОВЕРКА НЕ УДАЛАСЬ (cc): в remote нет ветки-канала '{branch}'", False
    remote_sha = out.split()[0]
    if remote_sha != head:
        return (f"ОТСТАВАНИЕ (cc): канал {branch} ушёл вперёд (клон {head[:9]}, "
                f"remote {remote_sha[:9]}) — каталог у платформы несвеж"), True
    return f"OK (cc): канал {branch} — клон каталога на голове remote ({head[:9]})", False


def check_codex(reg: dict) -> tuple[str, bool]:
    """(строка отчёта, отстал ли). Канал в config.toml не хранится — эвристика:
    ревизия снапшота должна совпадать с какой-нибудь головой/тегом remote."""
    revision = reg.get("revision")
    if not revision:
        return "ПРОВЕРКА НЕ УДАЛАСЬ (codex): у [marketplaces.kit] в config.toml нет last_revision", False
    if not reg.get("url"):
        return "ПРОВЕРКА НЕ УДАЛАСЬ (codex): у [marketplaces.kit] в config.toml нет source", False
    rc, out, err = git("ls-remote", reg["url"])
    if rc:
        return f"ПРОВЕРКА НЕ УДАЛАСЬ (codex): git ls-remote {reg['url']}: {err}", False
    heads = {line.split()[0] for line in out.splitlines() if line.strip()}
    if revision not in heads:
        return (f"ОТСТАВАНИЕ (codex): ревизия снапшота {revision[:9]} не найдена среди "
                "голов/тегов remote — снапшот каталога несвеж"), True
    return f"OK (codex): ревизия снапшота {revision[:9]} совпадает с головой канала/тегом remote", False


def cmd_check(regs: list[dict]) -> int:
    stale = False
    for reg in regs:
        line, is_stale = (check_cc if reg["platform"] == "cc" else check_codex)(reg)
        print(line)
        stale = stale or is_stale
    if stale:
        print("Обновление — скилл base:update (молча не запускать: осознанное действие).")
    return 1 if stale else 0


def cli_argv(name: str) -> list[str] | None:
    exe = shutil.which(name)
    if exe is None:
        return None
    if exe.lower().endswith((".cmd", ".bat")):  # Windows-шимы CreateProcess сам не исполняет
        return ["cmd", "/c", exe]
    return [exe]


def update_platform(reg: dict) -> list[str]:
    """Каталог, затем модули. Возврат — список сбоев вида 'платформа: что'."""
    platform = reg["platform"]
    cli_name, marketplace_args, module_args = PLATFORM_CLI[platform]
    argv = cli_argv(cli_name)
    if argv is None:
        print(f"({platform}) CLI '{cli_name}' не найден в PATH — платформа пропущена", file=sys.stderr)
        return [f"{platform}: CLI '{cli_name}' отсутствует"]
    failures: list[str] = []
    print(f"\n=== ({platform}) каталог {MARKETPLACE} ===")
    if subprocess.run(argv + marketplace_args, check=False).returncode != 0:
        print(f"({platform}) каталог не обновился — модули этой платформы пропущены", file=sys.stderr)
        return [f"{platform}: обновление каталога"]
    if not reg["modules"]:
        print(f"({platform}) установленных модулей {MARKETPLACE} в реестре нет — только каталог")
    for module in reg["modules"]:
        print(f"\n--- ({platform}) модуль {module}@{MARKETPLACE} ---")
        if subprocess.run(argv + module_args(module), check=False).returncode != 0:
            failures.append(f"{platform}: {module}@{MARKETPLACE}")
    return failures


def cmd_update(regs: list[dict]) -> int:
    failures: list[str] = []
    for reg in regs:
        failures += update_platform(reg)
    print()
    if failures:
        print("Сбои обновления (повторный запуск догонит):", file=sys.stderr)
        for failure in failures:
            print(f"  - {failure}", file=sys.stderr)
    else:
        print("Обновление прошло без сбоев.")
    print("Дальше руками (скрипту не дано):\n"
          "  1. рестарт сессии платформы — новые версии подхватываются при старте;\n"
          "  2. в репо проекта — base:check (перерендер тощей базы .kit/ под новое ядро).")
    return 1 if failures else 0


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Обновление kit у потребителя: каталог + модули через CLI платформ / детект отставания канала")
    parser.add_argument("--check", action="store_true",
                        help="ничего не менять: сверить ревизию клона/снапшота каталога с remote")
    parser.add_argument("--platform", choices=sorted(PLATFORM_CLI),
                        help="ограничить одной платформой (дефолт: все найденные)")
    args = parser.parse_args()
    regs = [reg for reg in (cc_registry(), codex_registry()) if reg is not None]
    if args.platform:
        regs = [reg for reg in regs if reg["platform"] == args.platform]
    if not regs:
        fail(f"маркетплейс {MARKETPLACE} не найден ни в одном реестре платформ "
             "(cc: ~/.claude/plugins/known_marketplaces.json, codex: ~/.codex/config.toml)")
    return cmd_check(regs) if args.check else cmd_update(regs)


if __name__ == "__main__":
    sys.exit(main())
