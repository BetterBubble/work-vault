#!/usr/bin/env python3
"""Доставка фидбэка потребитель → ядро kit: по GitLab-issue на запись (петля base:contribute).

Заменяет старый транспорт «push в orphan-ветку inbox под неймспейсом потребителя»: судьба
фидбэка теперь видна НАТИВНЫМ трекером репо ядра, свой реестр не строим (решение карты
agent-env 004 п.5). Запись трения по-прежнему рождается локальным .md-файлом в моменте
(дёшево, офлайн, батчится); этот скрипт превращает накопленные записи в issue репо ядра.

Пер-запись: для каждой непосланной записи `<feedback_dir>/*.md` (корень, кроме README/
_TEMPLATE) → `glab issue create --repo <core_repo>` с заголовком `[feedback] <slug>` и телом
= содержимое записи + футер-атрибуция. При успехе запись помечается доставленной (футер с
URL issue дописывается в файл) и переезжает в `_sent/`. Идемпотентно: повторный вызов
берёт только оставшиеся в корне; частичный сбой оставляет недоставленные на месте.

Гейт подтверждения — на СКИЛЛЕ (base:contribute): создание issue во внешнем трекере —
внешний write-action, показать dry-run и получить отмашку человека до боевого запуска
(инвариант write-actions схемы base). Скрипт без --dry-run исполняет сразу.

Часть модуля base каталога kit; stdlib + внешний `glab` (GitLab CLI). Кроссплатформенный:
pathlib, явный utf-8, glab через subprocess со списком аргументов (без shell). Нет glab /
нет доступа → фолбэк: печать готовых тел issue для ручного заведения, записи не трогаются.

Параметры (`.kit/answers.toml`, секция `[contribute]`, читаются с дефолтами):
  core_repo     — репо ядра для issue (дефолт "ivaqa/kit")
  feedback_dir  — каталог outbox записей (дефолт ".tasks/toolkit-feedback")

Коды выхода: 0 — доставлено/нечего доставлять; 1 — сбой доставки (записи на месте);
2 — ошибка окружения (нет репо / битый answers).
"""
from __future__ import annotations

import argparse
import datetime
import shutil
import subprocess
import sys
from pathlib import Path

try:
    import tomllib
except ModuleNotFoundError:  # Python < 3.11
    sys.stderr.write("deliver_feedback: нужен Python >= 3.11 (модуль tomllib)\n")
    sys.exit(2)

ANSWERS = Path(".kit") / "answers.toml"
DEFAULT_CORE_REPO = "ivaqa/kit"
DEFAULT_FEEDBACK_DIR = ".tasks/toolkit-feedback"
SKIP = {"README.md", "_TEMPLATE.md"}


def fail(msg: str) -> "sys.NoReturn":
    sys.stderr.write(f"deliver_feedback: {msg}\n")
    sys.exit(2)


def load_contribute(repo: Path) -> dict:
    path = repo / ANSWERS
    if not path.exists():
        return {}
    try:
        data = tomllib.loads(path.read_text(encoding="utf-8"))
    except tomllib.TOMLDecodeError as e:
        fail(f"{path} не парсится как TOML: {e}")
    section = data.get("contribute", {})
    return section if isinstance(section, dict) else {}


def project_name(repo: Path) -> str:
    """Имя проекта из [project].name answers; фолбэк — имя каталога репо."""
    path = repo / ANSWERS
    if path.exists():
        try:
            data = tomllib.loads(path.read_text(encoding="utf-8"))
            name = data.get("project", {}).get("name")
            if isinstance(name, str) and name.strip():
                return name.strip()
        except tomllib.TOMLDecodeError:
            pass
    return repo.name


def pending_records(feedback_dir: Path) -> list[Path]:
    """Записи к отправке: *.md в корне outbox, кроме README/_TEMPLATE (не рекурсивно)."""
    if not feedback_dir.is_dir():
        return []
    return sorted(f for f in feedback_dir.glob("*.md") if f.name not in SKIP)


def issue_title(record: Path) -> str:
    """Заголовок issue из имени записи: снять дату-префикс, вернуть человекочитаемый слаг."""
    stem = record.stem
    parts = stem.split("-")
    if len(parts) >= 4 and parts[0].isdigit() and len(parts[0]) == 4:
        stem = "-".join(parts[3:]) or stem  # YYYY-MM-DD-slug → slug
    return f"[feedback] {stem}"


def issue_body(record: Path, project: str) -> str:
    body = record.read_text(encoding="utf-8").rstrip()
    return f"{body}\n\n---\n_Доставлено `base:contribute` из потребителя `{project}` (файл `{record.name}`)._"


def have_glab() -> bool:
    return shutil.which("glab") is not None


def create_issue(core_repo: str, title: str, body: str) -> tuple[bool, str]:
    """glab issue create → (успех, url_или_ошибка). glab печатает URL созданной issue в stdout."""
    try:
        res = subprocess.run(
            ["glab", "issue", "create", "--repo", core_repo,
             "--title", title, "--description", body, "--yes"],
            capture_output=True, text=True, check=False,
        )
    except OSError as e:
        return False, f"запуск glab не удался: {e}"
    if res.returncode != 0:
        return False, (res.stderr.strip() or res.stdout.strip() or "glab вернул ненулевой код")
    url = ""
    for token in (res.stdout + " " + res.stderr).split():
        if token.startswith("http"):
            url = token.strip()
            break
    return True, url


def mark_sent(record: Path, feedback_dir: Path, url: str, today: str) -> Path:
    """Дописать футер доставки в запись и перенести её в _sent/. Возврат — новый путь."""
    trail = f"\n\n<!-- delivered: {url or 'issue создан'} ({today}) -->\n"
    with record.open("a", encoding="utf-8") as fh:
        fh.write(trail)
    sent_dir = feedback_dir / "_sent"
    sent_dir.mkdir(exist_ok=True)
    dest = sent_dir / record.name
    shutil.move(str(record), str(dest))
    return dest


def deliver(repo: Path, core_repo: str, feedback_dir: Path, dry_run: bool) -> int:
    records = pending_records(feedback_dir)
    if not records:
        print("Нет непосланных записей — доставлять нечего.")
        return 0
    project = project_name(repo)
    print(f"Потребитель: {project}")
    print(f"К заведению в {core_repo} — {len(records)} issue:")
    for r in records:
        print(f"  • {issue_title(r)}   ← {r.name}")

    if dry_run:
        print("\n[dry-run] issue не создавались.")
        return 0

    if not have_glab():
        print("\nglab не найден в PATH — фолбэк: готовые тела issue для ручного заведения "
              f"в {core_repo} (записи оставлены на месте):", file=sys.stderr)
        for r in records:
            print(f"\n===== {issue_title(r)} =====", file=sys.stderr)
            print(issue_body(r, project), file=sys.stderr)
        return 1

    today = datetime.date.today().isoformat()
    delivered = 0
    for r in records:
        ok, info = create_issue(core_repo, issue_title(r), issue_body(r, project))
        if not ok:
            print(f"\nСбой на записи {r.name}: {info}", file=sys.stderr)
            print(f"Доставлено до сбоя: {delivered}. Остальные оставлены на месте — повторный вызов продолжит.",
                  file=sys.stderr)
            return 1
        mark_sent(r, feedback_dir, info, today)
        print(f"  ✓ {issue_title(r)} → {info or 'создан'}")
        delivered += 1
    print(f"\nДоставлено {delivered} issue в {core_repo}; записи перенесены в {feedback_dir / '_sent'}/.")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="Доставка фидбэка потребитель → issue репо ядра kit (пер-запись).")
    ap.add_argument("--repo", type=Path, default=Path.cwd(), help="корень репо проекта (дефолт: cwd)")
    ap.add_argument("--dry-run", action="store_true", help="показать, что уйдёт, без создания issue")
    ap.add_argument("--core-repo", default=None, help="репо ядра (override [contribute].core_repo)")
    ap.add_argument("--feedback-dir", default=None, help="каталог outbox (override [contribute].feedback_dir)")
    args = ap.parse_args()
    repo = args.repo.expanduser().resolve()
    if not repo.is_dir():
        fail(f"{repo} не каталог")

    cfg = load_contribute(repo)
    core_repo = args.core_repo or cfg.get("core_repo") or DEFAULT_CORE_REPO
    fb = args.feedback_dir or cfg.get("feedback_dir") or DEFAULT_FEEDBACK_DIR
    feedback_dir = (repo / fb).resolve()
    return deliver(repo, core_repo, feedback_dir, args.dry_run)


if __name__ == "__main__":
    sys.exit(main())
