#!/usr/bin/env python3
"""Рендер тощей базы kit в репо проекта + детект отставания/дрейфа.

Часть модуля base каталога kit; живёт в кэше платформы, запускается из корня
репо проекта (или с --repo). Кроссплатформенный: только stdlib (Python >= 3.11,
tomllib), pathlib, явный utf-8, записи атомарные (tmp + os.replace), генерат
детерминирован (без дат — байтовое сравнение в --check честное).

Режимы:
  --init        создать .kit/ и answers-файл из шаблона (шаг анкеты установки)
  (без флагов)  отрендерить .kit/schema.md из шаблона модуля и answers-файла;
                создать .kit/local.md, если его нет; записать версию шаблона
                в answers-файл
  --check       ничего не писать: сверить версию шаблона и байты генерата

Коды выхода: 0 — ок; 1 — check нашёл отставание/дрейф; 2 — ошибка (нет базы,
невалидные answers, сломанный шаблон).
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
from pathlib import Path

try:
    import tomllib
except ModuleNotFoundError:  # Python < 3.11
    sys.stderr.write("render_base: нужен Python >= 3.11 (модуль tomllib)\n")
    sys.exit(2)

MODULE_ROOT = Path(__file__).resolve().parent.parent
TEMPLATES = MODULE_ROOT / "templates"
KIT_DIR = ".kit"
ANSWERS = "answers.toml"
SCHEMA = "schema.md"
LOCAL = "local.md"

SUPPORTED_ANSWERS_SCHEMA = 1
ROLES = [
    ("pipeline_writer", "конвейер-писатель"),
    ("fog_writer", "туман-писатель"),
    ("scout", "разведчик"),
    ("reviewer", "встречный ревьюер"),
]
STRICTNESS_LABELS = {"auto_counter_review": "автозаказ встречного ревью"}
CARRIERS = {"codex", "claude", "counter"}
LINES = {"single", "dual"}
CHANNELS = {"stable", "main"}
MODES = {"strict", "auto"}


def fail(msg: str) -> "sys.NoReturn":
    sys.stderr.write(f"render_base: {msg}\n")
    sys.exit(2)


def module_version() -> str:
    manifest = MODULE_ROOT / ".claude-plugin" / "plugin.json"
    return json.loads(manifest.read_text(encoding="utf-8"))["version"]


def atomic_write(path: Path, text: str) -> None:
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(text, encoding="utf-8", newline="\n")
    os.replace(tmp, path)


def load_answers(path: Path) -> dict:
    try:
        data = tomllib.loads(path.read_text(encoding="utf-8"))
    except tomllib.TOMLDecodeError as e:
        fail(f"{path} не парсится как TOML: {e}")
    return data


def validate(a: dict) -> list[str]:
    errors: list[str] = []

    def need_str(section: str, key: str, allowed: set[str] | None = None) -> str:
        value = a.get(section, {}).get(key)
        if not isinstance(value, str) or not value.strip():
            errors.append(f"[{section}] {key}: обязательное непустое строковое поле")
            return ""
        if allowed is not None and value not in allowed:
            errors.append(f"[{section}] {key}: '{value}' — допустимо {sorted(allowed)}")
        return value

    schema_ver = a.get("kit", {}).get("schema_version")
    if schema_ver != SUPPORTED_ANSWERS_SCHEMA:
        errors.append(
            f"[kit] schema_version = {schema_ver!r}, скрипт поддерживает "
            f"{SUPPORTED_ANSWERS_SCHEMA} — версии answers-файла и модуля base разошлись"
        )
    if not isinstance(a.get("kit", {}).get("base_version"), str):
        errors.append("[kit] base_version: обязательное строковое поле")

    need_str("project", "name")
    main_branch = need_str("project", "main_branch")
    agent_branch = need_str("project", "agent_branch")
    if main_branch and agent_branch and main_branch == agent_branch:
        errors.append(
            "[project] agent_branch совпадает с main_branch — push-модель "
            "«агентская → MR → интеграционная» требует разных веток"
        )
    need_str("project", "lines", LINES)
    need_str("project", "python")
    need_str("project", "runner")
    need_str("project", "worktrees_root")
    need_str("project", "kit_channel", CHANNELS)

    profile = a.get("capacity", {}).get("profile")
    if profile not in (0, 1, 2):
        errors.append(f"[capacity] profile = {profile!r} — допустимо 0, 1 или 2")

    strictness = a.get("strictness", {})
    if "auto_counter_review" not in strictness:
        errors.append("[strictness] нет обязательной точки auto_counter_review")
    for key, value in strictness.items():
        if value not in MODES:
            errors.append(f"[strictness] {key} = {value!r} — допустимо {sorted(MODES)}")

    roles = a.get("roles", {})
    for slug, label in ROLES:
        role = roles.get(slug)
        if not isinstance(role, dict):
            errors.append(f"[roles.{slug}] секция обязательна ({label})")
            continue
        carrier = role.get("carrier")
        if carrier not in CARRIERS:
            errors.append(f"[roles.{slug}] carrier = {carrier!r} — допустимо {sorted(CARRIERS)}")
        elif carrier == "counter" and slug != "reviewer":
            errors.append(f"[roles.{slug}] carrier = 'counter' допустим только для reviewer")
        for key in ("tier", "effort"):
            if not isinstance(role.get(key), str):
                errors.append(f"[roles.{slug}] {key}: обязательное строковое поле (пустая строка = дефолт платформы)")
        permissions = role.get("permissions")
        if not isinstance(permissions, str) or not permissions.strip():
            errors.append(f"[roles.{slug}] permissions: обязательное непустое имя пресета")
    return errors


def roles_table(a: dict) -> str:
    rows = ["| Роль | Носитель | Tier | Effort | Разрешения |", "|---|---|---|---|---|"]
    for slug, label in ROLES:
        role = a["roles"][slug]
        tier = role["tier"] or "—"
        effort = role["effort"] or "—"
        rows.append(
            f"| {label} (`{slug}`) | {role['carrier']} | {tier} | {effort} | `{role['permissions']}` |"
        )
    return "\n".join(rows)


def strictness_table(a: dict) -> str:
    rows = ["| Точка | Режим |", "|---|---|"]
    for key in sorted(a["strictness"]):
        label = STRICTNESS_LABELS.get(key, key)
        suffix = f" (`{key}`)" if key in STRICTNESS_LABELS else ""
        rows.append(f"| {label}{suffix} | {a['strictness'][key]} |")
    return "\n".join(rows)


def render_schema(a: dict, version: str) -> str:
    template = (TEMPLATES / "schema.template.md").read_text(encoding="utf-8")
    ctx = {
        "base_version": version,
        "capacity.profile": str(a["capacity"]["profile"]),
        "roles_table": roles_table(a),
        "strictness_table": strictness_table(a),
    }
    for key, value in a["project"].items():
        ctx[f"project.{key}"] = str(value)
    rendered = re.sub(
        r"\{\{([^{}]+)\}\}",
        lambda m: ctx.get(m.group(1).strip(), m.group(0)),
        template,
    )
    leftovers = sorted(set(re.findall(r"\{\{[^{}]+\}\}", rendered)))
    if leftovers:
        fail(f"в шаблоне схемы неизвестные плейсхолдеры: {', '.join(leftovers)}")
    return rendered


def write_base_version(answers_path: Path, version: str) -> None:
    text = answers_path.read_text(encoding="utf-8")
    pattern = re.compile(r'(?m)^(base_version\s*=\s*")[^"]*(")')
    if len(pattern.findall(text)) != 1:
        fail(f"в {answers_path} поле base_version не найдено ровно один раз")
    atomic_write(answers_path, pattern.sub(rf"\g<1>{version}\g<2>", text))


def cmd_init(repo: Path) -> int:
    kit_dir = repo / KIT_DIR
    answers_path = kit_dir / ANSWERS
    if answers_path.exists():
        fail(f"{answers_path} уже существует — init только для чистой установки")
    kit_dir.mkdir(parents=True, exist_ok=True)
    atomic_write(answers_path, (TEMPLATES / "answers.template.toml").read_text(encoding="utf-8"))
    print(f"создан {answers_path}")
    print("дальше: заполнить ответы анкеты и запустить рендер (этот скрипт без флагов)")
    return 0


def cmd_render(repo: Path) -> int:
    answers_path = repo / KIT_DIR / ANSWERS
    if not answers_path.exists():
        fail(f"{answers_path} не найден — база не установлена (сначала --init и анкета)")
    answers = load_answers(answers_path)
    errors = validate(answers)
    if errors:
        sys.stderr.write("render_base: answers-файл невалиден:\n")
        for error in errors:
            sys.stderr.write(f"  - {error}\n")
        return 2
    version = module_version()
    atomic_write(repo / KIT_DIR / SCHEMA, render_schema(answers, version))
    print(f"отрендерен {KIT_DIR}/{SCHEMA} (base@{version})")
    local_path = repo / KIT_DIR / LOCAL
    if not local_path.exists():
        atomic_write(local_path, (TEMPLATES / "local.seed.md").read_text(encoding="utf-8"))
        print(f"создан сид {KIT_DIR}/{LOCAL}")
    if answers["kit"]["base_version"] != version:
        write_base_version(answers_path, version)
        print(f"в {KIT_DIR}/{ANSWERS} записана base_version = \"{version}\"")
    return 0


def cmd_check(repo: Path) -> int:
    answers_path = repo / KIT_DIR / ANSWERS
    if not answers_path.exists():
        fail(f"{answers_path} не найден — база не установлена (сначала --init и анкета)")
    answers = load_answers(answers_path)
    errors = validate(answers)
    if errors:
        sys.stderr.write("render_base: answers-файл невалиден:\n")
        for error in errors:
            sys.stderr.write(f"  - {error}\n")
        return 2
    version = module_version()
    findings: list[str] = []
    rendered_version = answers["kit"]["base_version"]
    if rendered_version != version:
        findings.append(
            f"ОТСТАВАНИЕ: база отрендерена base@{rendered_version}, "
            f"в кэше платформы base@{version} — нужен перерендер"
        )
    schema_path = repo / KIT_DIR / SCHEMA
    if not schema_path.exists():
        findings.append(f"ОТСТАВАНИЕ: генерат {KIT_DIR}/{SCHEMA} отсутствует — нужен рендер")
    elif rendered_version == version and schema_path.read_text(encoding="utf-8") != render_schema(answers, version):
        findings.append(
            f"ДРЕЙФ: {KIT_DIR}/{SCHEMA} отличается от детерминированного рендера "
            "(правка answers без перерендера или ручная правка генерата)"
        )
    if not (repo / KIT_DIR / LOCAL).exists():
        findings.append(f"ОТСТАВАНИЕ: {KIT_DIR}/{LOCAL} отсутствует — перерендер создаст сид")
    if findings:
        for finding in findings:
            print(finding)
        return 1
    print(f"OK: база свежа (base@{version})")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Рендер тощей базы kit / детект отставания")
    parser.add_argument("--repo", type=Path, default=Path.cwd(), help="корень репо проекта (дефолт: cwd)")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--init", action="store_true", help="создать .kit/ и answers-файл из шаблона")
    mode.add_argument("--check", action="store_true", help="сверить базу с ядром, ничего не писать")
    args = parser.parse_args()
    repo = args.repo.expanduser().resolve()
    if not repo.is_dir():
        fail(f"{repo} не каталог")
    if args.init:
        return cmd_init(repo)
    if args.check:
        return cmd_check(repo)
    return cmd_render(repo)


if __name__ == "__main__":
    sys.exit(main())
