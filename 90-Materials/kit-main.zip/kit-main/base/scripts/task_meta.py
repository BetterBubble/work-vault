#!/usr/bin/env python3
"""
task_meta.py — мета-файл дома задачи `.tasks/work/<ключ>/meta.json`.

Формат — контракт данных base (CONTRACT.md этого модуля, версия 1); мету читают
инструмент наблюдаемости (pulse) и скрипты среды проекта (изоляция разведки —
поле `env`, land ворктри — поле `base`). Норма durable-следа (стандарт схемы):
дом рождается с метой; закрытие переводит статус в closed, сносит эфемерный
`scratch/` задачи и переезжает домом в `work/_archive/`.

CLI (stdlib-only, работает голым python3; из корня репо/ворктри либо с --root):
  init  --key K [--kind KIND] [--mode inline|worktree] [--title T]
        [--env E] [--line L] [--base BRANCH] [--created YYYY-MM-DD] [--force]
      Создать дом + мету. Идемпотентен: мета уже есть → no-op (перезапись --force).
      kind: write|fix|update|research|infra|adhoc|review|refactor (дефолт adhoc).
      Связи links (tc/jira/todo) выводятся из ключа автоматически.
  close --key K
      status=closed + дата закрытия, снос scratch/, переезд дома в work/_archive/.
      Переезд трекаемых файлов коммитит вызывающий (агент), скрипт двигает только ФС.
"""
from __future__ import annotations

import argparse
import datetime
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

CONTRACT_VERSION = 1


def repo_root(override: str | None = None) -> Path:
    if override:
        return Path(override).expanduser().resolve()
    try:
        out = subprocess.run(['git', 'rev-parse', '--show-toplevel'],
                             capture_output=True, text=True, timeout=10).stdout.strip()
        if out:
            return Path(out)
    except Exception:
        pass
    return Path.cwd()


def derive_links(key: str) -> dict:
    m = re.match(r'^(?:tc|update)-(\d+)$', key, re.IGNORECASE)
    if m:
        return {'tc': [int(m.group(1))]}
    m = re.match(r'^(TODO-\d+)', key, re.IGNORECASE)
    if m:
        return {'todo': [m.group(1).upper()]}
    if re.match(r'^[A-Z]+-\d+$', key):
        return {'jira': [key]}
    return {}


def meta_path(root: Path, key: str) -> Path:
    return root / '.tasks' / 'work' / key / 'meta.json'


def write_meta(path: Path, meta: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(meta, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def cmd_init(args) -> int:
    root = repo_root(args.root)
    path = meta_path(root, args.key)
    if path.exists() and not args.force:
        print(f'meta уже есть, no-op: {path}')
        return 0
    meta = {
        'v': CONTRACT_VERSION,
        'key': args.key,
        'title': args.title or args.key,
        'kind': args.kind,
        'mode': args.mode,
        'status': 'active',
        'created': args.created or datetime.date.today().isoformat(),
    }
    if args.line:
        meta['line'] = args.line
    if args.env:
        meta['env'] = args.env
    if args.base:
        meta['base'] = args.base
    links = derive_links(args.key)
    if links:
        meta['links'] = links
    write_meta(path, meta)
    print(f'дом засеян: {path}')
    return 0


def cmd_close(args) -> int:
    root = repo_root(args.root)
    home = root / '.tasks' / 'work' / args.key
    archive = root / '.tasks' / 'work' / '_archive' / args.key
    if not home.is_dir():
        if archive.is_dir():
            print(f'уже в архиве, no-op: {archive}')
            return 0
        print(f'дом не найден: {home}', file=sys.stderr)
        return 1
    path = home / 'meta.json'
    if path.exists():
        meta = json.loads(path.read_text(encoding='utf-8'))
    else:
        # Легаси-дом без меты — дозасеять минимальную, чтобы архив не остался хвостом.
        print(f'WARN: дом без меты (нарушение контракта) — дозасеиваю минимальную: {path}',
              file=sys.stderr)
        meta = {'v': CONTRACT_VERSION, 'key': args.key, 'title': args.key,
                'kind': 'adhoc', 'mode': 'inline', 'status': 'active',
                'created': datetime.date.today().isoformat()}
    meta['status'] = 'closed'
    meta['closed'] = datetime.date.today().isoformat()
    write_meta(path, meta)
    scratch = home / 'scratch'
    if scratch.is_dir():
        shutil.rmtree(scratch)   # эфемерное задачи умирает с задачей (ретеншн стандарта)
    if archive.exists():
        print(f'в архиве уже есть {archive} — переезд не выполнен', file=sys.stderr)
        return 1
    archive.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(home), str(archive))
    print(f'закрыт и заархивирован: {archive}')
    return 0


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description='Мета-файл дома задачи (.tasks/work/<ключ>/meta.json, контракт base v1).')
    sub = p.add_subparsers(dest='cmd', required=True)
    si = sub.add_parser('init')
    si.add_argument('--root', help='корень репо/ворктри (дефолт — git toplevel от cwd)')
    si.add_argument('--key', required=True)
    si.add_argument('--kind', default='adhoc',
                    choices=['write', 'fix', 'update', 'research', 'infra', 'adhoc', 'review', 'refactor'])
    si.add_argument('--mode', default='inline', choices=['inline', 'worktree'])
    si.add_argument('--title')
    si.add_argument('--env')
    si.add_argument('--line')
    si.add_argument('--base')
    si.add_argument('--created')
    si.add_argument('--force', action='store_true')
    sc = sub.add_parser('close')
    sc.add_argument('--root', help='корень репо/ворктри (дефолт — git toplevel от cwd)')
    sc.add_argument('--key', required=True)
    args = p.parse_args(argv)
    return cmd_init(args) if args.cmd == 'init' else cmd_close(args)


if __name__ == '__main__':
    sys.exit(main())
