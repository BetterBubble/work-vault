#!/usr/bin/env python3
"""Детект нарушений инварианта корня `.tasks/` — элементов вне карты зоны.

Часть модуля base каталога kit; живёт в кэше платформы, запускается из корня
репо проекта (или с --repo). Кроссплатформенный: только stdlib, pathlib,
явный utf-8.

Инвариант стандарта (схема base, «Прозрачность»): в корне `.tasks/` не
появляется ничего вне карты зоны `.tasks/README.md`. Типовой дефект — путь,
сконструированный по памяти вместо чтения карты: два легальных scratch-места
(`work/<ключ>/scratch/` задачи и общий `.tasks/_scratch/`) гибридизуются
в несуществующий `.tasks/scratch/`, субагент послушно пишет туда, и нарушение
живёт до случайного взгляда человека. Этот скрипт делает детект машинным;
якоря — base:check (старт сессии) и Phase 0 keep:retro.

Знание «что легально» берётся из самой карты: элемент корня известен, если его
имя встречается в README как `бэктик`-токен (первый сегмент пути, `.tasks/`
отброшен). Детектор намеренно мягкий — упомянут в карте хоть где-то → легален
(ложное срабатывание дороже пропуска); gitignored неизвестные элементы
пропускаются (не сигналят в git-статусе — приберёт ротация retro).

Коды выхода: 0 — чисто (или `.tasks/` нет); 1 — найдены нарушения.
"""
from __future__ import annotations

import argparse
import re
import subprocess
import sys
from pathlib import Path

MAP_NAME = "README.md"
# Служебное самой зоны, законное без строки в карте.
ALWAYS_OK = {".gitignore"}


def known_names(map_text: str) -> set[str]:
    names: set[str] = set()
    for token in re.findall(r"`([^`\n]+)`", map_text):
        token = token.strip()
        if not token or any(ch.isspace() for ch in token):
            continue  # `ls -A .tasks/` и прочие команды — не имена классов
        token = token.removeprefix(".tasks/")
        first = token.split("/", 1)[0]
        if first:
            names.add(first)
    return names


def is_gitignored(repo: Path, rel_path: str) -> bool:
    try:
        result = subprocess.run(
            ["git", "-C", str(repo), "check-ignore", "-q", "--", rel_path],
            capture_output=True,
        )
    except OSError:
        return False  # нет git — считаем не-ignored, честнее предупредить
    return result.returncode == 0


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Детект элементов корня .tasks/ вне карты .tasks/README.md"
    )
    parser.add_argument("--repo", type=Path, default=Path.cwd(),
                        help="корень репо проекта (дефолт: cwd)")
    args = parser.parse_args()
    repo = args.repo.expanduser().resolve()
    tasks = repo / ".tasks"
    if not tasks.is_dir():
        print("OK: .tasks/ нет — проверять нечего")
        return 0
    map_path = tasks / MAP_NAME
    if not map_path.is_file():
        print(f"НАРУШЕНИЕ: .tasks/ есть, а карты .tasks/{MAP_NAME} нет — карта "
              "единственный статический вход зоны (стандарт схемы base): "
              "строка на каждый класс артефактов")
        return 1
    known = known_names(map_path.read_text(encoding="utf-8")) | ALWAYS_OK
    violations = [
        child.name
        for child in sorted(tasks.iterdir())
        if child.name not in known
        and not is_gitignored(repo, f".tasks/{child.name}")
    ]
    if violations:
        for name in violations:
            print(f"НАРУШЕНИЕ: .tasks/{name} — элемент корня вне карты .tasks/{MAP_NAME}")
        print("Адрес артефакта берётся из карты, не конструируется по памяти "
              "(дом задачи — work/<ключ>/, эфемерное — work/<ключ>/scratch/ "
              "или _scratch/); классу нужно постоянное место → сначала строка "
              "класса в карте.")
        return 1
    print(f"OK: корень .tasks/ соответствует карте .tasks/{MAP_NAME}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
