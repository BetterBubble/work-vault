#!/usr/bin/env python3
"""Инвентарь локальных наработок агент-среды репо потребителя (петля отдачи base:contribute).

Реестр локальных наработок не ведётся, а ВЫВОДИТСЯ (решение карты agent-env 004 п.5):
ядро kit живёт вне репо (в кэше платформы) ⇒ всё в агент-среде репо, кроме генерата, —
локально по определению. Скрипт перечисляет единицы + git-факты (возраст/стабильность/
churn). Зрелость («это можно переформулировать без имён продукта/стенда → кандидат в
ядро») скрипт НЕ судит — это аналитический разбор агента в скилле; скрипт — только листер.

Критерий отсечения — «генерат/проекция», НЕ «конкретный слой»: исключается механическая
проекция среды (двойной учёт первоисточника), а какой слой канонический, а какой генерат —
свойство развёртки (`[contribute].generated_globs` в answers), не хардкод. Для Codex-first
потребителя канонический слой — Codex, проекции-генерата обычно нет → инвентарь берёт слой
целиком.

Часть модуля base каталога kit; живёт в кэше платформы, запускается из корня репо проекта
(или с --repo). Кроссплатформенный: только stdlib (Python >= 3.11, tomllib), pathlib,
явный utf-8, git через subprocess со списком аргументов (без shell).

Параметры (`.kit/answers.toml`, секция `[contribute]`, читаются с дефолтами):
  inventory_roots  — каталоги агент-среды для обхода (дефолт [".claude", ".codex"])
  generated_globs  — глобы генерата-проекции для исключения (дефолт []; поддержка ** и *)

Коды выхода: 0 — ок (в т.ч. пустой инвентарь); 2 — ошибка (нет репо / битый answers).
"""
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
from pathlib import Path

try:
    import tomllib
except ModuleNotFoundError:  # Python < 3.11
    sys.stderr.write("inventory_local: нужен Python >= 3.11 (модуль tomllib)\n")
    sys.exit(2)

ANSWERS = Path(".kit") / "answers.toml"
DEFAULT_ROOTS = [".claude", ".codex"]
DEFAULT_GENERATED: list[str] = []
# Build-мусор, никогда не наработка — жёсткий скип (отдельно от generated_globs про проекцию).
JUNK_DIRS = {"__pycache__", ".pytest_cache", "node_modules"}
JUNK_SUFFIXES = {".pyc", ".pyo"}
JUNK_NAMES = {".DS_Store"}
# Классификация единицы по подкаталогу слоя (skills/ — единица = каталог скилла,
# остальное — единица = файл). Порядок = приоритет матчинга сегмента пути.
CATEGORIES = ("skills", "scripts", "rules", "agents", "hooks", "commands")


def fail(msg: str) -> "sys.NoReturn":
    sys.stderr.write(f"inventory_local: {msg}\n")
    sys.exit(2)


def load_contribute(repo: Path) -> dict:
    """Секция [contribute] answers-файла (мягко: нет базы/секции → дефолты)."""
    path = repo / ANSWERS
    if not path.exists():
        return {}
    try:
        data = tomllib.loads(path.read_text(encoding="utf-8"))
    except tomllib.TOMLDecodeError as e:
        fail(f"{path} не парсится как TOML: {e}")
    section = data.get("contribute", {})
    return section if isinstance(section, dict) else {}


def glob_to_regex(glob: str) -> re.Pattern:
    """Глоб → регэксп с поддержкой ** (любой префикс пути) и * (в пределах сегмента)."""
    out = []
    i, n = 0, len(glob)
    while i < n:
        c = glob[i]
        if c == "*":
            if i + 1 < n and glob[i + 1] == "*":
                out.append(".*")
                i += 2
                continue
            out.append("[^/]*")
        else:
            out.append(re.escape(c))
        i += 1
    return re.compile("^" + "".join(out) + "$")


def make_excluder(globs: list[str]):
    patterns = [glob_to_regex(g) for g in globs]

    def excluded(relposix: str) -> bool:
        return any(p.match(relposix) for p in patterns)

    return excluded


def git_facts(repo: Path, relposix: str) -> dict:
    """Git-факты по пути: возраст (первый коммит), последнее изменение, число коммитов.

    Не в git / нет коммитов по пути → {'tracked': False}. Ошибка git → то же (fail-open).
    """
    try:
        res = subprocess.run(
            ["git", "log", "--format=%as", "--", relposix],
            cwd=str(repo), capture_output=True, text=True, check=False,
        )
    except (OSError, ValueError):
        return {"tracked": False}
    if res.returncode != 0:
        return {"tracked": False}
    dates = [ln.strip() for ln in res.stdout.splitlines() if ln.strip()]
    if not dates:
        return {"tracked": False}
    return {
        "tracked": True,
        "first_commit": dates[-1],   # git log — новые сверху, старый снизу
        "last_change": dates[0],
        "commits": len(dates),
    }


def categorize(relparts: tuple[str, ...]) -> str:
    """Класс единицы по сегментам относительного пути (первый совпавший из CATEGORIES)."""
    for seg in relparts:
        if seg in CATEGORIES:
            return seg[:-1] if seg.endswith("s") else seg  # skills→skill, rules→rule
    return "other"


def collect_units(repo: Path, root: str, excluded) -> list[dict]:
    """Единицы под одним корнем агент-среды. skills/<name>/ — единица-каталог, прочее — файл."""
    base = repo / root
    if not base.is_dir():
        return []
    units: list[dict] = []
    seen_skill_dirs: set[Path] = set()
    for path in sorted(base.rglob("*")):
        rel = path.relative_to(repo)
        relposix = rel.as_posix()
        if excluded(relposix):
            continue
        parts = rel.parts
        if (set(parts) & JUNK_DIRS) or path.suffix in JUNK_SUFFIXES or path.name in JUNK_NAMES:
            continue
        # Каталог скилла: <root>/.../skills/<name>/ — единица = сам каталог <name>, не его файлы.
        if "skills" in parts:
            idx = parts.index("skills")
            if len(parts) > idx + 1:
                skill_dir = repo / Path(*parts[: idx + 2])
                if skill_dir in seen_skill_dirs:
                    continue
                seen_skill_dirs.add(skill_dir)
                srel = skill_dir.relative_to(repo)
                if excluded(srel.as_posix()):
                    continue
                units.append({
                    "unit": srel.as_posix(),
                    "category": "skill",
                    **git_facts(repo, srel.as_posix()),
                })
                continue
        if path.is_file():
            units.append({
                "unit": relposix,
                "category": categorize(parts),
                **git_facts(repo, relposix),
            })
    return units


def render_text(repo: Path, roots: list[str], globs: list[str], units: list[dict]) -> str:
    lines = [
        f"Инвентарь локальных наработок агент-среды — {repo.name}",
        f"Корни: {', '.join(roots)}   Исключено (генерат): {', '.join(globs) or '—'}",
        "",
    ]
    if not units:
        lines.append("Единиц не найдено (пустая агент-среда или всё под generated_globs).")
        lines.append("")
        lines.append("Зрелость и кандидаты в ядро — аналитический разбор агента (скилл base:contribute), не этого скрипта.")
        return "\n".join(lines)
    by_cat: dict[str, list[dict]] = {}
    for u in units:
        by_cat.setdefault(u["category"], []).append(u)
    lines.append(f"Единиц: {len(units)} (возраст = первый коммит, стабильность = последнее изменение, churn = коммитов).")
    lines.append("")
    for cat in sorted(by_cat):
        lines.append(f"## {cat} ({len(by_cat[cat])})")
        for u in by_cat[cat]:
            if u.get("tracked"):
                facts = f"с {u['first_commit']}, посл. {u['last_change']}, коммитов {u['commits']}"
            else:
                facts = "не в git (новая/непрокоммиченная)"
            lines.append(f"  • {u['unit']}  —  {facts}")
        lines.append("")
    lines.append("Зрелость и кандидаты в ядро — аналитический разбор агента (скилл base:contribute):")
    lines.append("критерий «формулируется без имён продукта/стенда» = «можно переформулировать»,")
    lines.append("общий принцип → ядро, конкретику → параметры. Скрипт зрелость не судит.")
    return "\n".join(lines)


def main() -> int:
    ap = argparse.ArgumentParser(description="Инвентарь локальных наработок агент-среды (листер, не судья зрелости).")
    ap.add_argument("--repo", type=Path, default=Path.cwd(), help="корень репо проекта (дефолт: cwd)")
    ap.add_argument("--json", action="store_true", help="машинный вывод (JSON) вместо таблицы")
    args = ap.parse_args()
    repo = args.repo.expanduser().resolve()
    if not repo.is_dir():
        fail(f"{repo} не каталог")

    cfg = load_contribute(repo)
    roots = cfg.get("inventory_roots") or DEFAULT_ROOTS
    globs = cfg.get("generated_globs") or DEFAULT_GENERATED
    if not isinstance(roots, list) or not all(isinstance(r, str) for r in roots):
        fail("[contribute].inventory_roots должен быть списком строк")
    if not isinstance(globs, list) or not all(isinstance(g, str) for g in globs):
        fail("[contribute].generated_globs должен быть списком строк")

    excluded = make_excluder(globs)
    units: list[dict] = []
    for root in roots:
        units.extend(collect_units(repo, root, excluded))

    if args.json:
        print(json.dumps(
            {"repo": repo.name, "roots": roots, "generated_globs": globs, "units": units},
            ensure_ascii=False, indent=2,
        ))
    else:
        print(render_text(repo, roots, globs, units))
    return 0


if __name__ == "__main__":
    sys.exit(main())
