#!/usr/bin/env python3
"""Генерат нативных Codex-обёрток каталога kit из канонических CC-манифестов.

Инструмент публикации репо-каталога (не модуль потребителя); запускается из
корня репо kit (или с --repo) после любой правки манифестов / добавления модуля.
Канон — CC-формат (.claude-plugin/marketplace.json + <модуль>/.claude-plugin/
plugin.json); генерат — нативный Codex-формат (.agents/plugins/marketplace.json +
<модуль>/.codex-plugin/plugin.json). При соседстве манифестов Codex берёт
нативный, CC видит только свой — генерат руками не правится.

Кроссплатформенный: только stdlib (Python >= 3.9), pathlib, явный utf-8,
записи атомарные (tmp + os.replace), генерат детерминирован (без дат —
байтовое сравнение в --check честное).

Режимы:
  (без флагов)  отрендерить обёртки из CC-манифестов
  --check       ничего не писать: сверить байты обёрток с рендером

Коды выхода: 0 — ок; 1 — check нашёл отставание/дрейф; 2 — ошибка
(нет/невалиден CC-манифест).
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

CC_MARKETPLACE = Path(".claude-plugin") / "marketplace.json"
CC_PLUGIN = Path(".claude-plugin") / "plugin.json"
CODEX_MARKETPLACE = Path(".agents") / "plugins" / "marketplace.json"
CODEX_PLUGIN = Path(".codex-plugin") / "plugin.json"

# Опциональные поля, общие для обоих форматов plugin.json — переносятся как есть.
PLUGIN_PASSTHROUGH = ("author", "homepage", "repository", "license", "keywords")


def fail(msg: str) -> "sys.NoReturn":
    sys.stderr.write(f"render_codex: {msg}\n")
    sys.exit(2)


def load_json(path: Path) -> dict:
    if not path.is_file():
        fail(f"{path} не найден")
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        fail(f"{path} не парсится как JSON: {e}")


def dump(data: dict) -> str:
    return json.dumps(data, ensure_ascii=False, indent=2) + "\n"


def atomic_write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(text, encoding="utf-8", newline="\n")
    os.replace(tmp, path)


def render(repo: Path) -> dict[Path, str]:
    """Пути генератов (относительно repo) -> детерминированный контент."""
    cc = load_json(repo / CC_MARKETPLACE)
    for key in ("name", "plugins"):
        if key not in cc:
            fail(f"{CC_MARKETPLACE}: нет обязательного поля '{key}'")

    out: dict[Path, str] = {}
    native_plugins = []
    for entry in cc["plugins"]:
        source = entry.get("source")
        if not isinstance(source, str) or not source.startswith("./"):
            fail(f"{CC_MARKETPLACE}: source модуля {entry.get('name')!r} — ожидается относительный путь './...'")
        module_dir = repo / Path(*source.split("/"))
        cc_plugin = load_json(module_dir / CC_PLUGIN)
        for key in ("name", "version"):
            if key not in cc_plugin:
                fail(f"{source}/{CC_PLUGIN}: нет обязательного поля '{key}'")

        native_entry = {"name": entry["name"], "source": source, "version": cc_plugin["version"]}
        if "description" in entry:
            native_entry["description"] = entry["description"]
        native_plugins.append(native_entry)

        native_plugin = {"name": cc_plugin["name"], "version": cc_plugin["version"]}
        if "description" in cc_plugin:
            native_plugin["description"] = cc_plugin["description"]
        for key in PLUGIN_PASSTHROUGH:
            if key in cc_plugin:
                native_plugin[key] = cc_plugin[key]
        if (module_dir / "skills").is_dir():
            native_plugin["skills"] = "./skills/"
        out[Path(*source.split("/")) / CODEX_PLUGIN] = dump(native_plugin)

    native_marketplace = {"name": cc["name"]}
    description = cc.get("metadata", {}).get("description")
    if description:
        native_marketplace["description"] = description
    if "owner" in cc:
        native_marketplace["owner"] = cc["owner"]
    native_marketplace["plugins"] = native_plugins
    out[CODEX_MARKETPLACE] = dump(native_marketplace)
    return out


def cmd_render(repo: Path) -> int:
    for rel, text in render(repo).items():
        atomic_write(repo / rel, text)
        print(f"отрендерен {rel}")
    return 0


def cmd_check(repo: Path) -> int:
    findings: list[str] = []
    for rel, text in render(repo).items():
        path = repo / rel
        if not path.is_file():
            findings.append(f"ОТСТАВАНИЕ: генерат {rel} отсутствует — нужен рендер")
        elif path.read_text(encoding="utf-8") != text:
            findings.append(
                f"ДРЕЙФ: {rel} отличается от детерминированного рендера "
                "(правка CC-манифеста без перерендера или ручная правка генерата)"
            )
    if findings:
        for finding in findings:
            print(finding)
        return 1
    print("OK: Codex-обёртки свежи")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Генерат Codex-обёрток каталога kit из CC-манифестов")
    parser.add_argument("--repo", type=Path, default=Path.cwd(), help="корень репо kit (дефолт: cwd)")
    parser.add_argument("--check", action="store_true", help="сверить обёртки с рендером, ничего не писать")
    args = parser.parse_args()
    repo = args.repo.expanduser().resolve()
    if not repo.is_dir():
        fail(f"{repo} не каталог")
    return cmd_check(repo) if args.check else cmd_render(repo)


if __name__ == "__main__":
    sys.exit(main())
