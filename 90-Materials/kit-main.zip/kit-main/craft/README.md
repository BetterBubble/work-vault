# craft — модуль изготовления автотестов (каталог kit)

Петля автоматизации: write / fix / update + оркестраторы batch / issue.
Трёхслойная модель: **стек-нейтральный канон** (скиллы, субагенты,
`rules/invariants.md`) + **референс-реализации стека** (`stacks/`, контракт —
`stacks/README.md`) + **экземплярный слой проекта** (параметры `[craft]` +
CLAUDE.md/конфиги репо).

## Состав

| Что | Где |
|---|---|
| Скиллы `craft:write` / `craft:fix` / `craft:update` / `craft:batch` / `craft:issue` | `skills/` |
| Субагенты `craft:code-writer` / `craft:codebase-analyst` / `craft:dom-explorer` | `agents/` |
| Стек-нейтральные инварианты тест-дисциплины | `rules/invariants.md` |
| Референс-реализации стека (pytest-playwright-canvas, pytest-selenium) | `stacks/` |
| Общие фрагменты (ledger метрик + отступления, coverage-ledger + его шаблон, bug-candidates) | `shared/` |
| Методология мини-эвалов агент-инфры | `evals/EVALS.template.md` |
| Референс фабрики research-юзеров (ось product-api) | `references/product-api/` |

## Параметры проекта — секция `[craft]` в `.kit/answers.toml`

Без файла/секции действуют дефолты (референс one-web). `python`/`runner` —
секция `[project]` базы, craft их не дублирует.

```toml
[craft]
stack = "pytest-playwright-canvas"  # каталог stacks/<stack>/ (pytest-playwright-canvas | pytest-selenium | свой)
default_env = ""       # env стенда по умолчанию для прогонов (референс: "kmp-stage")
shared_users = []      # white-list общих тест-юзеров (санитизация; opt-in разведка без фабрики)
research_user_cmd = "" # команда фабрики эфемерных research-юзеров (референс: "./venv/bin/python .claude/scripts/research_user.py"); пусто = фабрики нет
vendored_dep = ""      # имя vendored-библиотеки REST-обёрток (референс: "autocore"); пусто = блоки [vendored-dep] неактивны
product_clone = ""     # путь к read-only клону исходников AUT; пусто = нет клона
```

Экземпляр карты фич проекта — `.kit/craft/feature-mapping.md` (сеется из
`skills/write/references/feature-mapping.template.md` первым прогоном
`craft:write`; версионируется в git проекта).

## Межмодульные связи (мягкие)

Чтение TMS — модуль **tms** (`tms:read`); мета домов задач и контракт fallback
делегирования — **base** (`.kit/schema.md`); доставка MR и полный протокол
гигиены коммита — **ship**; CI-прогоны и разбор ланчей — **track**. Модули
ставятся независимо; отсутствие соседа скиллы обрабатывают явной развилкой
(сказать пользователю), не молчаливым пропуском.
