---
name: fix
description: >-
  Чинит упавший тест и вносит правки (адресация/методы page-слоя/импорты/вызовы;
  НЕ правит vendored-библиотеку). Вход: имя теста/TC-id (гоняет раннер сам), stack trace,
  путь к каталогу сырых результатов прогона (allure-raw), ссылка на ланч TMS либо
  diff-bundle от craft:update. Batch 1..N не-зелёных за прогон. Тест ещё не написан →
  craft:write; TC изменился (а не упал) → craft:update; только посмотреть ланч без
  фикса — read-only разбор ланча (модуль track).
---

# Анализ и фикс упавших тестов (модуль craft, batch)

Путь к модулю ниже обозначен `$CRAFT`: в Claude Code это `${CLAUDE_PLUGIN_ROOT}`;
на другой платформе — каталог модуля craft в её кэше плагинов. Стек проекта —
параметр `stack` секции `[craft]` в `.kit/answers.toml`; файлы стека —
`$CRAFT/stacks/{stack}/`.

Skill принимает информацию о падении (имя теста / stack trace / каталог сырых
результатов / ссылка на ланч TMS), формирует список не-зелёных тестов длиной от 1,
для каждого воспроизводит, классифицирует, фиксит, верифицирует по словарю
конфигураций стека, и в конце выдаёт сводный batch-отчёт с готовыми комментариями
для трекера и bug-report'ами.

## Знания о поверхности AUT

При анализе консультируйся с источниками знаний о поверхности проекта — их список
и приоритет задаёт CLAUDE.md проекта (референс: докстринги page-классов →
coverage-ledger проекта (`.tasks/coverage-ledger.md`) → реестр
`.tasks/known-issues.md`). Модель поверхности
и её вклад в падения — `$CRAFT/stacks/{stack}/recon.md` (референс canvas: часть
падений объясняется жизненным циклом accessibility-overlay, а не кодом теста).

*[опционально — модуль atlas]* Если проект ведёт living-AUT-map: в Phase 3 карта
показывает ожидаемую последовательность UI-шагов (расхождение → гипотеза
UX_FLOW_CHANGED); в Phase 4 её раздел quirks — готовые гипотезы flake'ов; при
обновлении карты по ходу фикса — пометка в Phase 7 «AUT-карта обновлена: §X.Y».

## Исходники продукта *[опционально]*

Если задан параметр `product_clone` секции `[craft]` (read-only клон исходников
AUT) — это второй источник знаний. Где помогает:
- **Phase 3-4 (гипотезы):** код компонента отвечает «что реально происходит при
  действии» — жесты, XHR, дебаунсы, optimistic UI. Надёжнее, чем угадывать по DOM.
- **DOM_CHANGED:** дифф клона между ревизиями по каталогу фичи — готовое
  объяснение для diagnosis.md (референс canvas: дифф реестра testTag'ов,
  `$CRAFT/stacks/pytest-playwright-canvas/recon.md`).
- `craft:dom-explorer` (mode=fix) сам сверяется с клоном при перепроверке адресации.

## Инвариант

> Один пайплайн для случая «1 тест» и «N тестов». Все три исторические ветки входа
> (имя теста / stack trace / сырые результаты прогона) — частные случаи списка длиной от 1.
>
> Phases 1-5 итерируются по каждому тесту, накапливая глобальный state `{fixed,
> deferred_flaky, deferred_automation, product_bugs, escalation, covered_by_undelivered,
> stand_incident, known_issue_confirmed}`. Phase 6 запускается **один раз** для двух
> корзин deferred-тестов. Phase 7 пишет единый batch-report.
>
> Массовые однопричинные падения (критерии — `references/batch-discovery.md` §4а)
> идут **групповым режимом**: Phases 1–3 — по представителю группы, фикс — эпицентра;
> Phase 5 — всё равно per-test для каждого теста группы (верификация прогоном не срезается).

Делегирует работу субагентам:
- `craft:codebase-analyst` (mode=fix) — inventory упавшего теста (фикстуры, методы, адресация, API).
- `craft:dom-explorer` (mode=fix) — проверяет актуальность адресации инструментом разведки стека (`$CRAFT/stacks/{stack}/recon.md`).
- `craft:code-writer` (mode=fix) — правит адресацию / методы / импорты через `Edit`.

Все прямые вызовы этих ролей здесь и в `references/` подчиняются контракту fallback
обязательного делегирования — `.kit/schema.md` проекта, секция «Роли» (база kit):
локальная подмена допустима только при подтверждённом отказе запуска до начала
работы роли, с теми же границами доступа и форматом выхода.

## Phase 0 — Discovery & Subgrouping

См. `references/batch-discovery.md`.

1. Определить источник входа по правилам `references/input-sources.md`:

| Признак | Ветка |
|---|---|
| Имя теста / TC-id без stack trace | `pytest-run` — запускаем раннер сами (`$CRAFT/stacks/{stack}/pytest-runner.md`) |
| `Traceback (most recent call last):` или `File "tests/...", line N` | `stack-trace-parse` — разбираем текст пользователя |
| Существующий путь к директории с `*-result.json` со `status:"failed"` | `allure-raw-parse` (`$CRAFT/stacks/{stack}/allure-raw-parser.md`) |
| URL ланча TMS или `launch <id>` | `launch-parse` — читаем ланч read-only CLI модуля tms (конвенции — tms:read; маппинг во вход фикса — `references/launch-input.md`) |
| Имя теста + структурированная дельта «TC↔код» (из `craft:update`) | `tc-diff` — ресинк под изменившийся TC, **не** падение; **минует Phase 1–3**, Phase 4 delta-driven (см. `references/input-sources.md` §5) |

2. Сформировать **список тестов** для обработки. В `allure-raw-parse` и
   `launch-parse` — если N>1, спросить пользователя короткой развилкой
   («все по очереди» — дефолт).

3. Для каждого теста извлечь:
   - `kind` (для launch — `failed`/`broken`/`xpass`/`xfail`/`skipped`; для xfail —
     отдельная ветка верификации места падения, см. `references/xfail-verification.md`);
   - *[test-stack]* `target_marker` — конфигурация браузера/платформы из словаря
     стека (`$CRAFT/stacks/{stack}/batch-conventions.md`). Мультибраузерный стек
     (референс Selenium): для launch — браузер из тегов ланча, на нём тест и упал;
     первичный repro (Phase 1) и финальная верификация (Phase 5) — на нём.
     Однобраузерный стек (референс canvas: headless chromium) — маркеров нет,
     пункт вырожден;
   - `was_local` — был ли прогон локальным (если стек различает; иначе False).

3a. Определить `env` (один на батч): параметр `default_env` секции `[craft]`.
   *[dual-line]* При двух линиях — по активной агентской ветке (карта — CLAUDE.md
   проекта). Записать в `state.md`. Перед прогонами — health-чек стенда по
   процедуре проекта (референс one-web: живость dev-server и REST; мёртвый слой →
   падения кластера — кандидат STAND_INCIDENT, кода не касаться).

> Вход `launch-parse`, пришедший через развилку read-only разбора ланча (модуль
> track; в args — готовые вердикты его сводки): **сверки** 3b/3c не повторять —
> перенести из сводки в `state.md` флаг `local_ahead` со списком недоставленных
> коммитов, границы окна деградации и known-issues-отметки. Действия по вердиктам —
> здесь, как обычно: «♻ подтверждён» → корзина `known_issue_confirmed` (обновить
> дату строки реестра, метрика `result=known-issue`); «⚠ сигнатура изменилась» →
> полный разбор с пометкой.

3b. **Только `launch-parse` — сверка ревизий и хронология** (процедура —
   `references/launch-input.md`, разделы «Сверка ревизий» и «Окна по времени»):
   - ветка ланча vs локальный код (`git log origin/<branch>..HEAD -- <тест-слой>`):
     локальный код впереди → `local_ahead=true` + список недоставленных коммитов
     в `state.md` — влияет на трактовку PASS в Phase 1;
   - кластер падений в узком временном окне + деградационные симптомы (5xx, пустые
     страницы аутентификации) → кандидат `STAND_INCIDENT`
     (`$CRAFT/stacks/{stack}/failure-taxonomy.md`), границы окна — в `state.md`.

3c. **Сверка с реестром known-issues** (`.tasks/known-issues.md`, все входы;
   процедура и критерий — `references/known-issues.md`): тест из входа имеет строку
   в реестре → сверить сигнатуру текущего падения (эпицентр + exception_class +
   ключевой фрагмент message) с записанной. Совпали все три → «подтверждён
   известный баг»: корзина `known_issue_confirmed`, Phase 1–6 не выполняются
   (метрика `result=known-issue`, дата строки обновляется). Разошёлся любой →
   полный разбор с пометкой «сигнатура изменилась» (гард от маскировки новой
   регрессии под старый баг). Вход `pytest-run` (trace ещё нет) — сверка после
   первого FAIL Phase 1.

4. Сгруппировать тесты по эпицентру (primary) → по симптому (fallback). Проверить
   критерии **группового режима** (`references/batch-discovery.md` §4а: от 3 тестов
   одного эпицентра/симптома + корень доказан drift-report/DE/предыдущим батчем) —
   выполняются → пометить группу `mode=group` (Phases 1–3 пройдёт представитель).
   Записать в `state.md` (группу — с явным эпицентром).

5. Создать дом батча `.tasks/work/batch-{YYYYMMDD-HHMMSS}/` (раскладка `.tasks/` —
   карта `.tasks/README.md` проекта); первым действием — мета дома каноническим CLI
   модуля base: `python3 "<каталог модуля base>/scripts/task_meta.py" init
   --key batch-{ts} --kind fix --title "<источник прогона: ланч/набор>"`.
   В каталог кладём все артефакты: `state.md`, `fix-{test}-*.md`, скриншоты. Путь
   каталога передавай субагентам в каждом задании (`batch_dir`) — свои артефакты
   они пишут туда, не в корень `.tasks/`.

## Phase 1 — Reproduce on target

См. `references/reproduce-phases.md` секцию Phase 1.

Для каждого теста — прогон одного теста по контракту стека
(`$CRAFT/stacks/{stack}/pytest-runner.md`; референс: `<runner> -k <test>
--tb=native --showlocals -p no:randomly`, плюс маркер конфигурации на
мультибраузерном стеке). Таймаут 5 минут.

**Групповой режим** (`mode=group` из Phase 0): Phases 1–3 проходит **представитель**
группы; остальным тестам группы repro до фикса не гоняется — их верифицирует
Phase 5 per-test прогоном. Падение представителя не объясняет группу (иной
эпицентр/симптом) → откат: группа расформировывается, тесты идут полным per-test
пайплайном (`references/batch-discovery.md` §4а).

- PASS → **до** вердикта `NON_REPRODUCIBLE_FLAKY` две проверки (обе —
  `$CRAFT/stacks/{stack}/failure-taxonomy.md`):
  1. `local_ahead=true` (Phase 0 3b) и недоставленные коммиты трогают файлы
     теста/эпицентра → исход **«покрыто недоставленным фиксом»** → корзина
     `covered_by_undelivered`: Phase 2-6 не нужны, «стабилизация» починенного кода
     запрещена; в отчёт — напоминание доставить фиксы.
  2. Падение попадает в зафиксированное окно деградации (Phase 0 3b) с 5xx-evidence
     → `STAND_INCIDENT` → корзина `stand_incident`: кода не касаться, окно в отчёт.

  Ни то, ни другое → `NON_REPRODUCIBLE_FLAKY` → в `deferred_flaky` корзину.
  **НЕ** идти в Phase 2-5; ждать Phase 6.
- FAIL → `target_repro=true`, идём в Phase 2.

## Phase 2 — Репро в альтернативном режиме стека *[test-stack]*

См. `references/reproduce-phases.md` секцию Phase 2 (обе процедуры оси).

**Phase 2 условная.** Её дискриминатор — «target FAIL + альтернативный режим PASS»
⇒ намёк на WEBDRIVER_QUIRK (окружение-специфика). Альтернативный режим — что есть
у стека: headed-прогон при headless-дефолте (референс canvas: `--headed` +
наблюдение глазами; квирки headless-канала — clipboard, нативные диалоги) либо
локальный браузер вместо grid (референс Selenium: `--local`). **Нет альтернативного
режима у стека/проекта → Phase 2 всегда skip.**

Выполняется, когда после Phase 1 жива гипотеза окружение-специфики. Гипотеза
стендовая/серверная (гонки данных, готовность бэка) или дрейф сборки, доказанный
реестром/DE/предыдущим батчем, → явный skip одной строкой обоснования
(`alt_repro=skipped (hypothesis: <класс>)` в reproduce.md и state.md), не тихое
отступление. Late-check: Phase 4 склоняется к WEBDRIVER_QUIRK при пропущенной
Phase 2 → вернуться и прогнать её. Skip также если изначальный прогон был локальным
(`was_local=true`).

## Phase 3 — Manual step-by-step walkthrough

Пошаговое ручное воспроизведение сценария (не перезапуск раннера) инструментом
разведки стека — `$CRAFT/stacks/{stack}/recon.md` (референс canvas: разведскрипт
`craft:dom-explorer` mode=fix с `scenario_steps` до точки падения; референс
Selenium: `$CRAFT/stacks/pytest-selenium/manual-walkthrough.md` — CLI разведки +
per-браузер driver-скрипты). В групповом режиме — по представителю группы.
Развилка PRODUCT_BUG vs WEBDRIVER_QUIRK может требовать репро «без автоматизации» —
та же последовательность руками пользователя в обычном браузере.

Если ни один путь не воспроизвёл — `AUTOMATION_ONLY` → в `deferred_automation`
корзину. Phase 4 пропускается. Результат — `fix-{test}-manual.md` с гипотезой причины.

## Phase 4 — Classify + Fix

Локализация (`references/failure-localization.md`) + классификация
(`$CRAFT/stacks/{stack}/failure-taxonomy.md`) + playbook
(`$CRAFT/stacks/{stack}/fix-playbooks.md`).

Делегируем:
1. `craft:codebase-analyst` (mode=fix) → `fix-{test}-analysis.md` (inventory
   методов/адресации/API/фикстур; субагент возвращает контент текстом, файл
   в `{batch_dir}` пишет оркестратор).
2. Классифицируем по таксономии стека (8 базовых категорий + 2 deferred +
   `STAND_INCIDENT`/«покрыто недоставленным фиксом» — последние четыре сюда
   не доходят, они терминальны раньше).
3. Записываем `fix-{test}-diagnosis.md`.
4. Для категорий, требующих перепроверки живого UI (DOM_CHANGED / UX_FLOW_CHANGED /
   WEBDRIVER_QUIRK) — `craft:dom-explorer` (mode=fix) → `fix-{test}-locators.md`.
5. `craft:code-writer` (mode=fix, category=...) — правки в тест-слое: тесты,
   page-слой, общие хелперы, словарь i18n (раскладка — rules стека).
   *[vendored-dep]* **Не** правит vendored-библиотеку (параметр `vendored_dep`).

   **Порог тривиальности** (когда допустимо без делегирования): механическая правка
   ≤3 строк по образцу, уже доказанному в этом батче (вставка готового
   гейта/импорта/константы — фикс того же класса прошёл верификацию), — основной
   агент вносит сам (Edit + синтакс-гейт стека); верификация Phase 5 обязательна
   как обычно. Новая адресация/методы/логика или первая правка класса в батче —
   только `craft:code-writer`.

   **Гейт REST-вызовов** *[product-api]*: фикс добавляет **новый** HTTP-вызов к AUT
   (гейт готовности, создание данных) → сначала проверить обёртку эндпоинта
   в REST-библиотеке продукта; обе ветки (обёртка той же работой / временный прямой
   вызов только с задачей на вынос) — `$CRAFT/stacks/{stack}/fix-playbooks.md`,
   секция «Гейт: новый REST-вызов».
6. Для `PRODUCT_BUG` — никаких правок; копим репро-bundle для трекера.

## Phase 5 — Verification

Для каждого исправленного теста:
0. Определить **объём верификации по классу правки**: конфигурационно-независимая
   правка (замена селектора, REST-гейт, i18n-строка, импорт, правка вызова API) →
   достаточно target-конфигурации, остальную матрицу закрывают плановые прогоны
   проекта; конфигурационно-зависимая (интеракции, браузерные гарды, JS-workaround,
   тайминги) → матрица стека. Словарь и процедура матрицы —
   `$CRAFT/stacks/{stack}/batch-conventions.md` (мультибраузерный референс —
   `$CRAFT/stacks/pytest-selenium/cross-browser-verification.md`; однобраузерный
   стек — матрица вырождена в одиночный прогон). Выбор объёма зафиксировать
   в verification.md.
1. Прогон target-конфигурации — если FAIL, 1 retry Phase 4. Если retry FAIL →
   `escalation`, к следующему тесту.
2. Правка класса flaky (тайминг/гейт) → прогон 3× подряд (одиночный PASS флак
   не доказывает; для спорных — статистический эксперимент из таксономии стека).
3. Результат — `fix-{test}-verification.md` (на мультибраузерном стеке — с матрицей).

После верификации — обновить корзину `fixed` в state.md.

## Phase 6 — Deferred handling

См. `references/deferred-handling.md`.

Один проход по двум корзинам:
- `deferred_flaky` (`NON_REPRODUCIBLE_FLAKY`) → попытка стабилизации наблюдаемым
  ожиданием (примитивы и паттерны — playbooks стека; референс canvas: `wait_for`
  узла, `expect_api`, REST-гейт сида; референс Selenium: js-clickable-wait,
  presence-wait). Лимит — 2 попытки.
- `deferred_automation` (`AUTOMATION_ONLY`) → workaround примитивами стека
  (референс canvas: retreat-клик, `click_blind`, REST-ассерт вместо
  headless-канала; референс Selenium: JS-click, API-bypass). Лимит — 2 попытки.
  После workaround — верификация Phase 5.

После Phase 6: тест перешёл в `fixed` → ok; не перешёл → `escalation`
с обязательным **обоснованием** (список попыток + рекомендация пользователю).

## Phase 7 — Final batch report

См. `references/batch-report.md`.

Записать `.tasks/work/batch-{ts}/fix-batch-{ts}-report.md` с разделами:
- Summary (числа по корзинам);
- Изменённые файлы (только staged);
- Комментарии для трекера (по тесту) — готовые блоки;
- Product bugs — по каждому подтверждённому багу **каталог-кандидат**
  `.tasks/jira-candidates/<NNN>-TC-<XXXXX>-<slug>/` (внутри `draft.md` + копии
  всех артефактов бага; формат, именование, разметка трекера —
  `$CRAFT/shared/jira-candidates.md`), секция отчёта ссылается на кандидатов,
  не на сырые трейсы;
- Deferred (escalation с обоснованием);
- Отступления от протокола скилла (инвариант связывания — ниже);
- Helper-команды для повторной проверки руками.

**Обновить реестр known-issues** (`references/known-issues.md`): исходы
`red-product-bug`/`deferred` → добавить/обновить строку `.tasks/known-issues.md`;
доведённые до `green` тесты, числившиеся в реестре, → снять строку.

**Закрыть отчёт ledger'ом** (только standalone-запуск, не изнутри `craft:batch`) —
инвариант ledger `$CRAFT/shared/ledger-and-deviations.md`; специфика fix: «тест
в Summary отчёта ⇔ строка метрик», значения полей и `result` —
`references/batch-report.md`.

**Инвариант связывания отступлений** (`$CRAFT/shared/ledger-and-deviations.md`):
каждая строка секции «Отступления от протокола скилла» завершается исходом (а/б/в);
секция без исхода у каждой строки = **отчёт не закрыт** (симметрично инварианту ledger).

Сообщить пользователю:
- путь к `fix-batch-{ts}-report.md`;
- 1-2 строки итога (`K fixed / E escalation / P product bugs`);
- напоминание: коммит не сделан, `git status && git diff --staged` для review.

## Артефакты в `.tasks/work/batch-{ts}/`

```
.tasks/work/batch-{ts}/
├── state.md                            ← глобальный state (корзины, счётчики)
├── fix-{test}-failure.md               ← собранные факты + log-выдержка
├── fix-{test}-analysis.md              ← из codebase-analyst (inventory)
├── fix-{test}-reproduce.md             ← P1+P2: target_repro / alt_repro
├── fix-{test}-manual.md                ← P3: walkthrough log + гипотеза
├── fix-{test}-locators.md              ← из dom-explorer (если был вызван)
├── fix-{test}-diagnosis.md             ← P4: категория + улики
├── fix-{test}-verification.md          ← P5: результат верификации (матрица — если стек мультибраузерный)
├── fix-{test}-screenshot-step-*.png    ← из dom-explorer / инструмента разведки
├── recon_{test}.py                     ← разведскрипты (если использовались)
└── fix-batch-{ts}-report.md            ← итоговый отчёт (Phase 7)
```

## Запреты

- ❌ *[vendored-dep]* Не править файлы vendored-библиотеки (параметр `vendored_dep`;
  референс one-web: `venv/.../autocore/`).
- ❌ Не делать `git commit`. Только `git add` если нужно, но **финальный коммит**
  оставить пользователю.
- ❌ Не делать больше 2 итераций Phase 4 на тест (защита от циклов). Не делать
  больше 2 попыток стабилизации в Phase 6 на тест.
- ❌ Не переименовывать существующие методы page-слоя (сломает другие тесты).
- ❌ Не помечать тест `skip`/`xfail` как «фикс» — это сокрытие. Исключение:
  подтверждённый PRODUCT_BUG с bug-candidate → xfail по конвенции rules стека
  (кодирует ТК, reason — путь к заготовке) — по решению пользователя, не молча.
- ❌ Не вводить слепые таймауты (sleep/wait_for_timeout) в тестах и page-методах —
  только наблюдаемые ожидания; политика — rules стека.
- ❌ Прочие структурные запреты стека — rules стека (референс Selenium: не менять
  порядок наследования runtime-mixin; референс canvas: слепой таймаут допустим
  только внутри примитивов базового page-класса с документированием отсутствия
  сигнала).
- ❌ Не запускать раннер для нескольких тестов одной командой — каждый тест
  прогоняется отдельно (per-test сырые результаты, чище парсинг).
