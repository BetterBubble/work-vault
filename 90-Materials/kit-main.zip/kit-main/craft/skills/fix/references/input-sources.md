# Источники информации о падении

Skill принимает пять типов входа. Распознавание — по содержанию пользовательского сообщения и аргументов. Механика распознавания веток и нормализации в «список тестов» — канон; форматы конкретных источников — по конвенциям стека (`$CRAFT/stacks/{stack}/` — параметр `stack` секции `[craft]`): сырые результаты и запуск раннера — `allure-raw-parser.md` / `pytest-runner.md` стека, ланч TMS — `launch-input.md` (пайплайн-часть) + скилл tms:read (формат выдачи).

**Все источники** превращаются в **список тестов** длиной от 1. `pytest-run` и `stack-trace-parse` — частные случаи batch'а длиной 1. `allure-raw-parse` и `launch-parse` — источники, где список может быть длиннее. `tc-diff` (diff-bundle) — особый вход: триггер не падение, а **расхождение TC↔код** (приходит из craft:update); минует repro-фазы.

## 1. Имя теста / TC-id (ветка `pytest-run`)

Признак: пользовательский ввод содержит **только** имя функции (`test_<...>`) или TC-id, и **не содержит** ни stack trace, ни путь к директории.

Примеры:
- `craft:fix test_channel_edit_avatar_visible`
- `craft:fix test_chat_send_receive_message`
- `craft:fix 925` (TC-id)

В этой ветке skill **сам запускает** раннер (конвенции и флаги — `$CRAFT/stacks/{stack}/pytest-runner.md`).

Если дан TC-id (число) — найти тест по id в метаданных теста (референс: `@allure.id`):
```bash
grep -r "@allure.id(\"<id>\")" tests/
```
Результат — имя файла и тестовой функции.

### Обогащение через CLI модуля tms (опционально)

После того как TC-id известен (из аргумента, или вытащен grep'ом по метаданным в тестах), можно read-only подтянуть бизнес-сценарий из TMS:

```
<python-проекта> "$TMS/scripts/testops_cli.py" get <tc_id>
```

(конвенции вызова и разбор ошибок — скилл tms:read)

Когда это полезно:
- **Phase 3 (Manual walkthrough)** — сверить «что должен делать пользователь» по TC vs «что делает тест». Если шаги расходятся (например, в TC появился новый шаг подтверждения, а тест его не учитывает) — это сразу гипотеза `UX_FLOW_CHANGED`.
- **Phase 7 (комментарии для issue-трекера)** — Feature/Story из custom fields для маркировки коммента, URL тест-кейса сразу из ответа.

Если CLI вернул ошибку / TC не найден / у TC нет шагов — пропустить enrichment, не блокировать pipeline. Это **необязательный** шаг.

## 2. Stack trace в чате (ветка `stack-trace-parse`)

Признак: в сообщении пользователя есть одна из строк (референс Python):
- `Traceback (most recent call last):`
- `File "tests/...", line N`
- имя exception-класса драйвера/движка (референс Selenium: `selenium.common.exceptions.<ExceptionType>`; референс Playwright: `TimeoutError` с селектором, ошибка strict mode)
- `E   `... + exception message

Здесь skill **не запускает раннер** на Phase 0 — берёт данные из текста. Перезапуск произойдёт только на верификации (Phase 5).

Что вытаскивать из stack trace:
- имя файла теста и тестовой функции (последний кадр в тест-файлах)
- последний кадр в page-слое (page/chunk/flows/локатор-файлы — по раскладке стека) — это эпицентр
- класс exception и его сообщение
- селектор из сообщения exception (если есть) — «Unable to locate element using xpath: //...»

См. подробный парсинг в `failure-localization.md`.

## 3. Директория сырых результатов прогона (ветка `allure-raw-parse`)

Признак: пользовательский ввод содержит существующий путь к директории, в которой есть файлы `*-result.json`.

Примеры:
- `craft:fix ./allure-raw`
- `craft:fix <абсолютный путь>/allure-raw`

Проверка: `Glob` по `<path>/*-result.json`. Если хоть один файл найден — ветка распознана.

В этой ветке skill парсит JSON-ы, ищет файлы со `status:"failed"`. Если их несколько — спросить пользователя через `AskUserQuestion`:

> Найдено N упавших тестов: {short list}. Что фиксить?
> - **все по очереди в batch'е** (Recommended)
> - выбрать подмножество (укажу имена)
> - один конкретный

Дефолт — «все по очереди». Все последующие фазы итерируются по выбранному списку — см. `batch-discovery.md`.

Формат JSON — `$CRAFT/stacks/{stack}/allure-raw-parser.md`.

## 4. Ланч TMS (ветка `launch-parse`)

Признак: пользовательский ввод содержит URL ланча TMS (референс: `https://<tms-хост>/launch/{id}`) или команду вида `launch <id>` / `ланч <id>`.

Примеры:
- `craft:fix <URL ланча TMS>`
- `craft:fix launch 726`

В этой ветке skill читает ланч read-only через CLI модуля tms (без локальных сырых результатов) и формирует список **всех не-зелёных** результатов:

```bash
<python-проекта> "$TMS/scripts/testops_cli.py" launch <id> --attachments .tasks/work/batch-{ts}/launch-att --json
```

Разбор JSON, маппинг в список тестов и развилка по `kind` (failed/broken/xpass → фикс-пайплайн; xfail → верификация места падения; skipped → только список) — `launch-input.md`. Если N>1 — спросить через `AskUserQuestion` («все по очереди» — дефолт), как в `allure-raw-parse`.

## 5. diff-bundle от craft:update (ветка `tc-diff`)

Признак: вход содержит **имя теста + структурированную дельту «TC↔код»** (не stack trace, не падение). Приходит из craft:update (minor-маршрут), когда тест-кейс в TMS изменился и тест надо привести в соответствие. Триггер — **расхождение, а не падение**: тест может быть зелёным на старом сценарии.

Вход:
- `test_path` + `test_name` + `allure_id`;
- **дельта** (из `.tasks/work/update-{id}/diff.md`): added/removed/reordered шаги, изменённые expected→assert, дифф метаданных, protected-список (skip/xfail/стабилизации/дивергентные локаторы — НЕ трогать).

Отличия ветки от обычного фикс-пайплайна:
- **Минует Phase 1–3** (reproduce target / дискриминирующий репро / manual walkthrough) — воспроизводить нечего, цель не «повторить падение», а «привести код к свежему TC».
- **Phase 4 — delta-driven, не taxonomy-driven.** Failure-таксономия не применяется; спецификация правки = сама дельта. Делегирование: `craft:codebase-analyst` (mode=fix) inventory → при DOM-дельте (новый/изменённый шаг требует новой адресации) `craft:dom-explorer` (mode=fix) → `craft:code-writer` **хирургически** применяет дельту (add/remove/reorder шагов-логирования + соответствующие вызовы page-слоя, правка assert'ов, i18n-ключи). Дефолт — хирургия, **не** rewrite.
- **expected-дельта строже action-дельты:** изменённый/добавленный expected → обязательно правка `assert`, не косметика.
- **Гарды:** protected-список из дельты переносится дословно; дивергентные локаторы другой линии *[dual-line]*, skip/xfail, стабилизации — не трогать (см. craft:update → `references/diff-routing-guards.md`).
- **Phase 5 — только дефолтная конфигурация** (усечён; матрица верификации — работа плановых прогонов). Критерий: PASS на свежем сценарии И дельта реально применена.
- Красный после правки → обычный фикс-пайплайн (это уже настоящее падение). Маскировка `skip`/`xfail` запрещена.

Phase 6 (deferred) и Phase 7 (batch-report) — как обычно; в отчёте помечать, что вход был `tc-diff` (ресинк под изменённый TC), а не падение.

## Если входной артефакт нечитаем

- раннер не запустился (нет окружения, env-переменные не заданы) → сообщить пользователю и остановиться. Не «фиксить» отсутствие окружения.
- Stack trace в чате обрезанный (нет имени теста и нет пути к файлу) → попросить пользователя дать полный traceback или имя теста для перезапуска.
- В директории сырых результатов нет `failed`-результатов → сообщить «все тесты в этой директории прошли, нечего фиксить».

## Формат `fix-{test_name}-failure.md`

```markdown
# Failure bundle: {test_name}

## Метаданные
- test_path: tests/test_chat.py
- test_name: test_channel_edit_avatar_visible
- allure_id: 925
- источник: pytest-run | stack-trace-parse | allure-raw-parse | launch-parse | tc-diff

## Exception
- class: selenium.common.exceptions.NoSuchElementException
- message: Unable to locate element using xpath: //chat-sidebar//input[@type="file"]

## Stack trace
```
File "tests/test_chat.py", line 1314, in test_channel_edit_avatar_visible
    info_channel_profile.upload_avatar(avatar_file_name)
File "tests/pages/chunks/chat_profile_base.py", line 142, in upload_avatar
    file_input = self.driver.find_element(*self.L_AVATAR_UPLOAD_INPUT())
...
```

## Скриншот (если есть)
- путь: ./allure-raw/<uuid>-attachment.png (из сырых результатов)

## Связанные шаги сценария (если есть)
- step 3.1 "Загрузить аватар" → failed
- предыдущий пройденный шаг: step 3 "Открыть профиль чата"
```

(пример exception/trace — референс Selenium-стека; в Playwright-стеке те же поля с его классами ошибок)
