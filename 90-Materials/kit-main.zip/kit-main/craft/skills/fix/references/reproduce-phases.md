# Phases 1-2 — Reproduce on target / Дискриминирующий репро

Цель — **до** любых правок установить, как ведёт себя падение:
- воспроизводится ли в той же конфигурации, что в исходном прогоне (`target`);
- воспроизводится ли в **дискриминирующем режиме** стека (Phase 2, ось): режиме, отделяющем «падает только под автоматизацией / в её канале» от «падает везде».

Это критично для классификации:
- `target FAIL + дискриминирующий FAIL` → нормальный случай, идём в Phase 3 (manual walkthrough).
- `target PASS` → `NON_REPRODUCIBLE_FLAKY` (отложить).
- `target FAIL + дискриминирующий PASS` → специфика канала автоматизации — намёк на `WEBDRIVER_QUIRK`, но окончательно классифицирует Phase 4.

## Phase 1 — Reproduce on target

### Команда (референс pytest; раннер — параметр `runner` секции `[project]`, env — `default_env` секции `[craft]`)

```bash
<runner> -k <test_name> [-m <target_marker>] --env <default_env> --tb=native --showlocals -p no:randomly
```

`<target_marker>` — значение, извлечённое в Phase 0 (см. `batch-discovery.md`) из словаря конфигураций проекта (референс Selenium-стека: `browser_lin_chrome`, `browser_win_firefox`, `browser_mac_safari`; флаги вида `--browser-tag` — по `$CRAFT/stacks/{stack}/pytest-runner.md`). В одноконфигурационном стеке (референс canvas one-web: единственный headless chromium) маркеров нет — `-m` опускается.

Таймаут Bash-вызова — 5 минут (`timeout=300000`).

### Анализ результата

- **PASS** → тест проходит. Это `NON_REPRODUCIBLE_FLAKY`:
  - Записать в `fix-{test}-reproduce.md` → `target_repro=false (passed on retry)`.
  - Записать в state.md → `deferred_flaky += [test]`.
  - **Не идти в Phase 2/3/4/5**. Тест будет разобран в Phase 6.
  - (До вердикта FLAKY — проверки `local_ahead` / окна деградации, см. SKILL Phase 1.)
- **FAIL та же точка** → стабильно воспроизводится → `target_repro=true`. Идём в Phase 2 (если исходный прогон уже не был в дискриминирующем режиме).
- **FAIL другая точка** → пишем эпицентр актуальный, идём в Phase 2 с новым failure-bundle. Возможно, исходное падение было устаревшим.

### Особый случай: target-marker не определён

Если в Phase 0 не удалось извлечь конфигурационный маркер из сырых результатов (отсутствует labels/parameters, нет внятного имени директории) — использовать **дефолтную верификационную конфигурацию проекта** (референс one-web: `lin_chrome`, без `-m`-маркера; правило выбора — `$CRAFT/stacks/{stack}/pytest-runner.md`).

## Phase 2 — Дискриминирующий репро (ось стека)

Phase 2 **условная**, и её форма зависит от возможностей стека/проекта. Какие режимы даёт раннер — `$CRAFT/stacks/{stack}/pytest-runner.md`. Два известных варианта оси (оба сохранены как канонические процедуры; проект выбирает по своему стеку):

- **Вариант A — локальный режим** (референс Selenium-стека: флаг `--local` — локальный браузер dev-машины вместо grid/selenoid). Дискриминатор: `target FAIL + local PASS` ⇒ специфика grid/платформы/WebDriver — намёк на `WEBDRIVER_QUIRK`.
- **Вариант B — headed-репро** (референс canvas/Playwright-стека one-web: прогон `--headed` и/или наблюдение глазами). Дискриминатор: `headless FAIL + headed/ручной PASS` ⇒ квирк headless-канала (clipboard, нативные диалоги) — тот же намёк на `WEBDRIVER_QUIRK`.

Ни одного дискриминирующего режима в стеке/проекте нет → `alt_repro=skipped (no discriminating mode)` и сразу Phase 3.

### Skip-conditions (общие для обоих вариантов)

Единственная ценность Phase 2 — дискриминирующий сигнал «специфика канала автоматизации»; выполнять её стоит только пока жива гипотеза браузер/окружение-специфики. Каждый skip — явный, одной строкой в `fix-{test}-reproduce.md` и state.md (не тихое отступление):

- **изначальный прогон был в дискриминирующем режиме** (`was_local=true` из Phase 0) → `alt_repro=skipped (was_local=true)`;
- источник входа — `stack-trace-parse` без сырых результатов (не знаем, как был запущен исходный прогон → допускаем, что уже в нём) → та же пометка;
- **гипотеза после Phase 1 — стендовая/серверная или дрейф сборки**: падение объясняется гонками данных стенда / готовностью бэка (асинхронная материализация) / дрейфом DOM/overlay сборки, доказанным canary/разведкой/предыдущим батчем (DOM один во всех окружениях) → `alt_repro=skipped (hypothesis: <класс>)` — дискриминирующий прогон не даст сигнала, а стоит по прогону на тест;
- **групповой режим** (`batch-discovery.md` §4а): решение о Phase 2 принимается один раз по представителю группы.

**Late-check:** Phase 4 склоняется к `WEBDRIVER_QUIRK`, а Phase 2 была пропущена → вернуться и прогнать её для дискриминации (падение и в дискриминирующем режиме = не quirk).

### Команда — вариант A, локальный режим (референс Selenium-стека)

```bash
<runner> -k <test_name> --env <default_env> --local --tb=native --showlocals -p no:randomly
```

**Важно:** **никаких конфигурационных маркеров браузера**. В локальном режиме стек собирает локальный браузер dev-машины (см. `pytest-runner.md` стека). Маркер тут бесполезен и может смутить.

### Команда — вариант B, headed-репро (референс canvas/Playwright-стека)

```bash
<runner> -k <test_name> --env <default_env> --headed --tb=native --showlocals -p no:randomly
```

При необходимости — дополнить наблюдением глазами (той же последовательностью в обычном браузере на стенде); развилка «PRODUCT_BUG vs WEBDRIVER_QUIRK» без автоматизации — это уже Phase 3.

Таймаут — 5 минут.

### Анализ результата

| target_repro | дискриминирующий режим | Интерпретация | Куда идём |
|---|---|---|---|
| FAIL | FAIL | Воспроизводится везде. Скорее всего `DOM_CHANGED`/`UX_FLOW_CHANGED`/`API_CONTRACT_CHANGED`/`PRODUCT_BUG`. | Phase 3 |
| FAIL | PASS | Специфика канала автоматизации (grid/платформа/headless). Скорее всего `WEBDRIVER_QUIRK`. | Phase 3 (надо понять, что именно ломается под автоматизацией) |
| FAIL | skipped | Дискриминирующий прогон пропущен. | Phase 3 |
| PASS (target) | — | Уже отложили в Phase 1 | (не доходит сюда) |

## Что писать в `fix-{test}-reproduce.md`

Каноническое имя поля — `alt_repro` (единый grep-паттерн по артефактам всех стеков);
вариант оси (local | headed) виден из заголовка секции Phase 2 артефакта.

```markdown
# Reproduce — {test_name}

## Phase 1 — target
- marker: browser_lin_chrome (либо «единственная конфигурация стека»)
- результат: FAIL
- exception: selenium.common.exceptions.NoSuchElementException
- эпицентр: tests/pages/chunks/chat_profile_base.py:142
- artifact (свежие сырые результаты retry): ./allure-raw/<uuid>-result.json
- log-выдержка (3-5 строк):
  - `[INFO] chat.py:403 Текущий url: "about:blank"`

## Phase 2 — дискриминирующий репро (local | headed)
- результат: PASS (или skipped — c причиной: was_local / no discriminating mode / hypothesis)
- если PASS — это сигнал WEBDRIVER_QUIRK
- если FAIL — эпицентр такой же / другой / новый
```

## Эскалация если раннер не запускается

Если раннер падает на сборе тестов (ошибка импорта в конфигурации, missing fixture) — это валидный сигнал, который ловится категорией `IMPORT_OR_REGISTRY` (таксономия стека — `$CRAFT/stacks/{stack}/failure-taxonomy.md`). НЕ переходить в Phase 6 как `NON_REPRODUCIBLE_FLAKY` — это разные классы проблем.
