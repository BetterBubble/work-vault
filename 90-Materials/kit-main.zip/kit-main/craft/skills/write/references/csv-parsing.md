# Парсинг CSV из TMS

Формат CSV-экспорта и имена колонок — по TMS проекта (референс здесь — Allure TestOps). Формат сценария `[step N]` / `[expected N.M.K]` — внутренний формат конвейера, не менять.

## Формат файла

CSV-экспорт из TMS. Референс Allure TestOps: разделитель — `;`, заголовок первой строки:
```
allure_id;name;full_name;automated;description;precondition;expected_result;status;scenario;tag;link;example;parameter;<колонка issue-трекера>;Lead;Owner;Suite;Component;Story;Feature;Epic
```
(референс one-web: колонка issue-трекера называется `Jira corp`)

## Извлекаемые поля

Целевые декораторы — метаданные теста по конвенциям стека (референс — pytest-allure):

- `allure_id` → ID теста в TMS (идёт в метаданные id: `@allure.id(...)`)
- `name` → название теста (идёт в `@allure.title(...)` и формирует имя функции)
- `Owner` → автор (идёт в `@allure.label("owner", ...)`)
- `Feature` → фича (определяет целевой файл теста — карта фич проекта `.kit/craft/feature-mapping.md`; идёт в `@allure.feature(...)`)
- `Story` → история (идёт в `@allure.story(...)`)
- `Suite` → suite
- `tag` → теги через запятую (идёт в `@allure.tag(...)`)
- колонка issue-трекера → ссылки на issue (идёт в проектный label связи с трекером; референс one-web: `@allure.label("IVAQA", ...)`)
- `scenario` → шаги сценария (см. ниже)

## Парсинг поля `scenario`

Поле содержит многострочный текст вида:
```
[step 1] Авторизация WEB
    [step 1.1] Написать в адресной строке...
        [expected 1.1.1] Expected Result
            [expected.step 1.1.1.1] Если пользователь не авторизован...
[step 2] Переход в раздел
    [step 2.1] Выбрать элемент
        [expected 2.1.1] Expected Result
```

Правила разбора:
- `[step N]` — шаг верхнего уровня
- `[step N.M]` — подшаг (конкретное UI-действие)
- `[expected N.M.K]` / `[expected.step ...]` — ожидаемый результат
- `[expected.attachment ...]` — игнорировать

## Запись input-артефакта

После парсинга создать `.tasks/work/tc-{allure_id}/input.md` со структурой, описанной в `input-sources.md`. До записи — обязательно прогнать через санитизацию (`sanitization.md`).

## Парсинг тонкости

- Поля могут содержать переносы строк внутри значения (CSV-quoted strings). Используй стандартный модуль `csv` Python, если парсинг сложный — не пытайся регулярками.
- Кодировка обычно UTF-8 с BOM. Открывать с `encoding='utf-8-sig'`.
- Если в `scenario` есть строки без префикса `[step ...]` / `[expected ...]` — присоединять их к предыдущему пункту как продолжение.
