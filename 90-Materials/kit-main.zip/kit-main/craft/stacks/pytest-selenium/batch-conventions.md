<!-- Референс-реализация стека pytest-selenium модуля craft (kit). Прародитель — ядро
aqa-agent-toolkit. Стековые/продуктовые конвенции батча (craft:batch): матрица браузеров
верификации, фабрика юзеров, multi-session паттерны, ассерт-конвенции, i18n, стиль функций
vendored-библиотеки — generic-часть конвенций остаётся в references скилла craft:batch. -->

# pytest+Selenium (one-web): стековые конвенции craft:batch

> Референс-реализация контракта стека (`../README.md`) — pytest+Selenium
> (инсталляция one-web, продукт IVA ONE WEB, vendored-библиотека autocore — параметр
> `vendored_dep` секции `[craft]` answers-файла базы kit).
> Сюда вынесены стековые/продуктовые куски конвенций `craft:batch`
> (`references/conventions.md`) при порте в канон. На другом стеке — свой документ с теми
> же ролями (матрица конфигураций, фабрика юзеров, ассерт-конвенции, i18n, стиль функций
> библиотеки); generic-часть конвенций остаётся в references скилла.

## Стенд (`--env`) по активной линии

`git branch --show-current` = агентская ветка RC-линии → `--env <RC-стенд>`; иначе →
`--env <dev-стенд>` (CLAUDE.md → «Ветки и линии разработки»; [dual-line], single-line —
всегда `default_env` секции `[craft]`). В командах ниже `at-test-1-one` — референс one-web,
пример main-линии.

## Браузеры по умолчанию для верификации

**Первичная верификация — `lin_chrome`** (дефолт: запуск БЕЗ `-m browser_*`; `--browser-tag`
для lin не нужен):

```bash
./venv/bin/python -m pytest -k <test_name> --env at-test-1-one
```

(Команда — референс one-web; раннер проекта — параметр `runner` секции `[project]`
answers-файла базы kit.)

**Полная матрица нового теста: `lin_chrome` → `browser_mac_safari` → `browser_win_firefox`**
(три движка: Chromium / WebKit / Gecko). Все три живут на **разных машинах** (основной
selenoid / mac-selenoid / win-selenoid) — их можно гонять **параллельно**; запрет только
на win+win (один selenoid). При параллели каждому прогону — свой
`--alluredir=./allure-raw-<marker>` (CLI перекрывает pytest.ini), чтобы скриншоты/логи
падений не смешивались между браузерами.

- **НЕ** `browser_win_chrome` и **НЕ** `browser_win_ya` в обязательной матрице — Chromium
  покрыт `lin_chrome`, win-специфику доловит полный CI-прогон.
- **Исключение — voice/audio-тесты** (fake_audio): референс one-web — на lin `/testdata`
  не смонтирован → звук = silence; первичная верификация таких тестов — `browser_win_ya`.

Команда для win/mac-браузеров (`--browser-tag current` нужен только win — lin/mac его
игнорируют):
```bash
./venv/bin/python -m pytest -k <test_name> -m browser_<env> --env at-test-1-one --browser-tag current
```

Без `--local` для browser-specific прогонов.

## users_factory

Дефолт фикстуры — **1 пользователь** (`getattr(request, "param", 1)` в `conftest.py`).
Для single-user тестов **не ставить** `@pytest.mark.parametrize("users_factory", [1],
indirect=True)` — это избыточно.

Параметризация нужна **только** для `[2]` и больше:
```python
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_two_users(...):
    ...
```

## Multi-session: конкретные паттерны

(Решающее правило «Multi-user ≠ Multi-session» — в `conventions.md` скилла craft:batch.)

- Второй юзер через REST: `login + send_message + ...` — только первый ходит в UI →
  single-session.
- Последовательное переключение: `driver.quit()` + `setup_aut['driver_starter']()`
  (прецедент-паттерн референса one-web: TC-2271, TC-938) → single-session.
- Одновременное присутствие обоих в UI (пуши в реальном времени, «второй уже онлайн») →
  фикстура `setup_multiple_auts`.

Multi-session особенно flaky на Safari.

## Тесты с почтой/imail (`require_ldap_user`) — продуктовый референс one-web

Оффлайн-«Событие», письма и прочий imail-функционал требуют пользователя **с mail/LDAP-доступом**.
Эфемерные `users_factory`-юзеры его НЕ имеют → imail отвечает 401, форма зависает.

- Главный юзер — предсозданный, из конфига: `config['credentials']['mail_user']`, НЕ из
  `users_factory`. Это **исключение** из правила «не создавать юзеров вручную» — mail-юзер
  не создаётся, он предсоздан.
- Тест помечается **`@pytest.mark.require_ldap_user`** (маркер «особых требований
  окружения», зарегистрирован в `pytest.ini`).
- mail-юзер персистентный → seed-данные чистить в `teardown` (нет ephemeral-автоочистки).
- Артефакты imail (события) удаляются jump-протоколом, а не REST — у продукта нет API
  для событий; реюз — chunk `offline_event`.

Обобщаемый урок: у стека должен быть словарь маркеров «особых требований окружения»
+ понимание, какие юзеры персистентные (ручной cleanup) vs эфемерные (автоочистка).

## Assert методы (`assert_presence`)

```python
# ✅ Правильно — assert_presence сам пишет Allure step
def assert_some_toast_visible(self):
    self.assert_presence(self.L_SOME_TOAST(self.lang), 'Отображается тост "..."')

# ❌ Неправильно — дублирование, step пишется дважды
def assert_some_toast_visible(self):
    log.step('Отображается тост "..."', where='...')
    self.wait_presence(self.L_SOME_TOAST(self.lang), 5)
```

Сигнатура: `assert_presence(self, locator, message)` — message становится Allure step
текстом + assert сообщением (реализация — база page-классов vendored-библиотеки).

Используй `wait_presence` (не assert_presence) когда:
- Нужно дождаться элемента, но без assert (например, в середине workflow).
- Нужен явный timeout (`wait_presence(loc, 5)`).

## Локаторы — переиспользование через базовый

Если у класса локаторов несколько связанных локаторов с одинаковой DOM-структурой,
отличающихся только текстом, — выноси базовый и стройся через него:

```python
@staticmethod
def L_I18N_MENU_ITEM(key, lang):
    text = i18n.get_str(key, lang)
    return 'xpath', f'//div[@role="menu"]//button[normalize-space()="{text}"]'

@staticmethod
def L_I18N_MUTE_MENU_ITEM(lang):
    return LSomeChunk.L_I18N_MENU_ITEM('p2p_chat_profile_mute_menu_item', lang)
```

Это убирает дублирование XPath и облегчает рефакторинг (если DOM-структура изменится —
правка в одном месте).

## Тосты — общий chunk `toast`

Для проверок тостов **не** заводи локальные `L_I18N_*_TOAST` в локаторе своего page/chunk.
Используй общий chunk (референс one-web: `CVersion2Toast`, `tests/pages/chunks/toast.py` +
локаторы `LToast`):

```python
from tests.pages import chunks

def assert_some_toast_visible(self):
    toast = chunks.get_chunk(self.version, 'toast')(driver=self.driver, lang=self.lang)
    toast.assert_i18n_visible('group_chat_profile_copy_link_toast',
                              'Отображается тост "Ссылка скопирована"')
```

API: `assert_visible_by_text(text)`, `assert_i18n_visible(key)`, `wait_visible_by_text(text)`,
`wait_i18n_visible(key)`, `wait_disappear(timeout=10)`. Новые i18n-ключи для текста тоста —
как обычно, в словарь i18n проекта.

## i18n

- Новые ключи **всегда** через словарь проекта (референс one-web: `tools/i18n/strings.py`),
  не хардкод.
- `LANG_RU` — точный текст из UI (получается через `dom-explorer`).
- `LANG_EN` — `'TODO'` допустимо, если не верифицируем EN-прогон.
- Имя ключа — `{chunk_or_page}_{element}_{kind}`: `group_chat_profile_copy_link_toast`,
  `chat_message_context_menu_info_button`.

## Vendored-библиотека (референс autocore)

(Когда трогать / граница «1 вызов ≈ 1 эндпоинт» / ветка по issue-id / workflow с rebuild
и доставкой MR — `conventions.md` скилла craft:batch, §Библиотека-зависимость. Здесь — стиль.)

### Стиль функции

Следовать паттерну существующих функций REST-клиента (login, send_message, pin_message):
docstring → `log.info` → `base_url = conf[env]['web_url']` → `headers` (Bearer token) →
`data` → `requests.post(verify=False)` → `raise_for_status` → return json.

### Cross-browser детект

`self.driver.name.lower() == 'safari'` — **case-insensitive**. Selenium может возвращать
`'Safari'` (capital) или `'safari'` (lower) в зависимости от версии.

## Запреты (pytest/one-web-специфичные)

- НЕ редактировать `venv/.../site-packages/<библиотека>/` — это устанавливаемая копия.
  Все правки — в исходниках библиотеки.
- НЕ оставлять `print` — есть `log.info` / `log.step` / `log.debug`.
- НЕ вызывать selenium напрямую из теста — только методы page/chunk.
- НЕ создавать пользователей вручную — `users_factory`.
- НЕ ставить `@pytest.mark.browser_*` руками — добавляются автоматически
  в `conftest.py:pytest_collection_modifyitems`.
