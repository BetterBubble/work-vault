<!-- Референс-реализация стека pytest-selenium модуля craft (kit). Прародитель — ядро
aqa-agent-toolkit. Как парсить каталог сырых Allure-результатов прогона (`allure-raw/`):
структура, извлечение падений, сканирование лога, target-platform и local-mode detection. -->

# Парсинг директории `allure-raw/` (референс-реализация: pytest + allure-pytest)

Референс-реализация раздела «Артефакты прогона» контракта стека (`../README.md`)
для стека pytest+Selenium+allure; исходник — one-web. Читатель — скилл `craft:fix`
(ссылки вида `batch-discovery.md` — на его references; `failure-taxonomy.md` /
`pytest-runner.md` — файлы этого стека). `<python-проекта>` в командах — интерпретатор
окружения проекта (параметр `python` секции `[project]` answers-файла базы kit;
референс `./venv/bin/python`).

После прогона раннера в `./allure-raw/` (каталог задан конфигом раннера) лежат JSON-файлы Allure.

## Структура директории

```
allure-raw/
├── <uuid>-result.json              ← один файл на тест
├── <uuid>-container.json           ← фикстуры (before/after)
├── <uuid>-attachment.png           ← скриншоты (прикладывает хук раннера при падении)
├── <uuid>-attachment.txt           ← логи
└── ...
```

## Формат `*-result.json` (минимально нужные поля)

```json
{
  "uuid": "...",
  "name": "test_channel_edit_avatar_visible",
  "fullName": "tests/test_chat.py#test_channel_edit_avatar_visible",
  "status": "failed",
  "statusDetails": {
    "message": "Unable to locate element using xpath: //chat-sidebar//input[@type=\"file\"]",
    "trace": "Traceback (most recent call last):\n  File \"tests/test_chat.py\", line 1252, ..."
  },
  "steps": [
    {
      "name": "Открыть чат",
      "status": "passed",
      "start": 1715750400000,
      "stop": 1715750402000
    },
    {
      "name": "Загрузить аватар",
      "status": "failed",
      "statusDetails": {"message": "...", "trace": "..."},
      "attachments": [
        {"name": "screenshot", "source": "<uuid>-attachment.png", "type": "image/png"}
      ]
    }
  ],
  "attachments": [
    {"name": "browser log", "source": "<uuid>-attachment.txt", "type": "text/plain"}
  ],
  "labels": [
    {"name": "feature", "value": "Чаты"},
    {"name": "AS_ID", "value": "925"}
  ]
}
```

## Что извлекать

1. **Найти упавший тест**: `Glob` по `<allure-raw>/*-result.json`, читать каждый, фильтр по `status in ('failed', 'broken')`.

   - `failed` — `AssertionError` (наш assert не сошёлся).
   - `broken` — любое другое исключение, всплывшее из теста: `selenium.common.exceptions.TimeoutException` / `NoSuchElementException` / `StaleElementReferenceException`, `KeyError`, `requests.HTTPError`, и т.п. **Это тоже падение**, его обязательно нужно обработать. Ошибка «отфильтровал только `failed` и пропустил `broken`-тесты» уже случалась (прецедент one-web) — не повторяй.
   - `passed` / `skipped` — пропускаем.
   - Распределение по таксономии (`failure-taxonomy.md` этого стека) определяется по тексту exception, **а не** по полю `status`: например, `broken` с `TimeoutException` → чаще всего `DOM_CHANGED` или `FLAKY_TIMING`; `failed` с `AssertionError` → может быть `PRODUCT_BUG` / `UX_FLOW_CHANGED` / `WEBDRIVER_QUIRK`.

2. Из найденного файла:
   - `test_name` — из `name`
   - `test_path` — из `fullName`, до `#`
   - `tc_id` — из массива `labels`, `name == "AS_ID"` (или `name == "AllureId"`)
   - `exception_class` + `exception_message` — из `statusDetails.message` (первая строка обычно `<Class>: <message>`)
   - полный traceback — из `statusDetails.trace`
   - **последний пройденный шаг** — из `steps`, последний со `status == "passed"` перед первым `failed`. Это важно: указывает, где скрипт сценария «дошёл» — а где сломалось.
   - **упавший шаг** — первый `step` со `status == "failed"`. Имя шага помогает понять смысл локатора при классификации.
   - **скриншот падения** — из `attachments` упавшего шага (или из top-level `attachments`, `name == "<test_name>[N]"`). Сохранить путь для `fix-report.md`.
   - **лог-attachment** — из top-level `attachments`, `name == "log"` (обычно `<uuid>-attachment.txt`). **Обязательно извлечь и просканировать** — см. секцию «Сканирование log-attachment» ниже.

3. **Сканирование log-attachment** — отдельный шаг, выполнять **до** перехода к локализации падения. Логи часто содержат `log.info(...)` строки с фактическими значениями переменных, которые мгновенно превращают гипотезу в диагноз.

### Что искать в логе

| Pattern (case-insensitive) | Зачем |
|---|---|
| `Текущий url`, `current_url`, `url =`, `redirected to` | Куда реально открылась/перешла страница (особенно после `switch_to.window`, popup'ов, OAuth-редиректов) |
| `Response`, `Status code`, `HTTP/`, `requests.get/post`, вызовы REST-обёртки продукта | Что вернул бэкенд — body, статус, ID созданной сущности |
| `Got value`, `Expected`, `Actual`, `assert`, `AssertionError` | Конкретные значения, на которых сломался assert |
| `Selected`, `Clicked`, `Sent keys` | Что именно успели сделать перед падением |
| `WARN`, `WARNING`, `Traceback` (после `first_failed_step`) | Часто скрывает teardown-ошибки, маскирующие корневое падение |
| `Start waiting presence`, `Finished waiting presence`, `TIMEOUT` | Какие локаторы ждались, сколько раз; помогает увидеть стейл/полл-проблемы (особенно rich-text-редакторы / virtual-scroll) |
| Step-name keywords из `first_failed_step` | Прямые упоминания падшей сущности (имя файла, текст сообщения, имя чата) |

### Технически как читать

```python
# в Python-скрипте, который запускает skill для парсинга
import json, re, glob
data = json.load(open(result_json, encoding='utf-8'))
log_atts = [a for a in data.get('attachments', []) if a.get('name') == 'log']
if log_atts:
    log_path = f'{allure_raw_dir}/{log_atts[0]["source"]}'
    # Файл может быть большим (десятки МБ). Использовать grep с -B/-A контекстом:
    # grep -n -B 2 -A 2 -i 'Текущий url\|current_url\|Response\|WARN' <log_path>
```

Для grep'а в Bash:
```bash
grep -n -B 2 -A 2 -i 'Текущий url\|current_url\|Response\|WARN\|TIMEOUT' allure-raw/<uuid>-attachment.txt
```

### Что записывать в `fix-{test_name}-failure.md`

В дополнение к exception/trace/screenshot — добавить секцию:

```markdown
## Лог (выдержка)
- путь: ./allure-raw/<uuid>-attachment.txt
- ключевые строки (то, что прямо указывает на симптом):
  - `[INFO] chat.py:403 Текущий url: "about:blank"`
  - `[WARN] base_page.py:81 Element has not gone for 5 seconds`
  - ... (3-7 строк, не весь лог)
```

Если в логе нет ничего полезного — явно записать `## Лог: нет дополнительных сигналов`. Это сигнал для локализации/walkthrough, что искать улики дальше нужно через `dom-explorer`.

## Target-platform extraction

Из каждого `*-result.json` нужно извлечь **`target_marker`** (`browser_<os>_<browser>` — словарь конфигураций проекта), который потом используется в Phase 1 (Reproduce on target) и Phase 5 (Cross-browser).

Алгоритм (по убыванию приоритета):

1. **labels с name='tag'**: в Allure теги pytest-маркеров попадают сюда. Берём первый, соответствующий регулярке словаря конфигураций (референс one-web):
   ```python
   for label in data.get('labels', []):
       if label.get('name') == 'tag' and re.match(r'^browser_(win|lin|mac)_(chrome|firefox|msedge|ya|safari)$', label.get('value', '')):
           return label['value']
   ```
2. **parameters с name='browser'**: некоторые pipeline-конфиги пишут параметр `browser=win_chrome`. Маппим в маркер: `browser_<value>`.
3. **Имя директории**: если allure-raw лежит в `allure-raw-<env>-<marker>/`, парсим из имени.
4. **Дефолт**: верификационная конфигурация проекта (референс one-web: `browser_win_chrome` — см. `pytest-runner.md` секция «Выбор браузера для верификации» — самый быстрый).

Если ни один способ не дал маркер — записать в failure-bundle `target_marker=browser_win_chrome (defaulted)`. Этот fallback виден в `state.md` пользователю.

## Local-mode detection

Также нужно знать, был ли изначальный прогон в локальном режиме (`--local`). Если да — Phase 2 (повторный локальный прогон) пропускается.

Алгоритм:

1. **`environment.properties`** рядом с `*-result.json` (Allure-конвенция):
   ```
   command_line=pytest -k test_xxx --env <default_env> --local
   ```
   Ищем подстроку ` --local` в значении `command_line` или подобных ключах.
2. **`parameters` массив в `*-result.json`**: иногда `--local=True` попадает туда как отдельный параметр.
3. **Если ни то ни другое не нашлось** — считаем `was_local=false`. Это безопасный дефолт: Phase 2 в худшем случае дублирует Phase 1, не теряя информации.

Записать в failure-bundle:
```markdown
## Source-mode
- target_marker: browser_win_firefox
- was_local: false  (определено из labels[].name='tag')
```

## Несколько failed-тестов в одной директории

Если в `allure-raw/` несколько `failed`-результатов — это batch-вход. См. `batch-discovery.md` скилла craft:fix → секция «Если в сырых результатах больше одного failed-теста». Skill спросит пользователя через `AskUserQuestion` («все по очереди» дефолт) и итерируется по выбранному списку.

## Чтение через Bash

Поскольку файлы — JSON, удобнее всего читать через `python -c`:

```bash
<python-проекта> -c "import json,sys; d=json.load(open(sys.argv[1],encoding='utf-8')); print(d.get('name'), d.get('status'))" allure-raw/<uuid>-result.json
```

Чтобы сразу получить **полный список упавших** (`failed` + `broken`):

```bash
<python-проекта> -c "
import json, glob
for f in glob.glob('allure-raw/*-result.json'):
    d = json.load(open(f, encoding='utf-8'))
    s = d.get('status')
    if s in ('failed', 'broken'):
        print(s, '|', d.get('name'), '|', (d.get('statusDetails') or {}).get('message','')[:120])
"
```

Или через `Read` tool, если файл небольшой (обычно <100 КБ).

## Если директория пустая или нет упавших результатов

Сообщить пользователю: «В `<path>` не найдено упавших тестов (нет файлов со `status in ('failed', 'broken')`). Все результаты — passed/skipped. Возможно, директория от другого прогона. Уточните путь.»
