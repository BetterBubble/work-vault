<!-- Референс-реализация стека pytest-selenium модуля craft (kit). Прародитель — ядро
aqa-agent-toolkit (экстракт стековых секций субагента dom-explorer + заметок и README
референса browser-driver reference-playwright-cli). Вождение разведки живого UI для
субагента dom-explorer: инструмент playwright-cli, последовательность входа, правила
именования локаторов L_*, canary-sweep, реальный браузер через grid, гигиена артефактов.
Роль, режимы и форматы артефактов субагента — канон агента dom-explorer модуля craft,
здесь только стековое. -->

# Вождение разведки живого UI (референс: playwright-cli + selenoid, one-web)

Всё продуктовое ниже — референс инсталляции-источника one-web: стенды `at-test-*`, юзеры,
IP grid'а, Angular-теги — примеры, при установке подставляются значения своего проекта.
`<python-проекта>` — интерпретатор окружения проекта (параметр `python` секции `[project]`
answers-файла базы kit; референс `./venv/bin/python`).

## Инструмент: playwright-cli — апстримом, не вендорится

Инструмент разведки — [microsoft/playwright-cli](https://github.com/microsoft/playwright-cli).
Он **сам поставляет свой скилл**: `playwright-cli install --skills` копирует SKILL.md +
references в `.claude/skills/` проекта; обновление — вместе с инструментом (npm). Мануал
инструмента в канон **не вендорится** — снапшот немедленно начинает отставать от апстрима,
а `install --skills` конфликтует с локальными правками (урок референс-инсталляции one-web:
апстрим-снапшот с вставками проектных конвенций прямо в тело SKILL.md → форк без ресинка).

Установка в web-проект:

1. `npm i -g @playwright/cli` (или локально в проект).
2. `playwright-cli install --skills` — штатный скилл в `.claude/skills/`.
3. Апстрим-скилл **не править**: конвенции проекта поверх инструмента живут в нашем слое —
   у субагента dom-explorer (единственный потребитель браузер-CLI): гигиена артефактов
   (`--filename` → служебный каталог), login-state (`state-save`/`state-load`), REST-setup
   вместо UI.

**Известное ограничение (референс one-web):** профиль браузера playwright-cli персистентен
и является синглтоном на машину — параллельные разведчики бьются за SSO-сессию, логаут
одного сбрасывает соседа; эфемерные юзеры не спасают.

## Справка по командам playwright-cli

| Команда | Назначение |
|---------|-----------|
| `playwright-cli open <url>` | Открыть браузер |
| `playwright-cli goto <url>` | Перейти по URL |
| `playwright-cli snapshot` | Accessibility-снапшот (предпочтительнее скриншота) |
| `playwright-cli click <ref>` | Левый клик |
| `playwright-cli fill <ref> "text"` | Заполнить поле |
| `playwright-cli type "text"` | Ввести текст в активный элемент |
| `playwright-cli hover <ref>` | Навести курсор |
| `playwright-cli press <Key>` | Нажать клавишу (Enter, ArrowDown и т.д.) |
| `playwright-cli screenshot` | Скриншот (если нужно визуально) |
| `playwright-cli eval "code"` | Выполнить JavaScript |
| `playwright-cli go-back` | Вернуться назад |
| `playwright-cli close` | Закрыть браузер |

> `ref` из снапшота используется **только** для взаимодействия в браузере — в итоговый
> артефакт записывается селектор, не `ref`.

## Выбор браузерного движка

| Кейс | Движок | Инструмент |
|---|---|---|
| Default — DOM / локаторы / структура компонентов | Chromium | `playwright-cli` (по умолчанию) |
| Проверить движко-специфичный (WebKit) рендер без mac-selenoid | WebKit | `playwright-cli open --browser=webkit` |
| **Браузер-специфичные падения** (window.handles, popup, sent-status timing, click event) | Реальный браузер через grid | референс one-web: `python .claude/scripts/selenoid_safari.py` (см. «Реальный браузер через grid» ниже) |

Решение по умолчанию — `playwright-cli` (Chromium). На реальный браузер переходим только
когда упавший тест помечен `failed_in: <browser>` и проблема не воспроизводится в
дефолтном/альтернативном движке.

## Последовательность входа в приложение

Сначала получи креды research-юзера задачи (протокол доступа — канон субагента dom-explorer;
ось product-api). Выполни один раз перед исследованием:

1. Открой URL стенда (операция «открыть URL»).
2. Сними снапшот дерева UI, найди поля логин-формы, заполни `username`/`password` (операция «ввод») и подтверди (операция «клик»).
3. Обработай пост-логин попапы проекта (референс one-web: попап разрешения уведомлений появляется через несколько секунд после входа, не больше 10 — закрыть кликом).
4. Сними снапшот и убедись, что приложение загрузилось (нет попапа, виден интерфейс).

Конкретные команды (референс one-web):

```bash
playwright-cli open https://at-test-1-one.ivcs.su/
playwright-cli fill e13 "<username из ensure>"
playwright-cli fill e17 "<password из ensure>"
playwright-cli click e21
```

После клика, через несколько секунд (не больше 10), появится попап разрешения уведомлений:
```bash
playwright-cli click e911
playwright-cli snapshot
```

Убедиться по снапшоту, что приложение загрузилось (нет попапа, виден интерфейс).

> **Если ref'ы элементов логин-формы (e13, e17, e21, e911) изменились** — сделай свежий
> `playwright-cli snapshot` и найди актуальные ref через accessibility-дерево.

**Скорость: сохраняй login-state, сетап данных — REST.** UI-логин стоит десятки секунд на
каждый старт CLI — на многосессионной разведке это удваивает время. Используй персистентный
login-state (`state-save` после первого входа → `state-load` в следующих сессиях; файл — в
служебный каталог инструмента); state протух → перелогин и пересохранение. Тестовые данные
для разведки (сущности продукта) создавай REST-обёртками *[product-api]*, не через UI:
UI — для **наблюдения** результата (DOM, текст, локатор), REST — для **setup'а**. Созданное
для разведки удали через REST до завершения сессии.

## Правый клик (контекстное меню)

Жест сложнее клика: hover на элемент → правая кнопка down → правая кнопка up → снапшот:

```bash
playwright-cli hover <ref_элемента>
playwright-cli mousedown right
playwright-cli mouseup right
playwright-cli snapshot
```

## Проверка XPath через eval

### mode=fix — есть ли узел (true/false)

```bash
playwright-cli eval "document.evaluate('//chat-sidebar//input[@type=\"file\"]', document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue !== null"
```
Возвращает `true`/`false` — есть ли элемент по этому XPath.

### mode=canary — подсчёт узлов (count ≥ 1)

```bash
playwright-cli eval "document.evaluate('<xpath>', document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null).snapshotLength"
```
Как в mode=fix, но считается число узлов: `≥1` → OK; `0` → BROKEN.

## Правила именования локаторов [test-stack]

> Формат и именование локаторов задаёт стек проекта — сверься с правилами стека
> (`rules/page-objects.md` этого стека, разделы «Локаторы» и «Составные виджеты»).
> Шаблоны кода ниже — референс one-web (pytest+Selenium+XPath); на другом стеке замени
> формат на свой, **сохранив сами правила** (парные локаторы, i18n, корневые локаторы).

**Парные локаторы для составных виджетов:** для toggle/checkbox-виджетов дизайн-системы предлагай **пару** локаторов — `L_I18N_<X>_SWITCH` на внутренний control (для клика; референс one-web: `<ds-toggle>`) и `L_I18N_<X>_CHECKBOX` на `<input>` (для проверки состояния, референс: `is_selected()`); по внешнему контейнеру не кликают — драйвер бьёт в пустой центр (референс-прецедент Selenium).

```python
# Статический — без параметров
@staticmethod
def L_<ИМЯ_ЭЛЕМЕНТА>(lang=''):
    return 'xpath', '//tag[@attr="value"]'

# Динамический — с параметром (текст, имя, id)
@staticmethod
def L_<ИМЯ_ЭЛЕМЕНТА>(<param>, lang=''):
    return 'xpath', f'//tag[contains(text(),"{<param>}")]'

# С i18n (если текст переводится) — только i18n текст, без динамических параметров
@staticmethod
def L_I18N_<ИМЯ_ЭЛЕМЕНТА>(lang):
    i18n_str = i18n.get_str('<ключ_строки>', lang)
    return 'xpath', f'//tag[text()="{i18n_str}"]'

# Смешанный — динамический параметр + i18n текст
@staticmethod
def L_I18N_<ИМЯ_ЭЛЕМЕНТА>(<param>, lang):
    i18n_str = i18n.get_str('<ключ_строки>', lang)
    return 'xpath', f'//tag[.//span[text()="{<param>}"]]//*[text()="{i18n_str}"]'
```

- Именование: `L_` + заглавные слова через `_`, отражает ЧТО это за элемент
- Примеры: `L_SELECT_MODE_TOOLBAR`, `L_I18N_SELECT_BTN`, `L_SELECTED_MESSAGE(text)`
- Если текст кнопки/элемента переводится — использовать `L_I18N_` с ключом i18n
- Если локатор строится через i18n-корневой локатор (`L_I18N_*...(lang)`), например `f'{LChat.L_I18N_FORWARD_DIALOG(lang)[1]}//...'`, то имя такого локатора тоже должно начинаться с `L_I18N_` — это сигнал, что `lang` обязателен

### ⚠️ ОБЯЗАТЕЛЬНОЕ ПРАВИЛО: любой текст UI → только через i18n

**ЗАПРЕЩЕНО** хардкодить любой видимый пользователю текст в локаторе:
```python
# ❌ НЕПРАВИЛЬНО — "Ред." захардкожено
return 'xpath', f'//span[text()="Ред."]'

# ✅ ПРАВИЛЬНО — через i18n
i18n_str = i18n.get_str('chat_message_edited_mark', lang)
return 'xpath', f'//span[text()="{i18n_str}"]'
```

**Это правило применяется ко всем текстовым меткам**, даже если они выглядят как "фиксированный текст" (сокращения типа "Ред.", статусы "Онлайн", подписи "Переслано" и т.д.) — приложение поддерживает несколько языков, поэтому любой UI-текст может меняться при смене языка.

**Порядок действий при обнаружении текстового элемента:**
1. Проверить словарь строк проекта (референс one-web: `tools/i18n/strings.py`) — есть ли уже ключ с таким текстом
2. Если есть — использовать `i18n.get_str('<ключ>', lang)` в локаторе
3. Если нет — добавить ключ в раздел `## Необходимые новые i18n строки` выходного файла: текст основного языка из DOM, перевод — из i18n-словаря исходников AUT (клон продукта — параметр `product_clone` секции `[craft]`; не нашёлся — `TODO`)
4. Назвать локатор `L_I18N_<ИМЯ>` и добавить `lang` как **обязательный** параметр (без `=''`)

## Паттерн локатора через родительский локатор

Если дочерний локатор принадлежит компоненту, у которого уже есть корневой локатор — строй дочерний селектор через `ClassName.L_ROOT()[1]` (примеры-теги — референс one-web/Angular):

```python
# Корневой локатор:
@staticmethod
def L_SELECT_MODE_TOOLBAR(lang=''):
    return 'xpath', '//chat-select-mode-toolbar'

# Дочерние — ВСЕГДА через L_SELECT_MODE_TOOLBAR()[1]:
@staticmethod
def L_SELECT_MODE_CANCEL_BTN(lang=''):
    return 'xpath', f'{LChat.L_SELECT_MODE_TOOLBAR()[1]}//button[1]'
```

### ⚠️ ОБЯЗАТЕЛЬНОЕ ПРАВИЛО: перед написанием селектора — проверь корневые локаторы

**Перед формулировкой нового локатора** прочитай файл локаторов (указан в `analysis.md`) и найди все методы, которые возвращают селектор с тегом верхнего уровня (референс one-web: строка вида `return 'xpath', '//tag...'` без ссылок на другие локаторы). Это корневые локаторы.

**ЗАПРЕЩЕНО** начинать дочерний селектор с тега, для которого уже есть корневой локатор:
```python
# ❌ НЕПРАВИЛЬНО — //chat-message-container уже есть как L_CHAT_MESSAGE_CONTAINER()
return 'xpath', f'//chat-message-container[.//span[text()="{text}"]]//span[text()="{mark}"]'

# ✅ ПРАВИЛЬНО — используем существующий корневой локатор
return 'xpath', f'{LChat.L_CHAT_MESSAGE_CONTAINER()[1]}[.//span[text()="{text}"]]//span[text()="{mark}"]'
```

Это правило применяется ко всем корневым компонентам, для которых в файле уже есть метод, возвращающий этот тег (референс one-web: `//chat-message-container`, `//chat-topbar` и т.п.).

## Canary-sweep (дрейф примитивов при смене сборки)

У Selenium-стека canary-sweep — механизм отлова дрейфа примитивов дизайн-системы, который
молча ломает локаторы (референс-прецедент one-web: миграция тегов `ds-*`→`iva-*`).
Запускается при смене сборки AUT, **до** прогона батчей. Вход — протокол-список канареек
проекта (референс one-web: `.tasks/aut-research/canary-locators.md`: примитив, экран,
bare-селектор, Guards — по группам S0–S8 + протокол).

Порядок:
1. Прочитай список канареек — группы экранов и селекторы.
2. **Login** research-юзером, подтверди сборку на экране версии/сборки AUT → в отчёт.
3. По группам экранов в порядке S0→S8 (cheap→deep): навигируй по breadcrumb группы, затем
   для каждой канарейки — eval-подсчёт узлов по селектору (сниппет — «Проверка XPath через
   eval» → mode=canary). `≥1` → OK; `0` → BROKEN; экран не достигнут → «недостижимо».
4. **Только проверка наличия из списка** — не искать новые локаторы, не перебирать DOM
   сверх списка. mode-gated/action-triggered канарейки (отмечены в списке) — по их заметке.
5. Выход: отчёт дрейфа (референс one-web: `.tasks/aut-research/drift-report-<build>.md`
   по формату из списка канареек — сводка N/OK/BROKEN + таблица BROKEN с Guards-локаторами
   на актуализацию).

`0` у канарейки = либо реальный дрейф (Guards-локатор чинить через mode=fix), либо
устаревшая канарейка (экран/режим уехал — флагни в отчёте, чинит список человек/агент).

## Реальный браузер через grid

Используй когда падение **уникально для конкретного браузера** (другие браузеры тест
проходят, либо при том же сценарии дефолтный/альтернативный движок показывает другое
поведение). Реальный браузер воспроизводит баги, которых нет в эмуляции движка (референс
one-web, real Safari vs Playwright WebKit: ordering `window.handles`, popup blocker,
click event timing, обновление sent-status иконки).

- **Один сценарий = одна сессия.** Если grid/браузер не переживает reattach между вызовами
  (референс: Safari WebDriver на selenoid) — весь сценарий разведки собери в один скрипт
  (логин → шаги до точки падения → dump DOM в точке интереса → проверка целевого селектора
  → скриншот), прогони целиком, сохрани артефакты. Нетривиальные сценарии — оформляй файлом
  в рабочем каталоге задачи (`{batch_dir}` либо `.tasks/work/adhoc-<тема>/`), не в корне `.tasks/`.
- Перед запуском проверь доступность grid (сетевой чек — ниже). Недоступен → выйди с
  сообщением «нет доступа к grid».
- Помни: среда разведки ≠ среда прогона (флаги браузера, фейковые медиа-устройства) —
  поведенческие выводы перепроверяй на стеке.

### Safari через mac-selenoid (референс one-web)

Реальный Safari на macOS воспроизводит баги, которых нет в Playwright WebKit: ordering
`window.handles`, popup blocker, click event timing, sent-status icon обновление, и т.д.

#### Helper

Файл `.claude/scripts/selenoid_safari.py` — обёртка над Selenium webdriver.Remote с подключением к `mac-selenoid` (IP читается из `config.yaml`; env по умолчанию — `default_env()` из `selenoid_common.py`: стенд активной линии, явный `--env` перекрывает).

**Ключевая особенность**: каждая Safari-сессия = один Python-скрипт. Reattach между вызовами **не поддерживается** (Safari WebDriver на selenoid плохо переживает повторные подключения). Поэтому весь сценарий разведки нужно собрать в одну Python-функцию, прогнать, сохранить артефакты.

#### Доступные функции внутри сценария

| Функция | Назначение |
|---|---|
| `drv` | `selenium.webdriver.Remote` с открытой Safari-сессией |
| `dump_html(drv, xpath, first_n=3)` | `outerHTML` первых N элементов по XPath (для DOM-снапшота) |
| `xpath_count(drv, xpath)` | Сколько элементов нашлось |
| `wait_xpath(drv, xpath, timeout=15)` | Polling до появления элемента; `True/False` |
| `screenshot(drv, path)` | PNG-скриншот в `path` |
| `window_dump(drv)` | Список всех окон с URL/title (важно для редирект-кейсов) |
| `login_iva_one(username, password)` | Стандартная авторизация в AUT (референс one-web) |

#### Запуск

```bash
# вариант 1: inline-скрипт
<python-проекта> .claude/scripts/selenoid_safari.py --script "drv.get('https://at-test-1-one.ivcs.su/'); print(drv.title)"

# вариант 2: сценарий из файла
<python-проекта> .claude/scripts/selenoid_safari.py --file .tasks/work/<task>/safari_scenario.py
```

Для нетривиальных сценариев — оформлять как файл в `.tasks/work/<task>/safari_<test_name>.py`.

#### Шаблон сценария

```python
# .tasks/work/<task>/safari_<test_name>.py — выполняется в области сценария selenoid_safari
# В scope доступны: drv, dump_html, xpath_count, wait_xpath, screenshot, window_dump, login_iva_one, time

import time

# 1. Логин
login_iva_one('<username>', '<password>')
wait_xpath(drv, '//chats-list', timeout=20)

# 2. Воспроизвести сценарий до точки падения
# ... шаги UI: drv.find_element('xpath', '...').click(), .send_keys('...'), ...

# 3. Снять DOM в точке интереса
print(dump_html(drv, '//chat-message-container[last()]'))
screenshot(drv, '.tasks/work/<task>/safari_<test_name>_step.png')

# 4. Проверить целевой локатор
print('matches:', xpath_count(drv, '//ds-icon-check-bold[contains(@class,"icon_sent")]'))
```

#### Доступ к стенду (референс one-web)

- mac-selenoid: `10.6.0.219:4444`
- Перед запуском проверить сеть: `nc -z -G 3 10.6.0.219 4444` (exit 0 = доступен). Если недоступен (exit ≠ 0) — выйти с сообщением «нет доступа к mac-selenoid».
- VNC живой сессии: `http://10.6.0.219:4444/vnc/<session_id>` (скрипт сам выводит URL при открытии).
- Список активных сессий: `curl http://10.6.0.219:4444/status`.

#### Формат вывода (mode=fix, реальный браузер)

`{batch_dir}/fix-{test_name}-locators.md`, в дополнение к обычным секциям (общий формат —
канон субагента dom-explorer, «Формат вывода (mode=fix, реальный браузер)»), добавить:

````markdown
## Safari (mac-selenoid) — фактический DOM в точке падения

- session VNC: http://10.6.0.219:4444/vnc/<id>
- scenario file: .tasks/work/<task>/safari_<test_name>.py
- screenshot:  .tasks/work/<task>/safari_<test_name>_step.png

### DOM фрагмент

```html
<chat-ui-seen-status ...>...</chat-ui-seen-status>
```

### Проверка целевого XPath
- count = N (где N=0 если не найден)
- альтернативный XPath, который находит реальный элемент: `//...`
````

#### Ограничения Safari-режима

- Один сценарий = одна сессия. Между запусками `selenoid_safari.py` Safari-сессия закрывается, и DOM-состояние теряется. Если нужно «подвиснуть» в точке для мануального VNC-просмотра — добавить `time.sleep(N)` в конец сценария.
- Старт Safari ≈ 1с, login ≈ 5с, полный сценарий обычно 15-30с. Долгие сценарии (chat + media) — до 60с. По умолчанию `sessionTimeout=600s` хватит.
- Если сессия зависла и не закрылась штатно — она будет жить до `sessionTimeout` (10 минут), затем Selenoid сам её прибьёт. Можно вручную через `curl -X DELETE -m 5 http://10.6.0.219:4444/wd/hub/session/<id>` (наш `-m 5` нужен, потому что DELETE сам по себе может зависнуть).
- Параллельных Safari-сессий нет (mac-selenoid выдаёт по одной за раз — Safari instance is paired with another WebDriver session). Если получена эта ошибка — кто-то уже работает, надо подождать или прибить чужую сессию через `/status` + DELETE.

## Гигиена артефактов CLI

Снапшоты/скриншоты/pdf CLI разведки по умолчанию может писать в CWD — это мусорит в корне
проекта. **Всегда передавай явный путь в gitignored служебный каталог инструмента**
(референс playwright-cli: `--filename=.playwright-cli/<name>.<ext>` для **любого**
`snapshot`/`screenshot`/`pdf`; каталог уже в .gitignore). В конце работы закрой браузер
(`playwright-cli close`); случайно оставил файлы в корне — удали перед завершением.
Артефакты, идущие в выдачу (fix-эвиденс, скриншоты), — в свои каталоги `.tasks/` по
правилам режима субагента.
