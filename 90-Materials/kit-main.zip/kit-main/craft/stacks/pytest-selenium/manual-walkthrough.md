<!-- Референс-реализация стека pytest-selenium модуля craft (kit). Прародитель — ядро
aqa-agent-toolkit. Phase 3 скилла craft:fix — ручное пошаговое воспроизведение сценария:
принцип «делай-смотри-думай», алгоритм и форматы артефактов — generic; инструменты — ось
[browser-driver] (вождение разведки — `recon.md` этого стека; референс one-web: playwright-cli
+ per-браузер driver-скрипты selenoid_<os>_<browser>.py). Чтение TC — модуль tms (скилл
tms:read). Логин — research-юзер задачи (ось product-api). -->

# Phase 3 — Manual step-by-step walkthrough

После того как Phase 1+2 установили, что падение воспроизводимо, нужно понять **что именно** идёт не так. Это **ручное пошаговое выполнение сценария**, не перезапуск раннера.

## Принцип «делай-смотри-думай»

Цикл на каждом шаге сценария:
1. **Сделать** одно действие в браузере (клик / ввод / навигация).
2. **Снять состояние** (снапшот дерева UI для CLI-разведки; dump DOM/окон для driver-скрипта).
3. **Сравнить с ожиданием**: пройдено ли действие? Появился ли нужный элемент? Сменился ли URL?
4. Если ожидание не совпало — это место провала. Зафиксировать DOM, скриншот, console / network если уместно.
5. Иначе — следующий шаг.

Не делать runner-like рестарт всего сценария, если что-то сломалось — анализируем точку, в которой стало плохо.

## Выбор инструмента *[browser-driver]*

Референс one-web (маппится на инструменты проекта при установке):

| Условие | Инструмент |
|---|---|
| target — Chromium-браузер (chrome/lin_chrome) | интерактивный CLI разведки (референс: `playwright-cli open`, Chromium) |
| target — Chromium-based (msedge и т.п.) | CLI разведки (Chromium — большинство багов воспроизводится) — fallback per-браузер driver-скрипт, если не воспроизвёл |
| target — firefox / нестандартная сборка | CLI разведки → если не воспроизвёл → per-браузер driver-скрипт (референс: `selenoid_win_firefox.py`) |
| target — safari | CLI разведки с движком webkit → если не воспроизвёл → per-браузер driver-скрипт с VNC (референс: `selenoid_mac_safari.py`) |

**Правило**: всегда сначала пробуем интерактивный CLI разведки — он быстрее и даёт богатые snapshot'ы. На per-браузер driver-скрипт переходим только когда подозреваем браузер-специфичный quirk или CLI не воспроизвёл, а раннер воспроизводит стабильно.

## Алгоритм Phase 3

### 3.0. (Опционально) Достать ожидаемый сценарий из TMS

Если у теста есть численный TC-id в метаданных (референс: `@allure.id("<N>")`, не `desc-*`) — read-only вытащи бизнес-сценарий через CLI модуля tms (скилл tms:read, операция `get`; вызов из корня репо проекта):

```
<python-проекта> "$TMS/scripts/testops_cli.py" get <N>
```

($TMS — каталог модуля tms в кэше плагинов; в Claude Code `${CLAUDE_PLUGIN_ROOT}` модуля tms.)

Из ответа возьми блок `Steps:` — это **ожидаемый** сценарий с точки зрения QA. Сравни его с шагами, которые делает тест. Расхождение (новый/изменённый/удалённый шаг) — сильный сигнал `UX_FLOW_CHANGED` ещё до открытия браузера.

TMS-модуль вернул ошибку / TC не зарегистрирован / id не численный → пропустить, использовать только код теста как источник истины.

### 3.1. Воспроизведение через интерактивный CLI разведки

1. Извлечь сценарий из тест-функции: список шагов от login до точки падения (см. `failure-localization.md` скилла craft:fix, секция эпицентр).
2. Открыть web-URL стенда `{env}` (референс: `playwright-cli open <web_url>`; нужный движок браузера — по таблице выше).
3. Залогиниться под research-юзером задачи (процедура логина — инструкция `dom-explorer` + `recon.md` этого стека; учётки — ось product-api).
4. Выполнить шаги сценария **по одному**:
   - после каждого — снапшот; console / network — если есть подозрение.
   - сохранять скриншоты в `.tasks/work/batch-{ts}/fix-{test}-screenshot-step-{N}.png`.
5. Дойти до точки падения. Зафиксировать:
   - **DOM в момент падения** (снапшот или JS-запрос к DOM через `eval`);
   - **Console errors / warnings**;
   - **Network requests** (особенно неуспешные 4xx/5xx);
   - **Local state** (cookies, localStorage если важно).

### 3.2. Если CLI разведки **не** воспроизвёл

Возможно, баг привязан к конкретной WebDriver-реализации (Safari/Firefox/прочие) или к специфике версии браузера в grid-VM.

1. Запустить per-браузер driver-скрипт для target-platform (референс one-web; `<python-проекта>` — параметр `python` секции `[project]` answers-файла):
   ```bash
   <python-проекта> .claude/scripts/selenoid_win_firefox.py --file .tasks/work/batch-{ts}/manual_{test}.py
   ```
2. Сценарий в `.tasks/work/batch-{ts}/manual_{test}.py` (шаблон ниже).
3. Открыть VNC/live-сессию по ссылке, которую напечатает скрипт при старте — можно наблюдать в реальном времени.
4. Завершить сценарий `time.sleep(N)` чтобы успеть посмотреть UI вручную если нужно.

### 3.3. Если **ни один** инструмент не воспроизвёл

→ Классификация: `AUTOMATION_ONLY` (отложить в корзину).

Записать в `fix-{test}-manual.md`:
```markdown
## Manual repro — НЕ ВОСПРОИЗВЕЛОСЬ
- CLI разведки ({browser}): сценарий выполнен полностью, ошибки нет
- per-браузер driver-скрипт: сценарий выполнен полностью, ошибки нет

→ AUTOMATION_ONLY. Будет рассмотрено в Phase 6 на предмет workaround.
```

В Phase 4 эту категорию **не** обрабатываем — переходим к следующему тесту.

## Шаблон файла-сценария для driver-скрипта (референс one-web)

`.tasks/work/batch-{ts}/manual_{test}.py`:

```python
# Выполняется внутри open_session driver-скрипта. В scope доступны (референс one-web):
#   drv, dump_html, xpath_count, wait_xpath, screenshot, window_dump, login-хелпер, time

# 1. Логин под research-юзером задачи
login('<research-user>', '<password>')
wait_xpath(drv, '<локатор корневого экрана>', timeout=20)

# 2. Воспроизводим сценарий шаг за шагом — между шагами обязательно snapshot/dump
# Шаг 1: открыть сущность
drv.find_element('xpath', '<локатор элемента списка>').click()
wait_xpath(drv, '<локатор поля ввода>', timeout=10)
print('STEP 1 done. items count:', xpath_count(drv, '<локатор элементов>'))

# Шаг 2: ввести текст
drv.find_element('xpath', '<локатор поля ввода>').send_keys('hello')
print('STEP 2 done. input text:', drv.find_element('xpath', '<локатор поля ввода>').text)

# Шаг 3: действие (тут ожидаем падение в раннер-прогоне)
drv.find_element('xpath', '<локатор кнопки действия>').click()
time.sleep(2)
# Зафиксировать состояние
screenshot(drv, '.tasks/work/batch-{ts}/fix-{test}-after-action.png')
print(dump_html(drv, '<локатор результата>'))
print('window dump:', window_dump(drv))

# 4. Optional: пауза для VNC-просмотра
time.sleep(15)
```

## Формат `fix-{test}-manual.md`

```markdown
# Manual walkthrough — {test_name}

## Использованный инструмент
- CLI разведки (движок chrome) ИЛИ per-браузер driver-скрипт

## Сценарий (сжатая последовательность шагов)
1. login <research-user>
2. открыть чат "Test channel"
3. ввести "hello"
4. клик [send] ← здесь упало

## Наблюдения по шагам
| Шаг | Ожидание | Факт | OK? |
|---|---|---|---|
| 1 | поле ввода появилось | появилось (timeout 2.4s) | ✅ |
| 2 | text="hello" в input | в DOM .text="hello", но textContent="hel" | ⚠️ rich-text partial render |
| 3 | новое сообщение в скроллере | скроллер не сдвинулся; сообщение в DOM, но virtual-scroll спрятал его | ❌ |

## DOM/console/network в точке падения
- DOM: см. .tasks/work/batch-{ts}/fix-{test}-after-action.png
- console: WARN virtual-scroll: synthetic event ignored
- network: POST <endpoint отправки> → 200 OK (значит, бэкенд получил)

## Гипотеза причины
- WebDriver-вход не активирует auto-scroll → виртуализация выносит новое сообщение → ассерт присутствия не находит.
- Похоже на типовой WEBDRIVER_QUIRK с virtual-scroll (см. failure-taxonomy.md этого стека).
```

Эта гипотеза пойдёт в Phase 4 (Classify + Fix) — `code-writer` применит JS-скролл-обход с гардом по `driver.name`.
