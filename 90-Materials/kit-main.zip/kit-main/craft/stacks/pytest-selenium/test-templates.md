<!-- Референс-реализация стека pytest-selenium модуля craft (kit). Прародитель — ядро
aqa-agent-toolkit. Шаблоны тестовой функции и каркасы кода для code-writer: стандартные
импорты · single-session шаблон · multi-session шаблон · правила тела теста (порядок блоков,
именование, teardown, маркеры, фабрика юзеров, сигнатуры из analysis.md) · каркасы
локаторов/методов/enum/файлов/реестров/i18n/REST-обёртки. Скиллы модуля (craft:write шаг 6,
craft:batch) ссылаются на этот файл как «шаблоны кода — стек проекта» (параметр `stack`
секции `[craft]` answers-файла базы kit); контракт разделов — `../README.md` (контракт
стека). Весь код и имена ниже — референс one-web (pytest + Selenium, vendored-библиотека
autocore, product-api iva_one), целиком. -->

# Шаблоны тестовой функции (референс pytest+Selenium, one-web)

Два шаблона: для одного браузера (1 пользователь) и для нескольких (2+ пользователя).

## Стандартный набор импортов

В начале `tests/test_<feature>.py` всегда (референс one-web):

```python
import allure
import pytest
from autocore.test.logger import get_log
from autocore.test.generate_data import get_random_string
from autocore import driver_sessions
from autocore.clients.rest import iva_one
from tools.helpers.session import web_preamble, iva_one_web_login
from tests import pages
from tests.pages import chunks

log = get_log()
```

(`web_preamble` нужен только для single-session шаблона ниже; в мультибраузерном не используется. `iva_one_web_login` — в обоих шаблонах.)

Если в существующем файле уже есть эти импорты — не дублируй, добавь только недостающие.

## Шаблон для одного браузера (1 пользователь, `setup_aut`)

```python
@allure.id("<allure_id>")
@allure.title("<name из CSV/TestOps>")
@allure.label("owner", "<Owner>")
@allure.tag("<tag1>", "<tag2>")
@allure.story("<Story>")
@allure.label("IVAQA", "<jira_link>")
@allure.feature("<Feature>")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_<entity>_<action>_<result>(setup_aut, users_factory, teardown):
    # 1. Блок переменных (web_preamble: lang/version/driver + регистрация quit браузера в teardown)
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    chat_name = get_random_string(10)            # для каждого <generate: ...>
    message_text = get_random_string(10)

    # 2. API-предусловия (iva_one_web_login сворачивает iva_one.login(.., 'IVA', 'iva-one', secret))
    token = iva_one_web_login(setup_aut, users_data[0])
    iva_one.create_chat(token, chat_name, [users_data[0]['username']],
                        type=iva_one.ChatTypes.GROUP)

    # 3. TC-логирование
    log.tc('<allure_id>')

    # 4. UI-шаги по сценарию
    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))

    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()

    # Список чатов (chats_list) и комната (chat) — разные домены: операции над СПИСКОМ
    # (открыть/найти/контекст-меню/бейджи) — через chats_list; действия в КОМНАТЕ — через chat.
    # Порядок init следует UI: open_chats открывает список → chats_list первым, затем chat.
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(chat_name)
    chat.type_message(message_text)
    chat.send_message()
    chat.assert_message_in_chat(message_text)
```

## Шаблон для нескольких браузеров (2+ пользователя, `setup_multiple_auts`)

```python
@allure.id("<allure_id>")
@allure.title("<name>")
@allure.label("owner", "<Owner>")
@allure.tag("<tag>")
@allure.story("<Story>")
@allure.label("IVAQA", "<jira_link>")
@allure.feature("<Feature>")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_<entity>_<action>_<result>(setup_multiple_auts, users_factory, teardown):
    # 1. Блок переменных
    auts = setup_multiple_auts(2)
    lang = auts['setup']['cmd']['lang']
    version = auts['setup']['cmd']['ver']
    users_data = users_factory
    chat_name = get_random_string(10)
    message_text = get_random_string(10)

    # 2. API-предусловия (создание чата с обоими пользователями)
    token = iva_one_web_login(auts, users_data[0])
    iva_one.create_chat(
        token,
        chat_name,
        [user['username'] for user in users_data],
        type=iva_one.ChatTypes.GROUP,
    )

    # 3. Driver-ы + teardown
    driver, driver_2 = auts['driver']
    teardown.append((lambda el: el.quit(), driver))
    teardown.append((lambda el: el.quit(), driver_2))

    # 4. TC-логирование
    log.tc('<allure_id>')

    # 5. Действия первого пользователя
    driver_sessions.set_active(driver)
    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))

    chunks.get_chunk(version, 'left_menu')(driver, lang=lang).open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(chat_name)
    chat.type_message(message_text)
    chat.send_message()

    # 6. Действия второго пользователя
    driver_sessions.set_active(driver_2)
    login_page_2 = pages.get_page(version, 'login')(driver_2, lang=lang)
    login_page_2.login(users_data[1].get('username'), users_data[1].get('password'))

    chunks.get_chunk(version, 'left_menu')(driver_2, lang=lang).open_chats()
    chats_list_2 = chunks.get_chunk(version, 'chats_list')(driver=driver_2, lang=lang)
    chat_2 = pages.get_page(version, 'chat')(driver_2, lang=lang, open_page=False)
    chats_list_2.open_chat(chat_name)
    chat_2.assert_message_in_chat(message_text)
```

## Правила тела теста

### 1. Порядок блоков (строгий)
1. **Блок переменных**: `lang, version, driver = web_preamble(setup_aut, teardown)` (single-session — сразу даёт lang/version/driver и регистрирует quit браузера в teardown), затем `users_data`, все `get_random_string(...)`
2. **API-предусловия**: `iva_one_web_login(setup_aut, user)` (REST-логин веб-клиента → token), `iva_one.create_chat`, `iva_one.send_message` и т.д.
3. **`log.tc('<allure_id>')`** — ровно одна строка
4. **UI-шаги** по сценарию

Мультибраузерный тест (`setup_multiple_auts`) `web_preamble` не использует — там несколько драйверов и quit регистрируется на каждый отдельно (см. шаблон выше).

### 2. Именование теста

`test_<entity>_<action>_<result>` в snake_case. Примеры:
- `test_channel_edit_avatar_visible`
- `test_chat_send_receive_message`
- `test_login_logout_redirect_to_login_page`

Генерируется из поля `name` (CSV/TMS/текст) через транслитерацию или подбор английских аналогов основных глаголов/существительных. **Не оставляй кириллицу в имени функции.**

### 3. Teardown обязателен

Закрытие браузерной сессии должно быть в каждом тесте.

- **Single-session** (`setup_aut`): регистрируется автоматически внутри `web_preamble(setup_aut, teardown)` — отдельную строку `teardown.append(...)` писать не нужно.
- **Мультибраузерный** (`setup_multiple_auts`): `web_preamble` не используется — на каждый driver отдельно `teardown.append((lambda el: el.quit(), driver))`.
- **Свой порядок teardown** (нужна очистка с живым driver): `web_preamble(setup_aut, teardown, register_quit=False)`, и тест аппендит quit сам **последним** (детали — rules стека, «Стандартная сигнатура»: `rules/tests.md`).

### 4. Маркеры

Всегда добавлять:
```python
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
```

**Браузерные маркеры вручную не добавлять.** Они проставляются автоматически в `conftest.py` через хук `pytest_collection_modifyitems` (словарь конфигураций — на проект; референс one-web: `browser_win_firefox`, `browser_win_chrome`, `browser_win_msedge`, `browser_lin_chrome`, `browser_win_ya`; тестам с одной параллельной сессией — дополнительно `browser_mac_safari`).

Никакие `@pytest.mark.browser_*` руками не пишем.

Запуск теста в конкретном браузере выбирается флагом `-m browser_<os>_<name>` на стороне pytest (см. README проекта, «Запуск в разных браузерах»).

### 5. `@pytest.mark.parametrize("users_factory", [N], indirect=True)`

`N` — количество тестовых пользователей, которое создаст фикстура `users_factory`. Если в сценарии задействован 1 пользователь, чаще ставят `[2]` (запасной для будущих расширений и для случаев, когда нужен второй участник сущности). Если 2+ пользователей — соответствующее число.

### 6. Использование сигнатур из analysis.md

В `analysis.md` (`.tasks/work/tc-{id}/`) `codebase-analyst` записал точные сигнатуры существующих методов page/chunk **с поведенческими примечаниями**. Используй их буквально, не угадывай:

- Если в analysis отмечено «`type_message(message, check_value=True)` — `check_value=True` уже проверяет содержимое инпута» — не добавляй дополнительный assert после `type_message`.
- Если отмечено «`send_keys` дописывает, не заменяет» — перед `type_message` вызови `clear_input(...)`, если нужно заменить, а не дописать.

### 7. Импорты

Стандартный набор импортов в начале файла (см. выше). Если в `analysis.md` есть упоминание новых enum-ов, добавь импорт:
```python
from tools.enums import <NewEnum>
```

### 8. Смежные домены UI — разные объекты (пример: `chats_list` vs `chat`)

Урок-референс one-web: левая панель списка чатов вынесена в отдельный chunk `chats_list`
(`<chat-chats-list>`); page `chat` — только открытая комната справа (`<chat-room>`/`<chat-topbar>`).
Это разные непересекающиеся DOM-поддеревья, поэтому в тестах **два отдельных объекта**,
без делегирования через `chat`:

- **Операции над СПИСКОМ → `chats_list`** (`chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)`):
  `open_chat(name)`, `search_chat`/`open_chat_from_search`/`open_found_user_dialog`, `click_create_chat_btn`/
  `select_chat_type`, `open_chat_context_menu`/`click_pin_in_chat_context_menu`/`assert_chat_pinned`/
  `click_delete_in_chat_context_menu`/`confirm_delete_chat`, `assert_chat_not_in_list`, бейджи
  `assert_unread_badge_visible/_absent`/`assert_mention_badge_visible`.
- **Действия в КОМНАТЕ → `chat`**: `type_message`/`send`, бабблы/реакции/пины сообщений, thread, forward,
  медиа, `open_chat_profile`, `assert_chat_with_chat_name_opened` (verify «нужная комната открыта» по топбару).
- **`chats_list.open_chat(name)` НЕ проверяет, что комната открылась** (это chat-room DOM). Если следом идёт
  chat-room действие (`type_message`, `open_chat_profile`, ...) — оно само упадёт при неудаче, verify не нужен.
  Если следом идёт проверка СПИСКА, зависящая от факта открытия (например `assert_unread_badge_absent` после
  прочтения), добавь барьер `chat.assert_chat_with_chat_name_opened(name)` между ними.
- На каждый драйвер/сессию — свой `chats_list` (как и `chat`): в multi-browser `chats_list` на `driver`,
  `chats_list_2` на `driver_2`.

---

## Каркасы code-writer (референс-реализация)

Субагент модуля `craft:code-writer` ссылается на этот раздел за конкретными каркасами кода: шаблоны локаторов, методов page/chunk, enum, файлов новых page/chunk, регистрация в реестрах, i18n-запись, REST-обёртка. Код ниже — дословно из one-web (референс-реализация; продуктовые имена в коде допустимы). Порядок шагов, обязательные проверки и запреты — инвариант канона, живут в самом определении code-writer; здесь — только каркасы.

### Шаблоны локатор-методов (статический / динамический / i18n)

Локатор-методы — `@staticmethod` в классе `L<ModuleName>` (файл `tests/pages/locators/Version2/<module>.py` или `chunks/<module>.py`):

```python
# Статический
@staticmethod
def L_<ИМЯ_ЭЛЕМЕНТА>(lang=''):
    return 'xpath', '//tag[@attr="value"]'

# Динамический
@staticmethod
def L_<ИМЯ_ЭЛЕМЕНТА>(<param>, lang=''):
    return 'xpath', f'//tag[contains(text(),"{<param>}")]'

# С i18n
@staticmethod
def L_I18N_<ИМЯ_ЭЛЕМЕНТА>(lang):
    i18n_str = i18n.get_str('<ключ_строки>', lang)
    return 'xpath', f'//tag[text()="{i18n_str}"]'
```

### Паттерн через родительский локатор

Дочерний локатор строится подстановкой существующего корневого локатора (`L_X()[1]` — селектор из пары `('xpath', selector)`), а не повторным хардкодом корня:

```python
@staticmethod
def L_SELECT_MODE_CANCEL_BTN(lang=''):
    return 'xpath', f'{LChat.L_SELECT_MODE_TOOLBAR()[1]}//button[1]'
```

### Исправление хардкода корневого локатора (❌ получено от dom-explorer → ✅ исправлено)

Если селектор из locators.md начинается с узла, для которого уже есть корневой локатор-метод — заменить хардкод корня подстановкой перед вставкой:

```python
# ❌ Получено от dom-explorer — неправильно
return 'xpath', f'//chat-message-container[.//span[text()="{text}"]]//span[text()="{mark}"]'

# ✅ Исправить перед записью в файл
return 'xpath', f'{LChat.L_CHAT_MESSAGE_CONTAINER()[1]}[.//span[text()="{text}"]]//span[text()="{mark}"]'
```

### Формат записи i18n (`tools/i18n/strings.py`)

```python
'<ключ>': {
    consts.LANG_RU: 'Текст кнопки',
    consts.LANG_EN: 'Button text',
},
```

Второй язык (`consts.LANG_EN`) — из locators.md, колонка «Английский текст»; колонки нет или там `TODO` — ставить `'TODO'`, основной текст не дублировать.

### Шаблон метода page/chunk

```python
def <action>(self, <param>=''):
    log.step('Описание шага', where='IVA ONE WEB Клиент')
    self.get_object(self.L_<LOCATOR>(<param>)).click()
    # при необходимости: self.wait_presence / self.wait_absence / self.assert_presence
```

Примеры методов:

```python
def click_select_in_context_menu(self):
    select_btn_name = i18n.get_str('<ключ>', self.lang)
    log.step(f'Нажать кнопку "{select_btn_name}" в контекстном меню', where='IVA ONE WEB Клиент')
    self.get_object(self.L_I18N_CONTEXT_MENU_SELECT_BTN(self.lang)).click()
    self.wait_absence(self.L_CHAT_MESSAGE_CONTEXT_MENU())

def assert_select_mode_toolbar_visible(self):
    self.assert_presence(self.L_SELECT_MODE_TOOLBAR(),
                         'Тулбар режима выбора сообщений отображается')
```

### Каркас enum-класса (`tools/enums.py`)

Параметр метода с ограниченным набором значений типизируется enum'ом (`def click_message_action(self, action: MessageAction):`, в локатор передаётся `action.value`):

```python
from enum import Enum


class <ClassName>(Enum):
    <VALUE1> = '<value1>'
    <VALUE2> = '<value2>'
```

### Скелет нового chunk-файла (`tests/pages/chunks/<name>.py`)

```python
from typing import TYPE_CHECKING

from autocore.base.web.base_page import PBase
from tests.pages.locators.Version2.chunks import <name> as Version2Locators
from autocore.test.logger import get_log

if TYPE_CHECKING:
    from tests.pages.locators.Version2.chunks.<name> import (
        L<Name> as _LocatorsTypingBase,
    )
else:
    class _LocatorsTypingBase:
        pass

log = get_log()


class _C<Name>(PBase, _LocatorsTypingBase):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_ROOT()
        self.page_path = ''
        kwargs['open_page'] = False
        super().__init__(*args, **kwargs)

    def <method>(self):
        log.step('...', where='IVA ONE WEB Клиент')
        self.get_object(self.L_<LOCATOR>()).click()


class CVersion2<Name>(_C<Name>, Version2Locators.L<Name>):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.version = 'Version2'
```

### Скелет нового page-файла (`tests/pages/<name>.py`)

```python
from typing import TYPE_CHECKING

from .locators import Version2 as Version2Locators
from autocore.base.web.base_page import PBase
from autocore.test.logger import get_log

if TYPE_CHECKING:
    from .locators.Version2.<name> import L<Name> as _LocatorsTypingBase
else:
    class _LocatorsTypingBase:
        pass

log = get_log()


class _PVersion<Name>(PBase, _LocatorsTypingBase):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_ROOT()
        self.page_path = ''
        super().__init__(*args, **kwargs)


class PVersion2<Name>(_PVersion<Name>, Version2Locators.L<Name>):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.version = 'Version2'
```

### Совместимость с runtime (typing-fallback и порядок наследования — детали и анти-паттерны)

- В `if TYPE_CHECKING` импортируй локатор-класс как `_LocatorsTypingBase`, в `else` оставляй пустой fallback-класс.
- Не меняй порядок наследования у версионного класса: сначала базовый `_PVersion...`/`_C...`, затем `Version2Locators.L...`.
- Не заменяй runtime-mixin на typing-base: реальный источник локаторов в runtime — `Version2Locators.L...`.

### Регистрация в реестрах get_chunk / get_page

После создания chunk-файла — зарегистрировать в `tests/pages/chunks/__init__.py`:

```python
from .<name> import CVersion2<Name>
# в функции get_chunk():
if chunk_name == '<name>':
    return CVersion2<Name>
```

Аналогично для нового page-файла — зарегистрировать в `tests/pages/__init__.py` (функция `get_page()`). Незарегистрированный класс недоступен тестам.

### Каркас REST-обёртки (функция библиотеки product-api)

Код в библиотеку-зависимость code-writer не пишет — только выводит заготовку функции для отдельного проекта библиотеки (референс: `autocore/clients/rest/iva_one.py`):

```python
def <function_name>(<params>):
    """Описание"""
    log.info(f'...')
    base_url = conf[env]['web_url']
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    url = f'{base_url}/api/v1/<endpoint>'
    response = requests.<method>(url=url, headers=headers, json=data, verify=False)
    response.raise_for_status()
    return response.json()
```
