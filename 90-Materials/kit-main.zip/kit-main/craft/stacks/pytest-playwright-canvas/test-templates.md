# Шаблоны тестовой функции (стек pytest-playwright-canvas)

Референс-реализация стека `pytest-playwright-canvas` модуля craft (kit). Прародитель — one-web,
kmp-линия (пилот 2026-07). Содержимое: скелеты тестовой функции (single-/multi-session), правила
тела теста и код-каркасы для субагента `craft:code-writer` (i18n, методы page-классов, enum,
page-модуль, flow, REST-обёртка).

Живые образцы — референс one-web: `tests/test_chat.py` (все паттерны ниже — оттуда),
`tests/test_login.py`. Конвенции — `rules/tests.md` этого стека (приоритетнее шаблонов при
расхождении). Имена в примерах — живой код референса: `autocore` — vendored-библиотека
REST-обёрток (параметр `vendored_dep` секции `[craft]`), `iva_one` — её REST-клиент продукта.

## Стандартный набор импортов

В начале `tests/test_<feature>.py` (добавлять только недостающие):

```python
import allure
import pytest

from autocore.clients.rest import iva_one
from autocore.test.generate_data import get_random_string
from autocore.test.logger import get_log
from tests.flows.chat import open_chat            # флоу-преамбулы целевой поверхности
from tests.flows.login import web_login
from tools.helpers.chat_setup import wait_group_chat_materialized   # гейты REST-сида
from tools.helpers.session import iva_one_web_login, web_preamble

log = get_log()
```

## Шаблон single-session теста (1 браузер)

```python
@allure.id("<allure_id>")
@allure.title("<name из TestOps>")
@allure.tag("<tag1>", "<tag2>")
@allure.story("<Story>")
@allure.feature("<Feature>")
@allure.label("owner", "<Owner>")
@allure.label("IVAQA", "<jira-ключи>")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_<entity>_<action>_<result>(setup_aut, users_factory, teardown):
    # 1. Блок переменных
    lang, page = web_preamble(setup_aut)
    users_data = users_factory
    chat_name = get_random_string(10)
    message = get_random_string(10)

    # 2. REST-сид + гейты материализации
    token = iva_one_web_login(setup_aut, users_data[0])
    chat_id = iva_one.create_chat(token, chat_name, [u['username'] for u in users_data])
    wait_group_chat_materialized(token, chat_id, min_members=2)

    # 3. TC-логирование
    log.tc('<allure_id>')

    # 4. UI-шаги: флоу-преамбула → методы page-объектов
    chat = open_chat(setup_aut, users_data[0], lang, page, chat_name)
    chat.type_message(message)
    chat.send()
    chat.assert_message_in_feed(message)
```

`IVAQA` — имя issue-label интеграции TMS↔трекер в референсе one-web; в проекте — свой label
(нормализация значений — `rules/tests.md`).

## Вторая сессия того же теста (второй пользователь параллельно)

```python
    page_2 = setup_aut['page_starter']()          # свежий context (чистая SSO-сессия)
    chat_2 = open_chat(setup_aut, users_data[1], lang, page_2, chat_name)
    chat_2.assert_message_in_feed(message)
```

Смена пользователя в ТОЙ ЖЕ роли (relogin) — `relogin_session(setup_aut)` из
`tools/helpers/session.py` (закрывает текущий context, возвращает новую page).

Несколько сессий с самого старта — `setup_multiple_auts` + маркер
`@pytest.mark.multiple_browsers`:

```python
def test_...(setup_multiple_auts, users_factory, teardown):
    auts = setup_multiple_auts(2)
    lang = auts['setup']['cmd']['lang']
    page, page_2 = auts['page']
    ...
```

## Правила тела теста

1. **Порядок блоков (строгий):** переменные → REST-сид с гейтами → `log.tc('<allure_id>')`
   (ровно одна строка) → UI-шаги. Закрытие браузерных сессий НЕ регистрировать — им владеет
   фикстура; `teardown` — только для REST-очистки персистентных данных.
2. **Именование:** `test_<entity>_<action>_<result>` в snake_case, без кириллицы
   (из поля `name` TestOps — перевод/транслитерация).
3. **Маркеры:** всегда оба suite-маркера; браузерных маркеров в этом стеке нет.
4. **`users_factory [N]`:** N = число пользователей сценария (участник чата = пользователь);
   1 пользователь → без параметризации (дефолт 1).
5. **Сигнатуры из analysis.md использовать буквально** — `craft:codebase-analyst` записал точные
   сигнатуры методов page-классов с поведенческими примечаниями; не угадывай и не дублируй
   проверки, которые метод уже делает.
6. **Список чатов vs открытый чат** (референс one-web) — разные поверхности: операции над списком
   (открыть, найти, фильтр) — `PChatsList`; действия в открытом чате (ввод, лента, шапка,
   карточка) — `PChat`. Преамбула «логин + открыть чат» — флоу `open_chat(...)`, возвращает
   готовый `PChat`.
7. **xfail при продуктовом баге:** `@pytest.mark.xfail(reason='<путь к jira-candidate>',
   raises=AssertionError)` — см. `rules/tests.md`; тест кодирует ТК, не фактическое поведение.

---

## Каркасы code-writer (референс-реализация)

Субагент `craft:code-writer` ссылается на этот раздел за конкретными каркасами. Код — дословно
из one-web (референс-реализация). Порядок шагов и запреты — в каноне агента.

### Формат записи i18n (`tools/i18n/strings.py`)

```python
'<ключ>': {
    consts.LANG_RU: 'Текст кнопки',
    consts.LANG_EN: 'Button text',
},
```

EN — из locators.md, колонка «Английский текст» (`craft:dom-explorer` берёт её из
`values-en/strings.xml` клона продукта — параметр `product_clone` секции `[craft]`);
колонки нет или `TODO` → `'TODO'`, RU-текст не дублировать.

### Метод-действие page-класса

```python
@step('Нажать кнопку «Закрепить» в меню сообщения')
def pin_via_menu(self):
    self.compose_click(self.page.get_by_role('button', name=i18n.get_str('message_menu_pin', self.lang), exact=True))
```

С подтверждением известным endpoint'ом:

```python
@step('Отправить сообщение')
def send(self):
    # test_id_send_button — тег на ТИП кнопки (есть и в recorder-меню), скоуп внутри поля ввода
    send_button = self.page.locator(f'#{tags.CHAT_BOTTOM_FIELD_MESSAGE_INPUT} #{tags.SEND_BUTTON}')
    with self.expect_api('/api/v1/messages', 'POST'):
        self.compose_click(send_button)
```

### Метод-проверка (ассерт из ТК)

```python
@step('Сообщение "{text}" отображается в ленте', where=StepPlace.ASSERT)
def assert_message_in_feed(self, text: str):
    message = self.page.locator(f'#{tags.CHAT_FEED_MESSAGE_ITEM}').filter(has_text=text)
    expect(message).to_have_count(1)
```

### Тихий гейт готовности / фабрика локатора (без @step)

```python
def wait_opened(self, timeout: int = 15_000):
    self.page.locator(f'#{tags.CHAT_SCREEN}').wait_for(state='attached', timeout=timeout)

def message(self, text: str) -> Locator:
    target = self.page.locator(f'#{tags.CHAT_FEED_MESSAGE_ITEM}').filter(has_text=text)
    return self.scroll_until_present(target, self.page.locator(f'#{tags.CHAT_FEED_LAZY_COLUMN}'))
```

### Каркас enum-класса (`tools/enums.py`)

Параметр с ограниченным набором значений типизируется enum'ом, по стилю существующих в файле:

```python
class <ClassName>(StrEnum):
    <MEMBER> = '<значение>'
```

### Скелет нового page-модуля (`tests/pages/<name>.py`)

```python
"""<Поверхность>: что это и как ведёт себя.

Квирки поверхности из разведки dom-explorer (locators.md «Наблюдения»): попап-слои,
canvas-only состояние, лаги материализации — документируются здесь.
"""
from playwright.sync_api import Locator, expect

from tests.pages.base_page import PBase
from tools import i18n
from tools import test_tags as tags
from tools.enums import StepPlace
from tools.helpers.steps import step


class P<Name>(PBase):
    def wait_opened(self, timeout: int = 15_000):
        self.page.locator(f'#{tags.<ROOT_TAG>}').wait_for(state='attached', timeout=timeout)

    @step('<Действие>')
    def <action>(self):
        self.compose_click(...)
```

Реестров нет — тесты импортируют класс напрямую (`from tests.pages.<name> import P<Name>`).

### Скелет флоу-преамбулы (`tests/flows/<domain>.py`)

```python
def open_<surface>(setup_aut, user, lang, page, <params>) -> P<Name>:
    """Логин + навигация до <поверхности>: общая преамбула её тестов."""
    web_login(setup_aut, user, lang, page)
    ...
    surface = P<Name>(page, lang=lang)
    surface.wait_opened()
    return surface
```

### Каркас REST-обёртки (функция vendored-библиотеки)

Код в vendored-библиотеку (параметр `vendored_dep` секции `[craft]`) code-writer не пишет —
только выводит заготовку функции для отдельного проекта библиотеки (референс one-web:
`autocore/clients/rest/iva_one.py`; тонкая обёртка ≈ 1 эндпоинт, поллинг/композиция —
в `tools/helpers/` тест-слоя проекта):

```python
def <function_name>(<params>):
    """Описание"""
    log.info(f'...')
    base_url = conf[env]['web_url']
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    url = f'{base_url}/api/v1/<endpoint>'
    response = requests.<method>(url=url, headers=headers, json=data, verify=False)
    response.raise_for_status()
    return response.json()
```
