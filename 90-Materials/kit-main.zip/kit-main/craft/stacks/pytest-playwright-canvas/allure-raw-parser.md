# Парсинг директории `allure-raw/` (стек pytest-playwright-canvas)

Референс-реализация стека `pytest-playwright-canvas` модуля craft (kit). Прародитель — one-web,
kmp-линия (пилот 2026-07). Содержимое: как из raw-результатов Allure после прогона pytest
извлечь упавшие тесты, эпицентр, evidence и сигналы для таксономии. `<python-проекта>` —
интерпретатор окружения проекта (параметр `python` секции `[project]` базы kit; референс:
`./venv/bin/python`). `$CRAFT` — каталог модуля craft в кэше плагинов (в Claude Code —
`${CLAUDE_PLUGIN_ROOT}`).

После прогона pytest в `./allure-raw/` лежат JSON-файлы Allure.

## Структура директории

```
allure-raw/
├── <uuid>-result.json              ← один файл на тест
├── <uuid>-container.json           ← фикстуры (before/after)
├── <uuid>-attachment.png           ← скриншоты (прикладывается conftest при падении)
├── <uuid>-attachment.txt           ← логи
├── <uuid>-attachment.zip           ← Playwright trace (retain-on-failure)
├── <uuid>-attachment.webm          ← video прогона (retain-on-failure)
└── ...
```

## Формат `*-result.json` (минимально нужные поля)

```json
{
  "uuid": "...",
  "name": "test_channel_edit_avatar_visible",
  "fullName": "tests/test_chat.py#test_channel_edit_avatar_visible",
  "status": "failed",
  "statusDetails": {
    "message": "Locator.wait_for: Timeout 15000ms exceeded.\nCall log:\n  - waiting for locator(\"#test_id_chat_screen\") to be attached",
    "trace": "Traceback (most recent call last):\n  File \"tests/test_chat.py\", line 1252, ..."
  },
  "steps": [
    {
      "name": "Открыть чат",
      "status": "passed",
      "start": 1715750400000,
      "stop": 1715750402000
    },
    {
      "name": "Загрузить аватар",
      "status": "failed",
      "statusDetails": {"message": "...", "trace": "..."},
      "attachments": [
        {"name": "screenshot", "source": "<uuid>-attachment.png", "type": "image/png"}
      ]
    }
  ],
  "attachments": [
    {"name": "log", "source": "<uuid>-attachment.txt", "type": "text/plain"}
  ],
  "labels": [
    {"name": "feature", "value": "Чаты"},
    {"name": "AS_ID", "value": "925"}
  ]
}
```

## Что извлекать

1. **Найти упавший тест**: `Glob` по `<allure-raw>/*-result.json`, читать каждый, фильтр по
   `status in ('failed', 'broken')`.

   - `failed` — `AssertionError` (наш assert / `expect` не сошёлся).
   - `broken` — любое другое исключение, всплывшее из теста: `TimeoutError` Playwright,
     strict mode violation, `KeyError`, `requests.HTTPError`, и т.п. **Это тоже падение**,
     его обязательно нужно обработать. Ошибка «отфильтровал только `failed` и пропустил
     `broken`-тесты» уже случалась — не повторяй.
   - `passed` / `skipped` — пропускаем.
   - Распределение по таксономии (`failure-taxonomy.md`) определяется по тексту exception,
     **а не** по полю `status`: например, `broken` с `TimeoutError` → чаще всего `DOM_CHANGED`
     или `FLAKY_TIMING`; `failed` с `AssertionError` → может быть `PRODUCT_BUG` /
     `UX_FLOW_CHANGED` / `WEBDRIVER_QUIRK`.

2. Из найденного файла:
   - `test_name` — из `name`
   - `test_path` — из `fullName`, до `#`
   - `allure_id` — из массива `labels`, `name == "AS_ID"` (или `name == "AllureId"`)
   - `exception_class` + `exception_message` — из `statusDetails.message` (первая строка обычно
     `<Class>: <message>`; у Playwright-ошибок дальше идёт Call log с селектором — сохранить)
   - полный traceback — из `statusDetails.trace`
   - **последний пройденный шаг** — из `steps`, последний со `status == "passed"` перед первым
     `failed`. Это важно: указывает, где скрипт сценария «дошёл» — а где сломалось.
   - **упавший шаг** — первый `step` со `status == "failed"`. Имя шага помогает понять смысл
     локатора в Phase 4.
   - **скриншот падения** — из `attachments` упавшего шага (или из top-level `attachments`,
     `name == "<test_name>[N]"`). Сохранить путь для `fix-report.md`.
   - **trace/video** — top-level `attachments` типов `.zip`/`.webm` (референс one-web: trace
     дублируется на диске в `tests/logs/pw-evidence/`); trace открывать
     `playwright show-trace <файл>` — покадровая история canvas там, где скриншота мало.
   - **лог-attachment** — из top-level `attachments`, `name == "log"` (обычно
     `<uuid>-attachment.txt`). **Обязательно извлечь и просканировать** — см. секцию
     «Сканирование log-attachment» ниже.

3. **Сканирование log-attachment** — отдельный шаг, выполнять **до** перехода в фазу
   локализации. Логи часто содержат `log.info(...)` строки с фактическими значениями переменных,
   которые мгновенно превращают гипотезу в диагноз.

### Что искать в логе

| Pattern (case-insensitive) | Зачем |
|---|---|
| `Текущий url`, `current_url`, `url =`, `redirected to` | Куда реально открылась/перешла страница (SSO-редиректы, `goto` после попапов) |
| `Response`, `Status code`, `HTTP/`, `requests.get/post`, вызовы REST-обёртки (референс: `iva_one\.`) | Что вернул бэкенд — body, статус, ID созданной сущности |
| `Got value`, `Expected`, `Actual`, `assert`, `AssertionError` | Конкретные значения, на которых сломался assert |
| STEP-строки (файловый STEP-лог пишет `@step`-декоратор) | Что именно успели сделать перед падением |
| `WARN`, `WARNING`, `Traceback` (после `first_failed_step`) | Часто скрывает teardown-ошибки, маскирующие корневое падение |
| `wait_for`, `TIMEOUT`, `expect` | Какие узлы overlay ждались и сколько; помогает увидеть стейл-слепок overlay / виртуализированную ленту |
| Step-name keywords из `first_failed_step` | Прямые упоминания падшей сущности (имя файла, текст сообщения, имя чата) |

### Технически как читать

```python
# в Python-скрипте, который запускает skill для парсинга
import json, re, glob
data = json.load(open(result_json, encoding='utf-8'))
log_atts = [a for a in data.get('attachments', []) if a.get('name') == 'log']
if log_atts:
    log_path = f'{allure_raw_dir}/{log_atts[0]["source"]}'
    # Файл может быть большим (десятки МБ) — сканировать по паттернам с контекстом,
    # не читать целиком.
```

Для grep'а в Bash (POSIX-вариант; кроссплатформенно — тем же python-скриптом):
```bash
grep -n -B 2 -A 2 -i 'Текущий url\|current_url\|Response\|WARN\|TIMEOUT' allure-raw/<uuid>-attachment.txt
```

### Что записывать в `fix-{test_name}-failure.md`

В дополнение к exception/trace/screenshot — добавить секцию:

```markdown
## Лог (выдержка)
- путь: ./allure-raw/<uuid>-attachment.txt
- ключевые строки (то, что прямо указывает на симптом):
  - `[INFO] chat.py:403 Текущий url: "about:blank"`
  - `[WARN] base_page.py:81 Element has not gone for 5 seconds`
  - ... (3-7 строк, не весь лог)
```

Если в логе нет ничего полезного — явно записать `## Лог: нет дополнительных сигналов`.
Это сигнал для последующих фаз, что искать улики дальше нужно через `craft:dom-explorer`.

## Несколько failed-тестов в одной директории

Если в `allure-raw/` несколько `failed`/`broken`-результатов — это batch-вход. См. канон
`craft:fix` (`$CRAFT/skills/fix/references/batch-discovery.md`) → секция «Если в allure-raw
больше одного failed-теста». Skill спросит пользователя («все по очереди» дефолт) и итерируется
по выбранному списку.

## Чтение через Bash

Поскольку файлы — JSON, удобнее всего читать через `python -c`:

```bash
<python-проекта> -c "import json,sys; d=json.load(open(sys.argv[1],encoding='utf-8')); print(d.get('name'), d.get('status'))" allure-raw/<uuid>-result.json
```

Чтобы сразу получить **полный список упавших** (`failed` + `broken`):

```bash
<python-проекта> -c "
import json, glob
for f in glob.glob('allure-raw/*-result.json'):
    d = json.load(open(f, encoding='utf-8'))
    s = d.get('status')
    if s in ('failed', 'broken'):
        print(s, '|', d.get('name'), '|', (d.get('statusDetails') or {}).get('message','')[:120])
"
```

Или через `Read` tool, если файл небольшой (обычно <100 КБ).

## Если директория пустая или нет упавших результатов

Сообщить пользователю: «В `<path>` не найдено упавших тестов (нет файлов со
`status in ('failed', 'broken')`). Все результаты — passed/skipped. Возможно, директория от
другого прогона. Уточните путь.»
