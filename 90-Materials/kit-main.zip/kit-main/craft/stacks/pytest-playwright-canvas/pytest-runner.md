# Запуск pytest (стек pytest-playwright-canvas)

Референс-реализация стека `pytest-playwright-canvas` модуля craft (kit). Прародитель — one-web,
kmp-линия (пилот 2026-07). Содержимое: команда и чтение вывода pytest для воспроизведения
(Phase 1 скилла `craft:fix`, ветка `pytest-run`) и **всегда** для верификации (Phase 5) — в
стеке с единственным браузером headless chromium Playwright.

`<python-проекта>` — интерпретатор окружения проекта (параметр `python` секции `[project]`
answers-файла базы kit; референс one-web: `./venv/bin/python` — работает без активации venv).

## Команда

```bash
<python-проекта> -m pytest -k <test_name>
```

Больше для одиночного прогона ничего не нужно:

| Что | Почему |
|---|---|
| `-k <test_name>` | Запускает только нужный тест (весь suite не нужен) |
| `--env` не ставим | Дефолтный стенд инжектится conftest'ом (референс one-web: `kmp-stage`; канонически — параметр `default_env` секции `[craft]`). Явный `--env <имя>` перекрывает — только когда прогон осознанно уводится на другой стенд |
| `--tb=native --showlocals --alluredir` не ставим | Уже в `addopts` `pytest.ini`: полный python-traceback, локальные переменные кадра, raw-результаты в `./allure-raw/` |
| `--lang` | Язык UI (дефолт RU); нужен только для воспроизведения языко-специфичного падения |

## Браузер один — выбора нет

Единственный браузер стека — **headless chromium** Playwright. Браузерных маркеров
(`-m browser_*`), тегов версий браузера, grid- и local-режимов в этом стеке не существует;
«выбор браузера для верификации» как шаг умер — верификация всегда там же, где падение.

- Посмотреть прогон глазами — `--headed` (окно браузера). Это режим отладки/ручной сверки
  (предусловие PRODUCT_BUG-классификации), не отдельная платформа верификации.

## Предусловие прогона — живой стенд

Референс one-web: браузер грузит UI с локального dev-server (`browser_url` в `config.yaml`),
REST идёт на `web_url`. Мёртвый dev-server кладёт ВСЕ тесты одинаково
(`net::ERR_CONNECTION_REFUSED`) — при подозрении проверить `curl -sk <browser_url>/` до
прогона; мёртв → протокол STAND_INCIDENT (`fix-playbooks.md`), кода не касаться.

## Параллель (xdist)

`pytest-xdist` готов: `-n N` (per-worker логи; тесты с общим ресурсом — `xdist_group`; маркер
`parallel_unsafe` — последовательный хвост). По умолчанию прогоны последовательные;
**верификация одиночного фикса — всегда без xdist** (параллель добавляет шум в evidence).

## Таймаут

Передавать `timeout=300000` (5 минут) в параметрах Bash-вызова. Если тест не уложился — это ещё
один сигнал (вероятно `FLAKY_TIMING` или `DOM_CHANGED`).

## Как читать вывод

После завершения:

1. **Exit code** Bash-вызова:
   - `0` — тест прошёл (Phase 1 — падения нет; Phase 5 — фикс сработал)
   - не `0` — тест упал

2. **stdout/stderr** — pytest пишет туда:
   - имя теста и `PASSED`/`FAILED`
   - блок `FAILED tests/...::test_xxx - <ExceptionClass>: <message>`
   - полный stack trace (благодаря `--tb=native` из pytest.ini)

3. **allure-raw/** — после прогона там появятся свежие `*-result.json`. Парсить по
   `allure-raw-parser.md` этого стека.

## Evidence падения

Референс one-web: при падении conftest прикладывает к Allure-результату скриншот, trace и video
(retain-on-failure); trace остаётся и на диске (`tests/logs/pw-evidence/`) — смотреть
`playwright show-trace <файл>`. Это основной канал «увидеть, что было на canvas» без повторного
прогона.

## Извлечение данных для fix-{test_name}-failure.md

Из stdout pytest вытащить:
- `exception_class` — из строки `FAILED tests/...::test_xxx - <ExceptionClass>: <message>`
- `exception_message` — оттуда же, после двоеточия
- полный traceback — между строкой `FAILED ...` и следующим разделителем (`====` или конец)
- `test_path`, `test_name` — из строки `FAILED tests/test_chat.py::test_channel_edit_avatar_visible`

Дополнительно прочитать `allure-raw/*-result.json` для этого теста (поиск по
`name == test_name`) — оттуда:
- ID шага, на котором упал тест (`steps[].status == "failed"`)
- attachments (скриншот, trace, video)

## Что НЕ запускать

- ❌ Полный прогон `pytest` без `-k` — многочасовая операция, не нужна.
- ❌ `--collect-only` — только для проверки синтаксиса, не для верификации фикса.
- ❌ Верификацию фикса под `-n N` — xdist для кампаний/suite-прогонов, не для одиночного репро.

## Если pytest не находится

Команда использует интерпретатор окружения проекта напрямую — активация venv не нужна. pytest
всё равно не найден → у пользователя не установлены зависимости: сообщить команду установки из
README проекта (референс one-web: `pip install` с internal PyPI + `-r requirements.txt`) и
**не пытаться** ставить пакеты от его имени.
