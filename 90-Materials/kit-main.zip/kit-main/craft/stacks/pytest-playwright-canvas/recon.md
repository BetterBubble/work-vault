# Вождение разведки живого UI (стек pytest-playwright-canvas)

Референс-реализация стека `pytest-playwright-canvas` модуля craft (kit). Прародитель — one-web,
kmp-линия (пилот 2026-07). Содержимое: стековое вождение разведки для субагента
`craft:dom-explorer` — модель поверхности canvas/overlay, шаблон python-разведскрипта
Playwright, стратегия адресации и работа с клоном исходников продукта. Роль субагента, режимы
работы, формат артефактов и протокол логина (research-юзеры) — канон агента
(`agents/dom-explorer.md` модуля), здесь их нет.

## Модель поверхности — обязательный контекст

AUT — canvas-клиент (Compose Multiplatform): UI рисуется в один `<canvas>` (Skiko),
автоматизации доступен только **accessibility-overlay** — DOM-узлы внутри open Shadow Root
(корень — `#cmp_a11y_root`), зеркалящие семантику. Полная модель, примитивы вождения и границы
честности overlay — докстринг базового page-класса проекта (референс one-web:
`tests/pages/base_page.py`); прочитай перед первой разведкой. Краткая памятка:

- Локация: CSS-id `#test_id_*` и `get_by_role`/`get_by_text` пробивают open shadow.
  **XPath мёртв.**
- Вождение: только координатное (`mouse.click` по центру bbox); `locator.click()`/`fill()`
  перехватывает canvas. Ввод — `keyboard.type` после координатного фокуса.
- SSO-логин (Keycloak) и filechooser — обычный DOM, штатные методы работают.
- **Попап-слои** (меню, bottom-sheet, тултипы) адресуемы, пока открыты; после закрытия overlay —
  стейл-слепок до `goto`. **Hover с задержкой на элементе с тултипом ломает overlay** — увод
  курсора сразу после клика. **Межфичевая навигация** (Чаты → Календарь) морозит overlay
  безвозвратно (референс one-web: не-чат поверхности разведке недоступны до фикса продукта).
- Виртуализированные ленты держат в DOM окно ~12 элементов: off-screen узлов нет, домотка —
  wheel-скролл с move в контейнер.

## Доступ к приложению

Конфиг стенда — секция дефолтного env в `config.yaml` проекта (параметр `default_env` секции
`[craft]`; референс one-web: `kmp-stage`): браузер грузит UI с `browser_url` (локальный
dev-server, поле опционально, фолбэк `web_url`), REST — `web_url`. Dev-server должен быть жив
(`curl -sk -o /dev/null -w "%{http_code}" <browser_url>/` → 200); мёртв → выйди с сообщением
«dev-server не поднят» (пересборка/запуск — работа основного агента, не твоя). Креды разведки
(логин/пароль юзера) выдаёт канон агента — фабрика research-юзеров либо общий юзер проекта.

## Инструмент разведки — python-скрипт Playwright (основной)

Вождение canvas требует координатных кликов и перехвата сети — это доступно только скриптом
(`playwright` установлен в окружении проекта). Скрипты и артефакты клади в рабочий каталог
задачи, запуск из корня репо:

```bash
PYTHONPATH=. <python-проекта> <каталог>/recon_<тема>.py
```

Шаблон (использует примитивы слоя — не переизобретай вождение):

```python
import yaml
from playwright.sync_api import sync_playwright
from tests.pages.base_page import PBase       # базовый page-класс проекта (референс one-web)

ENV = 'kmp-stage'                             # параметр default_env секции [craft]
cfg = yaml.safe_load(open('config.yaml'))[ENV]
APP_URL = cfg.get('browser_url') or cfg['web_url']
USERNAME, PASSWORD = '<креды разведки — из канона агента>', '<...>'

with sync_playwright() as pw:
    browser = pw.chromium.launch()          # headless работает: Skiko рендерит, клики попадают
    context = browser.new_context(device_scale_factor=2, ignore_https_errors=True,
                                  locale='ru-RU', viewport={'width': 1440, 'height': 900})
    page = context.new_page()
    page.goto(APP_URL)                       # SSO-логин (Keycloak) — обычный DOM
    page.fill('#username', USERNAME)
    page.fill('#password', PASSWORD)
    page.click('#kc-login')
    base = PBase(page)
    base.wait_app_ready()                    # canvas + #cmp_a11y_root

    # ... разведка: снапшот overlay, compose_click по кандидатам, page.screenshot(...)
    browser.close()
```

Приёмы разведки:

- **Снапшот overlay** — дамп доступных узлов с id/ролью/именем/текстом/bbox:
  ```python
  nodes = page.locator('#cmp_a11y_root [role], #cmp_a11y_root [id^="test_id_"]').all()
  for n in nodes[:200]:
      print(n.get_attribute('id'), n.get_attribute('role'),
            n.get_attribute('aria-label'), (n.text_content() or '')[:60], n.bounding_box())
  ```
- **Проверка кандидата** — `page.locator(...)`/`get_by_role(...)`: `.count()` (уникальность,
  strict mode вскрывает per-type коллизии testTag — скоупь контейнером `#контейнер #тег`),
  `.bounding_box()` (реально ли в видимой области), затем `base.compose_click(...)` + наблюдаемое
  следствие (новые узлы overlay / REST-ответ через `page.expect_response` / скриншот).
- **Действие за кликом** — сверяй сетью:
  `with page.expect_response(lambda r: '/api/v1/...' in r.url)`.
- **Скриншот** (`page.screenshot(path=...)`) — canvas рисуется полностью, глазами видно то, чего
  нет в overlay; для canvas-only состояния скриншот = единственный канал наблюдения.
- Один скрипт — одна сессия; состояние между запусками не живёт. Батчи элементы одной
  поверхности в один скрипт-проход, не перезапускай сценарий на каждый элемент.

## Стратегия адресации (правила подбора — `rules/page-objects.md` этого стека)

Приоритет: **(1)** `#test_id_*` из реестра констант testTag проекта (в выводе — именем
константы: `f'#{tags.CHAT_SCREEN}'`; тег на ТИП элемента → проверяй `.count()`, коллизию скоупь
контейнером) → **(2)** `get_by_role(name=..., exact=True)` — имя через i18n-ключ, не хардкод →
**(3)** `.filter(has_text=...)` для динамических строк → **(4)** гео-приёмы
(`click_unnamed_button`/`click_row_toggle`/отбор по bbox) — последний резерв для узлов без
testTag/aria/текста; фиксируй в выводе, почему честнее нельзя.

**Любой видимый текст — только через i18n:** проверь ключ в словаре проекта (референс:
`tools/i18n/strings.py`); нет → строка в таблицу новых i18n-строк (RU из overlay, EN из
`values-en/strings.xml` клона; не нашёлся — `TODO`).

Для каждого найденного локатора фиксируй **вождение**: `compose_click` / `compose_fill` /
штатный DOM-метод (SSO-логин, filechooser) / гео-примитив — и **наблюдаемое следствие** действия
(узел overlay / endpoint / только canvas → ассерт REST'ом, отметь это).

## Клон исходников продукта

Локальный read-only клон AUT — параметр `product_clone` секции `[craft]` (референс one-web:
`/Users/oc4kxb/Projects/iva/kmp`). Что оттуда берётся:

- **Реестр testTag** — `test_tags.xml` ресурсов Compose (референс:
  `core/resources/src/commonMain/composeResources/values/test_tags.xml`); в проекте живёт его
  генерат-реестр констант (референс: `tools/test_tags.py`).
- **Тексты RU/EN** — `values/strings.xml` + `values-en/strings.xml` там же (точные строки для
  i18n-словаря проекта).
- **Жесты/поведение компонента** — Grep по `*.kt` (прецедент one-web: меню сообщения
  открывается левым tap — вычитано из UserMessage.kt).

Checkout может не совпадать со сборкой стенда — финальная верификация только в живом overlay.
Не сканируй клон профилактически — только за конкретным (i18n-ключ, testTag, жест).

## `playwright-cli` — вспомогательный инструмент

Только для DOM-поверхностей (SSO-форма логина) и статичного снапшота: его `click <ref>` на
canvas-узлах мёртв (обычный клик), а браузер — общий синглтон (параллельные задачи конфликтуют
по SSO-cookie). Для overlay-разведки используй python-скрипт.

## Canary-режим снят (решение стека)

Отдельного canary-суипа разведки в этом стеке нет: дрейф сборки ловят сверка реестра testTag
(референс: `tools/generate_test_tags.py --check`) + полный suite-прогон — обе процедуры делает
основной агент, не разведчик.
