#!/usr/bin/env python3
"""render_presets.py — генерат платформенных конфигов пресетов разрешений (модуль dispatch).

Читает КАНОН пресетов `presets.toml` модуля и рендерит платформенные конфиги в репо
проекта под `.kit/presets/`:
  .kit/presets/claude/<preset>.settings.json  — settings-файл CC (permissions.allow/deny/
                                                 defaultMode/additionalDirectories);
                                                 invoke_role.py скармливает его как --settings.
  .kit/presets/codex/<preset>.config.toml      — профиль Codex (sandbox_mode/approval_policy);
                                                 инспектируемый артефакт (можно положить в
                                                 $CODEX_HOME и звать `codex exec --profile`);
                                                 invoke_role.py тот же радиус даёт флагами -s/-c.

Закрывает дыру схемы base: «Платформенные конфиги пресетов — генерат модуля кросс-вызова».
Answers хранит только ИМЯ пресета ([roles.*].permissions); радиусы — канон presets.toml.

Кроссплатформенный: только stdlib (tomllib ≥3.11, pathlib, явный utf-8, атомарная запись
tmp+os.replace, детерминированный вывод без дат — байтовый --check честный).

CLI (из корня репо проекта либо с --root):
  render_presets.py            отрендерить конфиги в .kit/presets/
  render_presets.py --check    ничего не писать: сверить байты с рендером (дрейф → exit 1)

Коды выхода: 0 — ок; 1 — --check нашёл отставание/дрейф; 2 — ошибка (нет канона/answers).
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

try:
    import tomllib
except ModuleNotFoundError:
    tomllib = None


def die(msg: str) -> "None":
    sys.stderr.write(f"render_presets: {msg}\n")
    sys.exit(2)


def find_root(override: str | None) -> Path:
    if override:
        return Path(override).expanduser().resolve()
    env = os.environ.get("CLAUDE_PROJECT_DIR")
    if env:
        return Path(env).expanduser().resolve()
    try:
        out = subprocess.run(["git", "rev-parse", "--show-toplevel"],
                             capture_output=True, text=True, timeout=10).stdout.strip()
        if out:
            return Path(out)
    except Exception:
        pass
    return Path.cwd()


def load_presets() -> dict:
    if tomllib is None:
        die("нужен Python ≥3.11 (tomllib)")
    path = Path(__file__).resolve().parent.parent / "presets.toml"
    if not path.is_file():
        die(f"нет канона пресетов: {path}")
    with open(path, "rb") as f:
        return tomllib.load(f).get("presets", {})


def render_claude(preset: dict) -> str:
    cc = preset.get("claude", {})
    settings = {
        "permissions": {
            "defaultMode": cc.get("permission_mode", "default"),
            "allow": cc.get("allow", []),
            "deny": cc.get("deny", []),
        }
    }
    ad = cc.get("additional_directories")
    if ad:
        settings["permissions"]["additionalDirectories"] = ad
    return json.dumps(settings, ensure_ascii=False, indent=2) + "\n"


def render_codex(name: str, preset: dict) -> str:
    cx = preset.get("codex", {})
    lines = [
        f"# Профиль Codex '{name}' — генерат dispatch/render_presets.py из presets.toml. Руками НЕ править.",
        "# Инспектируемый артефакт: положи в $CODEX_HOME и зови `codex exec --profile "
        f"{name}`, либо тот же радиус invoke_role.py даёт флагами -s/-c.",
        f'sandbox_mode = "{cx.get("sandbox", "read-only")}"',
    ]
    if cx.get("approval"):
        lines.append(f'approval_policy = "{cx["approval"]}"')
    return "\n".join(lines) + "\n"


def targets(root: Path, presets: dict) -> dict[Path, str]:
    out: dict[Path, str] = {}
    for name, preset in sorted(presets.items()):
        out[root / ".kit" / "presets" / "claude" / f"{name}.settings.json"] = render_claude(preset)
        out[root / ".kit" / "presets" / "codex" / f"{name}.config.toml"] = render_codex(name, preset)
    return out


def atomic_write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description="Генерат платформенных конфигов пресетов (dispatch, kit).")
    p.add_argument("--root", help="корень репо проекта (дефолт: CLAUDE_PROJECT_DIR | git toplevel | cwd)")
    p.add_argument("--check", action="store_true", help="сверить байты, ничего не писать")
    args = p.parse_args(argv)

    root = find_root(args.root)
    presets = load_presets()
    if not presets:
        die("канон presets.toml пуст")
    tgt = targets(root, presets)

    if args.check:
        drift = []
        for path, text in tgt.items():
            if not path.is_file() or path.read_text(encoding="utf-8") != text:
                drift.append(path)
        if drift:
            sys.stderr.write("render_presets: отставание/дрейф конфигов пресетов:\n")
            for d in drift:
                sys.stderr.write(f"  {d}\n")
            return 1
        print(f"render_presets: конфиги пресетов свежи ({len(tgt)} файлов)")
        return 0

    for path, text in tgt.items():
        atomic_write(path, text)
    print(f"render_presets: отрендерено {len(tgt)} конфигов в {root / '.kit' / 'presets'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
