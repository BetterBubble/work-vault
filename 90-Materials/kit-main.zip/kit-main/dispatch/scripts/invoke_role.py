#!/usr/bin/env python3
"""invoke_role.py — обёртка-носитель кросс-вызова роли (модуль dispatch каталога kit).

Единственный механизм вызова встречной роли другого провайдера/чистой сессии (решение
015 карты agent-env, вариант C). Руками `claude -p` / `codex exec` не собирает НИКТО —
ни агент, ни человек: собирает и запускает эта обёртка, она же пишет след.

Поток (при любом вызове):
  1. Резолв роли → носитель из `.kit/answers.toml` ([roles.<role>]: carrier/tier/effort/
     permissions; carrier=counter → противоположный провайдеру писателя).
  2. Материализация ЗАЯВКИ (JSON в доме задачи): роль, пин ревизии, носитель, команда,
     путь вердикта. Событие `requested`.
  3. Ось строгости [strictness].auto_counter_review:
       auto   → исполнить синхронно сейчас;
       strict → СТОП: заявка во «Входящих», отмашка человека = повторный запуск
                `--execute <request.json>` (та же заявка). Событие исхода несёт mode.
  4. Исполнение: собрать команду носителя с пресетом разрешений (presets.toml → флаги CLI),
     tier/effort, глубиной=1; события `started`/`finished`; при сбое CC — реактивная
     деградация на Codex + `degraded`; таймаут → `failed`.

События — глобальный `.tasks/events.jsonl` по контракту base v1 (класс «кросс-вызов роли»).

Кроссплатформенный: только stdlib (tomllib ≥3.11, pathlib, subprocess со списком аргументов,
явный utf-8, атомарный O_APPEND). Никаких POSIX-сигналов/локов на критическом пути.

CLI:
  invoke_role.py --role R --task K --target (unstaged|A..B)
                 [--writer-provider codex|claude] [--prompt-file F] [--agent A]
                 [--verdict-path V] [--timeout SEC] [--dry-run] [--root ROOT]
  invoke_role.py --execute <request.json> [--dry-run] [--root ROOT]   # отмашка/ретрай
"""
from __future__ import annotations

import argparse
import datetime
import json
import os
import re
import subprocess
import sys
import uuid
from pathlib import Path

try:
    import tomllib
except ModuleNotFoundError:  # Python < 3.11
    tomllib = None

CONTRACT_VERSION = 1
PROVIDERS = ("codex", "claude")
SUMMARY_MARKER = "DISPATCH_SUMMARY:"
DEFAULT_TIMEOUT = 1800  # 30 мин — ревью с прогонами (015 п.6, конфигурируемо)


# --- утилиты окружения ------------------------------------------------------

def now_iso() -> str:
    return datetime.datetime.now().astimezone().isoformat(timespec="seconds")


def find_root(override: str | None) -> Path:
    if override:
        return Path(override).expanduser().resolve()
    env = os.environ.get("CLAUDE_PROJECT_DIR")
    if env:
        return Path(env).expanduser().resolve()
    try:
        out = subprocess.run(["git", "rev-parse", "--show-toplevel"],
                             capture_output=True, text=True, timeout=10).stdout.strip()
        if out:
            return Path(out)
    except Exception:
        pass
    return Path.cwd()


def die(msg: str, code: int = 2) -> "None":
    sys.stderr.write(f"invoke_role: {msg}\n")
    sys.exit(code)


def load_toml(path: Path) -> dict:
    if tomllib is None:
        die("нужен Python ≥3.11 (tomllib) для чтения TOML; обнови интерпретатор")
    with open(path, "rb") as f:
        return tomllib.load(f)


def load_answers(root: Path) -> dict:
    path = root / ".kit" / "answers.toml"
    if not path.is_file():
        die(f"нет {path} — база kit не установлена в проекте (base:install)")
    return load_toml(path)


def load_presets() -> dict:
    # presets.toml лежит в корне модуля (рядом с scripts/)
    path = Path(__file__).resolve().parent.parent / "presets.toml"
    if not path.is_file():
        die(f"нет канона пресетов: {path}")
    return load_toml(path).get("presets", {})


def detect_writer_provider() -> str:
    """Провайдер ВЫЗЫВАЮЩЕЙ стороны (для резолва carrier=counter). Best-effort по env;
    надёжнее — явный --writer-provider."""
    env = os.environ
    if any(k.startswith("CODEX") for k in env):
        return "codex"
    if env.get("CLAUDECODE") or any(k.startswith("CLAUDE_") for k in env):
        return "claude"
    return "codex"  # база модели — Codex-only (005 п.1)


def resolve_carrier(carrier_val: str, writer_provider: str) -> str:
    if carrier_val == "counter":
        return "claude" if writer_provider == "codex" else "codex"
    if carrier_val not in PROVIDERS:
        die(f"неизвестный carrier '{carrier_val}' (ожидается codex|claude|counter)")
    return carrier_val


def git_head(root: Path) -> str:
    try:
        r = subprocess.run(["git", "-C", str(root), "rev-parse", "HEAD"],
                           capture_output=True, text=True, timeout=10)
        out = r.stdout.strip()
        if r.returncode == 0 and re.fullmatch(r"[0-9a-f]{7,40}", out):
            return out
    except Exception:
        pass
    return ""  # нет коммитов / не git — пин пуст (дрейф не считаем)


# --- события (writer, контракт base v1) -------------------------------------

def events_path(root: Path) -> Path:
    return root / ".tasks" / "events.jsonl"


def append_event(root: Path, rec: dict) -> None:
    """Атомарный append одной JSONL-строки (O_APPEND нейтрален к ОС)."""
    rec = {"v": CONTRACT_VERSION, "ts": now_iso(), **rec}
    path = events_path(root)
    path.parent.mkdir(parents=True, exist_ok=True)
    line = json.dumps(rec, ensure_ascii=False) + "\n"
    fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o644)
    try:
        os.write(fd, line.encode("utf-8"))
    finally:
        os.close(fd)


# --- пресеты → флаги носителя -----------------------------------------------

def preset_for_role(presets: dict, role_cfg: dict) -> tuple[str, dict]:
    name = role_cfg.get("permissions") or "reviewer-readonly"
    spec = presets.get(name)
    if spec is None:
        die(f"пресет '{name}' не найден в presets.toml (роль требует его)")
    return name, spec


def claude_flags(root: Path, preset_name: str, preset: dict) -> list[str]:
    """Флаги CC. Предпочитаем сгенерённый .kit/presets/claude/<preset>.settings.json
    (config-primary); нет файла — инлайн из канона presets.toml."""
    gen = root / ".kit" / "presets" / "claude" / f"{preset_name}.settings.json"
    if gen.is_file():
        return ["--settings", str(gen), "--add-dir", str(root)]
    cc = preset.get("claude", {})
    flags = ["--permission-mode", cc.get("permission_mode", "default"), "--add-dir", str(root)]
    allow = cc.get("allow", [])
    deny = cc.get("deny", [])
    if allow:
        flags += ["--allowedTools", ",".join(allow)]
    if deny:
        flags += ["--disallowedTools", ",".join(deny)]
    return flags


def codex_flags(preset: dict) -> list[str]:
    """Флаги Codex прямо из канона (профиль-файлы Codex требуют $CODEX_HOME — не мутируем
    user-home; радиус даём флагами -s/-c, эквивалент сгенерённого профиля)."""
    cx = preset.get("codex", {})
    flags = ["-s", cx.get("sandbox", "read-only")]
    approval = cx.get("approval")
    if approval:
        flags += ["-c", f"approval_policy={json.dumps(approval)}"]
    return flags


# --- сборка команды и промпта -----------------------------------------------

DEPTH_GUARD = (
    "Ты вызван как делегированная роль '{role}' через обёртку dispatch. ЗАПРЕТЫ: "
    "не заказывай собственных кросс-вызовов ролей (глубина кросс-вызова = 1); "
    "не спавни собственного субагента-ревьюера. Твой ИТОГОВЫЙ вывод (последнее сообщение) "
    "целиком станет вердикт-файлом — обёртка сохранит его сама, тебе файлы писать НЕ нужно. "
    "Последней строкой вывода напечатай машинное резюме ровно в форме: "
    "{marker} {{\"result\":\"clean|findings|blocked\",\"findings\":<int>}}."
)


def compose_prompt(args, verdict_path: Path, root: Path) -> str:
    if args.prompt_file:
        p = Path(args.prompt_file)
        if not p.is_absolute():
            p = root / p
        if not p.is_file():
            die(f"нет prompt-file: {p}")
        return p.read_text(encoding="utf-8")
    return (
        f"Ты вызван в роли '{args.role}'. Цель работы: {args.target}. "
        f"Прочитай определение своей роли и исполни её процедуру. "
        f"Результат запиши в файл {verdict_path} (repo-relative от корня проекта)."
    )


def build_command(provider: str, root: Path, preset_name: str, preset: dict,
                  role_cfg: dict, prompt: str, agent: str | None,
                  role: str) -> list[str]:
    guard = DEPTH_GUARD.format(role=role, marker=SUMMARY_MARKER)
    tier = role_cfg.get("tier") or ""
    effort = role_cfg.get("effort") or ""
    if provider == "claude":
        cmd = ["claude", "-p", prompt, "--output-format", "json",
               "--append-system-prompt", guard]
        cmd += claude_flags(root, preset_name, preset)
        if agent:
            cmd += ["--agent", agent.split(":")[-1]]  # bare-имя агента (неймспейс навешивает платформа)
        if tier:
            cmd += ["--model", tier]
        if effort:
            cmd += ["--effort", effort]
        return cmd
    # codex
    full_prompt = guard + "\n\n" + prompt
    cmd = ["codex", "exec", full_prompt, "-C", str(root)]
    cmd += codex_flags(preset)
    if tier:
        cmd += ["-m", tier]
    return cmd


# --- парсинг результата встречной сессии ------------------------------------

def parse_claude_json(stdout: str) -> tuple[str, str]:
    """(session_id, result_text) из --output-format json CC."""
    try:
        obj = json.loads(stdout)
        return obj.get("session_id", ""), str(obj.get("result", ""))
    except Exception:
        return "", stdout


def parse_summary(text: str) -> dict | None:
    m = re.search(re.escape(SUMMARY_MARKER) + r"\s*(\{.*\})", text)
    if not m:
        return None
    try:
        obj = json.loads(m.group(1))
        result = obj.get("result", "unknown")
        findings = int(obj.get("findings", 0))
        return {"result": result, "findings": findings}
    except Exception:
        return None


# --- заявка -----------------------------------------------------------------

def home(root: Path, task: str) -> Path:
    return root / ".tasks" / "work" / task


def rel(root: Path, path: Path) -> str:
    try:
        return str(path.relative_to(root))
    except ValueError:
        return str(path)


def build_request(root: Path, args, writer_provider: str, provider: str,
                  preset_name: str, role_cfg: dict, verdict_path: Path,
                  mode_axis: str) -> tuple[Path, dict]:
    h = home(root, args.task)
    if not h.is_dir():
        die(f"нет дома задачи {h} — засей мету (base task_meta.py init --key {args.task})")
    req = {
        "v": CONTRACT_VERSION,
        "kind": "dispatch-request",
        "task": args.task,
        "role": args.role,
        "created": now_iso(),
        "writer_provider": writer_provider,
        "carrier": {"provider": provider, "tier": role_cfg.get("tier", ""),
                    "effort": role_cfg.get("effort", ""), "preset": preset_name},
        "target": args.target,
        "pinned_sha": git_head(root),
        "prompt_file": args.prompt_file or None,
        "agent": args.agent or None,
        "verdict_path": rel(root, verdict_path),
        "timeout_sec": args.timeout,
        "mode_axis": mode_axis,
    }
    stamp = now_iso().replace(":", "").replace("-", "")[:15]
    path = h / f"{args.role}-request-{stamp}.json"
    path.write_text(json.dumps(req, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return path, req


# --- исполнение -------------------------------------------------------------

def run_carrier(cmd: list[str], root: Path, timeout: int, depth: int):
    env = dict(os.environ)
    env["KIT_DISPATCH_DEPTH"] = str(depth + 1)
    return subprocess.run(cmd, cwd=str(root), capture_output=True, text=True,
                          timeout=timeout, env=env)


def execute(root: Path, req: dict, request_path: Path, args, depth: int) -> int:
    task = req["task"]
    role = req["role"]
    provider = req["carrier"]["provider"]
    preset_name = req["carrier"]["preset"]
    presets = load_presets()
    preset = presets.get(preset_name, {})
    role_cfg = {"tier": req["carrier"].get("tier", ""),
                "effort": req["carrier"].get("effort", ""),
                "permissions": preset_name}
    verdict_path = root / req["verdict_path"]
    verdict_path.parent.mkdir(parents=True, exist_ok=True)

    # пин ревизии: дрейф HEAD не молча
    cur = git_head(root)
    drift = bool(req.get("pinned_sha") and cur and cur != req["pinned_sha"])

    prompt = compose_prompt(args, verdict_path, root) if not req.get("prompt_file") else \
        (root / req["prompt_file"]).read_text(encoding="utf-8")
    mode = "auto" if req.get("mode_axis") == "auto" else "gated"

    def do_run(prov: str) -> subprocess.CompletedProcess:
        cmd = build_command(prov, root, preset_name, preset, role_cfg, prompt,
                            req.get("agent"), role)
        started = {"task": task, "event": "started", "role": role,
                   "carrier": {"provider": prov, "tier": role_cfg.get("tier", ""),
                               "effort": role_cfg.get("effort", "")},
                   "mode": mode, "request": rel(root, request_path)}
        if drift:
            started["revision_drift"] = {"pinned": req.get("pinned_sha"), "current": cur}
        append_event(root, started)
        return run_carrier(cmd, root, req.get("timeout_sec", DEFAULT_TIMEOUT), depth)

    # первый запуск на резолвнутом носителе
    try:
        proc = do_run(provider)
    except subprocess.TimeoutExpired:
        append_event(root, {"task": task, "event": "failed", "role": role,
                            "carrier": {"provider": provider, "tier": "", "effort": ""},
                            "request": rel(root, request_path),
                            "reason": f"timeout {req.get('timeout_sec')}s (заявка остаётся для ретрая)"})
        die(f"таймаут исполнения роли {role}; заявка {rel(root, request_path)} остаётся", 4)

    prov_final = provider
    # реактивная деградация CC→Codex (015 п.4): CC упал → откат на базовый носитель Codex
    if proc.returncode != 0 and provider == "claude":
        reason = (proc.stderr or proc.stdout or "").strip().splitlines()
        reason = reason[-1] if reason else f"claude exit {proc.returncode}"
        append_event(root, {"task": task, "event": "degraded", "role": role,
                            "carrier": {"provider": "claude", "tier": "", "effort": ""},
                            "request": rel(root, request_path),
                            "reason": f"CC недоступен → откат на Codex: {reason[:200]}"})
        try:
            proc = do_run("codex")
            prov_final = "codex"
        except subprocess.TimeoutExpired:
            append_event(root, {"task": task, "event": "failed", "role": role,
                                "carrier": {"provider": "codex", "tier": "", "effort": ""},
                                "request": rel(root, request_path),
                                "reason": "timeout после деградации на Codex"})
            die("таймаут после деградации на Codex; заявка остаётся", 4)

    if proc.returncode != 0:
        reason = (proc.stderr or proc.stdout or "").strip().splitlines()
        reason = reason[-1] if reason else f"exit {proc.returncode}"
        append_event(root, {"task": task, "event": "failed", "role": role,
                            "carrier": {"provider": prov_final, "tier": "", "effort": ""},
                            "request": rel(root, request_path), "reason": reason[:300]})
        die(f"роль {role} завершилась с ошибкой ({prov_final}): {reason[:300]}", 5)

    # разбор результата
    if prov_final == "claude":
        session, text = parse_claude_json(proc.stdout)
    else:
        session, text = "", proc.stdout
    # обёртка сохраняет вердикт из итогового вывода роли (роль read-only, писать след —
    # дело обёртки: 015 п.2; заодно обходит гейт «чувствительных» dot-путей для read-only ролей)
    if not verdict_path.exists() or verdict_path.stat().st_size == 0:
        verdict_path.write_text(text or "(пустой вывод роли)\n", encoding="utf-8")
    summary = parse_summary(text) or {"result": "unknown", "findings": 0}
    verdict = {"path": rel(root, verdict_path), "result": summary["result"],
               "findings": summary["findings"]}
    finished = {"task": task, "event": "finished", "role": role,
                "carrier": {"provider": prov_final, "tier": role_cfg.get("tier", ""),
                            "effort": role_cfg.get("effort", "")},
                "mode": mode, "request": rel(root, request_path),
                "session": session, "verdict": verdict}
    append_event(root, finished)
    print(f"[dispatch] роль {role} исполнена на {prov_final}; вердикт {verdict['path']} "
          f"(result={verdict['result']}, findings={verdict['findings']}); "
          f"session={session or '(codex)'}")
    return 0


# --- main -------------------------------------------------------------------

def main(argv=None) -> int:
    p = argparse.ArgumentParser(description="Обёртка-носитель кросс-вызова роли (dispatch, kit).")
    p.add_argument("--root", help="корень репо проекта (дефолт: CLAUDE_PROJECT_DIR | git toplevel | cwd)")
    p.add_argument("--execute", metavar="REQUEST.json", help="исполнить существующую заявку (отмашка/ретрай)")
    p.add_argument("--role", help="имя роли из [roles.*] answers")
    p.add_argument("--task", help="ключ задачи (дом .tasks/work/<ключ>/)")
    p.add_argument("--target", help="цель работы: unstaged | A..B (пин ревизии)")
    p.add_argument("--writer-provider", choices=PROVIDERS, help="провайдер вызывающей стороны (для carrier=counter); дефолт — автодетект")
    p.add_argument("--prompt-file", help="файл с инструкциями встречной роли (иначе — генерик-промпт)")
    p.add_argument("--agent", help="имя агента платформы для роли (CC --agent), напр. audit:work-reviewer")
    p.add_argument("--verdict-path", help="путь вердикт-файла (дефолт: дом/<role>-verdict.md)")
    p.add_argument("--timeout", type=int, default=None, help=f"таймаут исполнения, сек (дефолт [dispatch].timeout_sec answers | {DEFAULT_TIMEOUT})")
    p.add_argument("--dry-run", action="store_true", help="собрать заявку+команду, напечатать, не запускать носитель")
    args = p.parse_args(argv)

    root = find_root(args.root)
    depth = int(os.environ.get("KIT_DISPATCH_DEPTH", "0") or "0")
    if depth >= 1:
        # глубина кросс-вызова = 1: встречная роль не заказывает свои кросс-вызовы
        if args.execute or args.task:
            task = args.task or "?"
            try:
                append_event(root, {"task": task, "event": "failed", "role": args.role or "?",
                                    "carrier": {"provider": "?", "tier": "", "effort": ""},
                                    "reason": "depth>1: встречная роль не заказывает кросс-вызовы (015 п.3)"})
            except Exception:
                pass
        die("глубина кросс-вызова = 1: встречная роль не может заказывать свои кросс-вызовы (015 п.3)", 3)

    if args.execute:
        req_path = Path(args.execute)
        if not req_path.is_absolute():
            req_path = root / req_path
        if not req_path.is_file():
            die(f"нет заявки: {req_path}")
        req = json.loads(req_path.read_text(encoding="utf-8"))
        if args.dry_run:
            cmd = build_command(req["carrier"]["provider"], root, req["carrier"]["preset"],
                                load_presets().get(req["carrier"]["preset"], {}),
                                {"tier": req["carrier"].get("tier", ""), "effort": req["carrier"].get("effort", "")},
                                "<prompt>", req.get("agent"), req["role"])
            print("[dry-run] команда исполнения:\n  " + " ".join(cmd))
            return 0
        return execute(root, req, req_path, args, depth)

    # материализация новой заявки
    if not (args.role and args.task and args.target):
        die("нужны --role, --task, --target (или --execute <request.json>)")
    answers = load_answers(root)
    roles = answers.get("roles", {})
    if args.role not in roles:
        die(f"роль '{args.role}' не описана в [roles.*] answers (есть: {', '.join(roles) or '—'})")
    role_cfg = roles[args.role]
    writer = args.writer_provider or detect_writer_provider()
    provider = resolve_carrier(role_cfg.get("carrier", "codex"), writer)
    presets = load_presets()
    preset_name, _ = preset_for_role(presets, role_cfg)
    verdict_path = (Path(args.verdict_path) if args.verdict_path
                    else home(root, args.task) / f"{args.role}-verdict.md")
    if not verdict_path.is_absolute():
        verdict_path = root / verdict_path

    axis = str(answers.get("strictness", {}).get("auto_counter_review", "strict")).lower()
    mode_axis = "auto" if axis == "auto" else "strict"
    if args.timeout is None:
        args.timeout = int(answers.get("dispatch", {}).get("timeout_sec", DEFAULT_TIMEOUT))

    if args.dry_run:
        # истинный dry-run: НИЧЕГО не материализуем — ни заявку, ни событие requested
        # (иначе каждая инспекция оставляет заявку-фантом и requested-сироту для pulse)
        cmd = build_command(provider, root, preset_name, presets.get(preset_name, {}),
                            role_cfg, "<prompt>", args.agent, args.role)
        print(f"[dry-run] была бы создана заявка: {rel(root, home(root, args.task))}/"
              f"{args.role}-request-<stamp>.json + событие requested "
              f"(роль={args.role}, носитель={provider}, пресет={preset_name}, писатель={writer})")
        print("[dry-run] команда исполнения:\n  " + " ".join(cmd))
        return 0

    request_path, req = build_request(root, args, writer, provider, preset_name,
                                      role_cfg, verdict_path, mode_axis)
    append_event(root, {"task": args.task, "event": "requested", "role": args.role,
                        "carrier": {"provider": provider, "tier": role_cfg.get("tier", ""),
                                    "effort": role_cfg.get("effort", "")},
                        "mode": mode_axis, "request": rel(root, request_path)})
    print(f"[dispatch] заявка: {rel(root, request_path)} "
          f"(роль={args.role}, носитель={provider}, пресет={preset_name}, писатель={writer})")

    if mode_axis == "strict":
        print(f"[dispatch] строгий режим (auto_counter_review=strict): СТОП. "
              f"Заявка во «Входящих». Отмашка = invoke_role.py --execute {rel(root, request_path)}")
        return 0

    return execute(root, req, request_path, args, depth)


if __name__ == "__main__":
    sys.exit(main())
