---
name: land
description: >-
  Сводит ворктри-задачу в её агентскую ветку и доставляет проектную часть: squash WIP →
  rebase на базу (конфликты решаются здесь, в контексте задачи) → merge --ff-only → ship:mr
  из диапазона ровно этой задачи. Активируй: «сведи задачу», «заland ворктри», «доставь из ворктри»,
  «приземли wt/<task>». НЕ создаёт ворктри (это worktree_bootstrap.py / git worktree add),
  НЕ диф текущей правки (→ ревью-скиллы платформы).
---

# Сведение ворктри-задачи в агентскую ветку + доставка (модуль ship)

Путь к модулю ниже обозначен `$SHIP`: в Claude Code это `${CLAUDE_PLUGIN_ROOT}`;
на другой платформе — каталог модуля ship в её кэше плагинов.

Skill приземляет работу из ворктри-задачи (`<worktrees_root>/<проект>/<task>`, ветка
`wt/<task>`; корень — параметр `worktrees_root`, имя — `name` секции `[project]`
`.kit/answers.toml`) в её **агентскую ветку** через `rebase → merge --ff-only`, затем
доставляет **проектную** часть через `ship:mr` из диапазона ровно этой задачи. Агент-инфра
остаётся на агентской ветке (её «общее пространство»). Модель «ворктри = задача» —
`$SHIP/references/worktree-model.md`.

## Инвариант

> **`--ff-only` — защёлка «доехало либо отказ, без полу-слияния».** Конфликты решаются
> на этапе **rebase** (Phase 2), в контексте задачи; к моменту `merge --ff-only` ветка
> `wt/<task>` строго впереди базы линейно. После ff критерий «село» проверяется явно
> (`git branch --merged <base>`). Доставка проектной части — отдельная Phase через
> `ship:mr` с **явным `base_commit=pre_ff`** (диапазон ровно этой задачи, без протечки
> соседних). Агент-only задача → MR не создаём.

## Кросс-ворктри механика (важно — читать до запуска)

Ветки `wt/<task>` и `<base>` **checked out в разных ворктри**. Поэтому фазы бегут в разных
каталогах:
- **Phase 1 (squash) + Phase 2 (rebase)** — двигают `wt/<task>` → бегут в **ворктри задачи**
  (там она checked out; обычно это cwd сессии).
- **Phase 3 (ff) + Phase 4 (delivery) + Phase 5 (retire)** — трогают `<base>` и удаляют
  каталог задачи → бегут из **главного репо** (`<main_repo>`); перед ними `cd <main_repo>`
  (нельзя удалить ворктри, стоя в нём).

Детект каталогов в Phase 0; дальше — через `git -C <dir>` либо явный `cd`.

## Прежде всего

Выполняй Phases 0–5 **подряд**. Останавливайся только на:
- ожиданиях ответа от `AskUserQuestion` (группировка squash, имя MR-ветки);
- ошибках git (конфликт rebase, грязное дерево базы, не-FF) — STOP с пояснением, состояние
  в `state.md`, инструкция resume;
- отсутствии ворктри/ветки задачи.

Никаких «можно продолжать?» вне `AskUserQuestion`.

## Phase 0 — Resolve inputs

1. **`task` и `worktree`.** Если cwd — ворктри (`git branch --show-current` = `wt/<task>`) →
   `task` = ветка без префикса `wt/`, `worktree = $(pwd)`. Иначе — пользователь назвал задачу
   явно: найти каталог по ветке:
   ```bash
   worktree=$(git worktree list --porcelain | awk -v b="refs/heads/wt/<task>" '/^worktree /{w=$2} /^branch /{if($2==b)print w}')
   ```
   Нет ни того, ни другого → STOP: «не нашёл ворктри-задачу; запусти из каталога ворктри
   или назови задачу».

2. **`main_repo`** (главный рабочий каталог репо, где живёт `.git`):
   ```bash
   main_repo=$(dirname "$(git rev-parse --path-format=absolute --git-common-dir)")
   ```

3. **`base`** (агентская ветка-цель). Источники по приоритету:
   - **мета дома задачи** `worktree/.tasks/work/<task>/meta.json`, поле `base` (засеяна
     `worktree_bootstrap.py` по контракту меты base@kit) — взять как есть;
   - фолбэк (нет меты/поля) — одна линия: `base` = параметр `agent_branch` секции
     `[project]` (проверить ancestry: `git merge-base --is-ancestor <agent_branch> wt/<task>`).

     При `lines = dual` (и сложнее) — ancestry-проверка по всем агентским веткам проекта
     (карта линий — `.kit/local.md`); предки несколько — предпочесть ту, к чьему tip ближе
     `wt/<task>` (`git rev-list --count <branch>..wt/<task>` минимальный). Неоднозначно →
     `AskUserQuestion`.

4. **`fork_point`**:
   ```bash
   fork_point=$(git merge-base wt/<task> <base>)
   ```
   Линия — по `base` (нужно только для отчёта; реальный детект линии делает `ship:mr`
   по имени source).

5. Записать `state.md` в `<main_repo>/.tasks/_scratch/ship-land/{YYYYMMDD-HHMMSS}/`
   (gitignored; в `main_repo`, чтобы пережить удаление ворктри в Phase 5):
   ```markdown
   task: <task>
   worktree: <worktrees_root>/<проект>/<task>
   main_repo: <абсолютный путь>
   base: <агентская ветка>
   line: main
   fork_point: <sha>
   pre_ff:                          # tip <base> до ff — Phase 3
   squashed: false
   started_at: <ISO-время>
   status: in_progress
   ```

6. **Sanity:** `git fetch origin --prune` (из `main_repo`); рабочее дерево ворктри
   по tracked-файлам чистое (`git -C <worktree> status --porcelain`, untracked игнорим —
   это нормальные артефакты skill'ов); рабочее дерево `<base>` чистое (см. Phase 3 шаг 1).

## Phase 1 — Squash WIP (на `wt/<task>`, до rebase)

Цель: схлопнуть свободные WIP-чекпоинты сессий в осмысленные коммиты **до** rebase.
Бежит в ворктри (`cd <worktree>`).

1. Показать диапазон:
   ```bash
   git -C <worktree> log --oneline <fork_point>..wt/<task>
   ```
2. Если коммитов нет — нечего сводить, перейти к Phase 2. Если ровно один и он осмысленный
   (не «WIP»/«checkpoint»/«wip») — спросить через `AskUserQuestion`, оставить как есть или
   переписать message; по «оставить» — пропустить шаг 4.
3. Иначе через `AskUserQuestion` собрать **группировку** (сколько финальных коммитов и как
   делить диапазон) + **финальные сообщения** (в стиле репо: глагол + что сделано).
4. Схлопнуть **на самой `wt/<task>`** (НЕ в detached):
   ```bash
   cd <worktree>
   git reset --soft <fork_point>
   # затем по группам: git add -A <пути группы> && git commit -m "<сообщение>"
   ```
   Один итоговый коммит = `git commit` всего разом; несколько — поэтапный `git add`
   по путям/`git commit` на группу.
5. Записать `squashed: true` в `state.md`.

> Squash до rebase: переписываем «свою» историю, пока она не наслоилась на базу — конфликты
> Phase 2 относятся к настоящим изменениям, не к промежуточным WIP-состояниям.

## Phase 2 — Rebase на базу (на `wt/<task>`)

```bash
cd <worktree>
git rebase <base> wt/<task>
```

- **Конфликт** (`git status` → `unmerged paths`) — STOP. Сообщи: какие файлы конфликтуют;
  «реши вручную в ворктри → `git rebase --continue`, затем перезапусти `ship:land`
  (resume)». Конфликт решается **здесь**, в контексте задачи (это и есть смысл per-task
  изоляции).
- **pre-commit hook упал** — НЕ `--no-verify`; STOP, попроси разобраться, сохрани state.
- Успех → `wt/<task>` строго впереди `<base>` линейно (ff возможен).

## Phase 3 — Land (merge --ff-only)

Бежит из главного репо / того ворктри, где `<base>` checked out (обычно `main_repo`).

1. Найти каталог с `<base>` и проверить чистоту его дерева:
   ```bash
   base_wt=$(git worktree list --porcelain | awk -v b="refs/heads/<base>" '/^worktree /{w=$2} /^branch /{if($2==b)print w}')
   # base не checked out нигде → возьмём main_repo и переключим его:
   if [ -z "$base_wt" ]; then base_wt=<main_repo>; git -C "$base_wt" checkout <base>; fi
   git -C "$base_wt" status --porcelain   # должно быть пусто (по tracked) — иначе STOP
   ```
2. **Гард от протёкшего handoff (до ff).** Просканировать файлы, которые вот-вот
   заland'ятся, на stray-агент-артефакты в **корне** репо — handoff обязан жить в доме
   задачи `.tasks/work/<task>/` (уезжает в агентскую ветку, deny-list `ship:mr` его
   дропает), а не в корне:
   ```bash
   git -C "$base_wt" diff --name-only <base>..wt/<task> | grep -qx 'PROGRESS.md' && echo LEAK
   ```
   Нашёлся корневой `PROGRESS.md` (или иной handoff-черновик в корне) → **STOP до ff**:
   «в `wt/<task>` закоммичен корневой `PROGRESS.md` — промах размещения handoff'а (должен
   быть в `.tasks/work/<task>/`). Убери из ветки:
   `git -C <worktree> rm PROGRESS.md && git -C <worktree> commit --amend --no-edit` (или
   отдельным коммитом), затем перезапусти land». **Не делать ff**, пока не убран: иначе
   агент-артефакт сядет на базовую ветку и рискует утечь в MR (корневого `PROGRESS.md` нет
   в deny-list `ship:mr` → он будет сочтён проектным).
3. Записать `pre_ff` (tip базы ДО ff — точка отсчёта диапазона задачи для Phase 4):
   ```bash
   pre_ff=$(git -C "$base_wt" rev-parse <base>)   # → записать в state.md
   ```
4. Fast-forward:
   ```bash
   git -C "$base_wt" merge --ff-only wt/<task>
   ```
   - Не-FF (`fatal: Not possible to fast-forward`) — база ушла вперёд после Phase 2 rebase
     (параллельный land). STOP: «база сдвинулась, перезапусти `ship:land` (повторный
     rebase подхватит)».
5. **Критерий «доехало»** (обязательная пост-проверка):
   ```bash
   git -C "$base_wt" branch --merged <base> | grep -qx '  wt/<task>\|* wt/<task>' \
     || git -C "$base_wt" merge-base --is-ancestor wt/<task> <base>
   ```
   Не подтвердилось → STOP, не продолжать к доставке. Подтвердилось → `cd <main_repo>`
   (для Phase 4–5) и дальше.

## Phase 4 — Классификация и доставка проектной части

Бежит из `<main_repo>`. Диапазон задачи на базе = `pre_ff..<base>`.

1. Что село — прогнать имена файлов через deny-list `ship:mr` (канон —
   [`../mr/references/exclusion-patterns.md`](../mr/references/exclusion-patterns.md),
   **не дублировать**):
   ```bash
   git -C <main_repo> diff --name-only <pre_ff>..<base>
   ```
   Файл матчит deny-list → агентный; иначе → проектный.

2. **Есть проектные файлы → доставка через `ship:mr`.** Сначала собрать имя MR-ветки —
   это **внешний идентификатор** (у потребителей обычно ключ AT-задачи в трекере, якорь
   связей CI/TMS/MR): `task` уже выглядит как тикет-ключ → взять его; иначе — **stop-gate**:
   `AskUserQuestion` с запросом точного ключа/имени (слаг задачи — опцией, только если у
   проекта MR-ветка не обязана быть тикет-ключом). Угадывать «свободный» номер из соседних
   задач запрещено (правило — `ship:mr` Phase 0). Затем вызвать skill, передав всё
   в первом сообщении (чтобы он пропустил свои вопросы):
   ```
   Skill(skill="ship:mr",
     args="source=<base>, target=<MR-ветка>, режим=новая от base, base=<base линии>, base_commit=<pre_ff>[, dep_mr_url=<url> если есть]")
   ```
   - `source=<base>` — **source для MR = агентская ветка после ff, НЕ `wt/<task>`.**
     Линию (при `lines = dual`) `ship:mr` задетектит сам по имени source-ветки.
   - `base_commit=<pre_ff>` — короткозамыкает авто-детект базовой точки → MR собирается
     из коммитов ровно этой задачи, без протечки соседних задач, севших на ту же базу.
   - `ship:mr` запушит MR-ветку и создаст MR (его Phase 6.5, после аппрува diff).

3. **Всё агент-only (проектных файлов нет) → MR не создаём.** Отчёт: «село на `<base>`;
   изменения — агент-инфра». При `lines = dual` + «кросс-линия — вручную (правило
   проекта)». Не звать `ship:mr`.

## Phase 5 — Retire + отчёт

Из `<main_repo>` (cwd уже не внутри ворктри).

1. **Снести эфемерные ресурсы задачи** (research-юзеры разведки и т.п., до удаления
   каталога — пока `<worktree>` жив). Команда фабрики — параметр `research_user_cmd`
   секции `[craft]` (пусто / craft не установлен → пропуск шага); референс one-web:
   ```bash
   <research_user_cmd> delete-task --task <task> --env <env>
   ```
   `<env>` — поле `env` меты дома задачи (`.tasks/work/<task>/meta.json`; фолбэк — карта
   `[ship.branches]` по `base` из `state.md`). Реестр = имя на бэкенде (не файл в ворктри);
   ресурсов нет → пустой результат, не ошибка. Сирот от брошенных ворктри (без land)
   подстраховывает reap-механизм разведчика.
2. Удалить **каталог** ворктри сразу после ff (+MR, если был):
   ```bash
   git -C <main_repo> worktree remove <worktrees_root>/<проект>/<task>
   ```
   (`--force`, только если git ругается на untracked-артефакты skill'ов и они не нужны.)

   > ⚠️ Если сессия запущена из этого ворктри (дефолтный сценарий Phase 0) — удаление
   > сносит и её среду: реестр скиллов/субагентов может быть привязан к конфигам удалённого
   > каталога, дальнейшие Skill-вызовы в этой сессии падают «Unknown skill», bash-cwd
   > сброшен. Поведение после retire — секция «Потеря среды после retire» ниже.
3. **Ветка `wt/<task>`:**
   - проектная задача (был MR) → **держать** до merge MR (нужна как source MR-ветки/для
     разбора);
   - агент-only → можно сразу `git -C <main_repo> branch -d wt/<task>`.
4. Статус в `state.md` — **по исходу, MR создан ≠ задача закрыта**:
   - был создан MR → `status: landed_mr_open` — работа продолжается (см. «Post-MR» ниже);
     дом задачи остаётся активным;
   - агент-only (MR нет) → `status: completed` + **закрыть дом задачи** каноническим CLI
     меты (модуль base; он уже сел на базу через ff):
     ```bash
     python3 <путь к task_meta.py модуля base> close --key <task>
     ```
     (статус closed + снос `scratch/` + переезд `work/<task>/` → `work/_archive/`;
     переезд закоммитить на `<base>` — агент-инфра коммит).

   Отчёт пользователю:
   - куда село (`<base>`), критерий merged подтверждён;
   - URL созданного MR (если был) либо «агент-only, MR нет»;
   - судьба ветки `wt/<task>` (удалена / держим до merge);
   - **при MR — обязательной строкой:** «задача **НЕ закрыта** до pipeline + разбора
     ланча + merge; следующий шаг — пайплайн на MR-ветке (checklist „Post-MR“)»;
   - при `lines = dual` для агент-only — напоминание про ручную кросс-линию.

## Post-MR — до закрытия задачи (когда был MR)

DoD задачи живёт **позже** MR: `landed_mr_open` → `completed` только после этого checklist'а
(канон шагов — `$SHIP/shared/delivery-protocol.md`, Шаги 4–6, профиль мутирующего
оркестратора; механика CI-пайплайна и резолва ланча — модуль **track**, не установлен →
сказать пользователю, шаги вручную):

1. **Пайплайн** на MR-ветке с нужными переменными (Шаг 4 протокола; якорь = MR-ветка) →
   дождаться результата.
2. **Резолв и разбор ланча** (Шаги 5–6 протокола): URL пользователю, не-зелёные —
   классифицировать и разобрать (развилка Шага 6).
3. **Merge MR** — решение человека либо по явному запросу (инвариант внешней поверхности —
   схема base, `.kit/schema.md` «Гейты»); дождаться merge.
4. **После merge:** `git pull` интеграционной ветки; удалить `wt/<task>`
   (`git branch -d`); закрыть задачу беклога (если велась по нему); **закрыть дом задачи** —
   `task_meta.py close --key <task>` (снос `scratch/` + переезд в `work/_archive/`,
   коммит на агентской ветке).
5. `status: completed` в `state.md`.

### Потеря среды после retire

Phase 5 удалила каталог, из которого (в дефолтном сценарии) запущена текущая сессия —
её реестр скиллов/субагентов может быть мёртв. Поэтому:
- post-MR шаги, требующие Skill-вызовов (например разбор ланча скиллом craft:fix), —
  **из новой сессии в главном репо** (там реестр живой); передай ей контекст (URL MR/ланча,
  путь `state.md`);
- в текущей сессии — только прямые команды (`bash`, чтение референсов из `<main_repo>`),
  Skill-вызовы не делать.

## Resume

Если в `<main_repo>/.tasks/_scratch/ship-land/` есть `state.md` со
`status: in_progress`/`aborted` для этой задачи — через `AskUserQuestion` предложи
«продолжить (task=X, на фазе Y)» / «начать заново». Resume переиспользует
`task/worktree/base/fork_point/pre_ff` из `state.md`; стартует с фазы, где остановились
(после ручного `git rebase --continue` — с Phase 3).

## Запреты

- ❌ Не создавать ворктри — это `$SHIP/scripts/worktree_bootstrap.py` / `git worktree add`
  (модель — `$SHIP/references/worktree-model.md`).
- ❌ Не делать `merge` без `--ff-only` — защёлка «доехало либо отказ»; не-FF = STOP,
  не полу-слияние.
- ❌ Не пушить `wt/<task>` и агентские ветки (push только MR-ветки — делает `ship:mr`).
- ❌ Не угадывать AT-ключ/имя MR-ветки — нет явного ключа → вопрос пользователю
  (Phase 4 шаг 2).
- ❌ Никаких внешних write-actions сверх прописанных (push MR-ветки/создание MR — делает
  `ship:mr` по аппруву): комментарии/labels/merge MR, пайплайны, мутации трекера/TMS —
  только по явному запросу (инвариант — схема base, `.kit/schema.md` «Гейты»).
- ❌ Не доставлять агент-инфру в MR — она садится на агентскую ветку.
- ❌ Не делать ff при корневом `PROGRESS.md` (или ином handoff-черновике в корне)
  в диапазоне land'а — STOP (Phase 3 шаг 2): handoff живёт в доме `.tasks/work/<task>/`,
  корневой утечёт в MR.
- ❌ Не править проектный код / не диф текущей правки — это ревью-скиллы платформы
  (skill только сводит и доставляет уже сделанное).
- ❌ Не `--no-verify` на rebase/cherry-pick; hook упал — STOP.
- ❌ Не удалять каталог ворктри, стоя внутри него — сначала `cd <main_repo>`.
- ❌ Не считать задачу закрытой на созданном MR — `landed_mr_open` ≠ `completed`;
  гейт закрытия — checklist «Post-MR» (pipeline → разбор ланча → merge → pull → беклог).
- ❌ Не вызывать Skill'ы из сессии, жившей в удалённом ворктри, — после retire её реестр
  мёртв («Потеря среды после retire»).
