---
name: mr
description: >-
  Переносит проектные коммиты грязной агентской ветки в MR-ветку через cherry-pick (агентные
  .claude//.tasks//.kit/ и .gitignore/CLAUDE.md дропаются), сохраняя message/порядок; mixed-коммиты —
  cherry-pick+amend. В конце — 3 блока для MR + push/создание MR через CLI VCS-хостинга. Активируй:
  «подготовь ветку для MR», «перенеси чистые коммиты в <branch>», «долей правки в MR-ветку».
  НЕ сводит ворктри-задачу (→ ship:land), НЕ коммитит новую работу (гигиена коммита — shared модуля).
---

# Подготовка MR-ветки через cherry-pick (модуль ship)

Путь к модулю ниже обозначен `$SHIP`: в Claude Code это `${CLAUDE_PLUGIN_ROOT}`;
на другой платформе — каталог модуля ship в её кэше плагинов.

Skill переносит проектные коммиты из source-ветки в target-ветку коммит-за-коммитом (через
`git cherry-pick`), сохраняя message, порядок и метаданные. Агентные коммиты пропускаются.
Mixed-коммиты переносятся с amend — агентные файлы откатываются к parent-версии. Target
может быть как новой (создаётся от base), так и существующей (доливаем поверх).

Словарь проекта — секция `[ship]` файла `.kit/answers.toml` (тощая база модуля base;
параметры перечислены в `$SHIP/README.md`); без файла/секции — дефолты (референс one-web).
Интеграционная ветка и агентская ветка — параметры `main_branch` / `agent_branch` секции
`[project]` той же базы.

## Инвариант

> **Source неизменна. Target собирается через cherry-pick.**
> - `pure-project` коммит → `git cherry-pick {sha}` как есть;
> - `mixed` коммит → `git cherry-pick {sha}` + `git restore --staged --worktree --source=HEAD^ -- {agent-files}` + `git commit --amend --no-edit`;
> - `pure-agent` коммит → SKIP;
> - `.gitignore` всегда считается агентным файлом и попадает в drop-список (если пользователь явно не сказал перенести его).
>
> По умолчанию skill готовит локальное состояние target-ветки и печатает 3 копируемых
> артефакта. **При доставке (после аппрува diff)** может запушить target и создать MR через
> CLI VCS-хостинга (параметр `vcs_cli` секции `[ship]`; Phase 6.5). Без CLI / при отказе
> пользователя — fallback на печать `git push` + блоков. Source при этом неизменна.
>
> Push target и создание MR (Phase 6.5, по аппруву) — **единственные** внешние write-actions
> skill'а. Комментарии/labels/merge MR и прочие мутации внешних систем — только по явному
> запросу пользователя (инвариант внешней поверхности — схема base, `.kit/schema.md` «Гейты»).

## Что в deny-list

См. [exclusion-patterns.md](references/exclusion-patterns.md) для полного списка
с обоснованием. Кратко: `.claude/**`, `.agents/**`, `.codex/**`, `AGENTS.md`, `.kit/**`,
`.tasks/**`, IDE-каталоги, кэши/артефакты сборки и прогонов, `**/.DS_Store`, локальные
пакеты/env-файлы, `**/settings.local.json`, `.gitignore`, `CLAUDE.md`, `CLAUDE.local.md`
+ проектные политики (параметр `extra_exclusions` секции `[ship]`).

## Прежде всего

Когда пользователь дал источник работы — выполни Phases 0–6 **подряд без остановок**.
Останавливайся только на:
- ожиданиях ответа от `AskUserQuestion`;
- ошибках git (грязное дерево, конфликт cherry-pick, pre-commit hook fail);
- если в Phase 5 найдена утечка агентного файла в target.

Никаких «можно продолжать?» вне `AskUserQuestion`.

## Phase 0 — Resolve inputs

1. Определи `source`:
   - если пользователь явно указал в запросе («перенеси из X в Y») — берём из запроса;
   - иначе `source = git branch --show-current`.

2. **Определи линию.** Одна линия (`lines = single` секции `[project]` — дефолт):
   `integration_branch` = параметр `main_branch`, base по умолчанию
   `origin/{main_branch}`, sync-grep (ERE, оба штатных варианта сообщения git) =
   `^Merge (remote-tracking )?branch '(origin/)?{main_branch}'`, `run_env` = параметр
   `default_env` секции `[craft]` (нет — без env-опции).

   При `lines = dual` (и сложнее) — маппинг по имени source-ветки: агентская ветка линии N →
   своя интеграционная ветка / base / sync-grep / стенд (карта линий — `.kit/local.md`
   проекта; референс one-web: `at-creation-crc` → `rc` / стенд RC-линии, `at-creation-kmp` →
   `kmp` / `kmp-stage`, иначе → `main` / стенд dev-линии).

   **Первая доставка новой линии:** интеграционная ветка линии может ещё не существовать
   в origin (`git ls-remote --heads origin {integration_branch}` пуст) — это не ошибка;
   её первый push делается вместе с первым MR (Phase 6.5), а base до того — **локальная**
   интеграционная ветка.

   Записать `line`, `integration_branch`, `run_env` в `state.md`.

3. Через `AskUserQuestion` (один вопрос с 4 опциями + Other) собери:
   - имя `target`-ветки;
   - режим: «новая от base» / «существующая, долить»;
   - `base` (показывать только если режим = новая; default — base линии из шага 2).

   Если пользователь дал всё в первом сообщении — пропусти вопросы.

   **`target` — внешний идентификатор, его не угадываем.** У потребителей имя MR-ветки
   обычно = ключ AT-задачи в трекере (референс one-web: `VCSAT-NNNN`) — якорь связей
   CI/TMS/MR; неверный ключ свяжет pipeline и ланч не с той задачей. Правило: имя не
   передано явно (пользователем или каллером) → **stop-gate — спросить точное имя** через
   `AskUserQuestion`. Выводить «свободный» номер из истории веток или соседней
   последовательности задач **запрещено**; формулировка задачи вида «взять свободный ключ» —
   действие пользователя (ключ выделяет он), не разрешение агенту выбрать самому.

4. `git fetch origin --prune`.

5. Создай рабочую папку `.tasks/_scratch/ship-mr/{YYYYMMDD-HHMMSS}/` и запиши `state.md`:
   ```markdown
   source: <агентская ветка>
   line: main
   integration_branch: <main_branch>
   run_env: <default_env [craft] или —>
   target: <MR-ветка>
   target_mode: new | existing
   base: origin/<main_branch>     # только для new
   base_commit: <sha>             # вычислен в Phase 1
   dep_mr_url: —                  # опц.: URL MR vendored-библиотеки от оркестратора (Block 1)
   started_at: <ISO-время>
   status: in_progress
   ```

   **Опциональный вход `dep_mr_url`** *(только при vendored-библиотеке — параметр
   `vendored_dep` секции `[craft]` непуст)*: если вызывающий (оркестратор или пользователь)
   передал URL уже созданного MR библиотеки-зависимости — записать в `state.md`. Block 1
   (Phase 6) подставит явную ссылку вместо абстрактного требования.

   **Опциональный вход `base_commit` (override авто-детекта):** если вызывающий передал
   явный `base_commit` (например, `ship:land` передаёт `pre_ff` — tip базовой ветки
   до ff-merge, чтобы MR собрался из диапазона ровно одной задачи) — записать в `state.md`.
   Phase 1 тогда **пропустит** авто-детект базовой точки и возьмёт этот SHA.

6. **Sanity-checks**:
   - `source != target`;
   - `git status --porcelain` по tracked-файлам пуст (untracked игнорируем — это нормальные артефакты skill-ов);
   - `git rev-parse --verify {source}` и `{base}` (или `{target}` для existing) проходят;
   - для existing: target существует локально, иначе предложи `git fetch origin {target}:{target}`.

## Phase 1 — Find commit range

Цель: найти все коммиты в source, которые добавлены **после** последней синхронизации
с интеграционной веткой.

1. Найти базовую точку.

   **Если `base_commit` пришёл явно от каллера** (Phase 0) — взять его как есть,
   авто-детект ниже **пропустить**.

   Иначе — авто-детект. Grep матчит **оба** штатных варианта сообщения sync-merge —
   `git merge {int}` даёт `Merge branch '{int}'`, `git merge origin/{int}` даёт
   `Merge remote-tracking branch 'origin/{int}'` (паттерн только первого варианта находит
   устаревший синк → диапазон с десятками уже доставленных коммитов):
   ```bash
   last_sync_merge=$(git log {source} --first-parent -E --grep="^Merge (remote-tracking )?branch '(origin/)?{integration_branch}'" --format=%H -n 1)
   merge_base=$(git merge-base {source} {base})
   if [ -z "$last_sync_merge" ]; then
     # source свежая, не было merge с integration-веткой — берём merge-base
     base_commit=$merge_base
   elif ! git merge-base --is-ancestor "$merge_base" "$last_sync_merge"; then
     # sanity-check: свежий sync-merge содержит merge-base в предках (его second parent —
     # tip интеграционной ветки на момент синка); merge-base НЕ предок найденного кандидата
     # → кандидат устарел (была более свежая синхронизация, которую grep не поймал) —
     # берём merge-base и показываем это пользователю вместе с диапазоном
     base_commit=$merge_base
   else
     base_commit=$last_sync_merge
   fi
   ```
   Записать `base_commit` в `state.md` (если ещё не записан в Phase 0); сработал
   sanity-check — зафиксировать там же («grep-кандидат {sha} устарел, взят merge-base»)
   и упомянуть в сводке диапазона пользователю.

2. Получить список коммитов в диапазоне (без merge-коммитов, в хронологическом порядке):
   ```bash
   git log {base_commit}..{source} --no-merges --reverse --format="%H %s"
   ```
   Записать в `.tasks/_scratch/ship-mr/{ts}/commits-raw.md`.

3. Если список пуст — сообщи пользователю «после {base_commit} нет новых коммитов
   в {source}» и заверши.

**Важно про режим existing**: `base_commit` используется только как точка отсчёта по source.
Cherry-pick всё равно идёт в target, и в Phase 5 проверка делается через
`git diff {target_head_before}..HEAD`, а не через base. Логика Phase 1 одинакова для
new и existing.

## Phase 2 — Classify commits

См. [exclusion-patterns.md](references/exclusion-patterns.md) для deny-list.

Для каждого SHA из `commits-raw.md`:

1. Получить список изменённых файлов:
   ```bash
   git show --name-only --format= {sha}
   ```

2. Прогнать каждый файл через deny-list (fnmatch с `**`). Разделить на:
   - `project-files` — НЕ матчат deny-list;
   - `agent-files` — матчат deny-list (включая `.gitignore`).

3. Классифицировать коммит:
   - все файлы agent → **pure-agent** (SKIP);
   - все файлы project → **pure-project** (cherry-pick as-is);
   - смесь → **mixed** (cherry-pick + amend).

4. Записать план в `commit-plan.md`:
   ```markdown
   ## 1. abc1234 — pure-project
   Message: <subject>
   Files (project):
     - <файлы>

   ## 2. def5678 — mixed
   Message: <subject>
   Files (project):
     - <файлы>
   Files (agent, будут откачены при amend):
     - .tasks/<...>/state.md
     - .gitignore

   ## 3. 999ghi9 — pure-agent (SKIP)
   Message: <subject>
   Files (agent):
     - .claude/skills/<...>/SKILL.md
   ```

5. Через `AskUserQuestion` показать общую сводку — один вопрос:
   - текст: «Cherry-pick {N pure-project} + amend {M mixed} + skip {K pure-agent}.
     План в `commit-plan.md`. Продолжаем?»;
   - опции: «всё ок» (default, recommended) / «покажи коммит-план целиком».
   - Если выбрана вторая — выведи `commit-plan.md` в чат и спроси ещё раз («ок» / «отмена»).

## Phase 3 — Switch to target

См. [existing-target-mode.md](references/existing-target-mode.md).

1. Сохранить `original = git branch --show-current` в `state.md` — для отката при abort.

2. Switch:
   - **new**: `git checkout --no-track -b {target} {base}` — **обязательно `--no-track`**.
     Без него git проставляет ветке `upstream = {base}` (т.е. `origin/{main_branch}`),
     и тогда голый `git push` (при `push.default=upstream`) или `git push origin HEAD`
     уйдёт **прямо в интеграционную ветку** — что строго запрещено. Если ветка уже создана
     без `--no-track`, немедленно снять: `git branch --unset-upstream {target}`.
   - **existing**: `git checkout {target}`. Если есть upstream — `git pull --ff-only`;
     если pull даёт non-FF — STOP, сообщи и предложи пользователю самому решить
     (rebase/merge), потом `resume` через перезапуск skill.

3. Записать `target_head_before = git rev-parse HEAD` в `state.md` — для Phase 5 diff
   и для отката.

4. **Sanity upstream:** убедиться, что у target НЕТ upstream на интеграционную ветку —
   `git rev-parse --abbrev-ref {target}@{u}` должен вернуть «no upstream» (или
   `origin/{target}`), но НЕ интеграционную ветку любой линии. Если вернул интеграционную —
   `git branch --unset-upstream {target}`.

## Phase 4 — Cherry-pick

По порядку из `commit-plan.md`:

### pure-project

```bash
git cherry-pick {sha}
```

Если конфликт (`git status` показывает `unmerged paths`) — STOP. Сообщи пользователю:
- какой SHA из source конфликтует;
- какие файлы конфликтуют;
- предложение: «реши вручную → `git cherry-pick --continue`, затем перезапусти skill (resume)».

Если pre-commit hook упал — **НЕ** используй `--no-verify`. Сообщи пользователю, попроси
разобраться, сохрани state и STOP.

### mixed

```bash
git cherry-pick {sha}
# Откатить агентные файлы к parent-версии (HEAD^ — это коммит target до cherry-pick):
git restore --staged --worktree --source=HEAD^ -- {agent-file-1} {agent-file-2} ...
# Amend без агентных файлов:
git commit --amend --no-edit
```

Особый случай: если **все** agent-files были `A` (добавлены) в cherry-pick'нутом коммите,
`git restore --source=HEAD^` просто удалит их из worktree и индекса. Если `M`/`D` — вернёт
к версии HEAD^ (т.е. как было в target до cherry-pick).

Если после amend `git diff HEAD^ HEAD` пустой — в коммите кроме агентных файлов ничего
не было (классификация была неверной). Удали коммит через `git reset --hard HEAD^` и пометь
в `state.md` как `reclassified-to-pure-agent`.

Конфликт на cherry-pick mixed коммита обрабатывается так же, как pure-project — STOP
с пояснением.

### pure-agent

SKIP. Записать в `state.md` прогресс.

### После каждого коммита

- Записать в `state.md`: `applied: [<sha>, ...]`, `pending: [...]`.
- Если cherry-pick прошёл нормально — продолжаем к следующему без вопросов.

## Phase 5 — Final cleanup check

1. **Проверка на утечку агентного файла в target**:
   ```bash
   git diff --name-only {target_head_before}..HEAD
   ```
   Прогнать через deny-list (тот же, что в Phase 2). Если хотя бы один файл матчится —
   агентный файл просочился в target (вероятно, ошибка классификации Phase 2 или
   некорректный amend).

2. Если утечка найдена:
   - Запиши `leak-report.md` с диффом проблемных файлов и виновными SHA;
   - Сообщи пользователю: «утечка агентных файлов в target: <список>. Skill останавливается,
     исправь вручную (git reset/amend) и перезапусти»;
   - STOP, **не** делай auto-cleanup.

3. Если всё чисто — переходим к Phase 6.

## Phase 6 — Generate output blocks

См. [output-blocks.md](references/output-blocks.md) для деталей форматирования
и детекта зависимости от vendored-библиотеки.

Сгенерировать в чат **три отдельных копируемых блока** (каждый в своём fenced code-block)
в строгом порядке:

### Block 1 — Тело MR (сводка + список коммитов)

Это **готовое тело MR**. В нём ТОЛЬКО: краткая сводка + список коммитов (+ абзац
зависимости от vendored-библиотеки, если флаг). **Запрещено** класть в тело MR: команды
запуска (это Block 3 — отдельно), ссылки на прогоны/пайплайны/ланчи TMS, «чем проверено /
X passed», метрики, упоминания агента/AI. Тело описывает ЧТО меняет MR, а не как его гоняли.

1. **Краткая сводка** — 1–2 предложения, обобщающие характер изменений (какие тесты
   добавлены/обновлены, какие фиксы), на основе subjects коммитов. Идёт первой строкой тела.
2. `git log {target_head_before}..HEAD --format="- %h %s"` — список новых коммитов в target
   (под сводкой).
3. *(Только при vendored-библиотеке — `vendored_dep` `[craft]` непуст.)* Проверить
   зависимость от обновлённой библиотеки — **две ветки детекта, обе питают `dep_required`**
   (детали и защита от ложных — `references/output-blocks.md`):
   - **Ветка А — новые импорты (leaf-style):** diff по `**/*.py` + grep добавленных
     `from <dep>|import <dep>`; извлечь имена; для каждой проверить, существовала ли она
     в base (`git show {base_commit}:{file}`). Новое имя → флаг.
   - **Ветка Б — новые ВЫЗОВЫ через алиас модуля (module-style):** для алиасов модулей
     библиотеки (параметр `dep_aliases` секции `[ship]`) собрать из added-строк пары
     `<alias>.<fn>` и сверить **по тому же файлу** с base-снимком. Пара, которой не было →
     новый вызов → флаг. Это ловит случай, когда импорт модуля был и раньше, а функция —
     новая.
   - `dep_required = (новые импорты) OR (новые вызовы)`.
4. Формат блока:
   ```
   <краткая сводка изменений — 1–2 предложения>

   - abc1234 <subject>
   - def5678 <subject>
   - ...
   ```
   Если `dep_required = True` — над сводкой добавить **жирный** абзац про актуализацию
   библиотеки (явная ссылка при наличии `dep_mr_url`, иначе абстрактный — см. references).
   Если `False` — без него.

### Block 2 — Заголовок MR

1. Подсчитать N = число коммитов в target, чей subject содержит TC-id: сигнал
   `TC[- ]?\d+` в любом месте сообщения. Жёсткий craft-шаблон
   (`^Добавлен автотест TC-\d+:`) здесь не предполагать: commit-hygiene этого же
   модуля (Шаг 1 «формат из истории целевого файла») велит коммитить в локальном
   стиле репо — проект со стилем вида «TC 2271: суть» иначе даёт N=0 и
   вырожденный заголовок.
2. Собрать non-TC коммиты (без TC-id в subject). Извлечь из их commit-message
   короткую суть (часть до первого `:` или весь subject, если `:` нет). Дедуплицировать
   схожие.
3. Шаблон:
   ```
   {target} Добавлено {N} тестов + {tail}
   ```
   - `{tail}` — non-TC коммиты, склеенные через ` + `.
   - Если non-TC коммитов нет — без хвоста. Если N = 0 — `{target} {tail}` без «Добавлено 0 тестов».
   - N = 0 и `{tail}` пуст либо выродился в обрезки — заголовок из обрезков не клеить:
     однострочная сводка работ диапазона своими словами (по духу Block 1).

### Block 3 — Команда прогона

Отдельный блок **для пользователя/оркестратора** (ручной прогон, источник имён для
переменной точечного отбора пайплайна). Печатается в чат — **в тело MR НЕ идёт**.

1. Diff по тест-файлам (`git diff {target_head_before}..HEAD -- '<маска тест-файлов>'`).
2. Grep по добавленным определениям тестов — извлечь имена новых тест-функций.
3. Дедуплицировать и отсортировать.
4. Шаблон (референс pytest; раннер — параметр `runner` секции `[project]`):
   ```
   pytest --env {run_env} -k "test_X or test_Y or ..."
   ```
   (`{run_env}` из Phase 0; не задан — без `--env`.)
   Если новых тестов 0 — Block 3 не печатаем (заметка «новых тестов нет»).

## Phase 6.5 — Push + Create MR (доставка)

Выполняется **только при доставке** и **после аппрува diff пользователем** (показать
`git log {target_head_before}..HEAD` + предложенные Block 1/2 → дождаться «ок»).
Без аппрува — не пушим.

1. **Push** target-ветки: `git push -u origin {target}` (MR-ветку пушим; агентские — нет).
   Source не трогаем.
   - **Первая доставка линии:** если интеграционная ветка ещё не существует в origin
     (`git ls-remote --heads origin {integration_branch}` пуст) — сначала запушить её:
     `git push -u origin {integration_branch}` (первый push интеграционной ветки идёт
     вместе с первым MR; без него MR-таргет не существует на VCS-хостинге).
2. **Создать MR** через CLI VCS-хостинга (параметр `vcs_cli` `[ship]`; тело — без
   упоминаний агента/AI, проектный MR); референс glab:
   ```bash
   glab mr create --source-branch {target} --target-branch {integration_branch} \
     --title "<Block 2>" --description "<Block 1>" --yes
   ```
   В `--description` — **только Block 1**. **НЕ** добавлять Block 3, ссылки на прогоны,
   «чем проверено». Многострочное тело — через файл (`--description "$(cat <tmp>)"`).
3. Вывести пользователю **URL созданного MR**.
4. **Fallback** (нет CLI / не авторизован / пользователь отказался): не пушим и не создаём
   MR — переходим к Finalization (печать `git push` + блоки), MR пользователь открывает сам.

## Finalization (fallback — без авто-создания MR)

Печатается, если Phase 6.5 не выполнялась (нет доставки / нет CLI / отказ):

1. Распечатать (но **не выполнять**) команду пуша:
   ```
   git push -u origin {target}
   ```

2. Обновить `state.md`: `status: completed`.

3. Skill завершает работу. Если был abort на любой Phase — финального вывода нет, только
   напоминание про `state.md` и инструкции для resume.

## Resume

Если в `.tasks/_scratch/ship-mr/` есть директория с `state.md`, где
`status: aborted` или `status: interrupted`, при следующем запуске **спроси через
`AskUserQuestion`**: «продолжить прерванную сессию (target=X, applied={M}/{N})?» или
«начать новую». Resume:

- Phases 0–2 переиспользуют `state.md` + `commits-raw.md` + `commit-plan.md`;
- Phase 4 стартует с первого `pending` SHA.

Если пользователь успел вручную сделать `git cherry-pick --continue` — skill это увидит
через сравнение `git log {target_head_before}..HEAD` с `applied` из state и автоматически
перенесёт «успевшие» коммиты в `applied`.
