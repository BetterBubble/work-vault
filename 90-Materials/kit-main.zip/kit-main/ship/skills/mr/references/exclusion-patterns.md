# Exclusion patterns

Полный список glob-паттернов, по которым `ship:mr` относит файл к **agent-files**
(Phase 2 классификации). Это «следы агентной работы», локальные/инструментальные артефакты,
а также файлы, которые по правилу пользователя не должны переноситься в MR без явного запроса.

Список трёхблочный: **ядро** (одинаково у потребителей kit) + **стек** (референс
pytest+allure; проект с другим раннером подстраивает) + **проектные политики** (параметр
`extra_exclusions` секции `[ship]` файла `.kit/answers.toml` — каждый паттерн задокументирован
причиной в `.kit/local.md` проекта).

## Как сопоставлять

Для каждой строки из `git show --name-only --format= {sha}` берём путь и проверяем по каждому
pattern из таблиц ниже. Pattern сопоставляется как `fnmatch` с поддержкой `**` (рекурсивное
«любые сегменты»). Первый сматчившийся pattern определяет причину drop'а.

Файл всегда нормализуется к slash-форме (`tests/pages/chat.py`, не `tests\pages\chat.py`).

## Таблица паттернов — ядро

| Pattern | Категория | Причина |
|---|---|---|
| `.claude/**` | agent-config | Конфиги Claude Code: агенты, скиллы, скрипты, settings.local.json, worktrees |
| `.agents/**`, `.codex/**`, `AGENTS.md` | agent-config | Codex-слой: нативные манифесты/обёртки второй платформы (в kit — генерат). Агент-инфра, живёт на агентской ветке, в MR не уезжает |
| `.kit/**` | agent-config | Тощая база kit (answers-файл, генерат схемы, local.md, экземпляры модулей) — агент-инфра агентской ветки. Проект, осознанно версионирующий её в интеграционной ветке, снимает паттерн решением человека (факт отступления — в `.kit/local.md`) |
| `.tasks/**` | skill-artifacts | Intermediate-файлы скиллов: state.md, analysis/locators, дома задач, PROGRESS, скриншоты |
| `.idea/**` | ide-local | Конфиг JetBrains — индивидуальный, в проектный репо не идёт |
| `.vscode/**` | ide-local | Конфиг VS Code — индивидуальный |
| `**/.DS_Store` | os-junk | macOS thumbnail cache |
| `**/Thumbs.db` | os-junk | Windows thumbnail cache |
| `**/settings.local.json` | agent-config | Claude per-machine settings (permissions, env), не репо-уровня |
| `.envrc`, `.env.local` | local-deps | Локальные env-файлы |
| `secrets.yaml` | local-deps | Секреты — вне git по принципу базы kit («схема в git, значения вне git»); сюда попасть не должен вовсе |
| `.gitignore` | gitignore-policy | По явному правилу пользователя skill **никогда** не трогает `.gitignore` в target без прямого запроса. Правка в mixed-коммите откатывается при amend |
| `CLAUDE.md` | agent-docs | Основной CLAUDE.md проекта — инфра/инструкции для агента. Всегда dropped, без вопросов |
| `CLAUDE.local.md` | agent-docs | Локальные дефолты пользователя, не коммитятся вообще |
| `**/CLAUDE.md` | agent-docs | Вложенные CLAUDE.md (subprojects) — тоже агентный артефакт |

## Таблица паттернов — стек (референс pytest+allure; подстроить)

| Pattern | Категория | Причина |
|---|---|---|
| `**/__pycache__/**` | build-artifacts | Python bytecode |
| `*.pyc`, `*.pyo` | build-artifacts | Скомпилированный Python |
| `**/allure-raw/**` | test-output | Сырые результаты прогона |
| `tests/logs/**` | test-output | Логи раннера |
| `report.xml` | test-output | JUnit-отчёт |
| `*.whl`, `*.tar.gz` | local-deps | Локально положенные пакеты (vendored-dep wheel рядом с venv) |
| `.playwright-cli/**` | skill-artifacts | Снимки страниц браузер-разведки: console/network-логи, скриншоты, page-снапшоты |

## Таблица паттернов — проектные политики (параметр `extra_exclusions` `[ship]`)

Примеры из референс-инсталляции one-web (`extra_exclusions = [".tcs/**", ".cursor/**",
"docs/**"]`):

| Pattern | Категория | Причина |
|---|---|---|
| `.tcs/**` | skill-artifacts | CSV-кеш выгрузки тест-кейсов из TMS |
| `.cursor/**` | agent-config | Наследие других агентских IDE |
| `docs/**` | project-docs | Пример **этапного** решения проекта: docs держится агентно-локально и не доставляется, пока команда не решила версионировать её в интеграционной ветке. Перед добавлением такой политики убедиться, что guard чист (в origin интеграционной ветки директории нет) |

## Что НЕ в deny-list (намеренно)

- `README.md` — легитимный проектный документ. Переносим как обычно.
- Манифесты зависимостей (`requirements.txt` / `pyproject.toml` / аналоги) — проектная
  конфигурация. Переносим.
- Любые `*.md` внутри тестовых/инструментальных каталогов проекта — проектная документация.
- Конфиг раннера (`pytest.ini`, `conftest.py` / аналоги) — проектный.

## Как добавить новый паттерн

1. Перед добавлением — убедись, что pattern не матчит ни один **трекнутый в текущей
   интеграционной ветке** файл. Грубо: `git ls-files origin/<main_branch> | <fnmatch>`
   должен быть пуст.
2. Проектная политика → в `extra_exclusions` секции `[ship]` + причина в `.kit/local.md`.
   Кандидат в ядро/стек (у всех потребителей) → фидбэк-запись разработчику kit.
3. Pattern привязан к новому skill — категория `skill-artifacts` + имя skill'а.
4. Pattern — новый IDE / агент / external tool — категория `agent-config` или `ide-local`.

## Категории — пояснение

- **agent-config** — конфигурация Claude / Codex / прочих агентов. Никогда не нужна в проектном MR.
- **agent-docs** — markdown-инструкции для агентов (CLAUDE.md и варианты). Не идут в MR.
- **skill-artifacts** — побочный продукт работы скиллов. Можно безопасно удалить.
- **ide-local** — индивидуальная настройка рабочей машины.
- **build-artifacts** — результат компиляции / запуска.
- **test-output** — артефакты прогона тестов.
- **os-junk** — мусор от ОС.
- **local-deps** — локально подложенные зависимости (пакеты, env-файлы, секреты).
- **gitignore-policy** — `.gitignore`: скилл его никогда не трогает в target без явной
  команды пользователя.
- **project-docs** — проектные политики этапа (пересматриваются решением команды).
