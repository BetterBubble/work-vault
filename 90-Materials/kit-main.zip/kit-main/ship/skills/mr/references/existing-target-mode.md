# Existing target — доливка коммитов поверх

Применяется, когда target-ветка уже существует и в неё ранее уже заливали часть коммитов
из source (через этот же skill или вручную). Skill должен **добавить только новые** коммиты
и не дублировать те, что уже применены.

## Проверки перед стартом (вход в Phase 3)

1. **Target существует локально**: `git rev-parse --verify {target}` возвращает SHA.
   - Если ветки нет локально, но есть в remote: предложи через `AskUserQuestion` сделать
     `git fetch origin {target}:{target}`.
   - Если ветки нет нигде — пользователь ошибся именем, спроси переподтверждение.

2. **Чистое working tree**: `git status --porcelain` пуст по tracked-файлам. Untracked
   допустимы (это обычно `.tasks/`, `.claude/worktrees/`).

3. **Upstream и его состояние**:
   - если есть upstream — `git pull --ff-only`;
   - если pull non-FF (forced push на удалённый, или target и upstream разошлись) — STOP,
     не делай rebase автоматически. Сообщи пользователю.

4. **Target не равна source**: `git rev-parse {target}` != `git rev-parse {source}`.

## Дедупликация уже применённых коммитов

В existing-режиме повторный запуск skill может повторно cherry-pick'нуть коммит, который
уже есть в target (применён в прошлой сессии). Это вызовет либо empty-commit (если
содержимое идентично parent) либо конфликт. Нужно отфильтровать такие SHA из `commit-plan.md`.

### Эвристика «уже применён»

После Phase 1 (мы знаем диапазон `{base_commit}..{source}`), но перед записью
`commit-plan.md`, для каждого SHA из source делаем:

```bash
git log {target} --format="%H %s" | grep -F "<subject первой строки коммита из source>"
```

Если subject коммита из source найден в `git log {target}`:
- Сравнить diff: `git diff {source_sha}^..{source_sha}` vs diff соответствующего коммита
  из target.
- Если diff идентичен — коммит **уже применён**, пометить в `commit-plan.md` как
  `already-in-target (SKIP)`.
- Если diff отличается — это конфликт (один и тот же subject, разное содержимое). Пометить
  как `subject-conflict` и спросить пользователя через `AskUserQuestion`:
  - «Subject совпадает, но diff другой. Применить заново (создаст дубликат) / пропустить /
    показать diff?»

### git cherry --no-merges как альтернатива

`git cherry {target} {source}` сравнивает patch-id'ы и отмечает уже применённые коммиты.
Использовать как дополнительную проверку, но **не** как единственный источник правды —
`git cherry` не учитывает amend'ы и rebase'ы.

## Конфликт cherry-pick

Конфликт — это **cherry-pick conflict**, разрешается git'овыми инструментами:

```bash
git cherry-pick {sha}
# error: could not apply <sha>... <subject>
# CONFLICT (content): Merge conflict in <file>
```

При конфликте skill **останавливается** и:

1. Записывает `state.md`:
   ```markdown
   status: aborted
   aborted_reason: cherry_pick_conflict
   aborted_sha: <sha>
   aborted_file(s): <files>
   ```

2. Сообщает пользователю:
   ```
   Конфликт на cherry-pick {sha} ({subject}).
   Файлы: <files>.

   Чтобы разрешить:
     1. Открой <files> в редакторе, разреши конфликт.
     2. git add <files>
     3. git cherry-pick --continue   (или --abort если хочешь откатить)
     4. Перезапусти ship:mr — skill подхватит state и продолжит со следующего pending SHA.
   ```

3. STOP. **Не** использует `--abort` автоматически — это решение пользователя.

## Pre-commit hook fail

Если cherry-pick прошёл, но `git commit` (внутри cherry-pick или amend) отвалился из-за
pre-commit hook:

1. **НЕ** используй `--no-verify`.
2. Сообщи пользователю причину (вывод хука).
3. Сохрани state, STOP.

## Что НЕ делает skill в existing-режиме

- Не делает автоматический `git merge {source}` или `git rebase {source}` — это втянуло бы
  агентные коммиты целиком, без фильтрации.
- Не делает `git revert` — мы только добавляем, не откатываем.
- Не пушит target без аппрува пользователя (push + MR — только Phase 6.5 SKILL.md,
  после аппрува diff; иначе печать команды).

## Resume после abort

При abort на Phase 4:

1. Skill **не** делает `git reset --hard` автоматически — если был cherry-pick conflict,
   файлы в состоянии конфликта и пользователь сам решает (continue / abort).
2. В `state.md` обновить:
   ```markdown
   status: aborted
   aborted_at: <ISO-время>
   aborted_reason: cherry_pick_conflict | pre_commit_failed | user_choice
   aborted_sha: <sha>
   applied: [abc1234, def5678]
   pending: [ghi9999, ...]
   ```

При следующем запуске Phase 0 ищет в `.tasks/_scratch/ship-mr/` папки со
`status: aborted`. Если есть — предлагает через `AskUserQuestion` resume:

- «продолжить сессию {ts} с pending[0]={sha}»;
- «начать новую» (тогда старый state перейдёт в `status: abandoned`).

При resume:
- Phases 0–2 переиспользуют записанные `state.md` + `commits-raw.md` + `commit-plan.md`;
- перед Phase 4 skill сверяет `applied` со списком `git log {target_head_before}..HEAD` —
  если пользователь успел вручную `cherry-pick --continue`, перенесёт «успевшие» SHA
  из `pending` в `applied`;
- Phase 4 стартует с обновлённого `pending[0]`.

## Идемпотентность

Безопасно запускать skill несколько раз подряд на одной паре source/target:

- если все коммиты уже применены — Phase 2 пометит их всех `already-in-target` и skill
  завершится с «всё уже синхронизировано» (Phase 6 при `target_head_before` == HEAD выведет
  «нечего печатать, target актуален»);
- если часть применена, часть нет — Phase 2 отметит часть `already-in-target`, остальные
  применит.
