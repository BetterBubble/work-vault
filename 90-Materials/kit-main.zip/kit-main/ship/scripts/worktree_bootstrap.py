#!/usr/bin/env python3
"""Создание ворктри-на-задачу (модуль ship каталога kit).

Модель «ворктри = задача» — ship/references/worktree-model.md: каталог
<worktrees_root>/<проект>/<task>, ветка wt/<task> от агентской ветки, линки
окружения/секретов из главного репо, дом задачи .tasks/work/<task>/ с meta.json
(контракт меты base@kit; сев — канонический CLI task_meta.py модуля base).

Использование (из любого каталога; stdlib-only, Python >= 3.11):
    python3 worktree_bootstrap.py <task> [<base>] [--repo PATH]
                                  [--kind K] [--title T]
    <task>  — id/slug задачи (TASK-1200, TODO-042, fix-toast...) -> каталог и ветка wt/<task>
    <base>  — базовая агентская ветка (дефолт — параметр agent_branch секции [project])
    --repo  — главный чекаут репо (дефолт — детект от cwd через git)
    --kind  — тип задачи меты (write|fix|update|research|infra|adhoc|review|refactor;
              дефолт adhoc); фолбэк — env TASK_KIND
    --title — заголовок задачи человеку (дефолт — сам <task>); фолбэк — env TASK_TITLE

Параметры проекта — <repo>/.kit/answers.toml: [project] worktrees_root / name /
agent_branch; [ship] link_dirs / link_files / branches.<ветка> (line/env меты).
Нет файла/секции — дефолты (референс one-web).

Создание = ТОЛЬКО для НОВОЙ задачи: повтор упадёт `branch already exists` — полезный
предохранитель. ВОЗВРАТ к задаче = просто cd в каталог (переживает сессии).
Сведение+доставка — скилл ship:land.
"""
import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path

DEFAULTS = {
    "worktrees_root": "~/worktrees",
    "link_dirs": ["venv"],
    "link_files": ["secrets.yaml"],
}


def run(cmd, **kwargs):
    """Команда с наследованием stdout/stderr; ненулевой код = стоп."""
    proc = subprocess.run(cmd, encoding="utf-8", **kwargs)
    if proc.returncode != 0:
        sys.exit(proc.returncode)
    return proc


def capture(cmd):
    """Команда с захватом stdout; ошибка -> None."""
    proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8")
    return proc.stdout.strip() if proc.returncode == 0 else None


def resolve_repo(arg):
    """Главный чекаут репо: --repo либо детект от cwd (общий .git — ворктри-safe)."""
    if arg:
        repo = Path(arg).expanduser().resolve()
        if not (repo / ".git").exists():
            sys.exit(f"не git-репо: {repo}")
        return repo
    common = capture(["git", "rev-parse", "--path-format=absolute", "--git-common-dir"])
    if not common:
        sys.exit("cwd вне git-репо — укажи главный чекаут через --repo")
    return Path(common).parent


def load_params(repo):
    """[project]/[ship] из .kit/answers.toml поверх дефолтов; без базы kit — дефолты."""
    params = {
        **DEFAULTS,
        "project_name": repo.name,
        "agent_branch": "",
        "branches": {},
    }
    answers = repo / ".kit" / "answers.toml"
    if not answers.is_file():
        return params
    import tomllib

    data = tomllib.loads(answers.read_text(encoding="utf-8"))
    project = data.get("project") or {}
    ship = data.get("ship") or {}
    if project.get("worktrees_root"):
        params["worktrees_root"] = project["worktrees_root"]
    if project.get("name"):
        params["project_name"] = project["name"]
    if project.get("agent_branch"):
        params["agent_branch"] = project["agent_branch"]
    for key in ("link_dirs", "link_files"):
        if key in ship:
            params[key] = ship[key]
    params["branches"] = ship.get("branches") or {}
    return params


def link(src: Path, dst: Path):
    """Линк src -> dst: symlink; Windows-фолбэк — junction (каталог) / hardlink /
    копия с предупреждением (симлинки там требуют прав или developer mode)."""
    try:
        os.symlink(src, dst, target_is_directory=src.is_dir())
        return
    except OSError:
        if os.name != "nt":
            raise
    if src.is_dir():
        proc = subprocess.run(
            ["cmd", "/c", "mklink", "/J", str(dst), str(src)],
            capture_output=True, text=True, encoding="utf-8",
        )
        if proc.returncode != 0:
            sys.exit(f"не создать junction {dst}: {proc.stderr.strip()}")
    else:
        try:
            os.link(src, dst)
        except OSError:
            shutil.copy2(src, dst)
            print(f"предупреждение: {dst.name} скопирован (не слинкован) — "
                  "правки в главном репо сюда не приедут", file=sys.stderr)


def find_task_meta(repo):
    """Канонический CLI меты (task_meta.py модуля base) — цепочка резолва:
    сиблинг в каталоге kit -> локальная копия проекта -> кэш CC-плагинов."""
    sibling = Path(__file__).resolve().parent.parent.parent / "base" / "scripts" / "task_meta.py"
    if sibling.is_file():
        return sibling
    local = repo / ".claude" / "scripts" / "task_meta.py"
    if local.is_file():
        return local
    cache = Path.home() / ".claude" / "plugins" / "cache" / "kit" / "base"
    if cache.is_dir():
        def ver_key(p: Path):
            try:
                return [int(x) for x in p.name.split(".")]
            except ValueError:
                return [0]
        versions = sorted((p for p in cache.iterdir() if p.is_dir()), key=ver_key)
        for vdir in reversed(versions):
            candidate = vdir / "scripts" / "task_meta.py"
            if candidate.is_file():
                return candidate
    return None


def main():
    parser = argparse.ArgumentParser(description="Создание ворктри-на-задачу (модуль ship)")
    parser.add_argument("task")
    parser.add_argument("base", nargs="?", default="")
    parser.add_argument("--repo", default="")
    parser.add_argument("--kind", default=os.environ.get("TASK_KIND", ""))
    parser.add_argument("--title", default=os.environ.get("TASK_TITLE", ""))
    args = parser.parse_args()

    repo = resolve_repo(args.repo)
    params = load_params(repo)

    base = args.base or params["agent_branch"]
    if not base:
        sys.exit("базовая ветка не задана: передай <base> аргументом либо заполни "
                 "agent_branch секции [project] в .kit/answers.toml")

    wt_root = Path(params["worktrees_root"]).expanduser() / params["project_name"]
    wt_dir = wt_root / args.task
    wt_root.mkdir(parents=True, exist_ok=True)

    # Ветка wt/<task> от базовой агентской ветки; упадёт, если ветка уже существует.
    run(["git", "-C", str(repo), "worktree", "add",
         "-b", f"wt/{args.task}", str(wt_dir), base])

    # Линки окружения и gitignored-секретов (без них ворктри рождается без
    # интерпретатора/учёток — раннер и TMS-обёртки падают).
    for name in list(params["link_dirs"]) + list(params["link_files"]):
        src = repo / name
        if name and src.exists():
            link(src, wt_dir / name)

    # Дом задачи work/<task>/ с метой (трекается, на land приезжает в агентскую ветку).
    # Мету читают ship:land (base), фабрика research-юзеров (env), наблюдаемость.
    # PROGRESS.md здесь не сеется — правило границы сессии (worktree-model.md).
    task_meta = find_task_meta(repo)
    if task_meta is None:
        print("предупреждение: task_meta.py модуля base не найден (сиблинг kit / "
              ".claude/scripts / кэш плагинов) — ворктри без меты дома задачи; "
              "ship:land возьмёт base по ancestry", file=sys.stderr)
    else:
        branch_map = params["branches"].get(base) or {}
        cmd = [sys.executable, str(task_meta), "init", "--root", str(wt_dir),
               "--key", args.task, "--mode", "worktree", "--base", base]
        if branch_map.get("line"):
            cmd += ["--line", branch_map["line"]]
        if branch_map.get("env"):
            cmd += ["--env", branch_map["env"]]
        if args.kind:
            cmd += ["--kind", args.kind]
        if args.title:
            cmd += ["--title", args.title]
        run(cmd)

    print(f"Ворктри готов: {wt_dir} (ветка wt/{args.task} от {base})")
    print(f"cd {wt_dir}")


if __name__ == "__main__":
    main()
