# ship — модуль доставки (каталог kit)

Петля доставки: отгрузка сделанной работы из грязной агентской ветки
в интеграционную ветку/MR. Жизненный цикл: создание ворктри-задачи
(`scripts/worktree_bootstrap.py`) → работа в ворктри → сведение + доставка
(`ship:land` → `ship:mr`). Канон гигиены коммита и последовательности
доставки — `shared/`.

## Состав

| Что | Где |
|---|---|
| Скилл `ship:mr` — MR-ветка из чистых коммитов (cherry-pick, deny-list, 3 блока MR, push+MR по аппруву) | `skills/mr/` |
| Скилл `ship:land` — сведение ворктри-задачи (squash → rebase → ff-only → доставка) | `skills/land/` |
| Протокол гигиены коммита (формат из истории, project/agent — два коммита) | `shared/commit-hygiene.md` |
| Протокол доставки (dep-MR → MR проекта → гейт публикации → CI-шаги track) | `shared/delivery-protocol.md` |
| Модель «ворктри = задача» (каталоги, мета, точки входа) | `references/worktree-model.md` |
| Создание ворктри-задачи с метой дома (кроссплатформенный) | `scripts/worktree_bootstrap.py` |
| Шаблон handoff'а между сессиями задачи | `templates/PROGRESS-template.md` |

## Параметры проекта — секция `[ship]` в `.kit/answers.toml`

Без файла/секции действуют дефолты (референс one-web). `worktrees_root` /
`agent_branch` / `main_branch` / `lines` — секция `[project]` базы, ship их
не дублирует; `default_env` / `vendored_dep` / `research_user_cmd` — секция
`[craft]` (читаются мягко, craft может быть не установлен).

```toml
[ship]
vcs_cli = "glab"        # CLI VCS-хостинга (glab | gh); сниппеты MR/пайплайна референсны glab
extra_exclusions = []   # проектные политики deny-list поверх ядра+стека
                        # (референс one-web: [".tcs/**", ".cursor/**", "docs/**"])
dep_aliases = []        # алиасы модулей vendored-библиотеки для детекта новых вызовов
                        # (референс one-web: ["iva_one", "rest", "driver_sessions", "consts"])
link_dirs = ["venv"]    # каталоги окружения, линкуемые из главного репо в ворктри
link_files = ["secrets.yaml"]  # gitignored-файлы, линкуемые в ворктри

[ship.branches."at-creation-kmp"]  # карта агентских веток → line/env меты дома задачи
line = "kmp"                        # (референс one-web; нет записи для базовой ветки →
env = "kmp-stage"                   # мета сеется без line/env — поля опциональны)
```

## Межмодульные связи (мягкие)

Инвариант внешних write-actions и fallback делегирования — схема **base**
(`.kit/schema.md`, «Гейты»); мета домов задач — канонический CLI `task_meta.py`
модуля **base**; скиллы **craft** зовут `ship:mr` и протокол доставки; механика
CI-пайплайна и резолва ланча (шаги 4–6 протокола) — модуль **track**; словарь
тегов TMS и чтение ланчей — модуль **tms**. Модули ставятся независимо;
отсутствие соседа скиллы обрабатывают явной развилкой (сказать пользователю),
не молчаливым пропуском.
