#!/usr/bin/env python3
"""Шим-лончер CLI пакета testops (модуль tms каталога kit).

Пакет живёт рядом (`scripts/testops/`) в кэше платформы — шим добавляет свой
каталог в sys.path и передаёт управление CLI пакета. Одна команда без
env-префиксов работает на macOS/Windows/Linux одинаково:

    python3 "<каталог модуля tms>/scripts/testops_cli.py" get 52275

Запускать из корня репо проекта: оттуда читаются gitignored `secrets.yaml`
(секреты TestOps) и `.kit/answers.toml` (параметры `[tms]`, если база kit есть).
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from testops.__main__ import main  # noqa: E402 — импорт после правки sys.path

if __name__ == "__main__":
    sys.exit(main())
