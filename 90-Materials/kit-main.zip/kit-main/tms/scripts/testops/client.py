"""HTTP-клиент к REST API Allure TestOps (read-only).

Обмен api-token на короткоживущий JWT (`POST /api/uaa/oauth/token`,
`grant_type=apitoken`), затем запросы с `Authorization: Bearer`. Все публичные
операции пакета — чтение (GET); единственный POST здесь — обмен токена для
аутентификации, данные TestOps он не меняет.

Endpoint/token/project — по принципу kit «схема в git, значения вне git»:
env-переменные TESTOPS_* → gitignored `secrets.yaml` в корне проекта;
литералов в коде нет.
"""
import os
import warnings

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
warnings.filterwarnings("ignore", message="Unverified HTTPS request")

_SECRETS_FILE = "secrets.yaml"
_SECRETS_SECTION = "testops"

_TIMEOUT = 30


class TestOpsError(RuntimeError):
    """Ошибка обращения к Allure TestOps (сеть, авторизация, не-2xx ответ, конфиг)."""


def _secrets_section():
    """Секция `testops:` из `./secrets.yaml` (gitignored; форма — secrets.yaml.example).

    CLI и скиллы зовут модуль из корня проекта, поэтому файл ищется в cwd.
    Нет файла/секции — пустой dict (env-переменных может хватить).
    """
    path = os.path.join(os.getcwd(), _SECRETS_FILE)
    if not os.path.exists(path):
        return {}
    import yaml
    with open(path, encoding="utf-8") as handle:
        data = yaml.safe_load(handle) or {}
    section = data.get(_SECRETS_SECTION) or {}
    return section if isinstance(section, dict) else {}


def resolve_settings():
    """(endpoint, token, project_id): env `TESTOPS_*` → secrets.yaml → TestOpsError.

    Env-override — путь для CI (masked variables) и удалённого хостинга агента.
    """
    section = _secrets_section()
    endpoint = os.environ.get("TESTOPS_ENDPOINT") or section.get("endpoint")
    token = os.environ.get("TESTOPS_TOKEN") or section.get("token")
    project_id = os.environ.get("TESTOPS_PROJECT_ID") or section.get("project_id")
    missing = [name for name, value in
               (("endpoint", endpoint), ("token", token), ("project_id", project_id))
               if not value]
    if missing:
        raise TestOpsError(
            "Не задано: " + ", ".join(missing)
            + ". Задай env TESTOPS_ENDPOINT / TESTOPS_TOKEN / TESTOPS_PROJECT_ID"
            + f" или секцию `{_SECRETS_SECTION}:` в ./{_SECRETS_FILE}"
            + " (форма — secrets.yaml.example; вызывать из корня проекта)."
        )
    return endpoint.rstrip("/"), token, int(project_id)


class TestOpsClient:
    """Тонкий read-only клиент к Allure TestOps.

    Параметры, не переданные явно, резолвятся через `resolve_settings()`
    (env → secrets.yaml). Авторизация ленивая: JWT берётся при первом запросе
    и переиспользуется; при 401 (токен истёк) делается один автоматический
    повтор с переавторизацией.
    """

    def __init__(self, endpoint=None, token=None, project_id=None, verify=False):
        if endpoint is None or token is None or project_id is None:
            resolved_endpoint, resolved_token, resolved_project = resolve_settings()
            endpoint = endpoint or resolved_endpoint
            token = token or resolved_token
            project_id = resolved_project if project_id is None else project_id
        self.endpoint = endpoint.rstrip("/")
        self.project_id = project_id
        self._token = token
        self._session = requests.Session()
        self._session.verify = verify
        self._authorized = False

    def _authorize(self):
        url = f"{self.endpoint}/api/uaa/oauth/token"
        try:
            resp = self._session.post(
                url,
                data={"grant_type": "apitoken", "scope": "openid", "token": self._token},
                timeout=_TIMEOUT,
            )
        except requests.RequestException as exc:
            raise TestOpsError(f"Не удалось подключиться к {url}: {exc}") from exc
        if not resp.ok:
            raise TestOpsError(f"Аутентификация не удалась ({resp.status_code}): {resp.text[:200]}")
        access_token = resp.json().get("access_token")
        if not access_token:
            raise TestOpsError("В ответе oauth/token нет access_token")
        self._session.headers["Authorization"] = f"Bearer {access_token}"
        self._authorized = True

    def get(self, path, **params):
        """GET `<endpoint><path>` с query-параметрами; возвращает разобранный JSON.

        Параметры со значением None отбрасываются. При 401 — один повтор с
        переавторизацией. Не-2xx (после повтора) поднимает `TestOpsError`.
        """
        if not self._authorized:
            self._authorize()
        params = {key: value for key, value in params.items() if value is not None}
        url = f"{self.endpoint}{path}"
        try:
            resp = self._session.get(url, params=params or None, timeout=_TIMEOUT)
            if resp.status_code == 401:
                self._authorized = False
                self._authorize()
                resp = self._session.get(url, params=params or None, timeout=_TIMEOUT)
        except requests.RequestException as exc:
            raise TestOpsError(f"GET {path} не удался: {exc}") from exc
        if not resp.ok:
            raise TestOpsError(f"GET {path} -> {resp.status_code}: {resp.text[:200]}")
        return resp.json()

    def get_content(self, path, **params):
        """GET сырых байтов (вложения и т.п.); авторизация/повтор как в `get`.

        Отличается от `get` только тем, что возвращает `resp.content`, а не JSON.
        """
        if not self._authorized:
            self._authorize()
        params = {key: value for key, value in params.items() if value is not None}
        url = f"{self.endpoint}{path}"
        try:
            resp = self._session.get(url, params=params or None, timeout=_TIMEOUT)
            if resp.status_code == 401:
                self._authorized = False
                self._authorize()
                resp = self._session.get(url, params=params or None, timeout=_TIMEOUT)
        except requests.RequestException as exc:
            raise TestOpsError(f"GET {path} не удался: {exc}") from exc
        if not resp.ok:
            raise TestOpsError(f"GET {path} -> {resp.status_code}: {resp.text[:200]}")
        return resp.content
