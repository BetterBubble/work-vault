"""Словарь проекта для пакета testops — параметры модуля tms.

Точки адаптации, которые в разных проектах различаются (тег «решено не
автоматизировать», пропускаемые вложения ланча, схема browser-маркера прогона),
вынесены из кода в параметры: секция `[tms]` файла `.kit/answers.toml` (тощая
база модуля base каталога kit; читается из cwd = корень репо проекта). Нет
файла / секции / ключа — дефолты ниже (референс-инсталляция one-web), поэтому
без базы kit пакет тоже работает.

Секреты (endpoint/token/project) сюда не входят — они в `client.py`
(env `TESTOPS_*` → gitignored `secrets.yaml`): параметр — свойство проекта
и живёт в git, секрет — вне git.
"""
import re
import sys
from functools import lru_cache
from pathlib import Path

_ANSWERS_FILE = Path(".kit") / "answers.toml"
_SECTION = "tms"

# Референс one-web; ключи = ключам секции [tms] answers-файла.
DEFAULTS = {
    # Тег TC «осознанно решено НЕ автоматизировать» — исключает кейс из
    # кандидатов на автоматизацию (`cases --unautomated`).
    "wont_automate_tag": "wont-automate",
    # Имена вложений ланча, которые не качаем (референс: «Видео» — мёртвая
    # ссылка на запись сессии при выключенной записи).
    "skip_attachments": ["Видео"],
    # Regex конфигурационного маркера прогона в тегах ланча (кладёт
    # upload-инструмент CI; референс: browser_<os>_<browser> от allurectl).
    "browser_marker_pattern": r"browser_(?:win|lin|mac|android|ios)_\w+",
}


@lru_cache(maxsize=1)
def load():
    """Параметры словаря проекта: DEFAULTS ← перекрытие из `[tms]` answers-файла.

    Файл ищется от cwd (CLI и скиллы зовут пакет из корня репо проекта).
    Незнакомые ключи секции игнорируются (совместимость вперёд).
    """
    params = dict(DEFAULTS)
    path = Path.cwd() / _ANSWERS_FILE
    if not path.is_file():
        return params
    try:
        import tomllib
    except ModuleNotFoundError:  # Python < 3.11
        sys.stderr.write(
            f"testops: найден {_ANSWERS_FILE}, но нет tomllib (Python < 3.11) — "
            "параметры [tms] не прочитаны, работаю на дефолтах\n"
        )
        return params
    section = tomllib.loads(path.read_text(encoding="utf-8")).get(_SECTION) or {}
    for key in DEFAULTS:
        if key in section:
            params[key] = section[key]
    return params


@lru_cache(maxsize=1)
def browser_marker_re():
    """Скомпилированный regex browser-маркера (из параметров)."""
    return re.compile(load()["browser_marker_pattern"])
