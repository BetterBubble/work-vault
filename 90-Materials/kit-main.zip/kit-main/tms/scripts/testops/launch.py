"""Чтение ланча Allure TestOps (read-only) — не-зелёные результаты + вложения.

Используется skill'ом craft:fix (вход «launch URL/ID»): из ланча тянутся
все не-`passed` результаты (failed / broken / skipped→xfail) с trace и вложениями
(скриншот, log), чтобы разобрать падения без локального allure-raw.

Эндпоинты (подтверждены на референс-инсталляции one-web):
    GET /api/rs/launch/{id}                         — overview (name, tags, issues)
    GET /api/rs/testresult?launchId={id}&page&size  — результаты (status/message/trace/...)
    GET /api/rs/testresult/{rid}/execution          — {steps, attachments}
    GET /api/rs/testresult/attachment/{aid}/content — сырые байты вложения

Только чтение. Как allure-pytest кодирует исходы в TestOps:
    xfail (ожидаемо упал)  -> status="skipped", message="XFAIL <reason>\\n\\n<реальное исключение>"
    xpass (неожиданно прошёл, xfail_strict=true в pytest.ini) -> status="failed", "XPASS" в message
    обычный skip           -> status="skipped", message=<причина skip> (без префикса XFAIL)
"""
import os
import re

from .params import browser_marker_re, load as load_params

_LAUNCH_URL_RE = re.compile(r"/launch/(\d+)")

_EXT_BY_CONTENT_TYPE = {
    "image/png": ".png",
    "image/jpeg": ".jpg",
    "text/plain": ".log",
    "text/html": ".html",
    "application/json": ".json",
}


def parse_launch_id(value):
    """'726' | 726 | '<endpoint>/launch/726' -> 726 (int)."""
    if isinstance(value, int):
        return value
    text = str(value).strip()
    if text.isdigit():
        return int(text)
    match = _LAUNCH_URL_RE.search(text)
    if match:
        return int(match.group(1))
    raise ValueError(f"Не распознан id ланча из {value!r} (ожидается число или URL .../launch/<id>)")


def get_launch(client, launch_id):
    """Overview ланча: name, tags, issues, closed, projectId, createdDate, ..."""
    return client.get(f"/api/rs/launch/{launch_id}")


def launch_url(client, launch_id):
    """URL страницы ланча в TestOps."""
    return f"{client.endpoint}/launch/{launch_id}"


def browser_marker(overview):
    """Конфигурационный маркер прогона из тегов ланча или None.

    Ланч = одна конфигурация; тег кладётся upload-инструментом CI при запуске
    (референс: `browser_<os>_<browser>` от allurectl, ALLURE_LAUNCH_TAGS; схема —
    параметр `browser_marker_pattern`). Это маркер, на котором тест реально
    упал → им же reproduce/verify при фиксе.
    """
    for tag in overview.get("tags") or []:
        name = tag.get("name") if isinstance(tag, dict) else str(tag)
        match = browser_marker_re().search(name or "")
        if match:
            return match.group(0)
    return None


def search_launches(client, name_contains=None, limit=20):
    """Ланчи проекта (read-only), новые сверху. name_contains -> rql `name ~=`."""
    if name_contains:
        data = client.get(
            "/api/rs/launch/__search", projectId=client.project_id,
            rql=f'name ~= "{name_contains}"', page=0, size=limit, sort="createdDate,DESC",
        )
    else:
        data = client.get(
            "/api/rs/launch", projectId=client.project_id,
            page=0, size=limit, sort="createdDate,DESC",
        )
    return data.get("content", [])


def iter_results(client, launch_id, page_size=100):
    """Все test-result'ы ланча (постранично)."""
    page = 0
    while True:
        data = client.get("/api/rs/testresult", launchId=launch_id, page=page, size=page_size)
        for item in data.get("content", []):
            yield item
        if data.get("last", True):
            break
        page += 1


def _split_module_func(full_name):
    """'tests.test_profile#test_x' -> ('tests/test_profile.py', 'test_x')."""
    module, _, func = (full_name or "").partition("#")
    test_path = module.replace(".", "/") + ".py" if module else ""
    return test_path, func


def _first_line(text):
    stripped = (text or "").strip()
    return stripped.splitlines()[0] if stripped else ""


def _split_exception(message):
    """'ExcClass: текст' -> ('ExcClass', 'текст'). Берём первую строку message."""
    line = _first_line(message)
    cls, sep, msg = line.partition(":")
    return (cls.strip(), msg.strip()) if sep else ("", line)


def _xfail_reason(message):
    """Из 'XFAIL <reason>' / 'XPASS(strict) <reason>' вернуть <reason> (первая строка)."""
    first = _first_line(message)
    return re.sub(r"^(XFAIL|\[?XPASS[^]]*\]?)\s*", "", first).strip()


def _xfail_actual(message):
    """Реальное исключение xfail-результата — текст после первого пустого разделителя."""
    parts = (message or "").split("\n\n", 1)
    return parts[1].strip() if len(parts) == 2 else ""


def classify(result):
    """Вернуть (kind, xfail_reason). kind: passed|failed|broken|xfail|xpass|skipped."""
    status = result.get("status")
    message = result.get("message") or ""
    if status == "passed":
        return "passed", ""
    if status == "skipped":
        if message.startswith("XFAIL"):
            return "xfail", _xfail_reason(message)
        return "skipped", ""
    # failed / broken
    if "XPASS" in _first_line(message):
        return "xpass", _xfail_reason(message)
    return status, ""


def to_record(result):
    """Нормализовать сырой test-result в запись для разбора (форма ~ allure-raw-parser)."""
    test_path, func = _split_module_func(result.get("fullName"))
    kind, xfail_reason = classify(result)
    message = result.get("message") or ""
    exc_source = _xfail_actual(message) or message if kind == "xfail" else message
    exc_class, exc_message = _split_exception(exc_source)
    return {
        "result_id": result.get("id"),
        "allure_id": result.get("testCaseId"),
        "test_name": func,
        "test_path": test_path,
        "title": result.get("name"),
        "status": result.get("status"),
        "kind": kind,
        "xfail_reason": xfail_reason,
        "exception_class": exc_class,
        "exception_message": exc_message,
        "trace": result.get("trace") or "",
        # start/stop (мс epoch) сырого item'а — хронология для детекта окон
        # деградации стенда (STAND_INCIDENT: «Окна по времени» —
        # references/launch-input.md скилла craft:fix)
        "start": result.get("start"),
        "stop": result.get("stop"),
        "parameters": [
            {"name": p.get("name"), "value": p.get("value")}
            for p in (result.get("parameters") or [])
        ],
        "flaky": result.get("flaky"),
        "muted": result.get("muted"),
        "known": result.get("known"),
        "attachments": [],
    }


def list_attachments(client, result_id):
    """Вложения test-result'а (execution.attachments верхнего уровня)."""
    execution = client.get(f"/api/rs/testresult/{result_id}/execution")
    return execution.get("attachments") or []


def _ext_for(content_type):
    return _EXT_BY_CONTENT_TYPE.get((content_type or "").split(";")[0].strip(), "")


def download_attachments(client, result_id, dest_dir, skip_names=None):
    """Скачать вложения результата в dest_dir; вернуть список локальных путей.

    skip_names (дефолт — параметр `skip_attachments` словаря проекта) пропускаем:
    референс — «Видео», мёртвая ссылка при выключенной записи сессий.
    """
    if skip_names is None:
        skip_names = load_params()["skip_attachments"]
    os.makedirs(dest_dir, exist_ok=True)
    paths = []
    for att in list_attachments(client, result_id):
        name = att.get("name") or str(att.get("id"))
        if name in skip_names or att.get("missed"):
            continue
        att_id = att.get("id")
        content = client.get_content(f"/api/rs/testresult/attachment/{att_id}/content")
        safe = re.sub(r"[^\w.-]+", "_", name)
        path = os.path.join(dest_dir, f"{result_id}-{att_id}-{safe}{_ext_for(att.get('contentType'))}")
        with open(path, "wb") as handle:
            handle.write(content)
        paths.append(path)
    return paths


def get_launch_failures(client, launch_id, include_passed=False, attachments_dir=None):
    """Высокоуровневый вход: overview + список нормализованных не-зелёных записей.

    attachments_dir не None -> для каждой записи качаем вложения (кроме видео) туда.
    """
    overview = get_launch(client, launch_id)
    records = [
        to_record(r)
        for r in iter_results(client, launch_id)
        if include_passed or r.get("status") != "passed"
    ]
    records.sort(key=lambda r: r["start"] or 0)  # хронология прогона (окна по времени)
    if attachments_dir is not None:
        for record in records:
            record["attachments"] = download_attachments(client, record["result_id"], attachments_dir)
    return overview, records


# Genuine-падения для flake-сводки: тест реально красный и подлежит разбору
# (`craft:fix`). xfail/skipped — не падение (ожидаемо); xpass — отдельный
# сигнал (кандидат на un-xfail), не «починить тест», поэтому в fails не входит.
FAILURE_KINDS = ("failed", "broken")


def _flake_key(record):
    """Ключ агрегации теста между ланчами: allure_id, иначе путь::функция."""
    return record["allure_id"] or f'{record["test_path"]}::{record["test_name"]}'


def flake_summary(client, name_contains=None, limit=10):
    """Сводка нестабильности по последним ланчам (read-only) — вход для fix-батча.

    Берёт последние `limit` ланчей (новые сверху; `name_contains` сужает выборку до
    сопоставимых — напр. один suite/браузер/ветка/issue), агрегирует genuine-падения
    (`failed`/`broken`) каждого теста между ними. Возвращает (launches, per_test):
    per_test — список dict {key, allure_id, test_name, test_path, title, runs, fails,
    flake_rate, latest_kind}, отсортированный по убыванию flake_rate, затем fails.
    flake_rate: 0.0 = всегда зелёный, 1.0 = всегда красный (персистентная регрессия),
    между = мигает (flaky). `skipped` в runs не входит (не информативен).
    """
    launches = search_launches(client, name_contains=name_contains, limit=limit)
    stats = {}
    for launch in launches:  # новые сверху -> первый встреченный исход теста = из новейшего ланча
        for raw in iter_results(client, launch.get("id")):
            record = to_record(raw)
            if record["kind"] == "skipped":
                continue
            stat = stats.setdefault(_flake_key(record), {
                "key": _flake_key(record), "allure_id": record["allure_id"],
                "test_name": record["test_name"], "test_path": record["test_path"],
                "title": record["title"], "runs": 0, "fails": 0,
                "latest_kind": record["kind"],
            })
            stat["runs"] += 1
            if record["kind"] in FAILURE_KINDS:
                stat["fails"] += 1
    per_test = []
    for stat in stats.values():
        stat["flake_rate"] = round(stat["fails"] / stat["runs"], 2) if stat["runs"] else 0.0
        per_test.append(stat)
    per_test.sort(key=lambda s: (s["flake_rate"], s["fails"]), reverse=True)
    return launches, per_test
