"""REST-доступ к Allure TestOps (read-only) — модуль tms каталога kit.

Пакет живёт в модуле (кэш платформы, обновления привозит платформа), в репо
потребителя не копируется. Запуск CLI — шим `scripts/testops_cli.py` рядом,
из корня репо проекта (кроссплатформенно, без env-префиксов):

    python3 "<каталог модуля tms>/scripts/testops_cli.py" get 52275
    ... search 'tag = "web" and status = "Active"'
    ... list --size 10
    ... cfv 52275

Быстрый старт (как библиотека):
    from testops import TestOpsClient, get_test_case, to_plain
    client = TestOpsClient()          # endpoint/token/project: env → secrets.yaml
    tc = get_test_case(client, 52275)
    print(to_plain(tc, client.endpoint))

Только чтение: GET-эндпоинты Allure TestOps (плюс обмен api-token на JWT для
аутентификации). Запись (create/update/delete, launch, upload) сюда не входит.
Секреты — env TESTOPS_* → gitignored secrets.yaml в корне репо проекта; словарь
проекта (теги/вложения/маркер) — параметры `[tms]` в `.kit/answers.toml`
(см. `params.py` и скилл `tms:read`).
"""
from .client import TestOpsClient, TestOpsError, resolve_settings
from .launch import (
    browser_marker,
    download_attachments,
    get_launch,
    get_launch_failures,
    iter_results,
    launch_url,
    parse_launch_id,
    search_launches,
    to_record,
)
from .testcase import (
    get_custom_fields,
    get_test_case,
    linked_test_cases,
    list_test_cases,
    search_test_cases,
    to_plain,
)

__all__ = [
    "TestOpsClient",
    "TestOpsError",
    "resolve_settings",
    "get_test_case",
    "get_custom_fields",
    "search_test_cases",
    "linked_test_cases",
    "list_test_cases",
    "to_plain",
    "parse_launch_id",
    "get_launch",
    "launch_url",
    "browser_marker",
    "search_launches",
    "iter_results",
    "to_record",
    "download_attachments",
    "get_launch_failures",
]
