"""CLI к read-only REST API Allure TestOps (модуль tms каталога kit).

Запуск — шимом `scripts/testops_cli.py` модуля, из корня репо проекта
(кроссплатформенно; `<tms>` = каталог модуля в кэше платформы):

    python3 "<tms>/scripts/testops_cli.py" get <id> [--json]
    python3 "<tms>/scripts/testops_cli.py" cfv <id> [--json]
    python3 "<tms>/scripts/testops_cli.py" search "<AQL>" [--page N] [--size N] [--json]
    python3 "<tms>/scripts/testops_cli.py" list [--page N] [--size N] [--json]
    python3 "<tms>/scripts/testops_cli.py" launch <id|url> [--all] [--attachments DIR] [--json]
"""
import argparse
import json
import sys
from datetime import datetime
from pathlib import Path

from .client import TestOpsClient, TestOpsError
from .launch import (
    FAILURE_KINDS,
    browser_marker,
    flake_summary,
    get_launch_failures,
    launch_url,
    parse_launch_id,
    search_launches,
)
from .testcase import (
    get_custom_fields,
    get_test_case,
    linked_test_cases,
    list_test_cases,
    search_test_cases,
    to_plain,
)


def _force_utf8():
    # Консоль Windows по умолчанию cp1251 — кириллица из TestOps иначе побьётся.
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8")
        except (AttributeError, ValueError):
            pass


def _print_page(page):
    content = page.get("content", [])
    print(f"Найдено: {page.get('totalElements')} (на странице: {len(content)})")
    for tc in content:
        status = (tc.get("status") or {}).get("name", "")
        automation = "auto" if tc.get("automated") else "manual"
        print(f"  #{str(tc.get('id')):>7}  [{status}/{automation}]  {tc.get('name', '')}")


def _print_launch(overview, records):
    tags = ", ".join(t.get("name", "") for t in (overview.get("tags") or []))
    issues = ", ".join(i.get("name", "") for i in (overview.get("issues") or []))
    closed = "закрыт" if overview.get("closed") else "открыт"
    print(f"Ланч #{overview.get('id')} [{closed}]: {overview.get('name', '')}")
    marker = browser_marker(overview)
    if marker:
        print(f"  Браузер (target_marker): {marker}")
    if tags:
        print(f"  Теги: {tags}")
    if issues:
        print(f"  Issues: {issues}")
    from collections import Counter
    by_kind = Counter(r["kind"] for r in records)
    print(f"  Не-зелёных: {len(records)} ({dict(by_kind)})\n")
    for r in records:  # отсортированы по start — хронология видна сразу (окна деградации)
        params = " ".join(f"{p['name']}={p['value']}" for p in r["parameters"])
        when = ""
        if r.get("start"):
            t0 = datetime.fromtimestamp(r["start"] / 1000).strftime("%H:%M:%S")
            t1 = datetime.fromtimestamp(r["stop"] / 1000).strftime("%H:%M:%S") if r.get("stop") else "?"
            when = f"  {t0}-{t1}"
        head = f"  [{r['kind']}]{when} {r['test_path']}::{r['test_name']}  (TC #{r['allure_id']})"
        print(head + (f"  [{params}]" if params else ""))
        if r["xfail_reason"]:
            print(f"      xfail-reason: {r['xfail_reason']}")
        exc = r["exception_class"] + (": " if r["exception_class"] else "") + r["exception_message"]
        if exc.strip():
            print(f"      {exc[:160]}")
        if r["attachments"]:
            print(f"      вложения: {', '.join(r['attachments'])}")


def _print_flake(launches, per_test, client):
    if not launches:
        print("Ланчей не найдено (проверь --name).")
        return
    latest = launches[0]
    print(f"Агрегировано ланчей: {len(launches)} | последний #{latest.get('id')}: {latest.get('name', '')}")
    print(f"  {launch_url(client, latest.get('id'))}")
    failing = [s for s in per_test if s["latest_kind"] in FAILURE_KINDS]
    print(f"Не-зелёных в последнем ланче: {len(failing)} (из {len(per_test)} тестов в истории)\n")
    for s in failing:
        if s["flake_rate"] == 1.0 and s["runs"] >= 2:
            tag = "регрессия"   # всегда красный за всю историю
        elif s["fails"] < s["runs"]:
            tag = "flaky"       # иногда зелёный — мигает
        else:
            tag = "single"      # один прогон в истории
        tc = f" (TC #{s['allure_id']})" if s["allure_id"] else ""
        print(f"  [{tag:>9} {s['fails']}/{s['runs']} {int(s['flake_rate'] * 100):>3}%]  {s['test_name']}{tc}")
    if failing:
        ks = " or ".join(s["test_name"] for s in failing if s["test_name"])
        print(f"\nВход для fix-батча:")
        if ks:
            print(f"  -k \"{ks}\"")
        # Подсказка тем же инструментом: интерпретатор из sys.executable, шим — по
        # известному месту рядом с пакетом (scripts/testops_cli.py модуля) — не хардкодим.
        shim = Path(__file__).resolve().parent.parent / "testops_cli.py"
        print(f'  {sys.executable} "{shim}" launch {latest.get("id")} --attachments <DIR>')


def _build_parser():
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--json", action="store_true", help="вывести сырой JSON")

    parser = argparse.ArgumentParser(prog="testops", description="Read-only REST к Allure TestOps")
    sub = parser.add_subparsers(dest="command", required=True)

    get_parser = sub.add_parser("get", parents=[common], help="детали TC (overview + сценарий)")
    get_parser.add_argument("id", type=int)

    cfv_parser = sub.add_parser("cfv", parents=[common], help="custom fields + Owner")
    cfv_parser.add_argument("id", type=int)

    search_parser = sub.add_parser("search", parents=[common], help="поиск по AQL (rql)")
    search_parser.add_argument("aql")
    search_parser.add_argument("--page", type=int, default=0)
    search_parser.add_argument("--size", type=int, default=20)

    cases_parser = sub.add_parser("cases", parents=[common], help="TC, связанные с Jira-issue (AQL issue=)")
    cases_parser.add_argument("issue", help="ключ Jira-issue, например VCSAT-1234")
    cases_scope = cases_parser.add_mutually_exclusive_group()
    cases_scope.add_argument("--unautomated", action="store_true", help="только не-автоматизированные TC (без тега wont-automate)")
    cases_scope.add_argument("--automated", action="store_true", help="только автоматизированные TC (вход retest-прогона)")

    list_parser = sub.add_parser("list", parents=[common], help="листинг TC проекта")
    list_parser.add_argument("--page", type=int, default=0)
    list_parser.add_argument("--size", type=int, default=20)

    launch_parser = sub.add_parser("launch", parents=[common], help="не-зелёные результаты ланча (+вложения)")
    launch_parser.add_argument("id", help="id ланча или URL .../launch/<id>")
    launch_parser.add_argument("--all", action="store_true", help="включая passed")
    launch_parser.add_argument("--attachments", metavar="DIR", help="скачать вложения (кроме видео) в DIR")

    launches_parser = sub.add_parser("launches", parents=[common], help="список/поиск ланчей проекта (новые сверху)")
    launches_parser.add_argument("--name", help="подстрока имени (rql name ~=), например ключ Jira-issue")
    launches_parser.add_argument("--limit", type=int, default=20)

    flake_parser = sub.add_parser("flake", parents=[common], help="сводка нестабильности по последним ланчам (вход fix-батча)")
    flake_parser.add_argument("--name", help="подстрока имени ланча — сузить до сопоставимых (suite/браузер/ветка/issue)")
    flake_parser.add_argument("--limit", type=int, default=10, help="сколько последних ланчей агрегировать (дефолт 10)")

    return parser


def main(argv=None):
    _force_utf8()
    args = _build_parser().parse_args(argv)

    try:
        # Внутри try: конструктор резолвит endpoint/token/project (env → secrets.yaml)
        # и при неполном конфиге кидает TestOpsError с подсказкой.
        client = TestOpsClient()
        if args.command == "get":
            tc = get_test_case(client, args.id)
            print(json.dumps(tc, ensure_ascii=False, indent=2) if args.json else to_plain(tc, client.endpoint))
        elif args.command == "cfv":
            fields = get_custom_fields(client, args.id)
            if args.json:
                print(json.dumps(fields, ensure_ascii=False, indent=2))
            else:
                for key, value in fields.items():
                    print(f"{key}={value}")
        elif args.command == "search":
            page = search_test_cases(client, args.aql, page=args.page, size=args.size)
            print(json.dumps(page, ensure_ascii=False, indent=2)) if args.json else _print_page(page)
        elif args.command == "cases":
            cases = linked_test_cases(
                client, args.issue,
                only_unautomated=args.unautomated, only_automated=args.automated,
            )
            if args.json:
                print(json.dumps(cases, ensure_ascii=False, indent=2))
            else:
                scope = "автоматизированных " if args.automated else ("не-автоматизированных " if args.unautomated else "")
                print(f"Связано с {args.issue}: {len(cases)} {scope}TC")
                for tc in cases:
                    flag = "auto" if tc["automated"] else "manual"
                    print(f"  #{str(tc['id']):>7}  [{tc['status']}/{flag}]  {tc['name']}")
        elif args.command == "list":
            page = list_test_cases(client, page=args.page, size=args.size)
            print(json.dumps(page, ensure_ascii=False, indent=2)) if args.json else _print_page(page)
        elif args.command == "launch":
            overview, records = get_launch_failures(
                client, parse_launch_id(args.id),
                include_passed=args.all, attachments_dir=args.attachments,
            )
            if args.json:
                payload = {"launch": overview, "browser_marker": browser_marker(overview), "results": records}
                print(json.dumps(payload, ensure_ascii=False, indent=2))
            else:
                _print_launch(overview, records)
        elif args.command == "launches":
            launches = search_launches(client, name_contains=args.name, limit=args.limit)
            if args.json:
                print(json.dumps(launches, ensure_ascii=False, indent=2))
            else:
                print(f"Найдено ланчей: {len(launches)}")
                for ln in launches:
                    closed = "закрыт" if ln.get("closed") else "открыт"
                    print(f"  #{str(ln.get('id')):>6} [{closed}] {ln.get('name', '')}")
                    print(f"         {launch_url(client, ln.get('id'))}")
        elif args.command == "flake":
            launches, per_test = flake_summary(client, name_contains=args.name, limit=args.limit)
            if args.json:
                payload = {
                    "launches": [{"id": l.get("id"), "name": l.get("name")} for l in launches],
                    "tests": per_test,
                }
                print(json.dumps(payload, ensure_ascii=False, indent=2))
            else:
                _print_flake(launches, per_test, client)
    except TestOpsError as exc:
        print(f"Ошибка TestOps: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
