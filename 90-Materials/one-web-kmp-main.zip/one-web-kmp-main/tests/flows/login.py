"""Сценарная преамбула входа: UI-логин веб-клиента.

Флоу-слой (tests/flows/) — композиции page-объектов, повторяющиеся в начале
сценариев. Хелперы без страниц (REST/WS, бандл-обёртки) живут в tools/helpers/.
"""
from tests.pages.login import PLogin


def web_login(setup_aut, user, lang, page):
    """Открыть веб-клиент и войти формой Keycloak под `user` (словарь кредов)."""
    login_page = PLogin(page, lang=lang)
    login_page.open(setup_aut['setup']['app_url'])
    login_page.login(user['username'], user['password'])
