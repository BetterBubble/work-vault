"""Сценарные преамбулы чат-домена: логин + навигация до целевой поверхности.

Каждый флоу доводит свежую страницу до готового к шагам сценария состояния и
возвращает page-объект поверхности. Работают с любой страницей (в т.ч. второй
сессией из page_starter) — page передаётся явно.
"""
from tests.flows.login import web_login
from tests.pages.chat import PChat, PChatsList
from tests.pages.chat_card import PChatCard
from tests.pages.chat_creation import PChatCreation


def open_chat(setup_aut, user, lang, page, chat_name) -> PChat:
    """Логин + открыть чат `chat_name` из списка, дождаться готовности ленты."""
    web_login(setup_aut, user, lang, page)
    chats_list = PChatsList(page, lang=lang)
    chats_list.open_chat(chat_name)
    chat = PChat(page, lang=lang)
    chat.wait_opened()
    return chat


def reopen_chat(lang, page, chat_name) -> PChat:
    """Перезагрузка приложения + повторное открытие чата: свежий overlay для
    UI-переассертов после действия в попап-слое (закрытый попап оставляет
    overlay стейл-слепком — лечит только перезагрузка)."""
    chats_list = PChatsList(page, lang=lang)
    chats_list.reload_app()
    chats_list.open_chat(chat_name)
    chat = PChat(page, lang=lang)
    chat.wait_opened()
    return chat


def open_chat_card(setup_aut, user, lang, page, chat_name, kind='chat') -> PChatCard:
    """Логин + открытие чата и его карточки: общая преамбула карточных тестов."""
    chat = open_chat(setup_aut, user, lang, page, chat_name)
    chat.open_card()
    card = PChatCard(page, lang=lang, kind=kind)
    card.wait_opened()
    return card


def open_chat_creation(setup_aut, user, lang, page) -> PChatCreation:
    """Логин + карандаш: общая преамбула тестов создания чата/канала."""
    web_login(setup_aut, user, lang, page)
    creation = PChatCreation(page, lang=lang)
    creation.open_panel()
    return creation
