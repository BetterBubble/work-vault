"""Адресная книга KMP: поиск контакта и открытие его профиля."""

from tests.pages.base_page import PBase
from tests.pages.chat_card import PChatCard
from tools import i18n
from tools.enums import StepPlace
from tools.helpers.steps import step


class PAddressBook(PBase):
    @step('Открыть адресную книгу')
    def open(self):
        navigation = self.page.get_by_role(
            'button', name=i18n.get_str('navigation_contacts', self.lang),
            exact=True)
        self.compose_click(navigation, retreat=True)
        self.wait_idle(url_part='/api/')

    @step('Найти контакт "{full_name}"')
    def search_contact(self, full_name: str):
        # Межфичевый переход оставляет прежний overlay чатов, но canvas уже на
        # адресной книге. Фиксированный viewport позволяет сфокусировать поле.
        self.page.mouse.click(700, 88)
        self.page.keyboard.type(full_name, delay=30)
        self.wait_idle(url_part='/api/')

    @step('Открыть профиль контакта "{full_name}"')
    def open_contact_profile(self, full_name: str) -> PChatCard:
        # Отфильтрованный результат единственный и рисуется первой строкой под
        # поиском; его семантика отсутствует в прежнем overlay чатов.
        self.page.mouse.click(700, 145)
        self.wait_idle(url_part='/api/')
        return PChatCard(self.page, lang=self.lang, kind='p2p')
