"""Page-объекты KMP-клиента IVA ONE (Playwright).

Тест импортирует классы напрямую (from tests.pages.login import PLogin) —
строкового реестра версий нет: версия UI одна, canvas-поверхность KMP.
Базовые примитивы вождения/ожидания — tests/pages/base_page.py.
"""
