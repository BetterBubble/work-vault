"""Чаты: лендинг со списком чатов + открытый чат (лента, поле ввода).

Локаторы canvas-поверхности: первично #test_id_* (реестр tools/test_tags.py),
где testTag нет — role+имя. Строка списка чатов — role=button со склеенным
текстом (имя + время + превью), матчится по подстроке имени. Лента жёстко
виртуализируется (окно ~12 сообщений, рециклинг): конкретное сообщение
адресуемо только через scroll_until_present + filter(has_text), .nth() якорем
не является. Кнопки меню/звонков в шапке чата открывают Compose Popup —
в сценариях ленты их не трогать (Popup безвозвратно ломает overlay);
исключение — кнопка поиска: раскрывает поле внутрисценно, overlay живой.
"""
import re
from pathlib import Path

from playwright.sync_api import Locator, expect
from playwright.sync_api import TimeoutError as PlaywrightTimeoutError

from tests.pages.base_page import PANEL_X_MIN, PBase
from tools import i18n
from tools import test_tags as tags
from tools.enums import StepPlace
from tools.helpers.steps import step


class PChatsList(PBase):
    """Лендинг «Чаты» — пост-логин экран по умолчанию (навбар-навигация не нужна)."""

    @step('Отображается лендинг «Чаты»', where=StepPlace.ASSERT)
    def assert_landing_loaded(self):
        """Приложение загрузилось и показывает лендинг «Чаты» (кнопка навбара в overlay).

        exact=True обязателен: substring-матч имени ловит соседнюю «MCU-чаты».
        """
        chats_button = self.page.get_by_role(
            'button', name=i18n.get_str('chats_header', self.lang), exact=True)
        expect(chats_button).to_be_visible()

    def row(self, chat_name: str) -> Locator:
        return self.page.get_by_role('button').filter(has_text=chat_name).first

    @step('Чат "{chat_name}" отображается в списке чатов', where=StepPlace.ASSERT)
    def assert_chat_in_list(self, chat_name: str, timeout: int = 15_000):
        """Строка чата в списке; таймаут с запасом — покрывает реалтайм-доставку
        (строка появляется по WS-событию без перезагрузки)."""
        expect(self.row(chat_name)).to_be_visible(timeout=timeout)

    @step('Чат "{chat_name}" отсутствует в списке чатов', where=StepPlace.ASSERT)
    def assert_chat_not_in_list(self, chat_name: str):
        """Гейт честности нулевого матча — лендинг дорисован и сеть списка
        утихла (иначе count=0 истинен и на ещё пустом экране)."""
        chats_button = self.page.get_by_role(
            'button', name=i18n.get_str('chats_header', self.lang), exact=True)
        expect(chats_button).to_be_visible()
        self.wait_idle()
        expect(self.page.get_by_role('button').filter(has_text=chat_name)).to_have_count(0)

    @step('Открыть вкладку «Треды»')
    def open_threads_tab(self):
        """Таб-фильтр над списком чатов (in-scene, overlay живой). Имя «Треды»
        коллизирует с тоглом настроек канала и табом поиска — отсев по
        геометрии левой панели."""
        name = i18n.get_str('general_threads_label', self.lang)
        tabs = self.page.get_by_role('button', name=name, exact=True)
        tabs.first.wait_for(state='visible')
        for tab in tabs.all():
            box = tab.bounding_box()
            if box and box['x'] < PANEL_X_MIN and box['y'] < 180:
                self.compose_click(tab)
                return
        raise AssertionError('Вкладка «Треды» не найдена над списком чатов')

    @step('Открыть чат "{chat_name}"')
    def open_chat(self, chat_name: str):
        self.compose_click(self.row(chat_name))

    @step('Открыть контекстное меню чата "{chat_name}"')
    def open_chat_context_menu(self, chat_name: str):
        """Строка чата на live KMP не несёт testTag; меню открывается
        web-жестом ПКМ по свежему bbox строки.
        """
        row = self.row(chat_name)
        row.wait_for(state='visible')
        box = row.bounding_box()
        if not box:
            raise AssertionError(f'Строка чата «{chat_name}» не имеет геометрии')
        self.page.mouse.click(
            box['x'] + box['width'] / 2,
            box['y'] + box['height'] / 2,
            button='right')
        self.page.get_by_role(
            'button',
            name=i18n.get_str('chats_context_menu_item_pin', self.lang),
            exact=True).wait_for(state='visible')

    @step('Выбрать пункт «Закрепить»')
    def pin_chat(self, chat_id: str):
        """Пункт живёт в Compose Popup без live testTag; после выбора
        overlay стейлится, поэтому дальнейшее состояние проверяется REST.
        """
        pin_button = self.page.get_by_role(
            'button',
            name=i18n.get_str('chats_context_menu_item_pin', self.lang),
            exact=True)
        with self.expect_api(f'/api/v1/chats/{chat_id}/pin', 'POST') as response_info:
            self.compose_click(pin_button)
        response = response_info.value
        assert response.ok, f'Закрепление чата: HTTP {response.status}'

    @step('Найти в поиске чатов "{query}"')
    def search(self, query: str):
        """Inline-фильтр над списком: результаты — те же строки списка (open_chat).
        Поисковое поле — единственный textbox левой панели (гео-отбор)."""
        self.page.get_by_role('textbox').first.wait_for(state='visible')
        boxes = [tb for tb in self.page.get_by_role('textbox').all()
                 if (box := tb.bounding_box()) and box['x'] < PANEL_X_MIN]
        if not boxes:
            raise AssertionError('Поисковое поле списка чатов не найдено')
        self.compose_fill(boxes[0], query)


class PChat(PBase):
    """Открытый чат: лента сообщений + нижнее поле ввода."""

    def wait_opened(self, timeout: int = 15_000):
        self.page.locator(f'#{tags.CHAT_SCREEN}').wait_for(state='attached', timeout=timeout)

    @step('Открыт чат "{title}"', where=StepPlace.ASSERT)
    def assert_header_title(self, title: str):
        header = self.page.locator(f'#{tags.CHAT_HEADER_TITLE_AREA}')
        expect(header).to_contain_text(title)

    @step('Открыть карточку чата')
    def open_card(self):
        """Клик по названию в шапке → панель «О чате»/«О канале» (PChatCard)."""
        self.compose_click(self.page.locator(f'#{tags.CHAT_HEADER_TITLE_AREA}'))

    def message(self, text: str) -> Locator:
        """Локатор сообщения по тексту; доматывает ленту при необходимости."""
        target = self.page.locator(f'#{tags.CHAT_FEED_MESSAGE_ITEM}').filter(has_text=text)
        return self.scroll_until_present(
            target, self.page.locator(f'#{tags.CHAT_FEED_LAZY_COLUMN}'))

    @step('Набрать сообщение "{text}"')
    def type_message(self, text: str):
        self.compose_fill(self.page.locator(f'#{tags.CHAT_BOTTOM_FIELD_TEXT_FIELD}'), text)

    @step('Упомянуть пользователя "{query}" через @')
    def mention_user(self, query: str):
        """Композиция «ввести @query + выбрать из списка» для сценариев, где
        сам список — не объект проверки (иначе гранулярные open_mention_list /
        assert_mention_item / pick_mention_user)."""
        self.open_mention_list(query)
        self.pick_mention_user(query)

    @step('Ввести «@{query}» в поле — открыть список упоминаний')
    def open_mention_list(self, query: str):
        """Ввод «@»+query открывает mention-список (данные локальные, REST-запрос
        не уходит — сигнал готовности только узел списка). Список — часть
        композиции экрана (не Compose Popup), overlay живой; плоский, только
        участники чата (включая автора), фамилия не-участника прячет список."""
        self.compose_fill(
            self.page.locator(f'#{tags.CHAT_BOTTOM_FIELD_TEXT_FIELD}'), f'@{query}')
        self.page.locator(
            f'#{tags.CHAT_BOTTOM_FIELD_MENTION_LIST}').wait_for(state='visible')

    @step('Участник "{query}" предлагается в списке с должностью "{position}"',
          where=StepPlace.ASSERT)
    def assert_mention_item(self, query: str, position: str):
        """Строка списка — склейка «инициалы + Фамилия Имя [+ должность]»;
        должность (Keycloak-атрибут position) в overlay внутри текста строки."""
        expect(self._mention_item(query).first).to_contain_text(position)

    @step('Выбрать пользователя "{query}" из списка упоминаний')
    def pick_mention_user(self, query: str):
        """Клик по строке участника подставляет упоминание в поле (с висячим
        пробелом после); после выбора список закрывается, overlay живой."""
        self.compose_click(self._mention_item(query).first)
        self.page.locator(
            f'#{tags.CHAT_BOTTOM_FIELD_MENTION_LIST}').wait_for(state='hidden')

    def _mention_item(self, query: str) -> Locator:
        return self.page.locator(f'#{tags.CHAT_BOTTOM_FIELD_MENTION_LIST}').locator(
            f'#{tags.CHAT_BOTTOM_FIELD_MENTION_ITEM}').filter(has_text=query)

    @step('Сообщение с упоминанием "@{last_name}" и текстом "{text}" отображается в ленте',
          where=StepPlace.ASSERT)
    def assert_mention_message_rendered(self, last_name: str, text: str):
        """Один узел текста сообщения несёт И отрендеренное упоминание
        («@Фамилия…» — mention-спан живёт на canvas, но его текст в overlay
        есть), И дописанный текст. Раздельные substring-матчи не доказали бы,
        что упоминание отрендерилось именно в этом сообщении."""
        body = self.page.locator(f'#{tags.CHAT_FEED_MESSAGE_TEXT}').filter(
            has_text=re.compile(rf'@{re.escape(last_name)}.*{re.escape(text)}'))
        expect(body.first).to_be_visible()

    @step('Дописать "{text}" к сообщению в поле ввода')
    def append_to_message(self, text: str):
        """Добор в уже сфокусированное поле (после вставки меншена caret стоит в
        конце): повторный фокус-клик compose_fill поставил бы caret по точке
        клика — в середину набранного. Overlay поля после вставки меншена
        перестаёт зеркалить добираемый текст (canvas-only) — состав сообщения
        ассертится REST-ом, не полем."""
        self.page.keyboard.type(text, delay=30)

    def _send_button(self) -> Locator:
        # test_id_send_button — тег на ТИП кнопки (есть и в recorder-меню),
        # уникальность даёт скоуп внутри поля ввода.
        return self.page.locator(
            f'#{tags.CHAT_BOTTOM_FIELD_MESSAGE_INPUT} #{tags.SEND_BUTTON}')

    @step('Отправить сообщение')
    def send(self):
        with self.expect_api('/api/v1/messages', 'POST'):
            self.compose_click(self._send_button())

    @step('Прикрепить файл "{file_path.name}"')
    def attach_file(self, file_path: Path):
        """Выбрать файл через web-picker и дождаться окончания загрузки.

        Attach-трей — Compose Popup: после закрытия его overlay остаётся
        слепком, поэтому координаты Send снимаются до открытия трея.
        """
        send_button = self._send_button()
        send_button.wait_for(state='visible')
        self._attached_file_send_box = send_button.bounding_box()
        if self._attached_file_send_box is None:
            raise AssertionError('Не получен bounding box кнопки отправки')

        self.compose_click(self.page.locator(f'#{tags.CHAT_COMPOSE_SERVICE_BUTTON}'))
        tray = self.page.locator(f'#{tags.CHAT_COMPOSE_SERVICE_TRAY}')
        tray.wait_for(state='visible')
        with self.page.expect_file_chooser() as chooser_info:
            self.compose_click(tray.locator(f'#{tags.CHAT_COMPOSE_SERVICE_ATTACH}'))

        with self.expect_api('/uploads/create', 'POST') as create_info, \
                self.expect_api('/complete', 'POST') as complete_info:
            chooser_info.value.set_files(file_path)
        assert create_info.value.ok, \
            f'Начало загрузки файла: HTTP {create_info.value.status}'
        assert complete_info.value.ok, \
            f'Завершение загрузки файла: HTTP {complete_info.value.status}'

    @step('Отправить прикреплённый файл')
    def send_attached_file_blind(self):
        """Отправить staged-файл по координатам Send из живого overlay."""
        send_box = getattr(self, '_attached_file_send_box', None)
        if send_box is None:
            raise AssertionError(
                'Координаты кнопки отправки не сняты (attach_file до отправки)')
        with self.expect_api('/api/v1/messages/batch', 'POST') as response_info:
            # Запас сверх дефолтных 700: у закрытия трея после file-chooser нет
            # наблюдаемого сигнала, а недозакрытый скрим молча съедает слепой клик.
            self.click_blind(send_box, settle_ms=900)
        assert response_info.value.ok, \
            f'Отправка прикреплённого файла: HTTP {response_info.value.status}'

    @step('Диалог открыт без сообщений', where=StepPlace.ASSERT)
    def assert_feed_empty(self):
        # Гейт готовности: контейнер ленты отрендерен и у пустого чата — без него
        # count(0) по сообщениям истинен и на ещё не дорисованном экране.
        self.wait_opened()
        self.page.locator(f'#{tags.CHAT_FEED_LAZY_COLUMN}').wait_for(state='attached')
        expect(self.page.locator(f'#{tags.CHAT_FEED_MESSAGE_ITEM}')).to_have_count(0)
        # Плашка даты появляется вместе с первым сообщением — второй признак пустоты.
        expect(self.page.locator(f'#{tags.CHAT_FEED_SYSTEM_MESSAGE}')).to_have_count(0)

    @step('Сообщение "{text}" отображается в ленте', where=StepPlace.ASSERT)
    def assert_message_in_feed(self, text: str):
        message = self.page.locator(f'#{tags.CHAT_FEED_MESSAGE_ITEM}').filter(has_text=text)
        expect(message).to_have_count(1)

    @step('Сообщение "{text}" отображается в ленте в {count} экземплярах',
          where=StepPlace.ASSERT)
    def assert_message_count_in_feed(self, text: str, count: int):
        """Честен для короткой ленты (без скролла) — как assert_message_not_in_feed."""
        message = self.page.locator(f'#{tags.CHAT_FEED_MESSAGE_ITEM}').filter(has_text=text)
        expect(message).to_have_count(count)

    @step('Сообщение "{text}" отсутствует в ленте', where=StepPlace.ASSERT)
    def assert_message_not_in_feed(self, text: str):
        """Честен только для короткой ленты (без скролла): off-screen сообщений
        виртуализированной ленты в overlay нет — count 0 длинной ленты ничего
        не доказывает."""
        message = self.page.locator(f'#{tags.CHAT_FEED_MESSAGE_ITEM}').filter(has_text=text)
        expect(message).to_have_count(0)

    @step('Лента показывает сообщение "{text}"', where=StepPlace.ASSERT)
    def assert_message_visible(self, text: str):
        """Сообщение материализовано в видимой области ленты (без домотки) —
        ассерт результата авто-перехода (закреплённое, цитата)."""
        message = self.page.locator(f'#{tags.CHAT_FEED_MESSAGE_ITEM}').filter(has_text=text)
        expect(message.first).to_be_visible()

    @step('Открыть профиль автора собственного сообщения "{text}"')
    def open_own_message_author_profile(self, text: str):
        """Нажать ФИ автора внутри собственного сообщения.

        Тест-кейс требует именно эту цель. Если KMP не рисует имя автора у
        исходящего сообщения, expect падает AssertionError и не маскирует
        продуктовый блокер инфраструктурным таймаутом.
        """
        message = self.page.locator(
            f'#{tags.CHAT_FEED_MESSAGE_ITEM}').filter(has_text=text)
        author = message.locator(f'#{tags.CHAT_FEED_MESSAGE_AUTHOR_NAME}')
        expect(author).to_be_visible()
        self.compose_click(author)

    @step('Вместо поля ввода — кнопка "{button_text}"', where=StepPlace.ASSERT)
    def assert_join_button_instead_of_input(self, button_text: str):
        """Не-участник публичного чата/канала: вместо поля ввода — кнопка вступления."""
        join = self.page.get_by_role('button').filter(has_text=button_text)
        expect(join.first).to_be_visible()
        field = self.page.locator(f'#{tags.CHAT_BOTTOM_FIELD_TEXT_FIELD}')
        expect(field).to_have_count(0)

    @step('Вместо поля ввода — заглушка "{expected_text}"', where=StepPlace.ASSERT)
    def assert_write_not_allowed(self, expected_text: str):
        """Вместо поля ввода — заглушка «нельзя писать» (просмотр канала не-админом)."""
        stub = self.page.locator(f'#{tags.CHAT_BOTTOM_FIELD_WRITE_NOT_ALLOWED}')
        expect(stub).to_be_visible()
        expect(stub).to_contain_text(expected_text)
        field = self.page.locator(f'#{tags.CHAT_BOTTOM_FIELD_TEXT_FIELD}')
        expect(field).to_have_count(0)

    # --- меню сообщения --------------------------------------------------------

    @step('Открыть меню сообщения "{text}"')
    def open_message_menu(self, text: str):
        """Меню действий с сообщением открывает ЛЕВЫЙ клик по бабблу — жест
        продукта в web-сборке (ПКМ меню не открывает). Точка клика — узел
        ТЕКСТА внутри баббла: центр самого баббла у сообщения с тредом
        попадает в чип-счётчик (навигация в тред вместо меню). Меню —
        попап-слой."""
        bubble = self.page.locator(
            f'#{tags.CHAT_FEED_MESSAGE_BUBBLE}').filter(has_text=text).first
        self.compose_click(bubble.locator(f'#{tags.CHAT_FEED_MESSAGE_TEXT}').first)

    @step('Выбрать пункт меню «{label}»')
    def select_menu_item(self, label: str):
        item = self._menu_item(label).first
        item.wait_for(state='visible')
        self.compose_click(item)

    @step('В меню отображается пункт «{label}»', where=StepPlace.ASSERT)
    def assert_menu_item_present(self, label: str):
        self._wait_menu_opened()
        expect(self._menu_item(label).first).to_be_visible()

    @step('Пункт «{label}» отсутствует в меню', where=StepPlace.ASSERT)
    def assert_menu_item_absent(self, label: str):
        self._wait_menu_opened()
        expect(self._menu_item(label)).to_have_count(0)

    def _menu_item(self, label: str) -> Locator:
        """Пункт меню — только точный матч текста: substring-has_text ловит
        соседние пункты («Скопировать» матчит и «Скопировать ссылку») и узлы
        вне слоя — превью строки списка чатов (role=button) содержит текст
        сообщения и до зеркалирования попапа даёт ложный матч."""
        return self.page.get_by_role('button').filter(
            has_text=re.compile(rf'^{re.escape(label)}$'))

    def _wait_menu_opened(self):
        """Гейт готовности слоя меню — вездесущий пункт «Скопировать» (есть в
        меню любого сообщения; открытый Compose Popup держит в overlay только
        узлы слоя, поэтому нулевой матч без гейта истинен и до открытия).
        Слой зеркалится в overlay с лагом ~1s после отрисовки на canvas."""
        self._menu_item(i18n.get_str(
            'chats_context_menu_item_copy', self.lang)).first.wait_for(state='visible')

    @step('Выбрать реакцию {emoji} в меню сообщения')
    def pick_quick_reaction(self, emoji: str):
        """Бар быстрых реакций в шапке меню (9 фиксированных эмодзи-кнопок);
        выбор уходит POST /reactions/{слаг}."""
        bar = self.page.locator(f'#{tags.CHAT_CONTEXT_MENU_REACTIONS_HEADER}')
        button = bar.get_by_role('button').filter(has_text=emoji).first
        with self.expect_api('/reactions/', 'POST') as response_info:
            self.compose_click(button)
        assert response_info.value.ok, \
            f'Установка реакции: HTTP {response_info.value.status}'

    @step('Под сообщением "{text}" отображается реакция {emoji}', where=StepPlace.ASSERT)
    def assert_message_reaction(self, text: str, emoji: str):
        """Бейдж реакции в футере сообщения — склейка «эмодзи + инициалы»."""
        item = self.page.locator(f'#{tags.CHAT_FEED_MESSAGE_ITEM}').filter(has_text=text)
        badge = item.locator(f'#{tags.CHAT_FEED_MESSAGE_REACTIONS}')
        expect(badge.first).to_be_visible()
        expect(badge.first).to_contain_text(emoji)

    @step('Написать сообщение "{text}" и отправить')
    def send_message_blind(self, text: str):
        """Слепой ввод по координатам capture_input_box: экран, открытый из
        пункта меню (тред), живёт на canvas при стейл-overlay, а его поле
        ввода рисуется на тех же координатах, что поле исходного чата.
        Отправка — Enter (send-кнопка в слепке не адресуема)."""
        if getattr(self, '_input_box', None) is None:
            raise AssertionError(
                'Координаты поля ввода не сняты (capture_input_box до попапа)')
        self._send_blind(self._input_box, text, 'Отправка сообщения в тред')

    def _send_blind(self, box: dict, text: str, error_label: str):
        self.click_blind(box)
        self.page.keyboard.type(text, delay=30)
        with self.expect_api('/api/v1/messages', 'POST') as response_info:
            self.page.keyboard.press('Enter')
        assert response_info.value.ok, \
            f'{error_label}: HTTP {response_info.value.status}'

    @step('Ввести текст ответа "{text}" и отправить')
    def send_reply_blind(self, text: str):
        """Слепой ввод по координатам capture_input_box: после закрытия попапа
        меню overlay — стейл-слепок, поле ввода в нём не адресуемо (рисуется
        на прежних координатах). Отправка — Enter.

        Пауза после отправки обязательна: клиент держит server-side черновик
        сообщения (clientMessageId) до подтверждения и при перезагрузке раньше
        ~3s переотправляет его свежей сессией — сервер по clientMessageId не
        дедуплицирует, в ленте дубль. Наблюдаемого сигнала очистки черновика
        нет (HTTP-ответ POST /messages приходит ДО очистки — не гейт)."""
        if getattr(self, '_input_box', None) is None:
            raise AssertionError(
                'Координаты поля ввода не сняты (capture_input_box до попапа)')
        self._send_blind(self._input_box, text, 'Отправка ответа с цитированием')
        self.page.wait_for_timeout(5_000)

    @step('Написать сообщение "{text}" в открытом после попапа чате')
    def send_message_blind_in_opened_chat(self, text: str):
        """Материализовать p2p, открытый из popup профиля контакта.

        Закрытый dropdown оставляет стейл overlay, но поле нового чата находится
        на стандартном месте фиксированного viewport. После UI-отправки reload
        восстанавливает overlay, а p2p уже появляется в списке чатов.
        """
        input_box = {'x': 658, 'y': 857, 'width': 718, 'height': 30}
        self._send_blind(input_box, text, 'Отправка сообщения в личный чат')

    @step('Выбрать пункт «Информация»')
    def open_message_info(self):
        """Экран «Информация о сообщении» рисуется на canvas при стейл-overlay
        (переход из попапа) — наблюдаемый сигнал открытия и канал ОР «список
        прочитавших» = запрос GET /messages/{id}/info."""
        item = self.page.get_by_role('button').filter(has_text=i18n.get_str(
            'chats_context_menu_item_about_message', self.lang)).first
        with self.expect_api('/info', 'GET') as response_info:
            self.compose_click(item)
        assert response_info.value.ok, \
            f'Информация о сообщении: HTTP {response_info.value.status}'

    # --- треды -----------------------------------------------------------------

    @step('Открыть тред сообщения "{text}"')
    def open_thread(self, text: str):
        """Чип-счётчик на баббле ведёт в тред-экран с ЖИВЫМ overlay (в отличие
        от входа пунктом меню «Начать тред», оставляющего стейл-слепок);
        чип появляется при ≥1 сообщении в треде. Гейт перехода — системное
        сообщение «Начало треда»."""
        item = self.page.locator(f'#{tags.CHAT_FEED_MESSAGE_ITEM}').filter(has_text=text)
        self.compose_click(item.locator(f'#{tags.CHAT_FEED_MESSAGE_THREAD_BUTTON}').first)
        self.page.locator(f'#{tags.CHAT_FEED_SYSTEM_MESSAGE}').filter(
            has_text=i18n.get_str('threads_label_system_message_start', self.lang)
        ).first.wait_for(state='visible')

    @step('На сообщении "{text}" отображается счётчик сообщений треда',
          where=StepPlace.ASSERT)
    def assert_thread_counter(self, text: str, count: int = 1):
        """Чип «N сообщение/сообщений» на баббле родительского сообщения."""
        item = self.page.locator(f'#{tags.CHAT_FEED_MESSAGE_ITEM}').filter(has_text=text)
        counter = item.locator(f'#{tags.CHAT_FEED_MESSAGE_THREAD_BUTTON}')
        expect(counter.first).to_be_visible()
        expect(counter.first).to_contain_text(str(count))

    @step('Подписаться на тред')
    def subscribe_to_thread(self):
        """Подписка на тред == вступление в чат-тред: POST /chats/{thread_id}/join.
        Пункт «Подписаться» живёт в kebab-меню ШАПКИ треда, а не в нижнем поле —
        там у не-участника заглушка «В этом чате нельзя писать». Меню — попап-
        слой; гейт открытия — видимость самого пункта «Подписаться» (в шапке
        треда нет вездесущего «Скопировать», на который опирается _wait_menu_opened;
        testTag пункта не смонтирован — адресация role=button + текст). После
        клика попап закрывается и overlay стейлится, поэтому UI-ассертов на
        overlay после метода не делать — членство наблюдается по REST."""
        self.compose_click(self.page.locator(f'#{tags.CHAT_HEADER_MENU_BUTTON}'))
        item = self._menu_item(i18n.get_str(
            'chats_context_menu_item_subscribe', self.lang)).first
        item.wait_for(state='visible')
        with self.expect_api('/join', 'POST') as response_info:
            self.compose_click(item)
        assert response_info.value.ok, \
            f'Подписка на тред: HTTP {response_info.value.status}'

    # --- ссылки в сообщении -----------------------------------------------------

    @step('Поле ввода линкифицировало ссылку "{url}"', where=StepPlace.ASSERT)
    def assert_input_linkified(self, url: str):
        """Линкификация (по пробелу после url) добавляет https://-префикс; текст
        поля при штатном наборе зеркалится в overlay. Цвет ссылки — canvas-only."""
        field = self.page.locator(f'#{tags.CHAT_BOTTOM_FIELD_TEXT_FIELD}')
        expect(field).to_contain_text(f'https://{url}')

    @step('Открыть контекстное меню на ссылке в сообщении')
    def open_link_context_menu(self, link_text: str):
        """ПКМ по зоне ссылки: пункт «Скопировать ссылку» появляется в меню,
        только когда курсор на ссылке (link-at-cursor резолвится по offset
        клика; левый клик по ссылке открывает url новой вкладкой). Ссылка
        стоит в начале текста — точка клика у левого края первой строки
        текстового узла."""
        self._context_menu_at_text_start(link_text)

    @step('Открыть контекстное меню на упоминании в сообщении')
    def open_mention_context_menu(self, text: str):
        """ПКМ по зоне упоминания: сообщение начинается с меншена, поэтому левый
        край первой строки текстового узла гарантированно в mention-спане
        (спан живёт только на canvas — отдельного узла overlay у «@ФИ» нет,
        текст сообщения зеркалится одним узлом). Только ПКМ и без hover-задержки:
        левый клик по меншену открывает canvas-only экран «О контакте» и морозит
        overlay (возврат — лишь reload)."""
        self._context_menu_at_text_start(text)

    def _context_menu_at_text_start(self, text: str):
        """ПКМ по левому краю первой строки текстового узла сообщения — точка
        попадает в начальный спан текста (ссылку/меншен)."""
        body = self.page.locator(
            f'#{tags.CHAT_FEED_MESSAGE_TEXT}').filter(has_text=text).first
        body.wait_for(state='visible')
        box = body.bounding_box()
        if box is None:
            raise AssertionError('Не получен bounding box текста сообщения')
        self.page.mouse.click(box['x'] + 20, box['y'] + 12, button='right')

    @step('Подтвердить удаление в диалоге')
    def confirm_delete_message(self):
        """Модальный диалог «Вы хотите удалить сообщение?»: пока он открыт,
        overlay содержит ТОЛЬКО узлы диалога — кнопка «Удалить» уникальна
        (коллизии с одноимённым пунктом меню нет). Подтверждение уходит
        DELETE /messages/batch."""
        self.page.get_by_text(i18n.get_str('chat_delete_message_header', self.lang),
                              exact=True).wait_for(state='visible')
        delete_button = self.page.get_by_role(
            'button', name=i18n.get_str('chat_delete_message_button_delete', self.lang),
            exact=True)
        with self.expect_api('/api/v1/messages/batch', 'DELETE') as response_info:
            self.compose_click(delete_button)
        assert response_info.value.ok, \
            f'Удаление сообщения: HTTP {response_info.value.status}'

    def capture_input_box(self):
        """Снять координаты поля ввода ДО открытия попап-слоя: после его
        закрытия overlay — стейл-слепок, свежий bbox не снять (слепые
        действия — по этому слепку)."""
        box = self.page.locator(f'#{tags.CHAT_BOTTOM_FIELD_TEXT_FIELD}').bounding_box()
        if box is None:
            raise AssertionError('Не получен bounding box поля ввода')
        self._input_box = box

    @step('Вставить скопированное в поле ввода и отправить')
    def paste_captured_and_send(self):
        """Слепой фокус в поле по координатам capture_input_box + Ctrl+V + Enter
        (send-кнопка после попапа — тоже стейл, Enter отправляет без неё)."""
        if getattr(self, '_input_box', None) is None:
            raise AssertionError(
                'Координаты поля ввода не сняты (capture_input_box до попапа)')
        self.paste_blind(self._input_box)
        with self.expect_api('/api/v1/messages', 'POST') as response_info:
            self.page.keyboard.press('Enter')
        assert response_info.value.ok, \
            f'Отправка вставленного сообщения: HTTP {response_info.value.status}'

    @step('Открыть список отреагировавших из меню сообщения')
    def open_reactions_list(self):
        """Пункт «N реакция/реакции» меню (plural со счётчиком — матч по основе
        слова) открывает bottom sheet со списком отреагировавших."""
        item = self.page.get_by_role('button').filter(has_text=re.compile(
            i18n.get_str('chat_message_context_menu_reactions_stem', self.lang))).first
        self.compose_click(item)
        self.page.locator(f'#{tags.CHAT_REACTIONS_BOTTOM_SHEET}').wait_for(
            state='visible')

    @step('В списке отреагировавших — «{full_name}» с реакцией {emoji}',
          where=StepPlace.ASSERT)
    def assert_reaction_author(self, full_name: str, emoji: str):
        """Строка шита — склейка «инициалы + ФИО + эмодзи»."""
        row = self.page.locator(f'#{tags.CHAT_REACTIONS_BOTTOM_SHEET}').get_by_role(
            'button').filter(has_text=full_name)
        expect(row.first).to_be_visible()
        expect(row.first).to_contain_text(emoji)

    @step('Сообщение "{reply_text}" содержит цитату исходного "{quoted_text}"',
          where=StepPlace.ASSERT)
    def assert_reply_quote(self, reply_text: str, quoted_text: str):
        """Превью цитаты внутри reply-сообщения несёт автора и текст исходного
        (склейка «АвторТекст»); скоуп итемом reply-сообщения — текст исходного
        есть в ленте и отдельным сообщением. Гейт готовности: после перезагрузки
        лента материализуется в overlay одной пачкой с лагом до ~12s (дефолтный
        таймаут expect живёт на кромке)."""
        self.page.locator(f'#{tags.CHAT_FEED_MESSAGE_ITEM}').first.wait_for(
            state='attached', timeout=20_000)
        reply_item = self.page.locator(
            f'#{tags.CHAT_FEED_MESSAGE_ITEM}').filter(has_text=reply_text)
        quote = reply_item.locator(f'#{tags.CHAT_FEED_MESSAGE_REPLY_PREVIEW}')
        expect(quote).to_be_visible()
        expect(quote).to_contain_text(quoted_text)

    @step('Нажать на цитату в сообщении "{reply_text}"')
    def click_quote(self, reply_text: str, parent_message_id: str):
        """Клик по превью цитаты внутри reply-сообщения → переход к родительскому
        сообщению (окно ленты центрируется на нём). Тег превью per-type — скоуп
        итемом reply-сообщения; гейт перехода — запрос ленты с offsetId родителя.
        """
        reply_item = self.page.locator(
            f'#{tags.CHAT_FEED_MESSAGE_ITEM}').filter(has_text=reply_text)
        quote = reply_item.locator(f'#{tags.CHAT_FEED_MESSAGE_REPLY_PREVIEW}')
        with self.expect_api(f'offsetId={parent_message_id}'):
            self.compose_click(quote)

    @step('Лента показывает текст сообщения "{text}"', where=StepPlace.ASSERT)
    def assert_message_body_visible(self, text: str):
        """Виден узел ТЕКСТА сообщения (не итем): в reply-сообщении текст родителя
        склеен внутри превью цитаты — item-матчер дал бы ложный позитив ещё до
        перехода. Текст при подмене окна ленты красится позже баблов (~1s) —
        expect дожидается."""
        body = self.page.locator(f'#{tags.CHAT_FEED_MESSAGE_TEXT}').filter(has_text=text)
        expect(body.first).to_be_visible()

    # --- медиа в ленте ---------------------------------------------------------

    def video_thumbnail(self) -> Locator:
        """Медиа-контейнер видео-сообщения: внутренние теги медиа (PREVIEWABLE_ITEM,
        PLAY_BUTTON) в сборке не смонтированы — контейнер общий (files_row), видео
        различается текстовым бейджем длительности mm:ss."""
        return self.page.locator(f'#{tags.CHAT_FEED_MESSAGE_FILES_ROW}').filter(
            has_text=re.compile(r'\d{2}:\d{2}')).first

    @step('Медиа-сообщения отображаются в ленте', where=StepPlace.ASSERT)
    def assert_media_feed_rendered(self):
        """Лента с вложениями отрендерилась: медиа-контейнеры материализованы."""
        expect(self.page.locator(f'#{tags.CHAT_FEED_MESSAGE_FILES_ROW}').first
               ).to_be_visible()

    @step('Видео отображается превью в ленте', where=StepPlace.ASSERT)
    def assert_video_thumbnail_visible(self):
        expect(self.video_thumbnail()).to_be_visible()

    @step('Аудиофайл "{name_part}" отображается карточкой в ленте', where=StepPlace.ASSERT)
    def assert_audio_message_visible(self, name_part: str):
        card = self.page.locator(f'#{tags.CHAT_FEED_MESSAGE_AUDIO_ITEM}').filter(
            has_text=name_part)
        expect(card.first).to_be_visible()

    @step('Документ "{file_name}" отображается в ленте', where=StepPlace.ASSERT)
    def assert_file_message_visible(self, file_name: str):
        # Внутренний FILE_ITEM в web-сборке не смонтирован; общий files-row
        # содержит имя документа и остаётся точным внутри чата с одним файлом.
        document = self.page.locator(f'#{tags.CHAT_FEED_MESSAGE_FILES_ROW}').filter(
            has_text=file_name)
        expect(document.first).to_be_visible()

    @step('Нажать воспроизведение аудиофайла')
    def play_audio_message(self):
        """Кнопка Play — единственная безымянная кнопка внутри карточки аудио.
        ОР — уходит запрос аудио-потока (audio.mp3Url либо оригинал /download);
        его отсутствие = ненаступление ОР, поэтому таймаут ожидания конвертируется
        в AssertionError (это продуктовое падение, не инфраструктура)."""
        card = self.page.locator(f'#{tags.CHAT_FEED_MESSAGE_AUDIO_ITEM}').first
        play = card.locator('[role="button"]').first
        try:
            with self.page.expect_response(
                    lambda r: '/mp3' in r.url or '/download' in r.url,
                    timeout=10_000):
                self.compose_click(play)
        except PlaywrightTimeoutError:
            raise AssertionError(
                'Запрос воспроизведения аудио (mp3/download) не ушёл') from None

    @step('Открыть видео в просмотрщике')
    def open_video_viewer(self):
        self.compose_click(self.video_thumbnail())

    @step('Проскроллить ленту до сообщения "{text}"')
    def scroll_to_message(self, text: str):
        self.message(text)

    @step('Превью загружены без запроса оригиналов', where=StepPlace.ASSERT)
    def assert_previews_without_download(self):
        """Рендер медиа тянет preview-эндпоинты, запросов оригинала (/download)
        нет. Требует start_request_capture('/uploads/') до открытия чата."""
        assert any('/preview' in url for url in self.captured_requests), \
            'Превью не запрашивались вовсе'
        downloads = [url for url in self.captured_requests if '/download' in url]
        assert not downloads, f'Ушли запросы оригинала: {downloads}'

    # --- закреплённые сообщения ----------------------------------------------

    def wait_pinned_bar(self, timeout: int = 10_000):
        # тег элемента плашки (PINNED_MESSAGE_ITEM) в сборке не навешан —
        # якорь = контейнер плашки в шапке
        self.page.locator(f'#{tags.CHAT_HEADER_PINNED_MESSAGES}').wait_for(
            state='visible', timeout=timeout)

    @step('Плашка закреплённого сообщения показывает "{text}"', where=StepPlace.ASSERT)
    def assert_pinned_bar_shows(self, text: str):
        """Плашка в шапке — склейка «Закрепленное сообщение N/M + текст»."""
        bar = self.page.locator(f'#{tags.CHAT_HEADER_PINNED_MESSAGES}')
        expect(bar).to_be_visible()
        expect(bar).to_contain_text(text)

    @step('Нажать на закреплённое сообщение в шапке чата')
    def go_to_pinned_message(self):
        self.compose_click(self.page.locator(f'#{tags.CHAT_HEADER_PINNED_MESSAGES}'))

    @step('Открыть список закреплённых сообщений')
    def open_pinned_messages_list(self):
        self.compose_click(
            self.page.locator(f'#{tags.CHAT_HEADER_PINNED_MESSAGES_LIST_BUTTON}').first)


class PPinnedMessages(PBase):
    """Экран «Закреплённые сообщения» (внутрифичевая навигация, overlay живой)."""

    def wait_opened(self, timeout: int = 10_000):
        self.page.locator(f'#{tags.CHAT_PINNED_MESSAGES_HEADER}').wait_for(
            state='attached', timeout=timeout)

    @step('Закреплённое сообщение "{text}" отображается в списке', where=StepPlace.ASSERT)
    def assert_pinned_message_present(self, text: str):
        message = self.page.locator(f'#{tags.CHAT_FEED_MESSAGE_ITEM}').filter(has_text=text)
        expect(message).to_have_count(1)

    @step('Поле ввода на экране закреплённых отсутствует', where=StepPlace.ASSERT)
    def assert_no_input(self):
        field = self.page.locator(f'#{tags.CHAT_BOTTOM_FIELD_TEXT_FIELD}')
        expect(field).to_have_count(0)
