"""Полноэкранный просмотрщик медиа (открывается кликом по вложению в ленте).

Уникальное исключение из правила «попап → стейл-overlay»: вьюер — fullscreen-
оверлей, после закрытия которого overlay остаётся живым (доказано liveness-
пробой разведки). Воспроизведение видео — настоящий DOM-элемент <video>
с blob-src (честный якорь вне canvas); закрытие — именованная кнопка
«Закрыть» либо Escape. Видео во вьюере играет ОРИГИНАЛ файла (/download),
а не video.preview.url.
"""
import re

from playwright.sync_api import expect

from tests.pages.base_page import PBase
from tools import i18n
from tools.enums import StepPlace
from tools.helpers.steps import step


class PMediaViewer(PBase):
    def wait_opened(self, timeout: int = 10_000):
        self.page.get_by_role(
            'button', name=i18n.get_str('general_close_label', self.lang),
            exact=True).wait_for(state='visible', timeout=timeout)

    @step('Видео воспроизводится в просмотрщике', where=StepPlace.ASSERT)
    def assert_video_playing(self):
        """Воспроизведение = DOM-элемент <video> с blob-источником появился
        (клиент фетчит оригинал в blob и автоплеит)."""
        video = self.page.locator('video')
        expect(video).to_be_visible()
        expect(video).to_have_attribute('src', re.compile(r'^blob:'))

    @step('Закрыть просмотрщик')
    def close(self):
        self.compose_click(self.page.get_by_role(
            'button', name=i18n.get_str('general_close_label', self.lang),
            exact=True))
