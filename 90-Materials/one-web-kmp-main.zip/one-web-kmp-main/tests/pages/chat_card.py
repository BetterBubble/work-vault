"""Карточка чата/канала («О чате»/«О канале») и её под-экраны.

Открывается кликом по названию в шапке чата (PChat.open_card). Панель
внутрисценная: строки-кнопки адресуемы role+text (testTag'ов нет), служебные
кнопки (карандаш, галка подтверждения, тоглы) — безымянные, адресуются
геометрией (viewport фиксирован conftest'ом: 1440×900). Под-экраны:

- «Изменить чат»: текстбоксы названия/описания (гео-отбор по правой панели),
  счётчик символов описания, «Выбрать фото» (DOM filechooser); сохранение —
  безымянная галка правого верхнего угла → PATCH /chats/{id};
- «Настройки чата»: тоглы публичности/реакций/тредов, применяются той же
  галкой → PATCH /chats/{id};
- bottom-sheet «Уведомления»: попап-слой. После выбора шит закрывается, а
  overlay остаётся его стейл-слепком — повторное открытие только слепым
  кликом по координатам строки, снятым до первого открытия. Живой шит
  перезаписывает слепок, поэтому ассерт кнопки шита честен: ожидаемая
  кнопка («Включить» после выключения и наоборот) в слепке отсутствует.
  Выбор в шите шлёт POST /chats/{id}/mute; статус в строке карточки после
  этого не перечитать (слепок), а после перезагрузки клиент серверный
  isMuted не подтягивает — состояние подтверждают REST и сам шит.
"""
from playwright.sync_api import Locator, expect

from tests.pages.base_page import PANEL_X_MIN, PBase
from tools import i18n
from tools.enums import StepPlace
from tools.helpers.steps import step

TOP_BAR_Y_MAX = 60  # верхняя полоса панели (назад, заголовок, карандаш/галка)


def _panel_textbox(page, index: int) -> Locator:
    """Текстбоксы правой панели сверху вниз.

    Плоский overlay не даёт контейнера панели — постоянный textbox-фильтр
    левого списка чатов отсекается по геометрии.
    """
    boxes = [(tb, box) for tb in page.get_by_role('textbox').all()
             if (box := tb.bounding_box()) and box['x'] > PANEL_X_MIN]
    boxes.sort(key=lambda pair: pair[1]['y'])
    if index >= len(boxes):
        raise AssertionError(f'На панели меньше {index + 1} полей ввода')
    return boxes[index][0]


def _panel_list(page) -> Locator:
    """Список (role=list) правой панели — гео-отсев списков левой части."""
    lists = [lst for lst in page.get_by_role('list').all()
             if (box := lst.bounding_box()) and box['x'] > PANEL_X_MIN]
    if not lists:
        raise AssertionError('Список правой панели не найден')
    return lists[0]


def _click_top_action(pbase: PBase):
    # карандаш на карточке/экране участников, галка подтверждения под-экранов —
    # самая правая безымянная кнопка верхней полосы панели
    pbase.click_unnamed_button(
        lambda b: b['y'] < TOP_BAR_Y_MAX and b['x'] > 1200,
        'кнопка правого верхнего угла панели',
        pick=lambda boxes: max(boxes, key=lambda b: b['x']))

_KIND_KEYS = {
    'chat': {
        'about': 'chat_card_about_chat',
        'toggle_public': 'create_group_chat_toggle_public',
        'members_section': 'create_chat_members_label',
        'delete_row': 'all_tabs_context_menu_delete_chat',
        'delete_dialog_stem': 'chat_card_delete_chat_dialog_stem',
    },
    'channel': {
        'about': 'chat_card_about_channel',
        'toggle_public': 'create_channel_toggle_public',
        'members_section': 'create_channel_subscribers_label',
        'delete_row': 'all_tabs_context_menu_delete_channel',
        'delete_dialog_stem': 'chat_card_delete_channel_dialog_stem',
    },
    # p2p-карточка — профиль собеседника: аватар, ФИО, действия, строка
    # «Уведомления», контакты; настроек/редактирования нет
    'p2p': {
        'about': 'chat_card_about_contact',
    },
}


class PChatCard(PBase):
    def __init__(self, page, lang: str = 'ru', kind: str = 'chat'):
        super().__init__(page, lang)
        self._kind = kind  # 'chat' (групповой) | 'channel'
        self._notifications_row_box = None

    def _key(self, name: str) -> str:
        return i18n.get_str(_KIND_KEYS[self._kind][name], self.lang)

    def _row(self, text: str) -> Locator:
        return self.page.get_by_role('button').filter(has_text=text).first

    def _click_top_action(self):
        _click_top_action(self)

    # --- карточка ---------------------------------------------------------------

    def wait_opened(self, timeout: int = 10_000):
        self.page.get_by_text(self._key('about'), exact=True).wait_for(
            state='visible', timeout=timeout)

    @step('Описание "{text}" отображается в карточке', where=StepPlace.ASSERT)
    def assert_description(self, text: str):
        expect(self.page.get_by_text(text, exact=True)).to_be_visible()

    @step('Название "{name}" отображается в карточке', where=StepPlace.ASSERT)
    def assert_chat_name(self, name: str):
        expect(self.page.get_by_text(name, exact=True).first).to_be_visible()

    @step('Профиль контакта "{full_name}" открыт', where=StepPlace.ASSERT)
    def assert_contact_profile_opened(self, full_name: str):
        expect(self.page.get_by_text(
            i18n.get_str('chat_card_about_contact', self.lang),
            exact=True)).to_be_visible()
        expect(self.page.get_by_text(full_name, exact=True).first).to_be_visible()

    @step('Открыть личный чат из профиля контакта')
    def open_direct_chat(self):
        # Профиль открыт внутри Address Book, пока overlay остался от экрана
        # чатов. Кнопка «Ещё» имеет стабильную позицию action-row;
        # открытый ею новый dropdown уже даёт живой именованный слой.
        self.page.mouse.click(1255, 265)
        action = self.page.get_by_text(
            i18n.get_str('user_profile_type_message_button', self.lang),
            exact=True)
        expect(action).to_be_visible()
        self.compose_click(action)

    @step('Открыть галерею «{category}»')
    def open_gallery(self, category: str):
        """Строка медиа-категории карточки («Изображения N» — склейка имени
        со счётчиком; появляется только у непустой категории) → экран галереи
        с вкладками (PChatGallery). category — ключ i18n (media_header_*)."""
        self.compose_click(self._row(i18n.get_str(category, self.lang)))

    @step('Открыть участников')
    def open_members(self) -> 'PChatMembers':
        """Строка «Участники N»/«Подписчики N» → экран участников; готовность
        гейтится загрузкой списка членов (GET /chats/{id}/members)."""
        row = self._row(self._key('members_section'))
        with self.expect_api('/members', 'GET'):
            self.compose_click(row)
        return PChatMembers(self.page, lang=self.lang)

    # --- копирование ссылки -------------------------------------------------------

    @step('Нажать «Копировать ссылку»')
    def copy_link(self):
        self.compose_click(self._row(i18n.get_str('chat_card_copy_link', self.lang)))

    @step('Отображается подтверждение «Ссылка скопирована»', where=StepPlace.ASSERT)
    def assert_link_copied(self):
        # строка карточки меняет текст на «Ссылка скопирована» (тост с тем же
        # текстом появляется внизу, но живёт секунды — якорь по строке стабильнее)
        copied = self._row(i18n.get_str('chat_card_link_copied', self.lang))
        expect(copied).to_be_visible()

    # --- удаление чата/канала ------------------------------------------------------

    @step('Нажать строку удаления на карточке')
    def open_delete_dialog(self):
        """Строка «Удалить чат»/«Удалить канал» (есть только у владельца) →
        первый диалог подтверждения. Гейт открытия — инвариантный фрагмент
        заголовка диалога (заголовок — листовой узел без role)."""
        self.compose_click(self._row(self._key('delete_row')))
        self.page.get_by_text(self._key('delete_dialog_stem')).first.wait_for(
            state='visible')

    @step('Дважды подтвердить удаление в диалогах')
    def confirm_delete(self):
        """Удаление двухшаговое: «Удалить» первого диалога открывает второй
        («…без возможности восстановления?»), DELETE /chats/{id} уходит
        только после второго. exact-имя кнопки отсекает строку карточки
        («Удалить» ≠ «Удалить чат»); при открытом диалоге overlay держит
        только его узлы. bbox второго диалога снимается заново — попап
        пересоздаётся со сдвигом."""
        delete_button = self.page.get_by_role(
            'button', name=i18n.get_str('chat_card_delete_confirm_button', self.lang),
            exact=True)
        self.compose_click(delete_button.first)
        self.page.get_by_text(i18n.get_str(
            'chat_card_delete_final_dialog_stem', self.lang)).first.wait_for(
            state='visible')
        with self.expect_api('/api/v1/chats/', 'DELETE') as response_info:
            self.compose_click(delete_button.first)
        assert response_info.value.ok, \
            f'Удаление чата: HTTP {response_info.value.status}'

    # --- уведомления (bottom-sheet) ----------------------------------------------

    def _sheet_button(self, key: str) -> Locator:
        return self.page.get_by_role('button').filter(
            has_text=i18n.get_str(key, self.lang)).first

    @step('Открыть управление уведомлениями')
    def open_notifications_sheet(self):
        row = self._row(i18n.get_str('chat_card_notifications', self.lang))
        row.wait_for(state='visible')
        # координаты строки — для слепого переоткрытия после закрытия шита
        self._notifications_row_box = row.bounding_box()
        self.compose_click(row)

    @step('Снова открыть управление уведомлениями')
    def reopen_notifications_sheet(self):
        box = self._notifications_row_box
        if box is None:
            raise AssertionError(
                'Шит уведомлений ещё не открывался — координаты строки не сняты')
        self.click_blind(box)

    @step('Выключить уведомления')
    def turn_off_notifications(self):
        with self.expect_api('/mute', 'POST'):
            self.compose_click(self._sheet_button('chat_card_notifications_turn_off'))

    @step('Включить уведомления')
    def turn_on_notifications(self):
        with self.expect_api('/mute', 'POST'):
            self.compose_click(self._sheet_button('chat_card_notifications_turn_on'))

    @step('Уведомления выключены: лист предлагает «Включить»', where=StepPlace.ASSERT)
    def assert_notifications_muted(self):
        expect(self._sheet_button('chat_card_notifications_turn_on')).to_be_visible()

    @step('Уведомления включены: лист предлагает «Выключить»', where=StepPlace.ASSERT)
    def assert_notifications_unmuted(self):
        expect(self._sheet_button('chat_card_notifications_turn_off')).to_be_visible()

    # --- настройки -----------------------------------------------------------------

    def _panel_text(self, text: str) -> Locator:
        """Текстовый узел правой панели: табы фильтра списка чатов слева
        дублируют тексты строк настроек («Треды») — узел отбирается геометрией."""
        nodes = self.page.get_by_text(text, exact=True)
        nodes.first.wait_for(state='visible')
        for node in nodes.all():
            box = node.bounding_box()
            if box and box['x'] > PANEL_X_MIN:
                return node
        raise AssertionError(f'Текст "{text}" не найден на правой панели')

    @step('Открыть настройки')
    def open_settings(self):
        self.compose_click(self._row(i18n.get_str('chat_card_settings', self.lang)))
        self._panel_text(self._key('toggle_public'))

    @step('Включить тогл публичности')
    def toggle_public(self):
        self.click_row_toggle(self._panel_text(self._key('toggle_public')))

    @step('Включить тогл реакций')
    def toggle_reactions(self):
        self.click_row_toggle(self._panel_text(
            i18n.get_str('info_channel_profile_reactions_toggle_label', self.lang)))

    @step('Включить тогл тредов')
    def toggle_threads(self):
        self.click_row_toggle(self._panel_text(
            i18n.get_str('info_channel_profile_threads_toggle_label', self.lang)))

    @step('Подтвердить настройки')
    def confirm_settings(self):
        with self.expect_api('/api/v1/chats/', 'PATCH') as response_info:
            self._click_top_action()
        assert response_info.value.ok, \
            f'Сохранение настроек: HTTP {response_info.value.status}'

    # --- редактирование --------------------------------------------------------------

    @step('Открыть редактирование')
    def open_edit(self):
        self._click_top_action()
        self._row(i18n.get_str('chat_card_select_photo', self.lang)).wait_for(
            state='visible')

    def _panel_textbox(self, index: int) -> Locator:
        """Текстбоксы панели сверху вниз: 0 — название, 1 — описание."""
        return _panel_textbox(self.page, index)

    @step('Ввести название "{name}"')
    def fill_name(self, name: str, *, clear: bool = True):
        self.compose_fill(self._panel_textbox(0), name, clear=clear)

    @step('Нажать кнопку очистки названия')
    def clear_name(self):
        """Кнопка «X» у правого края поля названия (безымянная — по геометрии)."""
        box = self._panel_textbox(0).bounding_box()
        if box is None:
            raise AssertionError('Не получен bounding box поля названия')
        center_y = box['y'] + box['height'] / 2
        self.click_unnamed_button(
            lambda b: abs(b['y'] + b['height'] / 2 - center_y) < 25
            and b['x'] > box['x'] + box['width'] - 60,
            'кнопка очистки поля названия')

    @step('Выбрать картинку аватара')
    def select_photo(self, file_path: str):
        """Строка «Выбрать фото» открывает DOM filechooser; превью выбранного
        аватара рисуется только на canvas."""
        with self.page.expect_file_chooser() as chooser_info:
            self.compose_click(
                self._row(i18n.get_str('chat_card_select_photo', self.lang)))
        chooser_info.value.set_files(file_path)

    @step('Ввести описание "{text}"')
    def fill_description(self, text: str):
        self.compose_fill(self._panel_textbox(1), text)

    @step('Счётчик символов описания показывает {count}', where=StepPlace.ASSERT)
    def assert_description_counter(self, count: int):
        # счётчик «N/200» появляется у поля описания при вводе
        expect(self.page.get_by_text(f'{count}/200', exact=True)).to_be_visible()

    @step('Сохранить изменения')
    def save_edit(self):
        with self.expect_api('/api/v1/chats/', 'PATCH') as response_info:
            self._click_top_action()
        assert response_info.value.ok, \
            f'Сохранение чата: HTTP {response_info.value.status}'


class PChatMembers(PBase):
    """Экран «Участники»/«Подписчики» карточки: просмотр и добавление участника.

    Весь флоу внутрисценный, overlay живой: карандаш (edit-режим) → строка
    «Добавить участника» (одинакова для группы и канала) → пикер контактов
    (справочник + поиск через /api/v2/users/search) → галка (подтвердить выбор,
    возврат в edit-режим с локальным снапшотом) → галка (подтвердить изменение,
    POST /chats/{id}/members). Квирки:
    - чекбоксы пикера и заголовок «Выбрано N» — canvas-only; наблюдаемый сигнал
      выбора — чип «Фамилия И» над списком (exact-матч имени отсекает строку
      справочника со склейкой «ИИФамилия Имя»);
    - счётчик «Участники N» самой карточки после добавления — стейл вплоть до
      полной перезагрузки: результат ассертится строкой на этом экране + REST;
    - ФИО добавленного попадает и в превью строки чата слева (системное
      сообщение «добавил (-а) в чат») — текстовые матчи скоупятся списком панели.
    """

    def _add_member_row(self) -> Locator:
        return self.page.get_by_role('button').filter(
            has_text=i18n.get_str('add_chat_member', self.lang)).first

    def member_row(self, full_name: str) -> Locator:
        """Строка участника на правой панели.

        Экран просмотра участников не размечает строки контейнером role=list,
        а то же ФИО может встречаться в системном сообщении списка чатов слева.
        Поэтому строка скоупится собственной геометрией, а не родителем.
        """
        rows = self.page.get_by_role('button').filter(has_text=full_name)
        for row in rows.all():
            box = row.bounding_box()
            if box and box['x'] > PANEL_X_MIN:
                return row
        return rows.nth(rows.count())  # compose_click сообщит, что строка не появилась

    def _member_list_live(self, anchor_name: str) -> Locator:
        """Живой список правой панели, содержащий известную строку участника.

        ФИО может одновременно попасть в превью чата слева; правая панель
        смонтирована в overlay позже, поэтому при коллизии берётся последний
        список. Ни список, ни его строки здесь не превращаются в снапшот.
        """
        anchor = self.page.get_by_role('button').filter(has_text=anchor_name)
        return self.page.get_by_role('list').filter(has=anchor).last

    def _member_row_live(self, full_name: str, anchor_name: str = None) -> Locator:
        """Живой локатор строки правой панели для web-first ассертов.

        Контейнер и его дочерние строки Playwright пересчитывает при каждом
        retry expect. Снапшот строк member_row остаётся только методам-действиям,
        где bbox нужен непосредственно перед кликом.
        """
        return self._member_list_live(anchor_name or full_name).get_by_role(
            'button').filter(
            has_text=full_name)

    @step('Открыть действия участника "{full_name}"')
    def open_member_actions(self, full_name: str):
        self.compose_click(self.member_row(full_name))

    @step('Открыть профиль участника "{full_name}"')
    def open_member_profile(self, full_name: str) -> PChatCard:
        self.compose_click(self.member_row(full_name))
        return PChatCard(self.page, lang=self.lang, kind='p2p')

    @step('Назначить участника администратором')
    def promote_to_admin(self):
        action = self.page.get_by_text(
            i18n.get_str('group_chat_profile_make_admin_btn', self.lang),
            exact=True)
        with self.expect_api('/members', 'POST') as response_info:
            self.compose_click(action)
        assert response_info.value.ok, \
            f'Назначение администратора: HTTP {response_info.value.status}'

    @step('Открыть диалог передачи прав владельца')
    def open_transfer_owner_dialog(self):
        self.compose_click(self.page.get_by_text(
            i18n.get_str('group_chat_profile_transfer_owner_btn', self.lang),
            exact=True))
        warning_title = i18n.get_str(
            'chat_members_transfer_owner_warning_title', self.lang)
        expect(self.page.get_by_text(warning_title, exact=True)).to_be_visible()

    @step('Подтвердить передачу прав владельца')
    def confirm_transfer_owner(self):
        confirm = self.page.get_by_text(
            i18n.get_str('group_chat_profile_transfer_owner_confirm_btn', self.lang),
            exact=True)
        with self.expect_api('/api/v1/chats/', 'PATCH') as response_info:
            self.compose_click(confirm)
        assert response_info.value.ok, \
            f'Передача прав владельца: HTTP {response_info.value.status}'

    @step('Открыть диалог удаления участника')
    def open_remove_member_dialog(self):
        self.compose_click(self.page.get_by_text(
            i18n.get_str('chat_members_remove_action', self.lang), exact=True))

    @step('Подтвердить удаление участника')
    def confirm_remove_member(self):
        confirm = self.page.get_by_text(
            i18n.get_str('chat_members_remove_confirm_btn', self.lang),
            exact=True)
        with self.expect_api('/members', 'POST') as response_info:
            self.compose_click(confirm)
        assert response_info.value.ok, \
            f'Удаление участника: HTTP {response_info.value.status}'

    @step('Участник "{full_name}" имеет роль "{role_key}"', where=StepPlace.ASSERT)
    def assert_member_role(self, full_name: str, role_key: str):
        expect(self._member_row_live(full_name).first).to_contain_text(
            i18n.get_str(role_key, self.lang))

    @step('Участник "{full_name}" отсутствует в списке', where=StepPlace.ASSERT)
    def assert_member_absent(self, full_name: str, anchor_name: str):
        expect(self._member_row_live(anchor_name).first).to_be_visible()
        expect(self._member_row_live(full_name, anchor_name)).to_have_count(0)

    @step('Войти в режим редактирования участников')
    def enter_edit_mode(self):
        _click_top_action(self)
        self._add_member_row().wait_for(state='visible')

    @step('Нажать «Добавить участника»')
    def open_member_picker(self):
        self.compose_click(self._add_member_row())
        # пикер открыт, когда строка добавления ушла из overlay
        self._add_member_row().wait_for(state='hidden')

    @step('Найти пользователя "{full_name}" в списке')
    def search_member(self, full_name: str, timeout: int = 120_000):
        """Поиск пикера ищет через /api/v2/users/search; свежий пользователь
        появляется в выдаче после своего первого логина (REST-гейт
        wait_user_in_directory_search), UI-выдача может отставать — таймаут
        с запасом. Искать ПОЛНЫМ именем «Фамилия Имя»: запрос фамилией ловит
        substring-соседей реального справочника («Игнатьев» → «Игнатьевич»)."""
        self.compose_fill(_panel_textbox(self.page, 0), full_name, clear=True)
        _panel_list(self.page).get_by_role('button').filter(
            has_text=full_name).first.wait_for(state='visible', timeout=timeout)

    @step('Выбрать пользователя "{full_name}"')
    def pick_member(self, full_name: str):
        """Клик по строке справочника (матч полным именем — см. search_member).
        Промежуточного overlay-сигнала выбора нет: чекбокс и заголовок
        «Выбрано N» — canvas-only, а чип выбранного над списком коллизирует
        текстом со строкой справочника — выбор подтверждают финальные ассерты
        (строка участника после подтверждения + REST)."""
        row = _panel_list(self.page).get_by_role('button').filter(
            has_text=full_name).first
        self.compose_click(row)

    @step('Подтвердить выбор участников')
    def confirm_picker(self):
        _click_top_action(self)
        # возврат в edit-режим: строка добавления снова в overlay
        self._add_member_row().wait_for(state='visible')

    @step('Подтвердить изменение участников')
    def confirm_edit(self):
        with self.expect_api('/members', 'POST') as response_info:
            _click_top_action(self)
        assert response_info.value.ok, \
            f'Добавление участников: HTTP {response_info.value.status}'

    @step('Участник "{full_name}" отображается в списке', where=StepPlace.ASSERT)
    def assert_member_present(self, full_name: str):
        expect(self._member_row_live(full_name).first).to_be_visible()


class PChatGallery(PBase):
    """Экран галереи медиа чата (вход — строки категорий на карточке).

    Внутрисценный (замещает правую панель, overlay живой): именованные вкладки
    «Изображения | Видео | Аудио» (role=button), тайлы — безымянные role=button
    внутри списка панели. ⚠️ Вкладки локализуются только со скоупом правой панели:
    get_by_role по имени без гео ловит одноимённые кнопки навбара («Файлы»),
    а клик по навбару — межфичевая навигация, безвозвратно ломающая overlay.
    """

    _TABS = ('media_header_pictures', 'media_header_video', 'media_header_audio')

    def _tab(self, category: str) -> Locator:
        """Вкладка галереи: exact-имя + гео-отсев навбара (правая панель)."""
        name = i18n.get_str(category, self.lang)
        tabs = self.page.get_by_role('button', name=name, exact=True)
        tabs.first.wait_for(state='visible')
        for tab in tabs.all():
            box = tab.bounding_box()
            if box and box['x'] > PANEL_X_MIN:
                return tab
        raise AssertionError(f'Вкладка галереи «{name}» не найдена на панели')

    def wait_opened(self, timeout: int = 10_000):
        self.page.get_by_role(
            'button', name=i18n.get_str(self._TABS[0], self.lang),
            exact=True).first.wait_for(state='visible', timeout=timeout)

    @step('Перейти на вкладку «{category}»')
    def switch_tab(self, category: str):
        # набор запросов вкладки непредсказуем (превью тумб; у аудио запросов
        # нет вовсе) — «доехало» ждётся idle-окном сети
        self.compose_click(self._tab(category))
        self.wait_idle()

    @step('Элементы галереи отображаются', where=StepPlace.ASSERT)
    def assert_items_present(self):
        """Контент вкладки отрендерился: в списке панели есть элементы
        (тайлы изображений/видео и строки аудио — безымянные role=button)."""
        items = _panel_list(self.page).get_by_role('button')
        expect(items.first).to_be_visible()
