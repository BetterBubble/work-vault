"""Панель создания чата/канала: карандаш top-bar → выбор типа → экран деталей.

Экран деталей — единый (не пошаговый мастер): аватар (камера), название, описание,
тогл публичности (у канала дополнительно «Реакции»/«Треды»), секция участников
(«Участники N» / «Подписчики N») с под-экраном выбора; создание и подтверждение
под-экранов — кнопка-стрелка в правом верхнем углу панели.

Особенности overlay этой поверхности:
- служебные кнопки (карандаш, камера, тогл, стрелка подтверждения, назад) не несут
  ни testTag, ни aria-label, ни текста — адресация по геометрии bounding box
  относительно именованных соседей (лейблы тоглов, верхняя полоса панели);
- состояние тогла и подсветка валидации полей рисуются только на canvas; наблюдаемы
  текст ошибки пустого названия (после попытки создать) и публичность чата по REST;
- панель занимает правую часть экрана — узлы левой панели списка чатов отсекаются
  по x >= PANEL_X_MIN (viewport фиксирован conftest'ом: 1440×900).
"""
from playwright.sync_api import Locator, expect

from tests.pages.base_page import PANEL_X_MIN, PBase
from tools import i18n
from tools import test_tags as tags
from tools.enums import StepPlace
from tools.helpers.steps import step

TOP_BAR_Y_MAX = 60         # верхняя полоса панели (назад, заголовок, стрелка действия)
ROW_ALIGN_TOLERANCE = 12   # допуск совпадения вертикальных центров лейбла и тогла

_KIND_KEYS = {
    'group': {
        'title': 'create_group_chat_title',
        'members': 'create_chat_members_label',
        'toggle_public': 'create_group_chat_toggle_public',
        'empty_name_error': 'create_group_chat_empty_name_error',
    },
    'channel': {
        'title': 'create_channel_title',
        'members': 'create_channel_subscribers_label',
        'toggle_public': 'create_channel_toggle_public',
        'empty_name_error': 'create_channel_empty_name_error',
    },
}


class PChatCreation(PBase):
    def __init__(self, page, lang: str = 'ru'):
        super().__init__(page, lang)
        self._kind = None  # 'group' | 'channel' — выставляется choose_*

    def _key(self, name: str) -> str:
        return i18n.get_str(_KIND_KEYS[self._kind][name], self.lang)

    # --- геометрическая адресация безымянных кнопок ---------------------------

    def _click_pencil(self):
        # карандаш — единственная безымянная кнопка top-bar лендинга
        self.click_unnamed_button(
            lambda b: b['y'] < TOP_BAR_Y_MAX and b['x'] > 120,
            'карандаш создания чата в top-bar списка чатов')

    def _click_top_action(self):
        # стрелка подтверждения — самая правая безымянная кнопка верхней полосы панели
        self.click_unnamed_button(
            lambda b: b['y'] < TOP_BAR_Y_MAX and b['x'] > PANEL_X_MIN,
            'кнопка подтверждения в верхней полосе панели',
            pick=lambda boxes: max(boxes, key=lambda b: b['x']))

    def _click_public_toggle(self):
        # тогл — безымянная кнопка на одной высоте с лейблом публичности правее него
        label = self.page.get_by_text(self._key('toggle_public'), exact=True)
        label.wait_for(state='visible')
        label_box = label.bounding_box()
        if label_box is None:
            raise AssertionError('Не получен bounding box лейбла публичности')
        label_center = label_box['y'] + label_box['height'] / 2
        self.click_unnamed_button(
            lambda b: b['x'] > label_box['x']
            and abs(b['y'] + b['height'] / 2 - label_center) < ROW_ALIGN_TOLERANCE,
            'тогл публичности рядом с лейблом')

    def _panel_textboxes(self) -> list:
        """Textbox-узлы панели с их bbox.

        Плоский overlay не даёт контейнера панели — отсекаем постоянный
        textbox-фильтр левого списка чатов по геометрии.
        """
        return [(tb, box) for tb in self.page.get_by_role('textbox').all()
                if (box := tb.bounding_box()) and box['x'] > PANEL_X_MIN]

    def _panel_textbox(self, index: int) -> Locator:
        """Текстбоксы панели сверху вниз: 0 — название, 1 — описание."""
        boxes = self._panel_textboxes()
        boxes.sort(key=lambda pair: pair[1]['y'])
        if index >= len(boxes):
            raise AssertionError(f'На панели меньше {index + 1} полей ввода')
        return boxes[index][0]

    def _widest_panel_textbox(self) -> Locator:
        """Основное поле поиска панели среди наложенных textbox-узлов overlay."""
        boxes = self._panel_textboxes()
        if not boxes:
            raise AssertionError('Поисковое поле панели не найдено')
        return max(boxes, key=lambda pair: pair[1]['width'])[0]

    # --- флоу ------------------------------------------------------------------

    @step('Нажать кнопку создания чата')
    def open_panel(self):
        self._click_pencil()
        self.page.get_by_role('button', name=i18n.get_str(
            'create_group_chat_button', self.lang)).wait_for(state='visible')

    @step('Найти пользователя "{query}"')
    def search_contact(self, query: str, timeout: int = 120_000):
        # Свежий пользователь появляется в панельном поиске (/api/v2/users/search)
        # асинхронно, до 1-2 минут, и НЕЗАВИСИМО от /api/v1/chats/search — долгое
        # ожидание нужно даже после пройденного REST-гейта wait_user_searchable.
        self.compose_fill(self._widest_panel_textbox(), query, clear=True)
        self.page.get_by_role('button').filter(has_text=query).wait_for(
            state='visible', timeout=timeout)

    @step('Выбрать пользователя "{full_name}"')
    def open_contact_chat(self, full_name: str):
        contact = self.page.get_by_role('button').filter(has_text=full_name)
        self.compose_click(contact)
        self.page.locator(f'#{tags.CHAT_SCREEN}').wait_for(state='attached')

    @step('Выбрать «Создать групповой чат»')
    def choose_group_chat(self):
        self._choose_type('group', 'create_group_chat_button')

    @step('Выбрать «Создать информационный канал»')
    def choose_channel(self):
        self._choose_type('channel', 'create_info_channel_button')

    def _choose_type(self, kind: str, button_key: str):
        self._kind = kind
        button = self.page.get_by_role('button', name=i18n.get_str(button_key, self.lang))
        self.compose_click(button)
        self.page.get_by_text(self._key('title'), exact=True).wait_for(state='visible')

    @step('Ввести название "{name}"')
    def fill_name(self, name: str):
        self.compose_fill(self._panel_textbox(0), name)

    @step('Выбрать картинку аватара')
    def select_photo(self, file_path: str):
        """Кнопка-камера — canvas-зона без узла в overlay: клик по геометрии
        (левее поля названия, на его высоте) открывает DOM filechooser.
        Превью выбранного аватара рисуется только на canvas."""
        name_box = self._panel_textbox(0).bounding_box()
        if name_box is None:
            raise AssertionError('Не получен bounding box поля названия')
        with self.page.expect_file_chooser() as chooser_info:
            self.page.mouse.click(
                name_box['x'] - 52, name_box['y'] + name_box['height'] / 2)
        chooser_info.value.set_files(file_path)

    @step('Нажать на поле ввода названия')
    def click_name_field(self):
        self.compose_click(self._panel_textbox(0))

    @step('Нажать на поле ввода описания')
    def click_description_field(self):
        self.compose_click(self._panel_textbox(1))

    @step('Включить тогл публичности')
    def toggle_public(self):
        # состояние тогла рисуется только на canvas: включение подтверждается
        # публичностью созданного чата (REST), см. wait_chat_created
        self._click_public_toggle()

    @step('Открыть список участников')
    def open_members(self):
        members = self.page.get_by_role('button').filter(has_text=self._key('members'))
        self.compose_click(members.first)
        # под-экран открыт, когда экран деталей ушёл (тогл-лейбл публичности скрыт)
        self.page.get_by_text(self._key('toggle_public'), exact=True).wait_for(state='hidden')

    @step('Выбрать первого пользователя из списка')
    def select_first_member(self):
        lists = [lst for lst in self.page.get_by_role('list').all()
                 if (box := lst.bounding_box()) and box['x'] > PANEL_X_MIN]
        if not lists:
            raise AssertionError('Список пользователей панели не найден')
        self.compose_click(lists[0].get_by_role('button').first)

    @step('Подтвердить выбор участников')
    def confirm_members(self):
        self._click_top_action()
        self.page.get_by_text(self._key('title'), exact=True).wait_for(state='visible')

    @step('Счётчик участников показывает {count}', where=StepPlace.ASSERT)
    def assert_members_count(self, count: int):
        counter = self.page.get_by_role('button').filter(
            has_text=f'{self._key("members")}{count}')
        expect(counter).to_be_visible()

    @step('Нажать кнопку создания')
    def submit_create(self) -> dict:
        """Возвращает созданный чат (тело ответа POST /chats) для REST-проверок."""
        with self.expect_api('/api/v1/chats', 'POST') as response_info:
            self._click_top_action()
        response = response_info.value
        assert response.ok, f'Создание чата: HTTP {response.status}'
        return response.json()

    @step('Нажать кнопку создания')
    def submit_create_rejected(self):
        """Попытка создания, отклоняемая клиентской валидацией: запрос не уходит."""
        self._click_top_action()

    @step('Отображается ошибка обязательности названия', where=StepPlace.ASSERT)
    def assert_empty_name_error(self):
        error = self.page.get_by_text(self._key('empty_name_error'), exact=True)
        expect(error).to_be_visible()

    @step('Экран создания остаётся открытым', where=StepPlace.ASSERT)
    def assert_creation_screen_open(self):
        title = self.page.get_by_text(self._key('title'), exact=True)
        expect(title).to_be_visible()
