"""Базовый Playwright-слой canvas-поверхности KMP-клиента IVA ONE.

UI приложения — один <canvas> (Skiko), семантика зеркалится в реальные DOM-узлы
accessibility-overlay внутри open Shadow Root. Отсюда два правила вождения:

- локация — по узлам overlay: `#test_id_*` (реестр tools/test_tags.py) и role/имя;
  CSS-id и get_by_role Playwright пробивают open shadow нативно, XPath — нет;
- клик/ввод — только координатно (compose_click/compose_fill): узлы overlay
  прозрачны для pointer-событий, обычный locator.click() перехватывает canvas.

Вторая поверхность — обычный DOM (Keycloak-логин, filechooser) — водится штатными
методами Playwright без compose_* (см. tests/pages/login.py).

Границы честности overlay (важно для ожиданий/ассертов):
- узлы «Чатов» остаются attached после ухода с фичи — auto-wait/expect легитимны
  только в живом overlay чата; межфичевая навигация и Compose Popup ломают overlay
  безвозвратно (лечит только goto);
- скролл ленты overlay не ломает.

Политика wait_for_timeout (= sleep): допустим ТОЛЬКО в примитивах этого модуля и
только там, где у canvas-перехода нет наблюдаемого сигнала (внутреннее состояние
Compose не зеркалится ни в overlay, ни в сеть) — каждое использование документирует
отсутствующий сигнал. В тестах и page-методах — запрещён: там всегда есть
overlay-узел / ответ API, которых можно дождаться честно.
"""
import re
import time

from playwright.sync_api import Locator, Page

from tools.enums import StepPlace
from tools.helpers.steps import step

APP_READY_TIMEOUT_MS = 30_000
ACTION_TIMEOUT_MS = 10_000

# Граница между левой панелью (список чатов, ~до 555px) и правой сценой/панелями
# при фиксированном conftest'ом viewport 1440×900. Гео-отборы: узел левой панели —
# x < PANEL_X_MIN, узел правой панели — x > PANEL_X_MIN.
PANEL_X_MIN = 530


class PBase:
    def __init__(self, page: Page, lang: str = 'ru'):
        self.page = page
        self.lang = lang

    # --- готовность приложения ---------------------------------------------

    def wait_app_ready(self, timeout: int = APP_READY_TIMEOUT_MS):
        """Bootstrap-гейт: wasm/Skiko поднялись — canvas в DOM и a11y-overlay смонтирован.

        Ждать один раз после логина/goto. Per-screen сигнала готовности у canvas
        нет — готовность конкретного экрана ждут его собственные overlay-узлы.
        """
        self.page.locator('canvas').first.wait_for(state='attached', timeout=timeout)
        self.page.locator('#cmp_a11y_root').wait_for(state='attached', timeout=timeout)

    # --- драйвинг ------------------------------------------------------------

    def compose_click(self, locator: Locator, *, retreat: bool = False,
                      timeout: int = ACTION_TIMEOUT_MS):
        """Координатный клик по центру bounding box узла overlay.

        bbox снимается непосредственно перед кликом и не кэшируется: ре-лейаут
        canvas двигает узлы. retreat=True — сразу увести курсор в угол: элементы
        с hover-тултипом (навбар) открывают Compose Popup, который безвозвратно
        схлопывает overlay; атомарный клик+увод не даёт тултипу раскрыться.
        """
        locator.wait_for(state='visible', timeout=timeout)
        box = locator.bounding_box()
        if box is None:
            raise AssertionError(f'Не получен bounding box узла {locator}')
        self.page.mouse.click(box['x'] + box['width'] / 2, box['y'] + box['height'] / 2)
        if retreat:
            self.page.mouse.move(0, 0)

    def click_unnamed_button(self, predicate, description: str, *,
                             pick=None, timeout: int = ACTION_TIMEOUT_MS):
        """Координатный клик по кнопке без accessible name, отобранной по геометрии.

        Иконки-кнопки Compose (карандаш, тоглы, стрелки подтверждения) не несут ни
        testTag, ни aria-label, ни текста — адресация только предикатом по bounding
        box. Скан поллится: overlay материализуется пачками после bootstrap'а, а
        локаторы из .all() протухают при перерисовке — клик идёт по свежеснятому
        bbox в той же итерации. pick — выбор из нескольких подходящих (например,
        max(x) для самой правой); без pick берётся первая найденная.
        """
        unnamed = self.page.locator('[role="button"]:not([aria-label])').filter(
            has_not_text=re.compile(r'\S'))
        deadline = time.monotonic() + timeout / 1000
        while True:
            candidates = []
            for button in unnamed.all():
                try:
                    box = button.bounding_box(timeout=200)
                except Exception:
                    continue  # кнопка исчезла при перерисовке — пропустить
                if box and predicate(box):
                    candidates.append(box)
            if candidates:
                box = pick(candidates) if pick else candidates[0]
                self.page.mouse.click(box['x'] + box['width'] / 2,
                                      box['y'] + box['height'] / 2)
                return
            if time.monotonic() > deadline:
                raise AssertionError(f'Не найдена кнопка: {description}')
            self.page.wait_for_timeout(300)

    def click_row_toggle(self, label: Locator, *, x_min: int = 1300,
                         tolerance: int = 20, timeout: int = ACTION_TIMEOUT_MS):
        """Клик тогла-строки: безымянная кнопка правее лейбла на той же высоте.

        Тоглы Compose не несут ни testTag, ни aria-label — адресация геометрией
        относительно именованного лейбла строки. Состояние тогла рисуется только
        на canvas: включение подтверждается наблюдаемым следствием (REST/текст).
        """
        label.wait_for(state='visible', timeout=timeout)
        box = label.bounding_box()
        if box is None:
            raise AssertionError(f'Не получен bounding box лейбла {label}')
        center_y = box['y'] + box['height'] / 2
        self.click_unnamed_button(
            lambda b: b['x'] > x_min
            and abs(b['y'] + b['height'] / 2 - center_y) < tolerance,
            f'тогл строки с лейблом {label}', timeout=timeout)

    def click_blind(self, box: dict, *, settle_ms: int = 700):
        """Слепой клик по координатам узла, снятым до открытия попап-слоя.

        После выбора в попапе (bottom-sheet, меню) слой закрывается
        canvas-анимацией, которая не зеркалится в overlay — там остаётся
        стейл-слепок, и сигнала «слой закрыт» нет; пока анимация идёт, клики
        съедает скрим. Пауза пережидает закрытие, затем клик по прежним
        координатам (canvas под слепком живой, узлы на месте).
        """
        self.page.wait_for_timeout(settle_ms)
        self.page.mouse.click(box['x'] + box['width'] / 2,
                              box['y'] + box['height'] / 2)

    def paste_blind(self, box: dict, *, settle_ms: int = 700):
        """Слепая вставка из буфера обмена в поле по координатам, снятым до попапа.

        Клик-фокус по слепку (click_blind) + Ctrl/Cmd+V. Пауза после вставки
        обязательна: содержимое canvas-поля в overlay не зеркалится, сигнала
        «вставка применилась» нет, а немедленный Enter отправил бы поле до
        материализации текста.
        """
        self.click_blind(box)
        self.page.keyboard.press('ControlOrMeta+V')
        self.page.wait_for_timeout(settle_ms)

    def reload_app(self):
        """Перезагрузить приложение: единственный способ восстановить overlay
        после закрытия попап-слоя (стейл-слепок — см. докстринг модуля)."""
        self.page.reload()
        self.wait_app_ready()

    def compose_fill(self, locator: Locator, text: str, *, clear: bool = False,
                     delay: int = 30):
        """Фокус через compose_click + посимвольный ввод с клавиатуры.

        Canvas-поле — не DOM-input: locator.fill() бесполезен, только keyboard.type.
        clear=True — очистить поле перед вводом (Ctrl/Cmd+A -> Delete). Пауза после
        Delete обязательна: compose-редактор обрабатывает удаление асинхронно и
        глотает первый символ ввода, начатого впритык.
        """
        self.compose_click(locator)
        if clear:
            self.page.keyboard.press('ControlOrMeta+A')
            self.page.keyboard.press('Delete')
            self.page.wait_for_timeout(150)
        self.page.keyboard.type(text, delay=delay)

    # --- локация в виртуализированных лентах --------------------------------

    def scroll_until_present(self, target: Locator, container: Locator, *,
                             direction: str = 'up', step_px: int = 600,
                             max_iter: int = 20, settle_ms: int = 350) -> Locator:
        """Домотать виртуализированную ленту до материализации target в overlay.

        Лента (LazyColumn) держит в DOM окно ~12 элементов с рециклингом: off-screen
        элементов в DOM нет, .nth() конкретный элемент не адресует. Скролл — колесом
        в центр container; move перед каждым wheel обязателен (wheel диспатчится в
        текущую точку курсора). Первый wheel часто поглощается — cap с запасом.
        direction='up' — к старым сообщениям (отрицательный deltaY).
        """
        if target.count() > 0:
            return target
        box = container.bounding_box()
        if box is None:
            raise AssertionError(f'Не получен bounding box контейнера {container}')
        cx, cy = box['x'] + box['width'] / 2, box['y'] + box['height'] / 2
        dy = -step_px if direction == 'up' else step_px
        for _ in range(max_iter):
            self.page.mouse.move(cx, cy)
            self.page.mouse.wheel(0, dy)
            self.page.wait_for_timeout(settle_ms)
            if target.count() > 0:
                return target
        raise AssertionError(
            f'Элемент не материализовался за {max_iter} скроллов ленты (шаг {step_px}px)')

    # --- ожидание сети --------------------------------------------------------

    def wait_idle(self, *, idle_ms: int = 800, timeout_ms: int = 15_000,
                  url_part: str = '/api/v1'):
        """Idle-окно сети: подряд idle_ms без ответов url_part — действие «доехало».

        Для действий с неизвестным набором запросов. Не networkidle Playwright —
        websocket Centrifugo держит соединение вечно и networkidle не наступает.
        Где endpoint действия известен — предпочитай expect_api().
        """
        last = {'t': time.monotonic()}

        def _on_response(response):
            if url_part in response.url:
                last['t'] = time.monotonic()

        context = self.page.context
        context.on('response', _on_response)
        try:
            deadline = time.monotonic() + timeout_ms / 1000
            while time.monotonic() < deadline:
                if time.monotonic() - last['t'] >= idle_ms / 1000:
                    return
                self.page.wait_for_timeout(50)
            raise AssertionError(f'Сеть {url_part} не успокоилась за {timeout_ms}мс')
        finally:
            context.remove_listener('response', _on_response)

    def start_request_capture(self, url_part: str):
        """Начать запись исходящих запросов, содержащих url_part (тихий примитив).

        Для ассертов класса «клиент НЕ дёргает endpoint» (рендер превью без
        запросов оригинала): вызвать ДО действия, снимать список captured_requests
        (общий негатив — assert_no_download_requests ниже; составные ассерты —
        в page-классах). Повторный вызов сбрасывает запись.
        Состояние живёт на инстансе — capture и ассерт делает один page-объект.
        """
        if getattr(self, '_capture_handler', None):
            self.page.remove_listener('request', self._capture_handler)
        self._capture_part = url_part
        self._captured_requests = []

        def _on_request(request):
            if url_part in request.url:
                self._captured_requests.append(request.url)

        self._capture_handler = _on_request
        self.page.on('request', _on_request)

    @property
    def captured_requests(self) -> list:
        return list(getattr(self, '_captured_requests', []))

    @step('Запросы оригинала (download) не уходили', where=StepPlace.ASSERT)
    def assert_no_download_requests(self):
        """Требует start_request_capture('/download') на этом же инстансе
        до наблюдаемого действия (рендер ленты, открытие галереи)."""
        assert not self.captured_requests, \
            f'Ушли запросы оригинала: {self.captured_requests}'

    def expect_api(self, url_part: str, method: str = None,
                   timeout: int = 15_000):
        """Ожидание ответа известного endpoint'а, оборачивающее действие:

            with chat.expect_api('/api/v1/messages', 'POST'):
                chat.send()
        """
        def _match(response):
            return url_part in response.url and (method is None or response.request.method == method)

        return self.page.expect_response(_match, timeout=timeout)
