"""Экран входа — стандартная страница Keycloak (обычный DOM, не canvas).

Единственная поверхность приложения со штатными DOM-инпутами: fill/click
Playwright работают как обычно, compose_* не нужны. После успешного входа
управление переходит canvas-приложению — дальше только примитивы PBase.
"""
from playwright.sync_api import expect

from tests.pages.base_page import PBase
from tools.enums import StepPlace
from tools.helpers.steps import step

L_USERNAME = '#username'
L_PASSWORD = '#password'
L_SUBMIT = '#kc-login'
L_ERROR = '#input-error'  # span Keycloak с текстом ошибки под полем ввода


class PLogin(PBase):
    @step('Открыть веб-клиент IVA ONE')
    def open(self, app_url: str):
        self.page.goto(app_url)
        self.page.locator(L_USERNAME).wait_for(state='visible')

    @step('Авторизоваться за пользователя "{username}"')
    def login(self, username: str, password: str, *, expect_success: bool = True):
        self.page.fill(L_USERNAME, username)
        self.page.fill(L_PASSWORD, password)
        self.page.click(L_SUBMIT)
        if expect_success:
            self.wait_app_ready()

    @step('Отображается сообщение об ошибке авторизации', where=StepPlace.ASSERT)
    def assert_wrong_auth_error(self):
        error = self.page.locator(L_ERROR)
        expect(error).to_be_visible()
        expect(error).not_to_be_empty()
