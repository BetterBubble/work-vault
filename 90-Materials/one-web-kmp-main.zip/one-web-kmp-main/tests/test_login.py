import allure
import pytest

from autocore.test.logger import get_log
from tests.pages.chat import PChatsList
from tests.pages.login import PLogin
from tools.helpers.session import web_preamble

log = get_log()


@allure.title("Авторизация за пользователя. Успешная авторизация")
@allure.feature("Авторизация")
def test_login_success_auth(setup_aut, users_factory, teardown):
    lang, page = web_preamble(setup_aut)
    user_data = users_factory[0]

    log.tc('36760')

    login_page = PLogin(page, lang=lang)
    login_page.open(setup_aut['setup']['app_url'])
    login_page.login(user_data['username'], user_data['password'])
    # Данные аккаунта живут в профиле (Compose Popup — ломает a11y-overlay);
    # успешный вход подтверждаем загрузкой пост-логин лендинга «Чаты».
    PChatsList(page, lang=lang).assert_landing_loaded()


@allure.title("Авторизация за пользователя. Неправильный логин")
@allure.feature("Авторизация")
def test_login_wrong_username_auth(setup_aut, users_factory, teardown):
    lang, page = web_preamble(setup_aut)
    user_data = users_factory[0]

    log.tc('36761')

    login_page = PLogin(page, lang=lang)
    login_page.open(setup_aut['setup']['app_url'])
    login_page.login('wrong_username', user_data['password'], expect_success=False)
    login_page.assert_wrong_auth_error()


@allure.title("Авторизация за пользователя. Неправильный пароль")
@allure.feature("Авторизация")
def test_login_wrong_password_auth(setup_aut, users_factory, teardown):
    lang, page = web_preamble(setup_aut)
    user_data = users_factory[0]

    log.tc('36762')

    login_page = PLogin(page, lang=lang)
    login_page.open(setup_aut['setup']['app_url'])
    login_page.login(user_data['username'], 'wrong_password', expect_success=False)
    login_page.assert_wrong_auth_error()


@allure.title("Авторизация за пользователя. Пустые поля")
@allure.feature("Авторизация")
def test_login_empty_inputs_auth(setup_aut, teardown):
    lang, page = web_preamble(setup_aut)

    log.tc('36767')

    login_page = PLogin(page, lang=lang)
    login_page.open(setup_aut['setup']['app_url'])
    login_page.login('', '', expect_success=False)
    login_page.assert_wrong_auth_error()
