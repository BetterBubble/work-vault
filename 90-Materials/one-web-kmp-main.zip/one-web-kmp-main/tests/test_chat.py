
import allure
import pytest

from autocore import consts
from autocore.clients.rest import iva_one
from autocore.clients.rest.enums import ChatTypes
from autocore.test.generate_data import get_random_string
from autocore.test.logger import get_log
from tests.flows.chat import open_chat, open_chat_card, reopen_chat
from tools import i18n
from tools.helpers.chat_setup import send_reply_message, wait_chat_detail, wait_group_chat_materialized, wait_message_absent, wait_message_id, wait_message_reaction, wait_message_reply, wait_user_in_directory_search
from tools.helpers.session import iva_one_web_login, web_preamble

log = get_log()

AVATAR_IMAGE = f'{consts.ROOT_DIR}/tools/data/test_image_sample.jpeg'
MEDIA_IMAGE = f'{consts.ROOT_DIR}/tools/data/test_image_sample.jpeg'
MEDIA_VIDEO = f'{consts.ROOT_DIR}/tools/data/test_video_sample.mp4'
MEDIA_AUDIO = f'{consts.ROOT_DIR}/tools/data/test_audio_sample.wav'
MEDIA_TEXT = f'{consts.ROOT_DIR}/tools/data/test_text_file_sample.txt'
# должность упоминаемого в mention-списке — Keycloak-атрибут position эфемера
MENTION_POSITION = 'Инженер тестирования'


@allure.id("54540")
@allure.title("Ответ на сообщение с цитированием")
@allure.tag("34", "Мессенджер")
@allure.feature("Мессенджер")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_group_chat_reply_to_message(setup_aut, users_factory, teardown):
    """Пользователь авторизован; в чате есть сообщение для ответа по требованию «Ответ с цитированием»."""
    lang, page = web_preamble(setup_aut)
    user = users_factory[0]
    chat_name = get_random_string(10)
    original = get_random_string(10)
    reply_text = get_random_string(10)
    token = iva_one_web_login(setup_aut, user)
    chat_id = iva_one.create_chat(token, chat_name, [user['username']])
    wait_group_chat_materialized(token, chat_id, min_members=1)
    original_id = iva_one.send_message(token, chat_id, original)['id']

    log.tc('54540')

    chat = open_chat(setup_aut, user, lang, page, chat_name)
    # координаты поля ввода — до попапа меню: после его закрытия overlay стейл
    chat.capture_input_box()
    chat.open_message_menu(original)
    chat.select_menu_item(i18n.get_str('message_menu_reply', lang))
    # плашка цитаты над полем — canvas-only при стейл-overlay:
    # «режим ответа активен» наблюдаем reply-связкой отправленного сообщения
    chat.send_reply_blind(reply_text)
    wait_message_reply(token, chat_id, reply_text, original_id)
    # цитата в отправленном сообщении — на свежем overlay после переоткрытия
    chat = reopen_chat(lang, page, chat_name)
    chat.assert_reply_quote(reply_text, original)


@allure.id("54541")
@allure.title("Навигация к исходному сообщению из цитаты")
@allure.tag("34", "Мессенджер")
@allure.feature("Мессенджер")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_jump_to_quoted_message(setup_aut, users_factory, teardown):
    """Пользователь авторизован; в чате есть сообщение для ответа по требованию «Ответ с цитированием»."""
    lang, page = web_preamble(setup_aut)
    user = users_factory[0]
    chat_name = get_random_string(10)
    parent_text = get_random_string(10)
    reply_text = get_random_string(10)
    token = iva_one_web_login(setup_aut, user)
    chat_id = iva_one.create_chat(token, chat_name, [user['username']])
    wait_group_chat_materialized(token, chat_id, min_members=1)
    parent_id = iva_one.send_message(token, chat_id, parent_text)['id']
    # >100 сообщений после родителя — он за пределами первой страницы ленты
    for i in range(105):
        iva_one.send_message(token, chat_id, f'filler {i}')
    # ответ-цитата — REST-сид: преамбула перехода (UI-механика ответа покрыта TC 54540)
    send_reply_message(token, chat_id, reply_text, parent_id)

    log.tc('54541')

    chat = open_chat(setup_aut, user, lang, page, chat_name)
    chat.click_quote(reply_text, parent_id)
    chat.assert_message_body_visible(parent_text)


@allure.id("54417")
@allure.title("Добавление участника при разрешенном праве")
@allure.tag("3", "Мессенджер")
@allure.feature("Мессенджер")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [3], indirect=True)
def test_add_member_to_group_chat_from_card(setup_aut, users_factory, teardown):
    """Пользователь авторизован; существует чат с настраиваемыми ролями и правами для требования «Настройка прав добавления новых участников в чат»."""
    lang, page = web_preamble(setup_aut)
    owner, member, candidate = users_factory
    chat_name = get_random_string(10)
    token = iva_one_web_login(setup_aut, owner)
    chat_id = iva_one.create_chat(
        token, chat_name, [owner['username'], member['username']])
    wait_group_chat_materialized(token, chat_id, min_members=2)
    # кандидат ищется пикером только после своего первого логина (индексация)
    iva_one_web_login(setup_aut, candidate)
    candidate_name = f"{candidate['last_name']} {candidate['first_name']}"
    wait_user_in_directory_search(token, candidate['id'], candidate_name)

    log.tc('54417')

    card = open_chat_card(setup_aut, owner, lang, page, chat_name)
    members_screen = card.open_members()
    members_screen.enter_edit_mode()
    members_screen.open_member_picker()
    members_screen.search_member(candidate_name)
    members_screen.pick_member(candidate_name)
    members_screen.confirm_picker()
    members_screen.confirm_edit()
    members_screen.assert_member_present(candidate_name)
    wait_chat_detail(token, chat_id, membersCount=3)


@allure.id("53294")
@allure.title("Проверка возможности добавления участника пользователем с правами администратора")
@allure.tag("Мессенджер")
@allure.feature("Мессенджер")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [3], indirect=True)
def test_add_subscriber_to_channel_from_card(setup_aut, users_factory, teardown):
    """Пользователь "Администратор" авторизован в системе. Существует чат с несколькими участниками."""
    lang, page = web_preamble(setup_aut)
    owner, member, candidate = users_factory
    channel_name = get_random_string(10)
    token = iva_one_web_login(setup_aut, owner)
    chat_id = iva_one.create_chat(
        token, channel_name, [owner['username'], member['username']],
        type=ChatTypes.CHANNEL)
    wait_group_chat_materialized(token, chat_id, min_members=2)
    iva_one_web_login(setup_aut, candidate)
    candidate_name = f"{candidate['last_name']} {candidate['first_name']}"
    wait_user_in_directory_search(token, candidate['id'], candidate_name)

    log.tc('53294')

    card = open_chat_card(setup_aut, owner, lang, page, channel_name, kind='channel')
    members_screen = card.open_members()
    members_screen.enter_edit_mode()
    members_screen.open_member_picker()
    members_screen.search_member(candidate_name)
    members_screen.pick_member(candidate_name)
    members_screen.confirm_picker()
    members_screen.confirm_edit()
    members_screen.assert_member_present(candidate_name)
    wait_chat_detail(token, chat_id, membersCount=3)


@allure.id("54513")
@allure.title("Удаление сообщения у всех участников")
@allure.tag("27", "Мессенджер")
@allure.feature("Мессенджер")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_group_chat_delete_message(setup_aut, users_factory, teardown):
    """Пользователь авторизован; в чате есть сообщение для удаления по требованию «При удалении сообщения предусмотреть режим «Удалить у себя» и «Удалить у всех»»."""
    lang, page = web_preamble(setup_aut)
    user, member = users_factory
    token = iva_one_web_login(setup_aut, user)
    member_token = iva_one_web_login(setup_aut, member)
    chat_name = get_random_string(10)
    message = get_random_string(10)
    chat_id = iva_one.create_chat(token, chat_name,
                                  [user['username'], member['username']])
    wait_group_chat_materialized(token, chat_id, min_members=2)
    message_id = iva_one.send_message(token, chat_id, message)['id']

    log.tc('54513')

    chat = open_chat(setup_aut, user, lang, page, chat_name)
    chat.open_message_menu(message)
    chat.select_menu_item(i18n.get_str('chats_context_menu_item_delete', lang))
    chat.confirm_delete_message()
    # «все пользователи в чате не видят сообщение автора» — история обоих участников
    wait_message_absent(token, chat_id, message_id)
    wait_message_absent(member_token, chat_id, message_id)
    chat = reopen_chat(lang, page, chat_name)
    chat.assert_message_not_in_feed(message)


@allure.id("54510")
@allure.title("Агрегация реакций от нескольких участников")
@allure.tag("26", "Мессенджер")
@allure.feature("Мессенджер")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [3], indirect=True)
def test_group_chat_view_message_reactions(setup_aut, users_factory, teardown):
    """Пользователь авторизован; в чате есть сообщение, доступное для реакции, по требованию «Реакции на сообщение»."""
    lang, page = web_preamble(setup_aut)
    user, reactor, second_reactor = users_factory
    token = iva_one_web_login(setup_aut, user)
    reactor_token = iva_one_web_login(setup_aut, reactor)
    second_reactor_token = iva_one_web_login(setup_aut, second_reactor)
    chat_name = get_random_string(10)
    message = get_random_string(10)
    chat_id = iva_one.create_chat(
        token, chat_name,
        [user['username'], reactor['username'], second_reactor['username']],
        has_reactions=True)
    wait_group_chat_materialized(token, chat_id, min_members=3)
    message_id = iva_one.send_message(token, chat_id, message)['id']
    iva_one.set_message_reaction(reactor_token, message_id)
    iva_one.set_message_reaction(second_reactor_token, message_id)

    log.tc('54510')

    chat = open_chat(setup_aut, user, lang, page, chat_name)
    chat.open_message_menu(message)
    chat.open_reactions_list()
    chat.assert_reaction_author(
        f"{reactor['last_name']} {reactor['first_name']}", '👍')
    chat.assert_reaction_author(
        f"{second_reactor['last_name']} {second_reactor['first_name']}", '👍')


@allure.id("54508")
@allure.title("Добавление реакции к сообщению")
@allure.tag("26", "Мессенджер")
@allure.feature("Мессенджер")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_p2p_react_to_foreign_message(setup_aut, users_factory, teardown):
    """Пользователь авторизован; в чате есть сообщение, доступное для реакции, по требованию «Реакции на сообщение»."""
    lang, page = web_preamble(setup_aut)
    user, peer = users_factory
    message = get_random_string(10)
    # p2p-чат создаётся первым сообщением собеседника (оно же — чужое сообщение
    # сценария); id чата в перспективе пользователя = keycloak-id собеседника
    peer_token = iva_one_web_login(setup_aut, peer)
    peer_chat_id = iva_one.create_p2p_chat(peer_token, user['username'], message=message)
    token = iva_one_web_login(setup_aut, user)
    message_id = wait_message_id(peer_token, peer_chat_id, message)

    log.tc('54508')

    chat = open_chat(setup_aut, user, lang, page, peer['last_name'])
    chat.open_message_menu(message)
    chat.pick_quick_reaction('🔥')
    wait_message_reaction(token, peer['id'], message_id, 'fire')
    # меню — попап-слой: бейдж реакции под баблом — на свежем overlay
    chat = reopen_chat(lang, page, peer['last_name'])
    chat.assert_message_reaction(message, '🔥')
