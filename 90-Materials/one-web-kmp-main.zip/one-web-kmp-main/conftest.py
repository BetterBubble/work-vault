import os
import sys

# Дефолт стенда kmp-линии — kmp-stage. autocore резолвит --env из sys.argv на момент
# импорта (test/config.get_env), поэтому дефолт прокидывается в argv ДО импорта autocore.
# Выбранный env шарится xdist-воркерам через окружение: воркеры стартуют через execnet
# без оригинального argv и восстанавливают значение отсюда.
_ENV_VAR = 'ONE_WEB_ENV'
if '--env' not in sys.argv:
    sys.argv += ['--env', os.environ.get(_ENV_VAR, 'kmp-stage')]
os.environ[_ENV_VAR] = sys.argv[sys.argv.index('--env') + 1]

# pytest-xdist: логгер autocore открывает фиксированные tests/logs/main.log{,.step,.debug}
# в 'w'-режиме — параллельные воркеры-процессы truncate'ят файлы и пишут каждый со своего
# смещения, перезаписывая байты друг друга. Переопределяем пути на per-worker ДО первого
# get_log(): он ленивый синглтон и читает consts.LOG_* атрибут-лукапом в момент создания
# хендлеров (autocore/test/logger.py:32-41). Мастер и непараллельный прогон остаются на
# дефолтном main.log.
if os.environ.get('PYTEST_XDIST_WORKER'):
    from autocore import consts as _consts

    _worker = os.environ['PYTEST_XDIST_WORKER']  # gw0, gw1, ...
    _consts.LOG_INFO = f'{_consts.LOG_DIR}/main-{_worker}.log'
    _consts.LOG_STEP = f'{_consts.LOG_DIR}/main-{_worker}.log.step'
    _consts.LOG_DEBUG = f'{_consts.LOG_DIR}/main-{_worker}.log.debug'

import re
import traceback
import uuid

import allure
import pytest
import yaml
from allure_commons.types import AttachmentType
from playwright.sync_api import expect, sync_playwright

from autocore import consts
from autocore.clients.rest import iva_one
from autocore.test.config import get_config
from autocore.test.generate_data import generate_email, generate_cyryllic_name
from autocore.test.logger import get_log
from tools.enums import StepPlace
from tools.helpers.steps import step

log = get_log()
option = None

EVIDENCE_DIR = f'{consts.ROOT_DIR}/tests/logs/pw-evidence'
_LOCALES = {'ru': 'ru-RU', 'en': 'en-US', 'es': 'es-ES'}


def pytest_configure(config):
    global option
    option = config.option
    expect.set_options(timeout=10_000)


def pytest_collection_modifyitems(items):
    for item in items:
        # Тесты на общем предсозданном mail/LDAP-юзере (require_ldap_user) нельзя
        # гонять одновременно — один аккаунт, сессии перетирают друг друга. В
        # параллельном прогоне (-n N --dist loadgroup) держим их в одной xdist-группе
        # → один воркер → сериализация между собой.
        if item.get_closest_marker('require_ldap_user'):
            item.add_marker(pytest.mark.xdist_group('ldap_user'))


@pytest.fixture(autouse=True)
def run_around_tests(request):
    test_case = re.findall('Function (.*?)>', str(request.keywords))[0]
    log.step(f'~~~~~START {test_case}~~~~~')
    yield
    log.step(f'~~~~~END {test_case}~~~~~')


@pytest.fixture(scope='session')
def version_reporter():
    # TODO: report version
    log.info('Calling "version_reporter" fixture')


def _deep_merge(dst: dict, src: dict):
    for key, value in src.items():
        if isinstance(value, dict) and isinstance(dst.get(key), dict):
            _deep_merge(dst[key], value)
        else:
            dst[key] = value


def _merge_secrets(cfg: dict, env: str):
    """Домёржить секцию env из gitignored secrets.yaml в config[env].

    Принцип «схема в git, значения вне git»: config.yaml несёт несекретную схему
    стенда, креды и клиент-секреты лежат в secrets.yaml под тем же именем env.
    Мёрж in-place: get_config() — модульный синглтон autocore, тот же dict видит
    и REST-клиент iva_one.
    """
    path = f'{consts.ROOT_DIR}/secrets.yaml'
    if not os.path.exists(path):
        return
    with open(path) as f:
        secrets = yaml.safe_load(f) or {}
    section = secrets.get(env)
    if section:
        _deep_merge(cfg, section)


@pytest.fixture(scope='session')
def setup(version_reporter):
    log.info('Calling "setup" fixture')
    log.info(f'Using "{option.env}" environment, language "{option.lang}"')
    cfg = get_config()[option.env]
    _merge_secrets(cfg, option.env)
    os.makedirs(f'{consts.ROOT_DIR}/allure-raw', exist_ok=True)
    with open(f'{consts.ROOT_DIR}/allure-raw/environment.properties', 'w') as f:
        f.write('browser=chromium\n')
        f.write(f'env={option.env}\n')
    return {
        'config': cfg,
        'cmd': {
            'lang': option.lang,
            'env': option.env,
        },
        # Браузер грузит UI с browser_url (локальный dev-server, api-dev-proxy на
        # stage); REST-сетап ходит напрямую в web_url. На развёрнутом KMP-стенде
        # поля browser_url нет — браузер берёт web_url.
        'app_url': cfg.get('browser_url') or cfg['web_url'],
    }


@pytest.fixture
def create_user(setup, teardown):
    iva_one_config = setup['config']
    iva_one_web_realm = iva_one_config['web-realm']
    iva_one_admin_creds = iva_one_config['credentials']['admin']
    admin_token = iva_one.login(**iva_one_admin_creds)
    password = 'DnUx0o'

    @step('Создать пользователя {email}', where=StepPlace.API)
    def _create_user(email, attributes=None):
        cyr_name = generate_cyryllic_name()
        user_data = {
            'username': email,
            'email': email,
            'password': password,
            'first_name': cyr_name['first_name'],
            'last_name': cyr_name['last_name']
        }
        user_creation_resp = iva_one.create_user(
            admin_token,
            iva_one_web_realm,
            user_data['username'],
            user_data['email'],
            user_data['first_name'],
            user_data['last_name'],
            attributes=attributes,
        )
        user_data['id'] = user_creation_resp['id']
        if attributes:
            user_data['attributes'] = attributes
        iva_one.set_user_password(admin_token, iva_one_web_realm, user_data['username'], user_data['password'])
        teardown.append(lambda: iva_one.delete_user(realm=iva_one_web_realm, username=email))
        return user_data

    return _create_user


@pytest.fixture
def users_factory(create_user, request):
    """Создаёт эфемерных юзеров. Параметр (indirect):
    - int N — N юзеров без Keycloak-атрибутов (поведение по умолчанию);
    - список — по элементу на юзера: dict атрибутов Keycloak
      (напр. {'position': ['...'], 'department': ['...']}) либо None для юзера без атрибутов.
    """
    param = getattr(request, "param", 1)
    specs = [None] * param if isinstance(param, int) else param

    users = []
    for i, attributes in enumerate(specs):
        # uuid-вставка: generate_email(full_name=False) — голый faker.email() с конечным пулом,
        # при параллельном прогоне (xdist) воркеры могут сгенерить одинаковый username → 409 Keycloak.
        user = create_user(f'0{i+1}_web_{uuid.uuid4().hex[:8]}_{generate_email(full_name=False)}', attributes=attributes)
        users.append(user)

    yield users


@pytest.fixture(scope='session')
def browser(setup):
    playwright = sync_playwright().start()
    browser = playwright.chromium.launch(headless=not option.headed)
    yield browser
    browser.close()
    playwright.stop()


def _context_args(setup):
    return dict(
        device_scale_factor=2,     # retina: без него canvas KMP рендерится мыльным
        ignore_https_errors=True,  # самоподписанные сертификаты стендов
        locale=_LOCALES.get(setup['cmd']['lang'], 'ru-RU'),
        viewport={'width': 1440, 'height': 900},
        record_video_dir=EVIDENCE_DIR,
    )


def _capture_failure_evidence(item):
    """Снять evidence не-зелёного исхода: скриншот и видео — вложениями в тест,
    trace — файлом в pw-evidence (в отчёт не прикладывается: десятки МБ на
    падение, а нужен только при ручном разборе — открывать playwright show-trace).

    Зовётся из pytest_runtest_makereport: вложения из хука попадают в сам
    результат теста; из финализации фикстуры они ушли бы в контейнер фикстуры
    (секция Tear down), которую Allure TestOps в теле теста не показывает.
    Страницы контекста закрываются здесь же: видео дописывается только после
    закрытия страницы. Идемпотентна по контекстам (setup- и call-фазы).
    """
    contexts = getattr(item, '_pw_contexts', [])
    captured = item.__dict__.setdefault('_pw_evidence_captured', set())
    multiple = len(contexts) > 1
    for i, context in enumerate(contexts, start=1):
        if id(context) in captured:
            continue
        captured.add(id(context))
        tag = f'-{i}' if multiple else ''
        live_pages = [page for page in context.pages if not page.is_closed()]
        for j, page in enumerate(live_pages, start=1):
            shot_name = f'{item.name}{tag}' + (f'-p{j}' if len(live_pages) > 1 else '')
            try:
                allure.attach(page.screenshot(), name=shot_name,
                              attachment_type=AttachmentType.PNG)
            except Exception as exc:
                log.warning(f'Не удалось снять скриншот при падении: "{exc}"')
        try:
            context.tracing.stop(path=f'{EVIDENCE_DIR}/{item.name}{tag}-trace.zip')
        except Exception as exc:
            log.warning(f'Не удалось сохранить trace: "{exc}"')
        try:
            videos = [page.video for page in context.pages if page.video]
            for page in context.pages:
                page.close()
            for video in videos:
                allure.attach.file(video.path(), name=f'Видео{tag}',
                                   attachment_type=AttachmentType.WEBM)
                video.delete()
        except Exception as exc:
            log.warning(f'Не удалось приложить видео: "{exc}"')


def _finalize_context(context, captured):
    """Закрыть контекст; на зелёном исходе — выбросить trace/video.

    Evidence не-зелёных прикладывает _capture_failure_evidence (makereport) —
    такой контекст здесь только закрывается.
    """
    try:
        if id(context) in captured:
            context.close()
            return
        videos = [page.video for page in context.pages if page.video]
        context.tracing.stop()
        context.close()
        for video in videos:
            video.delete()
    except Exception as exc:
        log.warning(f'Финализация браузерного контекста не удалась: "{exc}"')


@pytest.fixture
def _aut_factory(request, setup, browser):
    """Фабрика браузерных сессий: изолированный context на сессию пользователя.

    Trace и video пишутся всегда (retain-on-failure): на не-зелёном исходе
    pytest_runtest_makereport прикладывает к тесту скриншот+видео и оставляет
    trace в pw-evidence, на зелёном всё выбрасывается здесь. Контексты
    закрываются здесь же — регистрировать quit в teardown тесту не нужно.
    Падение в teardown-фазе evidence не получает принципиально: финализация
    этой фикстуры — сама часть teardown.
    """
    os.makedirs(EVIDENCE_DIR, exist_ok=True)
    born = []
    request.node._pw_contexts = born  # evidence при падении — pytest_runtest_makereport

    def start_aut():
        context = browser.new_context(**_context_args(setup))
        context.grant_permissions(['notifications'])
        context.tracing.start(screenshots=True, snapshots=True)
        page = context.new_page()
        born.append(context)
        return context, page

    yield start_aut

    captured = getattr(request.node, '_pw_evidence_captured', set())
    for context in born:
        _finalize_context(context, captured)


@pytest.fixture
def setup_aut(setup, _aut_factory):
    context, page = _aut_factory()
    bundle = {
        'page': page,
        'context': context,
        'setup': setup,
    }

    def page_starter():
        bundle['context'], bundle['page'] = _aut_factory()
        return bundle['page']

    bundle['page_starter'] = page_starter
    return bundle


@pytest.fixture
def setup_multiple_auts(setup, _aut_factory):
    def inner(auts_to_start: int = 2):
        contexts, pages = [], []
        for _ in range(auts_to_start):
            context, page = _aut_factory()
            contexts.append(context)
            pages.append(page)
        return {'page': pages, 'context': contexts, 'setup': setup}
    yield inner


@pytest.fixture
def teardown():
    methods = []
    yield methods

    for method in methods:
        try:  # все методы нужно выполнить несмотря на возможные ошибки
            method() if type(method) is not tuple else method[0](method[1])
        except Exception as exc:
            log.warn(f'teardown method failed with exception: "{exc}"')


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    rep = outcome.get_result()
    setattr(item, f'rep_{rep.when}', rep)
    # evidence в момент падения любой фазы (setup-падение сида — тоже не-зелёный
    # исход); при падении teardown контексты уже закрыты — evidence не снять
    if rep.failed or (rep.when == 'call' and 'xfail' in item.keywords):
        _capture_failure_evidence(item)
    # logging each traceback to respective testcase
    if call.excinfo:
        tb_obj = call.excinfo.tb
        stack_summary = traceback.extract_tb(tb_obj)
        tb_strings = stack_summary.format()
        tb_string = ''.join(tb_strings)
        tb_string = call.excinfo.exconly() + '\n' + tb_string

        stack_summary_locals = stack_summary.extract(traceback.walk_tb(tb_obj), capture_locals=True)
        tb_strings_locals = stack_summary_locals.format()
        tb_string_locals = ''.join(tb_strings_locals)
        tb_string_locals = call.excinfo.exconly() + '\n' + tb_string_locals

        log.info(tb_string)
        log.debug(tb_string_locals)


def pytest_addoption(parser):
    parser.addoption('--env', action='store', help='Environment name', default='kmp-stage')
    parser.addoption('--lang', action='store', help='AUT UI language', default=consts.LANG_RU)
    parser.addoption('--headed', action='store_true', default=False,
                     help='Запуск браузера с окном (отладка); по умолчанию headless')
