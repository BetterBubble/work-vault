"""Авто-шаги Allure: декоратор @step над методами действий и проверок.

Единый механизм шагов отчёта и файлового STEP-лога, симметричный для всего
слоя: помечено — рождает шаг, не помечено — тихое (служебные wait_*/фабрики
локаторов шагов не рождают — см. правила ассертов page-objects).

    class PChat(PBase):
        @step('Открыть чат "{chat_name}"')
        def open_chat(self, chat_name: str): ...

        @step('Сообщение "{text}" отображается в ленте', where=StepPlace.ASSERT)
        def assert_message_in_feed(self, text: str): ...

Текст — шаблон str.format по связанным аргументам метода (доступны имена
параметров, включая self: '{self.lang}'); тело метода оборачивается в
allure.step — упавшее действие или проверка красит СВОЙ шаг, вложенные
под-действия и проверки видны внутри блока. Метод из нескольких expect —
один шаг метода: гранулярность отчёта = шаг сценария ТК, а не каждая
техническая проверка.

В файловый STEP-лог текст пишется напрямую, минуя CustomLogger.step: тот
рождает ПУСТОЙ allure-шаг, который задваивал бы настоящий.
"""
import functools
import inspect

import allure

from autocore import consts
from autocore.test.logger import get_log
from tools.enums import StepPlace

log = get_log()


def _log_step_line(where: StepPlace, text: str):
    log.log(consts.LOG_STEP_LEVEL, f'{where}: {text}')


def step(template: str, where: StepPlace = StepPlace.UI):
    def decorator(method):
        signature = inspect.signature(method)

        @functools.wraps(method)
        def wrapper(*args, **kwargs):
            bound = signature.bind(*args, **kwargs)
            bound.apply_defaults()
            text = template.format(**bound.arguments)
            _log_step_line(where, text)
            with allure.step(text):
                return method(*args, **kwargs)
        return wrapper
    return decorator
