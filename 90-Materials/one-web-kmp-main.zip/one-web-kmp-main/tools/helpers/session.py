from autocore.clients.rest import iva_one


def web_preamble(setup_aut):
    """Стандартный single-session preamble: (lang, page).

    Жизненным циклом контекста/страницы владеет фикстура setup_aut (evidence
    retain-on-failure + закрытие) — регистрировать quit в teardown не нужно.
    config/secret тест берёт сам (он опционален).
    """
    return setup_aut['setup']['cmd']['lang'], setup_aut['page']


def iva_one_web_login(aut, user):
    """REST-логин веб-клиента IVA ONE по кредам user → access token.

    Сворачивает iva_one.login(u, p, 'IVA', 'iva-one', secret): realm/client_id
    константны для веб-клиента, secret берётся из aut. user — словарь кредов
    (users_factory / config-юзер). Admin/MCU-логины НЕ через неё (другой client_id).
    aut — бандл setup_aut (single) либо auts (multi); подструктура ['setup']['config'] одна.
    """
    secret = aut['setup']['config']['iva-one-client-secret']
    return iva_one.login(user['username'], user['password'], 'IVA', 'iva-one', secret)


def get_user_position(config, username):
    """Должность (Keycloak-атрибут `position`) пользователя — админским токеном.

    Нужна тестам, ассертящим отображение должности участника в UI: значение задаётся
    на стенде (в админке/LDAP), поэтому читаем из Keycloak, а не хардкодим. Возвращает
    строку должности либо None, если атрибут не задан.
    """
    admin_token = iva_one.login(**config['credentials']['admin'])
    for user in iva_one.get_user_info(admin_token, config['web-realm'], username):
        if user.get('username', '').lower() == username.lower():
            position = user.get('attributes', {}).get('position', [])
            return position[0] if position else None
    return None


def relogin_session(setup_aut):
    """Свежая браузерная сессия для смены пользователя (relogin).

    SSO-кука Keycloak живёт в browser context — закрываем текущий контекст и
    поднимаем новый (чистая сессия) через page_starter. Возвращает новую page —
    вызывающий делает UI-логин под новым пользователем.
    """
    setup_aut['context'].close()
    return setup_aut['page_starter']()
