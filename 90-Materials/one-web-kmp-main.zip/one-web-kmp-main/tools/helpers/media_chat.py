"""Подготовка медиа-чата для тестов IVAONE-11538 (отображение вложений в ленте/галерее/просмотрщике).

Тест-слой: композиция и поллинг поверх REST-примитивов autocore `iva_one`; заливка
файлов — прямыми запросами (см. upload_file_chunked: однозапросный флоу autocore
на stage-one мёртв — 403).

Новые медиа-поля бэкенда в объекте file сообщения: preview[] (image/video),
video.preview.url (video), audio.mp3Url (audio); file.url = оригинал (.../download).
После отправки файл проходит серверную SBC/DLP-проверку (file.status='processing',
лента рисует «Материалы на проверке») — перед UI-шагами ждать wait_files_processed.
"""
import time
import uuid
from pathlib import Path

import requests

from autocore.clients.rest import iva_one
from autocore.clients.rest.iva_one import conf, env
from autocore.test.assertions import assert_fn
from autocore.test.logger import get_log
from tools.enums import StepPlace
from tools.helpers.steps import step

log = get_log()


def upload_file_chunked(token, file_path):
    """Залить файл почанковым флоу клиента: create → parts → complete → uploadId.

    Однозапросный POST /uploads (iva_one.upload_file) на stage-one отвечает 403 —
    бэк перешёл на chunked-загрузку. Checksum части считает сервер (ответ шага
    parts) и просто эхом возвращается в complete. Файлы тест-данных уходят одной
    частью (клиент льёт одной частью и большие файлы — граница неизвестна).
    :returns: uploadId — id файла для POST /messages/batch
    """
    base_url = conf[env]['web_url']
    headers = {"Authorization": f"Bearer {token}"}
    path = Path(file_path)
    response = requests.post(f'{base_url}/api/v1/uploads/create', headers=headers,
                             json={'fileName': path.name}, verify=False)
    response.raise_for_status()
    upload_id = response.json()['uploadId']
    part = requests.put(
        f'{base_url}/api/v1/uploads/{upload_id}/parts', params={'partNumber': 1},
        headers={**headers, 'Content-Type': 'application/octet-stream'},
        data=path.read_bytes(), verify=False)
    part.raise_for_status()
    # под бурстом сида (несколько файлов + пачка сообщений) шлюз стенда отвечает
    # на complete транзиентным 5xx (наблюдён 504 через ~60s) — ретраим
    for attempt in range(3):
        complete = requests.post(
            f'{base_url}/api/v1/uploads/{upload_id}/complete', headers=headers,
            json={'parts': [{'partNumber': 1, 'checksum': part.json()['checksum']}]},
            verify=False)
        if complete.status_code < 500:
            break
        log.info(f'complete {upload_id}: HTTP {complete.status_code}, повтор через 5s')
        time.sleep(5)
    complete.raise_for_status()
    log.info(f'Файл {path.name} залит: uploadId={upload_id}')
    return upload_id


@step('Отправить файл {file_path} в чат', where=StepPlace.API)
def send_file_message(token, chat_id, file_path):
    """Отправить файл сообщением: chunked-заливка + POST /messages/batch.

    Формат batch снят с провода клиента: массив сообщений с clientMessageId
    (генерит отправитель) и files=[uploadId].
    :returns: объект созданного сообщения (files[] развёрнут, status='processing')
    """
    upload_id = upload_file_chunked(token, file_path)
    base_url = conf[env]['web_url']
    response = requests.post(
        f'{base_url}/api/v1/messages/batch',
        headers={"Authorization": f"Bearer {token}"},
        json=[{'chatId': chat_id, 'clientMessageId': str(uuid.uuid4()),
               'files': [upload_id], 'blocks': [], 'type': 'plain'}],
        verify=False)
    response.raise_for_status()
    return response.json()[0]


def get_chat_media_files(token, chat_id):
    """Плоский список объектов file со всех сообщений чата (у которых есть files)."""
    return [f for m in iva_one.get_chat_messages(token, chat_id) for f in (m.get('files') or [])]


def wait_files_processed(token, chat_id, expected_count, timeout=180, interval=3.0):
    """Дождаться прохождения SBC/DLP-проверки всеми файлами чата (status != processing).

    После заливки file.status='processing': лента рисует плейсхолдер «Материалы
    на проверке», превью не отдаются (HEAD /download → 403). Медиа-поля
    (preview/video/audio) появляются в JSON ещё ДО конца проверки —
    wait_media_fields_ready этот гейт не заменяет. Наблюдённые тайминги
    stage-one: image ~10s, audio ~30s, video ~60s.
    :param expected_count: сколько файлов должно быть в чате (защита от гонки,
                           когда часть файловых сообщений ещё не дошла)
    """
    deadline = time.time() + timeout
    state = 'файлы не получены'
    while time.time() < deadline:
        files = get_chat_media_files(token, chat_id)
        statuses = [f.get('status') for f in files]
        if len(files) >= expected_count and 'processing' not in statuses:
            log.info(f'Файлы чата {chat_id} прошли проверку: {statuses}')
            return
        state = f'{len(files)}/{expected_count} файлов, статусы {statuses}'
        time.sleep(interval)
    raise TimeoutError(f'Файлы чата {chat_id} не прошли проверку за {timeout}s ({state})')


def wait_files_available(token, chat_id, timeout=120, interval=3.0):
    """Дождаться фактической отдачи контента каждого файла чата (HTTP 200).

    Антивирусная проверка стенда — отдельный слой ПОСЛЕ file.status='done':
    до её конца preview/download отвечают 403 {"ruleName": "Antivirus default
    rule"} (лаг от секунд до минут), а клиент бесконечно ретраит такие файлы
    (цикл preview→download ~1/с) — фоновые запросы ленты ломают capture-ассерты
    «download не уходил». Гейт: у файла с preview[] ждём 200 на /preview,
    у остальных (аудио: /preview отвечает 400 unable-to-resolve) — HEAD /download.
    """
    base_url = conf[env]['web_url']
    headers = {"Authorization": f"Bearer {token}"}
    deadline = time.time() + timeout
    state = 'файлы не получены'
    while time.time() < deadline:
        pending = []
        for f in get_chat_media_files(token, chat_id):
            fid = f['id']
            if f.get('preview'):
                r = requests.get(f'{base_url}/api/v1/uploads/{fid}/preview',
                                 headers=headers, verify=False, timeout=30)
            else:
                r = requests.head(f'{base_url}/api/v1/uploads/{fid}/download',
                                  headers=headers, verify=False, timeout=30)
            if r.status_code != 200:
                pending.append(f'{fid}={r.status_code}')
        if not pending:
            log.info(f'Файлы чата {chat_id} отдаются (антивирус пройден)')
            return
        state = f'ждут антивируса: {pending}'
        time.sleep(interval)
    raise TimeoutError(f'Файлы чата {chat_id} не стали доступны за {timeout}s ({state})')


def wait_media_fields_ready(token, chat_id, expect=('preview', 'video', 'audio'),
                            timeout=120, interval=2.0):
    """Дождаться готовности новых медиа-полей после заливки файлов (async-конверсия на бэке:
    на быстром стенде почти мгновенно, на CI/крупных файлах нужен поллинг).

    expect — какие поля ждать среди файлов чата: 'preview' (непустой у image/video),
    'video' (video.preview.url у видео), 'audio' (audio.mp3Url у аудио). Передавать ровно
    те типы, что залиты.
    """
    want = set(expect)
    deadline = time.time() + timeout
    got = set()
    while time.time() < deadline:
        got = set()
        for f in get_chat_media_files(token, chat_id):
            if f.get('preview'):
                got.add('preview')
            if f.get('video'):
                got.add('video')
            if f.get('audio'):
                got.add('audio')
        if want <= got:
            return True
        time.sleep(interval)
    assert_fn(lambda: want <= got,
              f'Медиа-поля {sorted(want - got)} не готовы за {timeout}s в чате {chat_id} '
              f'(готовы: {sorted(got)})')


def seed_media_chat(token, chat_name, members, file_paths, *,
                    marker=None, text_filler=0, repeat_files=False,
                    ready_timeout=240):
    """Создать групповой чат и засеять медиа: (опц.) текст-маркер → file_paths →
    (опц.) text_filler текстовых сообщений → (опц.) повторить набор файлов →
    дождаться прохождения SBC/DLP-проверки всеми файлами и фактической
    отдачи контента (антивирусный слой — см. wait_files_available).

    Для TC 53251 (галерея): file_paths=[jpeg, mp4, wav]. Для TC 53239 (лента со
    скроллом до первого набора): marker=<строка> (первое сообщение чата — якорь
    домотки), text_filler=30, repeat_files=True.
    :param members: имена пользователей-участников (резолвятся в id внутри create_chat).
    :return: chat_id.
    """
    chat_id = iva_one.create_chat(token, chat_name, members)
    log.info(f'Засев медиа-чата {chat_id}: файлов={len(file_paths)}, '
             f'текст={text_filler}, повтор={repeat_files}')
    if marker:
        iva_one.send_message(token, chat_id, marker)
    for path in file_paths:
        send_file_message(token, chat_id, path)
    for i in range(text_filler):
        iva_one.send_message(token, chat_id, f'Сообщение {i + 1}')
    if repeat_files:
        for path in file_paths:
            send_file_message(token, chat_id, path)
    expected = len(file_paths) * (2 if repeat_files else 1)
    wait_files_processed(token, chat_id, expected, timeout=ready_timeout)
    wait_files_available(token, chat_id, timeout=ready_timeout)
    return chat_id
