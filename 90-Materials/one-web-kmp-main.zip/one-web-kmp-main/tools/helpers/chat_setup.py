"""REST-гейт готовности группового чата/канала после создания через REST.

Тест-слой: поллинг поверх REST API IVA ONE. POST /chats отдаёт id сразу, но участники
материализуются на бэке асинхронно: первые секунды GET /chats/{id} возвращает 404 либо
membersCount=0. UI, открытый до материализации, показывает «0 участников» / ловит 404
и сам не восстанавливается — поэтому перед открытием чата в браузере ждём готовности
по REST. Тонкой обёртки GET /chats/{id} в autocore iva_one нет — запрос делается напрямую.
"""
import time
import uuid

import requests

from autocore.clients.rest import iva_one
from autocore.clients.rest.iva_one import conf, env
from autocore.test.logger import get_log
from tools.enums import StepPlace
from tools.helpers.steps import step

log = get_log()


def wait_group_chat_materialized(token, chat_id, min_members, timeout=60, interval=3):
    """Дождаться материализации не меньше `min_members` участников в чате `chat_id`.

    404 в пределах таймаута — тоже ожидание (чат может быть ещё не виден читателю).
    :param token: токен пользователя-создателя чата
    :param chat_id: id чата из iva_one.create_chat
    :param min_members: минимальное число участников (создатель входит в счёт)
    :raises TimeoutError: чат не материализовался за timeout (с фактическим состоянием)
    """
    url = f"{conf[env]['web_url']}/api/v1/chats/{chat_id}"
    headers = {"Authorization": f"Bearer {token}"}
    deadline = time.time() + timeout
    state = 'ответ не получен'
    while time.time() < deadline:
        response = requests.get(url=url, headers=headers, verify=False)
        if response.status_code == 404:
            state = '404 (чат ещё не виден)'
        else:
            response.raise_for_status()
            members_count = response.json().get('membersCount', 0)
            if members_count >= min_members:
                log.info(f'Чат {chat_id} материализован: membersCount={members_count}')
                return
            state = f'membersCount={members_count} < {min_members}'
        time.sleep(interval)
    raise TimeoutError(f'Чат {chat_id} не материализовался за {timeout}s: {state}')


def wait_favorites_chat_materialized(token, user_id, timeout=180, interval=5):
    """Дождаться появления чата «Избранное» в списке чатов пользователя.

    Бэк создаёт favorites-чат свежего пользователя асинхронным job'ом (наблюдённый лаг
    75–120s от создания юзера); до этого GET /chats список его не отдаёт, а поиск в
    диалоге пересылки — уже находит (search-индекс), поэтому форвард проходит, а строка
    в левом списке чатов отсутствует. id favorites-чата детерминирован и равен
    keycloak-id владельца.
    :param token: токен владельца
    :param user_id: keycloak-id владельца (= id чата «Избранное»)
    :raises TimeoutError: чат не появился в списке за timeout
    """
    url = f"{conf[env]['web_url']}/api/v1/chats"
    headers = {"Authorization": f"Bearer {token}"}
    deadline = time.time() + timeout
    while time.time() < deadline:
        response = requests.get(url=url, headers=headers, verify=False)
        response.raise_for_status()
        data = response.json()
        chats = data if isinstance(data, list) else data.get('items', [])
        if any(chat.get('id') == user_id for chat in chats):
            log.info(f'Чат «Избранное» ({user_id}) материализован')
            return
        time.sleep(interval)
    raise TimeoutError(f'Чат «Избранное» ({user_id}) не появился в списке чатов за {timeout}s')


@step('Чат отображается в списке чатов', where=StepPlace.API)
def wait_chat_in_list(token, chat_id, timeout=60, interval=3):
    """Дождаться появления чата в списке GET /chats пользователя.

    Представление direct-чата у второй стороны материализуется асинхронно
    (лаг вариабелен, как members/favorites): сам чат по id уже читается,
    а строки в списке ещё нет — UI-открытие по имени в это окно падает.
    :param chat_id: id чата в представлении ЭТОГО пользователя
        (для direct — keycloak-id собеседника)
    :raises TimeoutError: чат не появился в списке за timeout
    """
    url = f"{conf[env]['web_url']}/api/v1/chats"
    headers = {"Authorization": f"Bearer {token}"}
    deadline = time.time() + timeout
    while time.time() < deadline:
        response = requests.get(url=url, headers=headers, verify=False)
        response.raise_for_status()
        data = response.json()
        chats = data if isinstance(data, list) else data.get('items', [])
        if any(chat.get('id') == chat_id for chat in chats):
            log.info(f'Чат {chat_id} отображается в списке')
            return
        time.sleep(interval)
    raise TimeoutError(f'Чат {chat_id} не появился в списке чатов за {timeout}s')


@step('Чат закреплён', where=StepPlace.API)
def wait_chat_pinned(token, chat_id, timeout=30, interval=2):
    """Дождаться непустого `pinnedAt` в детали GET /chats/{id}.

    Отдельного честного UI-признака закрепления строки чата в overlay нет.
    :returns: timestamp `pinnedAt`
    :raises TimeoutError: поле не заполнилось за timeout
    """
    url = f"{conf[env]['web_url']}/api/v1/chats/{chat_id}"
    headers = {"Authorization": f"Bearer {token}"}
    deadline = time.time() + timeout
    state = 'деталь чата не получена'
    while time.time() < deadline:
        response = requests.get(url=url, headers=headers, verify=False)
        if response.status_code == 404:
            state = '404 (чат ещё не виден)'
        else:
            response.raise_for_status()
            pinned_at = response.json().get('pinnedAt')
            if pinned_at:
                log.info(f'Чат {chat_id} закреплён: pinnedAt={pinned_at}')
                return pinned_at
            state = 'pinnedAt не заполнен'
        time.sleep(interval)
    raise TimeoutError(f'Чат {chat_id} не закреплён за {timeout}s: {state}')


@step('Чат «{name}» создан: тип {chat_type}', where=StepPlace.API)
def wait_chat_created(token, chat_id, name, chat_type, is_public=None, min_members=None,
                      timeout=60, interval=2):
    """Проверить поля созданного через UI чата по детали GET /chats/{id}.

    Деталь и участники материализуются асинхронно (404 / неполный membersCount
    первые секунды) — оба состояния входят в поллинг.
    :param chat_id: id из ответа POST /chats (возвращает PChatCreation.submit_create)
    :param chat_type: 'group' | 'channel'
    :param is_public: ожидаемая публичность; None — не проверять
    :param min_members: минимум участников; None — не проверять
    :returns: деталь чата (dict)
    :raises TimeoutError: деталь не материализовалась/не догнала min_members за timeout
    """
    headers = {"Authorization": f"Bearer {token}"}
    url = f"{conf[env]['web_url']}/api/v1/chats/{chat_id}"
    deadline = time.time() + timeout
    state = 'деталь чата не получена'
    while time.time() < deadline:
        response = requests.get(url=url, headers=headers, verify=False)
        if response.status_code == 404:
            state = '404 (чат ещё не материализован)'
        else:
            response.raise_for_status()
            detail = response.json()
            assert detail.get('name') == name, \
                f'Имя чата: ожидалось «{name}», фактическое «{detail.get("name")}»'
            assert detail.get('type') == chat_type, \
                f'Тип чата: ожидался {chat_type}, фактический {detail.get("type")}'
            if is_public is not None:
                actual_public = detail.get('isPublic', detail.get('public'))
                assert actual_public == is_public, \
                    f'Публичность чата: ожидалась {is_public}, фактическая {actual_public}'
            members_count = detail.get('membersCount', 0)
            if min_members is None or members_count >= min_members:
                log.info(f'Чат «{name}» ({chat_id}) создан: type={chat_type}, '
                         f'membersCount={members_count}')
                return detail
            state = f'membersCount={members_count} < {min_members}'
        time.sleep(interval)
    raise TimeoutError(f'Чат «{name}» не подтверждён за {timeout}s: {state}')


@step('Чат «{query}» доступен в поиске', where=StepPlace.API)
def wait_chat_in_search(token, chat_id, query, timeout=120, interval=5):
    """Дождаться появления чата в выдаче поиска чатов (GET /chats/search) искателя.

    Поисковый индекс лагает за созданием/сменой публичности (наблюдалось ~30s) —
    не-участник находит чужой публичный чат не сразу.
    :param token: токен пользователя-искателя
    :param chat_id: id искомого чата
    :param query: строка поиска (название чата)
    :raises TimeoutError: чат не появился в выдаче за timeout
    """
    deadline = time.time() + timeout
    while time.time() < deadline:
        if any(item.get('id') == chat_id for item in iva_one.search_chats(token, query)):
            log.info(f'Чат {chat_id} появился в поиске по «{query}»')
            return
        time.sleep(interval)
    raise TimeoutError(f'Чат {chat_id} не появился в поиске по «{query}» за {timeout}s')


@step('Пользователь «{full_name}» доступен в поиске', where=StepPlace.API)
def wait_user_searchable(token, full_name, timeout=120, interval=5):
    """Дождаться появления пользователя в поиске чатов искателя.

    Свежий пользователь индексируется асинхронно после своего первого логина
    (~20-60s); до этого поиск его не отдаёт.
    :param token: токен пользователя-искателя (scope выдачи)
    :param full_name: полное имя («Фамилия Имя») искомого пользователя
    :raises TimeoutError: пользователь не появился в выдаче за timeout
    """
    if not iva_one.wait_user_in_chat_search(token, full_name, timeout=timeout, interval=interval):
        raise TimeoutError(f'Пользователь «{full_name}» не появился в поиске за {timeout}s')


@step('Пользователь «{query}» доступен в справочнике людей', where=StepPlace.API)
def wait_user_in_directory_search(token, user_id, query, timeout=120, interval=5):
    """Дождаться пользователя в поиске справочника людей (GET /api/v2/users/search).

    Это ДРУГОЙ индекс, нежели поиск чатов (/api/v1/chats/search из
    wait_user_searchable): им пользуются UI-пикеры людей (добавление участников,
    выбор контакта), и индексация свежего пользователя в нём лагает независимо.
    UI-пикер шлёт запрос один раз на ввод — гейтить нужно до ввода запроса.
    :param token: токен пользователя-искателя
    :param user_id: keycloak-id искомого (матч по id — displayName может фаззиться)
    :param query: строка поиска (обычно фамилия)
    :raises TimeoutError: пользователь не появился в выдаче за timeout
    """
    url = f"{conf[env]['web_url']}/api/v2/users/search"
    headers = {"Authorization": f"Bearer {token}"}
    deadline = time.time() + timeout
    while time.time() < deadline:
        response = requests.get(url=url, headers=headers,
                                params={'query': query}, verify=False)
        response.raise_for_status()
        if any(item.get('id') == user_id for item in response.json()):
            log.info(f'Пользователь {user_id} появился в справочнике по «{query}»')
            return
        time.sleep(interval)
    raise TimeoutError(f'Пользователь «{query}» ({user_id}) не появился '
                       f'в справочнике людей за {timeout}s')


@step('Чат обновлён: {expected}', where=StepPlace.API)
def wait_chat_detail(token, chat_id, timeout=30, interval=2, can_contains=(), **expected):
    """Дождаться, пока поля детали GET /chats/{id} примут ожидаемые значения.

    Изменения настроек (mute, публичность, реакции/треды, название/описание)
    применяются бэком асинхронно относительно ответа PATCH/POST — поля детали
    поллятся до совпадения.
    :param can_contains: права, которые должны присутствовать в detail['can']
                         (например 'messages.reaction' после включения реакций)
    :param expected: ожидаемые поля детали, например isMuted=True
    :returns: деталь чата (dict)
    :raises TimeoutError: поля не приняли ожидаемых значений за timeout
    """
    headers = {"Authorization": f"Bearer {token}"}
    url = f"{conf[env]['web_url']}/api/v1/chats/{chat_id}"
    deadline = time.time() + timeout
    state = 'деталь чата не получена'
    while time.time() < deadline:
        response = requests.get(url=url, headers=headers, verify=False)
        if response.status_code != 404:
            response.raise_for_status()
            detail = response.json()
            actual = {field: detail.get(field) for field in expected}
            missing_can = [right for right in can_contains
                           if right not in detail.get('can', [])]
            if actual == expected and not missing_can:
                log.info(f'Чат {chat_id}: поля достигли {expected}'
                         + (f', can ⊇ {list(can_contains)}' if can_contains else ''))
                return detail
            state = f'фактически {actual}' + \
                    (f', в can нет {missing_can}' if missing_can else '')
        time.sleep(interval)
    raise TimeoutError(f'Чат {chat_id}: поля не достигли {expected} за {timeout}s ({state})')


@step('Отправить ответ-цитату на сообщение {reply_to_id}', where=StepPlace.API)
def send_reply_message(token, chat_id, text, reply_to_id):
    """Отправить сообщение-цитату (POST /messages с reply-метой) — сид reply-цепочки.

    Тонкой обёртки в autocore iva_one нет — запрос напрямую; reply — id
    цитируемого сообщения строкой, ответ несёт объект reply с телом родителя.
    :param reply_to_id: id цитируемого сообщения (из ответа send_message)
    :returns: тело созданного сообщения (dict)
    """
    url = f"{conf[env]['web_url']}/api/v1/messages"
    headers = {"Authorization": f"Bearer {token}"}
    response = requests.post(url=url, headers=headers,
                             json={'chatId': chat_id, 'message': text, 'reply': reply_to_id},
                             verify=False)
    response.raise_for_status()
    log.info(f'Ответ-цитата на {reply_to_id} отправлен')
    return response.json()


@step('Сообщение «{text}» содержит связку с цитируемым', where=StepPlace.API)
def wait_message_reply(token, chat_id, text, reply_to_id, timeout=15, interval=2):
    """Дождаться в истории чата сообщения `text` со связкой reply на `reply_to_id`.

    REST-канал ОР «режим ответа активен»: плашка цитаты над полем ввода
    рисуется только на canvas (после закрытия попапа меню overlay — стейл),
    факт «сообщение ушло именно ответом» наблюдаем reply-объектом в истории.
    :param reply_to_id: id цитируемого сообщения (из ответа send_message)
    :returns: сообщение (dict)
    :raises TimeoutError: сообщение со связкой не появилось за timeout
    """
    deadline = time.time() + timeout
    while time.time() < deadline:
        for message in iva_one.get_chat_messages(token, chat_id):
            if message.get('message') == text and \
                    (message.get('reply') or {}).get('id') == reply_to_id:
                log.info(f'Сообщение «{text}»: reply на {reply_to_id}')
                return message
        time.sleep(interval)
    raise TimeoutError(f'Сообщение «{text}» со связкой reply на {reply_to_id} '
                       f'не появилось в чате {chat_id} за {timeout}s')


@step('Удалить чат {chat_id}', where=StepPlace.API)
def delete_chat(token, chat_id):
    """Удалить чат (DELETE /api/v1/chats/{id}) — precondition-действие.

    Тонкой обёртки в autocore iva_one нет — запрос напрямую. У p2p-чата id
    в перспективе каждого участника свой: для удаляющего это keycloak-id
    собеседника. Удаление синхронно: чат сразу пропадает из GET /chats,
    история для удалившего очищается.
    :param token: токен пользователя, удаляющего чат
    :param chat_id: id чата в перспективе этого пользователя
    """
    url = f"{conf[env]['web_url']}/api/v1/chats/{chat_id}"
    headers = {"Authorization": f"Bearer {token}"}
    response = requests.delete(url=url, headers=headers, verify=False)
    response.raise_for_status()
    log.info(f'Чат {chat_id} удалён')


@step('Сообщение с упоминанием пользователя доставлено', where=StepPlace.API)
def wait_message_with_mention(token, chat_id, user_id, text=None, timeout=15, interval=2):
    """Дождаться в чате сообщения с блоком упоминания {'type': 'user', 'userId': ...}.

    Plain-текст сообщения имени упомянутого не несёт — упоминание живёт только
    в blocks; в ленте клиент рендерит его именем сам.
    :param user_id: keycloak-id упомянутого пользователя
    :param text: текст, который обязан присутствовать text-блоком того же
        сообщения (набранный после меншена текст уходит отдельным блоком
        с ведущим пробелом — матч подстрокой)
    :returns: сообщение (dict)
    :raises TimeoutError: сообщение с упоминанием не появилось за timeout
    """
    deadline = time.time() + timeout
    while time.time() < deadline:
        for message in iva_one.get_chat_messages(token, chat_id):
            blocks = message.get('blocks') or []
            mention_found = any(block.get('type') == 'user'
                                and block.get('userId') == user_id for block in blocks)
            text_found = text is None or any(block.get('type') == 'text'
                                             and text in block.get('text', '')
                                             for block in blocks)
            if mention_found and text_found:
                log.info(f'Сообщение {message.get("id")} упоминает {user_id}')
                return message
        time.sleep(interval)
    raise TimeoutError(f'Сообщение с упоминанием {user_id}'
                       f'{f" и текстом {text!r}" if text else ""} не появилось '
                       f'в чате {chat_id} за {timeout}s')


@step('Счётчик упоминаний чата у получателя = {count}', where=StepPlace.API)
def wait_chat_mention_counter(token, chat_id, count, timeout=30, interval=2):
    """Дождаться unreadMentionMessagesCount строки чата в GET /chats получателя.

    REST-канал для ОР «счётчик упоминания в списке чатов»: иконка упоминания
    в строке списка — canvas-only (в overlay не зеркалится), а поле hasMention
    бэк не использует (всегда false).
    :param token: токен упомянутого пользователя (получателя)
    :raises TimeoutError: счётчик не достиг count за timeout (с фактическим)
    """
    url = f"{conf[env]['web_url']}/api/v1/chats"
    headers = {"Authorization": f"Bearer {token}"}
    last = None
    deadline = time.time() + timeout
    while time.time() < deadline:
        response = requests.get(url=url, headers=headers, verify=False)
        response.raise_for_status()
        rows = response.json()
        rows = rows if isinstance(rows, list) else rows.get('items', [])
        for row in rows:
            if row.get('id') == chat_id:
                last = row.get('unreadMentionMessagesCount')
                if last == count:
                    log.info(f'Чат {chat_id}: unreadMentionMessagesCount={count}')
                    return
        time.sleep(interval)
    raise TimeoutError(f'unreadMentionMessagesCount чата {chat_id} не достиг {count} '
                       f'за {timeout}s (фактический: {last})')


@step('Тред сообщения содержит {min_messages} сообщение(й)', where=StepPlace.API)
def wait_thread_started(token, chat_id, parent_message_id, min_messages=1,
                        timeout=30, interval=2):
    """Дождаться треда у родительского сообщения и вернуть его id.

    Тред пре-создаётся бэком (поле thread.chatId есть у сообщения сразу),
    но счётчик thread.messagesCount растёт только с сообщениями треда —
    min_messages=0 ждёт лишь появления thread-поля (id для REST-сида).
    :param parent_message_id: id родительского сообщения в канале/чате
    :returns: id треда (thread.chatId — тред является чатом type=thread)
    :raises TimeoutError: тред не достиг min_messages за timeout
    """
    state = 'родительское сообщение не найдено'
    deadline = time.time() + timeout
    while time.time() < deadline:
        for message in iva_one.get_chat_messages(token, chat_id):
            if message.get('id') != parent_message_id:
                continue
            thread = message.get('thread') or {}
            if thread.get('chatId') and thread.get('messagesCount', 0) >= min_messages:
                log.info(f'Тред {thread["chatId"]}: '
                         f'messagesCount={thread.get("messagesCount", 0)}')
                return thread['chatId']
            state = f'thread={thread}'
        time.sleep(interval)
    raise TimeoutError(f'Тред сообщения {parent_message_id} не достиг '
                       f'{min_messages} сообщений за {timeout}s ({state})')


@step('Чат удалён на сервере', where=StepPlace.API)
def wait_chat_deleted(token, chat_id, timeout=30, interval=2):
    """Дождаться 404 детали GET /chats/{id} — удаление применено для читателя.

    :param token: токен пользователя, за которого проверяется недоступность
    :raises TimeoutError: чат всё ещё отвечает по истечении timeout
    """
    url = f"{conf[env]['web_url']}/api/v1/chats/{chat_id}"
    headers = {"Authorization": f"Bearer {token}"}
    deadline = time.time() + timeout
    while time.time() < deadline:
        response = requests.get(url=url, headers=headers, verify=False)
        if response.status_code == 404:
            log.info(f'Чат {chat_id} удалён (деталь отвечает 404)')
            return
        time.sleep(interval)
    raise TimeoutError(f'Чат {chat_id} не удалился за {timeout}s '
                       f'(деталь отвечает {response.status_code})')


@step('Реакция «{name}» установлена на сообщение', where=StepPlace.API)
def wait_message_reaction(token, chat_id, message_id, name, timeout=30, interval=2):
    """Дождаться реакции `name` в reactions сообщения (формат бэка:
    [{count, name, users}]) — подтверждение UI-выбора реакции.

    :param name: слаг реакции ('fire', 'thumbsup', ...)
    :raises TimeoutError: реакция не появилась за timeout
    """
    deadline = time.time() + timeout
    while time.time() < deadline:
        for message in iva_one.get_chat_messages(token, chat_id):
            if message.get('id') == message_id and any(
                    reaction.get('name') == name
                    for reaction in message.get('reactions') or []):
                log.info(f'Сообщение {message_id}: реакция {name} установлена')
                return
        time.sleep(interval)
    raise TimeoutError(f'Реакция {name} не появилась на сообщении '
                       f'{message_id} за {timeout}s')


@step('Отправить сообщение со ссылкой https://{url}', where=StepPlace.API)
def send_link_message(token, chat_id, url, text):
    """Отправить сообщение «ссылка + текст» готовыми блоками — сид линк-сообщения.

    Линкификация client-side: клиент шлёт POST /messages/batch с разобранными
    blocks (type=link + type=text) — хелпер воспроизводит формат клиента.
    :param url: адрес без схемы (https:// добавляется, как делает линкификация)
    :param text: текст после ссылки
    :returns: тело созданного сообщения (dict)
    """
    endpoint = f"{conf[env]['web_url']}/api/v1/messages/batch"
    headers = {"Authorization": f"Bearer {token}"}
    payload = [{
        'chatId': chat_id,
        'clientMessageId': str(uuid.uuid4()),
        'files': [],
        'blocks': [
            {'type': 'link', 'text': f'https://{url}', 'url': f'https://{url}'},
            {'type': 'text', 'text': f' {text}'},
        ],
        'type': 'plain',
    }]
    response = requests.post(url=endpoint, headers=headers, json=payload, verify=False)
    response.raise_for_status()
    log.info(f'Сообщение со ссылкой https://{url} отправлено в чат {chat_id}')
    return response.json()[0]


@step('Отправить сообщение с упоминанием пользователя', where=StepPlace.API)
def send_mention_message(token, chat_id, user_id, text):
    """Отправить сообщение «упоминание + текст» готовыми блоками — сид
    меншен-сообщения. Воспроизводит формат клиента: вставка меншена из
    mention-списка шлёт POST /messages/batch с blocks type=user + type=text
    (текст отдельным блоком с ведущим пробелом).
    :param user_id: keycloak-id упоминаемого
    :param text: текст после упоминания
    :returns: тело созданного сообщения (dict)
    """
    endpoint = f"{conf[env]['web_url']}/api/v1/messages/batch"
    headers = {"Authorization": f"Bearer {token}"}
    payload = [{
        'chatId': chat_id,
        'clientMessageId': str(uuid.uuid4()),
        'files': [],
        'blocks': [
            {'type': 'user', 'userId': user_id},
            {'type': 'text', 'text': f' {text}'},
        ],
        'type': 'plain',
    }]
    response = requests.post(url=endpoint, headers=headers, json=payload, verify=False)
    response.raise_for_status()
    log.info(f'Сообщение с упоминанием {user_id} отправлено в чат {chat_id}')
    return response.json()[0]


@step('Сообщение закреплено в чате', where=StepPlace.API)
def wait_message_pinned(token, chat_id, message_id, timeout=30, interval=2):
    """Дождаться isPinned=True у сообщения — подтверждение действия «Закрепить».

    Закрепление применяется бэком асинхронно относительно ответа POST /pin.
    :param message_id: id сообщения из ответа send_message
    :raises TimeoutError: сообщение не закрепилось за timeout
    """
    deadline = time.time() + timeout
    while time.time() < deadline:
        for message in iva_one.get_chat_messages(token, chat_id):
            if message.get('id') == message_id and message.get('isPinned'):
                log.info(f'Сообщение {message_id}: isPinned=True')
                return
        time.sleep(interval)
    raise TimeoutError(f'Сообщение {message_id} не закрепилось за {timeout}s')


@step('Сообщение удалено из истории чата', where=StepPlace.API)
def wait_message_absent(token, chat_id, message_id, timeout=30, interval=2):
    """Дождаться исчезновения сообщения из GET /messages участника.

    DELETE убирает объект сообщения из выдачи целиком (ни deletedAt-tombstone,
    ни isDeleted) — критерий удаления = отсутствие id в истории.
    :param token: токен участника, за которого проверяется история
    :raises TimeoutError: сообщение всё ещё в истории по истечении timeout
    """
    deadline = time.time() + timeout
    while time.time() < deadline:
        if all(message.get('id') != message_id
               for message in iva_one.get_chat_messages(token, chat_id)):
            log.info(f'Сообщение {message_id} исчезло из истории чата {chat_id}')
            return
        time.sleep(interval)
    raise TimeoutError(f'Сообщение {message_id} осталось в истории чата {chat_id} '
                       f'спустя {timeout}s')


@step('Сообщение «{text}» присутствует в чате в {count} экземплярах', where=StepPlace.API)
def wait_message_copies(token, chat_id, text, count, timeout=15, interval=2):
    """Дождаться `count` сообщений с текстом `text` в истории чата.

    REST-канал проверки копирования: содержимое поля ввода и тост
    «Сообщение скопировано» в overlay не зеркалятся — факт «вставилось
    ровно то, что скопировано» наблюдаем дублем текста в истории.
    :raises TimeoutError: число копий не достигло count за timeout
    """
    last = 0
    deadline = time.time() + timeout
    while time.time() < deadline:
        last = sum(1 for message in iva_one.get_chat_messages(token, chat_id)
                   if message.get('message') == text)
        if last == count:
            log.info(f'Сообщение «{text}» в чате {chat_id}: {count} шт.')
            return
        time.sleep(interval)
    raise TimeoutError(f'Сообщений «{text}» в чате {chat_id}: {last}, '
                       f'ожидалось {count} (за {timeout}s)')


@step('Сообщение «{text}» присутствует в истории чата', where=StepPlace.API)
def wait_message_id(token, chat_id, text, timeout=30, interval=2):
    """Дождаться сообщения с текстом `text` в истории чата и вернуть его id.

    Сид, где id нужен дальнейшим REST-действиям (реакция, пин): сообщение,
    отправленное при создании чата (`create_p2p_chat(message=...)`),
    материализуется в истории асинхронно — мгновенный поиск ловит гонку.
    :raises TimeoutError: сообщение не появилось в истории за timeout
    """
    deadline = time.time() + timeout
    while time.time() < deadline:
        for message in iva_one.get_chat_messages(token, chat_id):
            if message.get('message') == text:
                log.info(f'Сообщение «{text}» в чате {chat_id}: id={message["id"]}')
                return message['id']
        time.sleep(interval)
    raise TimeoutError(f'Сообщение «{text}» не появилось в истории чата {chat_id} '
                       f'за {timeout}s')


@step('Сообщение получило статус «{status}»', where=StepPlace.API)
def wait_message_status(token, chat_id, message_id, status, timeout=30, interval=2):
    """Дождаться, пока metadata.status сообщения станет `status` ('sent'/'delivered'/'read').

    Статус доставки/прочтения в a11y-overlay клиента не экспонируется (галочка
    рисуется только на canvas) — прочтение ассертится по REST.
    :param token: токен любого участника чата
    :param message_id: id сообщения из ответа send_message
    :raises TimeoutError: статус не достигнут за timeout (с фактическим статусом)
    """
    last = None
    deadline = time.time() + timeout
    while time.time() < deadline:
        for message in iva_one.get_chat_messages(token, chat_id):
            if message.get('id') == message_id:
                last = message.get('metadata', {}).get('status')
                if last == status:
                    log.info(f'Сообщение {message_id}: status={status}')
                    return
        time.sleep(interval)
    raise TimeoutError(f'Сообщение {message_id} не достигло status={status} за {timeout}s '
                       f'(фактический: {last})')
