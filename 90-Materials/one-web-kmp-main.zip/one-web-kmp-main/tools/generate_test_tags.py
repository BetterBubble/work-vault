"""Генератор реестра testTag-констант из test_tags.xml исходников KMP-клиента.

KMP-клиент (Compose Multiplatform) экспортирует Modifier.testTag(...) как DOM id
узла accessibility-overlay в open Shadow Root — эти id служат первичными локаторами
canvas-поверхности (см. tests/pages/base_page.py). Первоисточник — test_tags.xml
исходников продукта; реестр tools/test_tags.py генерируется из value элементов
(равенство name==value не гарантируется — DOM id несёт именно value).

Запуск из корня one-web:
    ./venv/bin/python tools/generate_test_tags.py             # перегенерировать реестр
    ./venv/bin/python tools/generate_test_tags.py --check     # сверить (exit 1 при дрейфе)

--check — детект дрейфа тегов при смене сборки стенда без браузера: обнови клон
исходников до ревизии сборки (git pull / checkout тега) и сверь реестр диффом.
"""
import argparse
import re
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

DEFAULT_XML = Path('/Users/oc4kxb/Projects/iva/kmp/core/resources/src/commonMain/composeResources/values/test_tags.xml')
TARGET = Path(__file__).parent / 'test_tags.py'

HEADER = '''"""Реестр testTag-констант KMP-клиента: значение = DOM id узла a11y-overlay.

АВТОГЕНЕРИРОВАН tools/generate_test_tags.py из test_tags.xml (ревизия продукта {rev}).
Не редактировать руками; при смене сборки стенда — перегенерировать или сверить --check.
Использование: page.locator(f'#{{CHAT_SCREEN}}') — CSS-id пробивает open Shadow Root.
"""
'''


def parse_tags(xml_path: Path) -> list[tuple[str, str]]:
    root = ET.parse(xml_path).getroot()
    tags = []
    seen = set()
    for el in root.findall('string'):
        name, value = el.get('name'), (el.text or '').strip()
        if not name or not value:
            raise ValueError(f'Пустой name/value в {xml_path}: name={name!r} value={value!r}')
        const = re.sub(r'^test_id_', '', name).upper()
        if const in seen:
            raise ValueError(f'Дубль константы {const} (name={name}) в {xml_path}')
        seen.add(const)
        tags.append((const, value))
    return tags


def product_revision(xml_path: Path) -> str:
    try:
        return subprocess.run(
            ['git', '-C', str(xml_path.parent), 'rev-parse', '--short', 'HEAD'],
            capture_output=True, text=True, check=True,
        ).stdout.strip()
    except (subprocess.CalledProcessError, FileNotFoundError):
        return 'unknown'


def render(tags: list[tuple[str, str]], rev: str) -> str:
    lines = [HEADER.format(rev=rev)]
    lines += [f"{const} = '{value}'" for const, value in tags]
    return '\n'.join(lines) + '\n'


def assignments(text: str) -> list[str]:
    return [line for line in text.splitlines() if re.match(r'^[A-Z0-9_]+ = ', line)]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--xml', type=Path, default=DEFAULT_XML, help='путь к test_tags.xml клона продукта')
    parser.add_argument('--check', action='store_true', help='сверить реестр с XML, не перезаписывая')
    args = parser.parse_args()

    tags = parse_tags(args.xml)
    content = render(tags, product_revision(args.xml))

    if args.check:
        if not TARGET.exists():
            print(f'{TARGET} отсутствует — сгенерируй без --check', file=sys.stderr)
            return 1
        current, fresh = assignments(TARGET.read_text()), assignments(content)
        if current == fresh:
            print(f'OK: {len(fresh)} тегов, дрейфа нет')
            return 0
        removed, added = set(current) - set(fresh), set(fresh) - set(current)
        print(f'ДРЕЙФ testTag ({len(removed)} исчезло, {len(added)} появилось):', file=sys.stderr)
        for line in sorted(removed):
            print(f'  - {line}', file=sys.stderr)
        for line in sorted(added):
            print(f'  + {line}', file=sys.stderr)
        return 1

    TARGET.write_text(content)
    print(f'{TARGET}: {len(tags)} тегов (ревизия {product_revision(args.xml)})')
    return 0


if __name__ == '__main__':
    sys.exit(main())
