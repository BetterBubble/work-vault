# one-web autotests (KMP-линия)

Репозиторий содержит Python/Playwright автотесты для IVA ONE WEB на Kotlin Multiplatform
(Compose, «IVA Aura»). Тесты запускаются через `pytest` в headless Chromium (Playwright,
без Selenoid) и формируют raw-результаты Allure в директории `allure-raw`.

UI приложения — один `<canvas>`; локация элементов идёт по узлам accessibility-overlay
внутри open Shadow Root (`#test_id_*` из реестра `tools/test_tags.py` и role/имя), клики
и ввод — координатные (`compose_click`/`compose_fill` из `tests/pages/base_page.py`).
Страница логина — обычный Keycloak-DOM, водится штатными методами Playwright.

## Требования

- Python 3.13 с модулем `venv`.
- Доступ к внутреннему PyPI: `http://at-pypi.iva.ru/root/dev/+simple/`.
- Сетевой доступ к стенду IVA ONE (REST) и к URL, с которого браузер грузит KMP-клиент.
- Для публикации результатов в Allure TestOps: установленный `allurectl` и токен доступа.

## Настройка окружения

Создание виртуального окружения и установка зависимостей:

```bash
python3 -m venv venv
./venv/bin/pip install --index-url http://at-pypi.iva.ru/root/dev/+simple/ --trusted-host at-pypi.iva.ru -r requirements.txt
./venv/bin/python -m playwright install chromium
```

## Конфигурация стендов и секреты

Стенды описаны в `config.yaml`; имя верхнего уровня — значение опции `--env`.
Основной стенд KMP-линии — `kmp-stage` (он же дефолт `--env`):

- `web_url` — базовый URL бэкенда (REST-сетап/ассерты ходят сюда напрямую).
- `admin_url` — URL админки/Keycloak.
- `browser_url` — опциональный URL, с которого браузер грузит KMP-клиент
  (локальный dev-server `local.ivcs.su:8443`, проксирующий API на стенд). Если поля
  нет (развёрнутый KMP-стенд), браузер открывает `web_url`.

Секреты (креды админа, client-secret) в git не хранятся: файл `secrets.yaml` в корне
(gitignored, схема — `secrets.yaml.example`), секция с именем env домёрживается в
конфиг стенда фикстурой `setup`.

## Основные pytest-опции

Опции добавлены в `conftest.py`:

- `--env` — имя стенда из `config.yaml`, по умолчанию `kmp-stage`.
- `--lang` — язык интерфейса AUT, по умолчанию русский из `autocore.consts`.
- `--headed` — запуск браузера с окном (отладка); по умолчанию headless.

В `pytest.ini` уже задано:

```ini
addopts = -v -p no:cacheprovider --tb=native --showlocals --strict-markers --alluredir=./allure-raw
```

Поэтому pytest всегда пишет результаты Allure в `./allure-raw`.

## Запуск тестов

Весь набор / срез, связанный с ТК TestOps / конкретный тест:

```bash
./venv/bin/python -m pytest tests/
./venv/bin/python -m pytest -m suite_smoke
./venv/bin/python -m pytest -k test_group_chat_send_message
```

Маркеры `suite_smoke`/`suite_regress` оставлены только на тестах, привязанных к
каноническому тест-кейсу TestOps (`@allure.id` на кейс project 37, домен Мессенджер);
`-m suite_smoke` гоняет ровно этот срез.

Стенд и браузер указывать не нужно: дефолт — `kmp-stage`, единственный браузер —
Chromium Playwright (селеноидов и браузерных маркеров в KMP-линии нет).

## testTag-реестр локаторов

Продукт инструментован `Modifier.testTag(...)` → DOM id узлов overlay. Реестр констант
`tools/test_tags.py` автогенерируется из `test_tags.xml` клона исходников продукта:

```bash
./venv/bin/python tools/generate_test_tags.py            # перегенерация
./venv/bin/python tools/generate_test_tags.py --check    # сверка с клоном (дрейф сборки)
```

При смене сборки стенда реестр сверяется с ревизией клона (`--check`); шапка файла
несёт ревизию продукта, из которой он сгенерирован.

## Артефакты падений (evidence)

Trace и видео пишутся для каждого теста (retain-on-failure): при падении скриншот и
видео прикладываются в Allure, trace остаётся файлом в `tests/logs/pw-evidence/`
(в отчёт не прикладывается — десятки МБ); на зелёных прогонах файлы удаляются.
Trace открывается так:

```bash
./venv/bin/python -m playwright show-trace <trace.zip>
```

## Загрузка в Allure TestOps через allurectl

Возможные опции:

- `--endpoint` — URL Allure TestOps.
- `--token` — API token пользователя.
- `--project-id` — ID проекта в TestOps.
- `--launch-name` — название запуска.
- `--launch-tags` — теги запуска через запятую.
- `--launch-id` — ID существующего запуска для дозагрузки результатов (ID берётся из
  URL страницы запуска: `https://allure.iva.ru/launch/12345` → `12345`).

Базовая загрузка результатов:

```bash
allurectl upload --endpoint https://allure.iva.ru/ --token <TOKEN> --project-id 5 --launch-name "<ALLURE_LAUNCH_NAME>" ./allure-raw/
```
