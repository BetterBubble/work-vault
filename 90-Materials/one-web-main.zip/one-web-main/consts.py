IVA_MCU_CLIENT_SECRET = 'gAzCQJqGmL3pi53KTfn7fJI0iUZiqLuE'
# Палитра appearance дефолт-аватара (iva-билд): SELECTABLE_GRADIENT_APPEARANCES продукта
# (AVATAR_GRADIENT_APPEARANCES без 'default'); порядок и имена должны совпадать с
# avatar.types.ts. На ds-линии (crc) idx 2 = 'orange' — НЕ переносить туда 'apricot'.
DEFAULT_AVATAR_GRADIENTS = ["pink", "yellow", "apricot", "turquoise", "purple", "blue"]