# one-web autotests

Репозиторий содержит Python/Selenium автотесты для IVA ONE WEB. Тесты запускаются через `pytest`, используют браузеры в Selenoid и формируют raw-результаты Allure в директории `allure-raw`.

## Требования

- Python 3.13 с модулем `venv`.
- Доступ к внутреннему PyPI: `http://at-pypi.iva.ru/root/dev/+simple/`.
- Сетевой доступ к нужному стенду IVA ONE WEB и Selenoid.
- Для публикации результатов в Allure TestOps: установленный `allurectl` и токен доступа.

## Настройка окружения

Создание виртуального окружения:

```bash
python3 -m venv venv
```

Активация виртуального окружения:

```bash
source venv/bin/activate
```

Установка зависимостей:

```bash
pip install --index-url http://at-pypi.iva.ru/root/dev/+simple/ --trusted-host at-pypi.iva.ru -r requirements.txt
```

## Конфигурация стендов

Стенды описаны в `config.yaml`. Имя верхнего уровня используется как значение опции `--env`.

Доступные стенды:

- `gamma`
- `at-test-1-one`
- `at-test-3-one`

Внутри каждого стенда заданы:

- `web_url` - URL веб-приложения.
- `admin_url` - URL админки/Keycloak.
- `selenoid` - основной Selenoid.
- `new-win-selenoid` - Selenoid для Windows-браузеров.
- `mac-selenoid` - Selenoid для Safari на macOS.

### Особенность стенда gamma

Основной стенд для запуска - `at-test-1-one`.

Для запуска тестов на `gamma`, в IVA ID должна быть включена настройка `Direct access grants` для клиента `iva-one` в realm `IVA` (Требуется для того, чтобы работала авторизация по api за созданных пользователей).

Путь к настройке:

1. Открыть IVA ID и выбрать `Manage realms`.
2. Выбрать realm `IVA`.
3. Перейти в `Clients`.
4. Открыть клиент `iva-one`.
5. В блоке `Capability config` включить `Direct access grants` и сохранить изменения.

## Основные pytest-опции

Опции добавлены в `conftest.py`:

- `--env` - имя стенда из `config.yaml`. Обязательная опция для обычного запуска.
- `--ver` - версия UI/локаторов, по умолчанию `Version2`.
- `--lang` - язык интерфейса AUT, по умолчанию русский язык из `autocore.consts`.
- `--local` - локальный режим: тестовые данные браузера пишутся в `tools/data`, иначе используется `/testdata`.
- `--browser-tag` - тег версии браузера, по умолчанию `current`; используется инфраструктурой `autocore`.
- `--from-pipeline` - флаг запуска из pipeline; в этом репозитории только регистрируется, остальная логика может находиться в `autocore`.

В `pytest.ini` уже задано:

```ini
addopts = -v -p no:cacheprovider --tb=native --showlocals --strict-markers --alluredir=./allure-raw
```

Поэтому pytest всегда пишет результаты Allure в `./allure-raw`.

## Запуск тестов

Локально (Chrome):

```bash
./venv/bin/python -m pytest -m suite_smoke --env at-test-1-one --local
```

Запустить конкретный тест:

```bash
./venv/bin/python -m pytest -k test_name --env at-test-1-one --local
```

## Запуск в разных браузерах

Браузер выбирается через pytest markers. Основные markers зарегистрированы в `pytest.ini` и автоматически добавляются к тестам в `pytest_collection_modifyitems`.

Доступные браузерные markers:

- `browser_win_chrome` - Chrome на Windows.
- `browser_win_firefox` - Firefox на Windows.
- `browser_win_msedge` - Microsoft Edge на Windows.
- `browser_lin_chrome` - Chrome на Linux.
- `browser_win_ya` - Yandex Browser на Windows.
- `browser_mac_safari` - Safari на macOS; добавляется только для single-session тестов с `setup_aut`.

Запустить smoke-набор:

На win-selenoid:

```bash
./venv/bin/python -m pytest -m "suite_smoke and browser_win_ya" --env at-test-1-one --browser-tag current
./venv/bin/python -m pytest -m "suite_smoke and browser_win_firefox" --env at-test-1-one --browser-tag current
./venv/bin/python -m pytest -m "suite_smoke and browser_win_msedge" --env at-test-1-one --browser-tag current
./venv/bin/python -m pytest -m "suite_smoke and browser_win_chrome" --env at-test-1-one --browser-tag current
```

На mac-selenoid:

```bash
./venv/bin/python -m pytest -m "suite_smoke and browser_mac_safari" --env at-test-1-one --browser-tag current
```

На lin-selenoid (chrome):

```bash
./venv/bin/python -m pytest -m "suite_smoke" --env at-test-1-one
```

## Allure-отчёты

Raw-результаты пишутся в директорию:

```text
allure-raw
```

При падении теста `conftest.py` прикладывает screenshot к Allure.

## Загрузка в Allure TestOps через allurectl

Возможные опции:

- `--endpoint` - URL Allure TestOps.
- `--token` - API token пользователя.
- `--project-id` - ID проекта в TestOps.
- `--launch-name` - название запуска.
- `--launch-tags` - теги запуска через запятую.
- `--launch-id` - ID существующего запуска, если нужно дозагрузить результаты в уже созданный запуск.

Если запуск в TestOps ещё не закрыт, в него можно дозагрузить результаты через `--launch-id`. ID запуска берётся из URL страницы запуска в TestOps: например, в URL вида `https://allure.iva.ru/launch/12345` ID запуска - `12345`.

Базовая загрузка результатов:

```bash
allurectl upload --endpoint https://allure.iva.ru/ --token c48d424e-f95d-49e9-be5e-0caedbcccde5 --project-id 5 --launch-name "<ALLURE_LAUNCH_NAME>" ./allure-raw/
```

## Запуск пайплайна через glab (CLI)

Помимо GitLab UI (CI/CD → Pipelines → Run pipeline), пайплайн можно дёрнуть из терминала через [`glab`](https://gitlab.com/gitlab-org/cli). Пайплайн принимает источник `api` (см. `workflow.rules` в `.gitlab-ci.yml`), поэтому `glab ci run` его запускает:

```bash
glab ci run -b <branch> \
  --variables TEST_ENV:at-test-1-one \
  --variables TEST_BROWSER:browser_lin_chrome \
  --variables TEST_SUITE:suite_smoke \
  --variables JIRA_ISSUE:VCSAT-1234
```

- `-b <branch>` — ветка, с которой гонять (она же попадёт в теги ланча).
- Переменные переопределяют дефолты из `variables` `.gitlab-ci.yml` (стенд/браузер/набор).
- `TEST_K` (опционально) — pytest `-k`-выражение (`test_a or test_b`): гонит **только** эти тесты на `TEST_BROWSER`, игнорируя `TEST_SUITE`. Полезно, чтобы прогнать узкий набор (например только что разработанные тесты).
- `JIRA_ISSUE` (опционально) — ключ Jira-задачи: попадёт в имя ланча и привяжет ланч к задаче через интеграцию TestOps↔Jira (`allurectl launch add-issue --integration-id 5`). Без неё прогон идёт без привязки.
