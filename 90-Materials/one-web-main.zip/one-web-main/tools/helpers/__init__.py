from consts import DEFAULT_AVATAR_GRADIENTS
from autocore.test.logger import get_log

log = get_log()


def _to_int32(n: int) -> int:
    """ToInt32 (как JS-побитовые операции): свернуть в знаковое 32-битное."""
    n &= 0xFFFFFFFF
    return n - 0x100000000 if n & 0x80000000 else n


def _hash_code(s: str) -> int:
    """Хеш appearance дефолт-аватара iva-билда — повторяет defaultAvatarHashFn продукта
    (libs/design-system avatar.tokens.ts): hash = charCodeAt(i) + ((hash << 5) - hash),
    где << 5 считается в int32, а вычитание/сложение — точные (float64 в JS), на выходе
    Math.abs. Отличается от ds-схемы (чистый 31*h+c в int32) — НЕ переносить на crc/ds-линию."""
    h = 0
    for ch in s:
        h = ord(ch) + (_to_int32(_to_int32(h) << 5) - h)
    return abs(h)


def _get_index(input_str: str) -> int:
    """Возвращает индекс цвета на основе хеша строки."""
    return _hash_code(input_str) % len(DEFAULT_AVATAR_GRADIENTS)


def get_gradient(s: str) -> str:
    """Возвращает текстовое значения градиента на основе строки."""
    idx = _get_index(s)
    gradient = DEFAULT_AVATAR_GRADIENTS[idx]
    log.info(f'Получен ожидаемый цвет градиента аватара по умолчанию "{gradient}"')
    return gradient


def build_chat_link(chat_id: str) -> str:
    """Собрать публичную ссылку на чат/канал в формате `{web_url}/chat/{chat_id}`.

    Формат совпадает с тем, что UI приложения IVA ONE WEB кладёт в буфер обмена
    при клике «Скопировать ссылку» в карточке чата. Никакого специального
    REST-endpoint'а в API нет — ссылка собирается клиентом.

    Используется в тестах, где Steps явно не предписывают UI-копирование (TC-705,
    TC-776). В TC-893/TC-769/TC-938 — наоборот, UI copy в Steps, поэтому там
    остаётся `group_chat_profile.copy_chat_link()` через буфер.
    """
    from autocore.clients.rest.iva_one import conf, env
    base_url = conf[env]['web_url']
    link = f'{base_url}/chat/{chat_id}'
    log.info(f'Собрана ссылка на чат: {link}')
    return link
