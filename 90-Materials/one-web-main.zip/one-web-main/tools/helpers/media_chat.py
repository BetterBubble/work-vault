"""Подготовка медиа-чата для тестов IVAONE-11538 (отображение вложений в ленте/галерее/просмотрщике).

Тест-слой: композиция и поллинг поверх REST-примитивов autocore `iva_one`. Своего HTTP
не делает — все сетевые вызовы только через `iva_one` (`create_chat`, `send_file_message`,
`send_message`, `get_chat_messages`).

Новые медиа-поля бэкенда в объекте file сообщения: preview[] (image/video),
video.preview.url (video), audio.mp3Url (audio); file.url = оригинал (.../download).
"""
import time

from autocore.clients.rest import iva_one
from autocore.test.assertions import assert_fn
from autocore.test.logger import get_log

log = get_log()


def get_chat_media_files(token, chat_id):
    """Плоский список объектов file со всех сообщений чата (у которых есть files)."""
    return [f for m in iva_one.get_chat_messages(token, chat_id) for f in (m.get('files') or [])]


def wait_media_fields_ready(token, chat_id, expect=('preview', 'video', 'audio'),
                            timeout=120, interval=2.0):
    """Дождаться готовности новых медиа-полей после заливки файлов (async-конверсия на бэке:
    на быстром стенде почти мгновенно, на CI/крупных файлах нужен поллинг).

    expect — какие поля ждать среди файлов чата: 'preview' (непустой у image/video),
    'video' (video.preview.url у видео), 'audio' (audio.mp3Url у аудио). Передавать ровно
    те типы, что залиты.
    """
    want = set(expect)
    deadline = time.time() + timeout
    got = set()
    while time.time() < deadline:
        got = set()
        for f in get_chat_media_files(token, chat_id):
            if f.get('preview'):
                got.add('preview')
            if f.get('video'):
                got.add('video')
            if f.get('audio'):
                got.add('audio')
        if want <= got:
            return True
        time.sleep(interval)
    assert_fn(lambda: want <= got,
              f'Медиа-поля {sorted(want - got)} не готовы за {timeout}s в чате {chat_id} '
              f'(готовы: {sorted(got)})')


def seed_media_chat(token, chat_name, members, file_paths,
                    text_filler=0, repeat_files=False,
                    expect=('preview', 'video', 'audio'), ready_timeout=120):
    """Создать групповой чат и засеять медиа: залить file_paths → (опц.) text_filler
    текстовых сообщений → (опц.) повторить набор файлов → дождаться готовности полей expect.

    Для TC 53251 (галерея): file_paths=[jpeg, mp4, wav]. Для TC 53239 (лента):
    дополнительно text_filler=100, repeat_files=True.
    :param members: имена пользователей-участников (резолвятся в id внутри create_chat).
    :return: chat_id.
    """
    chat_id = iva_one.create_chat(token, chat_name, members)
    log.info(f'Засев медиа-чата {chat_id}: файлов={len(file_paths)}, '
             f'текст={text_filler}, повтор={repeat_files}')
    for path in file_paths:
        iva_one.send_file_message(token, chat_id, path)
    for i in range(text_filler):
        iva_one.send_message(token, chat_id, f'Сообщение {i + 1}')
    if repeat_files:
        for path in file_paths:
            iva_one.send_file_message(token, chat_id, path)
    wait_media_fields_ready(token, chat_id, expect=expect, timeout=ready_timeout)
    return chat_id
