from autocore.clients.rest import iva_one


def web_preamble(setup_aut, teardown, register_quit=True):
    """Стандартный single-session preamble: lang/version/driver (+ quit в teardown).

    Возвращает (lang, version, driver). config/secret тест берёт сам (он опционален).
    register_quit=False — когда тесту нужен свой порядок teardown (mail_user/jump-cleanup).
    """
    cmd = setup_aut['setup']['cmd']
    driver = setup_aut['driver']
    if register_quit:
        teardown.append((lambda el: el.quit(), driver))
    return cmd['lang'], cmd['ver'], driver


def iva_one_web_login(aut, user):
    """REST-логин веб-клиента IVA ONE по кредам user → access token.

    Сворачивает iva_one.login(u, p, 'IVA', 'iva-one', secret): realm/client_id
    константны для веб-клиента, secret берётся из aut. user — словарь кредов
    (users_factory / config-юзер). Admin/MCU-логины НЕ через неё (другой client_id).
    aut — бандл setup_aut (single) либо auts (multi); подструктура ['setup']['config'] одна.
    """
    secret = aut['setup']['config']['iva-one-client-secret']
    return iva_one.login(user['username'], user['password'], 'IVA', 'iva-one', secret)


def get_user_position(config, username):
    """Должность (Keycloak-атрибут `position`) пользователя — админским токеном.

    Нужна тестам, ассертящим отображение должности участника в UI: значение задаётся
    на стенде (в админке/LDAP), поэтому читаем из Keycloak, а не хардкодим. Возвращает
    строку должности либо None, если атрибут не задан.
    """
    admin_token = iva_one.login(**config['credentials']['admin'])
    for user in iva_one.get_user_info(admin_token, config['web-realm'], username):
        if user.get('username', '').lower() == username.lower():
            position = user.get('attributes', {}).get('position', [])
            return position[0] if position else None
    return None


def relogin_session(setup_aut, teardown):
    """Пересоздать single-session драйвер для смены пользователя (relogin).

    Гасит текущий драйвер, снимает его quit из teardown (pop(-1) — web_preamble
    регистрирует его последним, между ними других append нет), поднимает свежий через
    driver_starter, перепривязывает setup_aut['driver'] и регистрирует новый quit.
    Возвращает новый driver — вызывающий делает UI-логин под новым пользователем.
    """
    setup_aut['driver'].quit()
    teardown.pop(-1)
    driver = setup_aut['driver_starter']()
    setup_aut['driver'] = driver
    teardown.append((lambda el: el.quit(), driver))
    return driver
