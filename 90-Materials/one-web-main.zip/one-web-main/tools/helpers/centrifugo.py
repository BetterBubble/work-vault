"""
Centrifugo-листенер для верификации серверных push-уведомлений без браузера.

IVA ONE realtime построен на Centrifugo (`wss://<web>/connection/websocket`, JSON-протокол).
После подключения клиент подписывается на персональный канал `user#<userId>`, куда бэкенд
шлёт события, в т.ч. `notification.new` (новое сообщение / добавление в чат и т.п.).

Этот листенер позволяет в тесте, где сообщение отправляет UI-сессия, проверить именно факт
доставки уведомления участнику — подписавшись на его канал отдельным python-клиентом
(см. TC-37723). Это «подкапотный» сигнал, который в Safari/Selenoid нельзя поймать хуком в
самом браузере (нет CDP/preload), а здесь он ловится напрямую с сервера.

Connect-токен (отдельный JWT, не keycloak) выдаётся по `GET /api/v1/link/token` под bearer
пользователя; его `sub` совпадает с keycloak-id пользователя, поэтому канал = `user#<user_id>`.
"""
import json
import ssl
import threading
import time

import requests
import websocket  # websocket-client

from autocore.test.assertions import assert_fn
from autocore.test.logger import get_log

log = get_log()


class CentrifugoListener:
    """Подписчик на персональный канал `user#<user_id>` для проверки `notification.new`.

    Использование:
        listener = CentrifugoListener(web_url, user_token, user_id).start()
        listener.wait_subscribed()
        ...                       # другая сессия отправляет сообщение
        listener.assert_message_notification_received(chat_id, text, expected_title=chat_name)
        listener.stop()           # удобно положить в teardown
    """

    # Серверные события звонка в персональном канале (литералы iva-модуля звонков —
    # calls-api/calls-events.service.ts): входящий сигналинг идёт по `v1.call.call.updated`.
    CALL_EVENT_TYPES = ('v1.call.call.updated', 'v1.call.call.created')

    def __init__(self, web_url: str, user_token: str, user_id: str):
        self.web_url = web_url.rstrip('/')
        self.user_token = user_token
        self.channel = f"user#{user_id}"
        self._ws = None
        self._thread = None
        self._stop = threading.Event()
        self._subscribed = threading.Event()
        self._lock = threading.Lock()
        self._notifications = []  # собранные data-объекты событий notification.new
        self._events = []         # все push-события канала: (ts, event_name, data) — для диагностики
        self._error = None

    def _get_connect_token(self) -> str:
        r = requests.get(f"{self.web_url}/api/v1/link/token",
                         headers={"Authorization": f"Bearer {self.user_token}"},
                         verify=False, timeout=15)
        r.raise_for_status()
        body = r.json()
        token = body.get('token') or body.get('accessToken')
        if not token:
            raise RuntimeError(f"GET /api/v1/link/token: connect-токен не найден в ответе: {body}")
        return token

    def start(self) -> "CentrifugoListener":
        token = self._get_connect_token()
        ws_url = self.web_url.replace('https://', 'wss://').replace('http://', 'ws://') + "/connection/websocket"
        self._ws = websocket.create_connection(ws_url, sslopt={"cert_reqs": ssl.CERT_NONE}, timeout=20)

        self._ws.send(json.dumps({"connect": {"token": token, "name": "py-listener"}, "id": 1}))
        connect_reply = self._first_json(self._ws.recv())
        if connect_reply.get('error'):
            raise RuntimeError(f"Centrifugo connect error: {connect_reply['error']}")

        self._ws.send(json.dumps({"subscribe": {"channel": self.channel}, "id": 2}))
        subscribe_reply = self._first_json(self._ws.recv())
        if subscribe_reply.get('error'):
            raise RuntimeError(f"Centrifugo subscribe error для {self.channel}: {subscribe_reply['error']}")

        self._subscribed.set()
        self._thread = threading.Thread(target=self._loop, name="centrifugo-listener", daemon=True)
        self._thread.start()
        log.step(f'Подписаться на канал уведомлений участника «{self.channel}»', where='WEBSOCKET Клиент')
        return self

    @staticmethod
    def _first_json(raw) -> dict:
        for line in str(raw).split('\n'):
            line = line.strip()
            if line:
                try:
                    return json.loads(line)
                except Exception:
                    return {}
        return {}

    def _loop(self):
        self._ws.settimeout(2)
        while not self._stop.is_set():
            try:
                raw = self._ws.recv()
            except websocket.WebSocketTimeoutException:
                continue
            except Exception as e:
                if not self._stop.is_set():
                    self._error = str(e)
                break
            if not raw:
                continue
            for line in str(raw).split('\n'):
                line = line.strip()
                if not line:
                    continue
                if line == '{}':  # ping от сервера -> pong
                    try:
                        self._ws.send('{}')
                    except Exception:
                        pass
                    continue
                try:
                    msg = json.loads(line)
                except Exception:
                    continue
                data = (msg.get('push') or {}).get('pub', {}).get('data', {})
                if isinstance(data, dict) and data.get('event'):
                    with self._lock:
                        self._events.append((time.time(), data.get('event'), data))
                        if data.get('event') == 'notification.new':
                            self._notifications.append(data)

    def wait_subscribed(self, timeout: float = 10):
        if not self._subscribed.wait(timeout):
            raise RuntimeError(f"Centrifugo listener: подписка на {self.channel} не подтверждена за {timeout}s")

    def get_events(self) -> list:
        """Все push-события канала: список (ts, event_name, raw_data). Для диагностики."""
        with self._lock:
            return list(self._events)

    def get_call_events(self) -> list:
        """Только события звонка (`v1.call.call.*`): список (ts, event_name, raw_data)."""
        with self._lock:
            return [(ts, ev, d) for (ts, ev, d) in self._events if ev in self.CALL_EVENT_TYPES]

    def _find_message_notification(self, chat_id: str, text: str):
        """Уведомление о НОВОМ пользовательском сообщении: event=chat.message.new, subtype пуст
        (системные — chat_created/chat.join — имеют непустой subtype/другой event)."""
        with self._lock:
            for n in self._notifications:
                inner = n.get('data') or {}
                if (inner.get('chatId') == chat_id
                        and inner.get('event') == 'chat.message.new'
                        and not inner.get('subtype')
                        and text in (n.get('body') or '')):
                    return n
        return None

    def wait_for_message_notification(self, chat_id: str, text: str, timeout: float = 15):
        deadline = time.time() + timeout
        while time.time() < deadline:
            found = self._find_message_notification(chat_id, text)
            if found:
                return found
            if self._error:
                break
            time.sleep(0.3)
        return None

    def wait_notification_event_received(self, event: str, timeout: float = 15):
        """Дождаться notification.new с указанным внутренним event без assertion-шага."""
        deadline = time.time() + timeout
        while time.time() < deadline:
            with self._lock:
                found = next(
                    (item for item in self._notifications
                     if (item.get('data') or {}).get('event') == event),
                    None,
                )
            if found is not None:
                return found
            if self._error:
                break
            time.sleep(0.3)
        with self._lock:
            seen = [(item.get('data') or {}).get('event') for item in self._notifications]
        raise TimeoutError(
            f'Centrifugo {self.channel}: за {timeout}s не получено '
            f'notification.new с event={event!r}; '
            f'получено={seen}, socket_error={self._error!r}'
        )

    def assert_message_notification_received(self, chat_id: str, text: str,
                                             expected_title: str = None, timeout: float = 15):
        notif = self.wait_for_message_notification(chat_id, text, timeout)
        with self._lock:
            seen = [(x.get('data') or {}).get('event') for x in self._notifications]
        log.info(f'Centrifugo {self.channel}: полученные notification.new события={seen}, socket_error={self._error}')
        assert_fn(lambda: notif is not None,
                  f'Участнику пришло уведомление о новом сообщении "{text}" (Centrifugo notification.new)')
        if expected_title is not None:
            assert_fn(lambda: notif.get('title') == expected_title,
                      f'Заголовок уведомления — название чата "{expected_title}"')
        return notif

    def stop(self):
        self._stop.set()
        try:
            if self._ws:
                self._ws.close()
        except Exception:
            pass
        if self._thread:
            self._thread.join(timeout=3)
