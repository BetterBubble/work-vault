import time

import requests
import urllib3

from autocore.clients import rest

urllib3.disable_warnings()


def ensure_mcu_profile(token, web_url):
    """Провизионировать профиль юзера в MCU (web_url: `-one.` → `-mcu.`).

    MCU создаёт профиль пользователя при первом авторизованном обращении к своему API
    его Bearer-токеном; Keycloak-логина самого по себе недостаточно. Встреча с участником
    без MCU-профиля отвергается: POST /conferences → 400 «Profile with id … not found»,
    причём клиент молча оставляет форму открытой (ни тоста, ни ошибок в полях). Провизия
    синхронная — после успешного GET сабмит с этим участником сразу проходит.
    """
    mcu_url = web_url.replace('-one.', '-mcu.')
    now = int(time.time() * 1000)
    requests.get(
        f'{mcu_url}/api/rest/conference-sessions/sessions',
        params={'dateFrom': now, 'dateTo': now + 1, 'limit': 1},
        headers={'Authorization': f'Bearer {token}'},
        verify=False,
    ).raise_for_status()


def delete_conferences_by_name(token, web_url, name):
    """Удалить MCU-конференции с точным именем (cleanup UI-созданных ВКС-встреч).

    ВКС-конференции живут на MCU-хосте (web_url: `-one.` → `-mcu.`) и в IVA ONE REST не
    управляются: список берём REST'ом `conference-sessions`, удаляем тонкой обёрткой
    autocore `rest.delete_meeting` (Bearer-токен). По имени, т.к. UI-создание не возвращает id.
    """
    mcu_url = web_url.replace('-one.', '-mcu.')
    resp = requests.get(
        f'{mcu_url}/api/rest/conference-sessions',
        headers={'Authorization': f'Bearer {token}'},
        verify=False,
    )
    resp.raise_for_status()
    for session in resp.json():
        if session.get('name') == name:
            rest.delete_meeting(None, session['conferenceId'], url=mcu_url, token=token)
