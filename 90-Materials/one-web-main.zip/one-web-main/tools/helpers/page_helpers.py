import base64
import mimetypes
import os
import time
from urllib.parse import urlsplit

from selenium.common.exceptions import NoSuchElementException, StaleElementReferenceException

from autocore.test.assertions import assert_fn
from autocore.test.logger import get_log

from tools.helpers.network import cdp_cmd

log = get_log()


def get_expected_default_avatars_letters(user_data):
    return ''.join(user_data['last_name'][:1] + user_data['first_name'][:1])


def retry_on_rerender(getter):
    """Повторяет getter при пересоздании DOM-узла под ним (stale либо мгновенный no-such):
    списки/таблицы обновляются вдогонку индексации свежесозданных сущностей, и под
    параллельной нагрузкой узел успевает пересоздаться между ожиданием и чтением/кликом.
    getter должен сам заново находить элемент (get_object внутри повторно ждёт presence)."""
    try:
        return getter()
    except (NoSuchElementException, StaleElementReferenceException):
        return getter()


def grant_notifications(driver, origin):
    """Выдать разрешение на push-уведомления через CDP (Chromium): без granted окно
    звонка у звонящего рендерится ненадёжно. Вызывать ДО login. Firefox/Safari — no-op."""
    if driver.name.lower() in ('firefox', 'safari'):
        log.warning(f'grant_notifications: CDP-грант недоступен для {driver.name}')
        return
    parts = urlsplit(origin)
    norm_origin = f'{parts.scheme}://{parts.netloc}'
    cdp_cmd(driver, 'Browser.grantPermissions', {'origin': norm_origin, 'permissions': ['notifications']})


def upload_file_via_js(driver, file_input, local_path):
    """
    Универсальная функция загрузки файла через JS DataTransfer.
    Подходит для обычных файлов и аватаров (Firefox, Safari, Chrome).
    """
    file_name = os.path.basename(local_path)

    # 1. Определяем MIME-тип (важно для валидации картинок)
    mime_type, _ = mimetypes.guess_type(local_path)
    mime_type = mime_type or 'application/octet-stream'

    # 2. Кодируем файл в base64
    with open(local_path, "rb") as f:
        file_content = base64.b64encode(f.read()).decode('utf-8')

    # 3. Универсальный JS-скрипт
    # Мы используем полную цепочку событий, так как она не мешает обычному инпуту,
    # но необходима для сложных компонентов (Angular/React).
    js_script = """
    var input = arguments[0];
    var b64Data = arguments[1];
    var fileName = arguments[2];
    var mimeType = arguments[3];

    // Преобразование base64 в Blob
    var byteCharacters = atob(b64Data);
    var byteNumbers = new Array(byteCharacters.length);
    for (var i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    var byteArray = new Uint8Array(byteNumbers);
    var blob = new Blob([byteArray], {type: mimeType});

    // Создание файла и контейнера
    var file = new File([blob], fileName, {type: mimeType});
    var container = new DataTransfer();
    container.items.add(file);

    // Загрузка файла
    input.files = container.files;

    // Генерация событий для активации скриптов на странице (Angular/React)
    var events = ['focus', 'change', 'input', 'blur'];
    events.forEach(function(ev) {
        input.dispatchEvent(new Event(ev, { bubbles: true }));
    });
    """

    time.sleep(3)

    driver.execute_script(js_script, file_input, file_content, file_name, mime_type)


# iva-сборка: <iva-avatar-edit> (host-директива ivaFilePicker) по клику лениво создаёт этот
# input на document.body и переиспользует его — статического инпута внутри компонента нет.
# Инпут вложений сообщения (<chat-send-message>) — с @hidden и не прямой потомок body,
# поэтому @aria-hidden="true" однозначно матчит именно аватарный инпут.
AVATAR_LAZY_FILE_INPUT_XPATH = '//body/input[@type="file" and @aria-hidden="true"]'


def upload_avatar_via_lazy_picker(driver, avatar_host, local_path, timeout: float = 10.0):
    """Загрузка аватара в iva-сборке через ленивый file-input.

    <iva-avatar-edit> по клику на хост лениво создаёт <input type=file aria-hidden> на
    document.body и дёргает у него .click(). Статического инпута внутри компонента нет,
    поэтому порядок: клик по хосту → ждём появления body-инпута → кормим файл
    (send_keys на Chrome, JS-DataTransfer на Safari/Firefox).
    """
    avatar_host.click()
    deadline = time.time() + timeout
    file_input = None
    while time.time() < deadline:
        found = driver.find_elements('xpath', AVATAR_LAZY_FILE_INPUT_XPATH)
        if found:
            file_input = found[0]
            break
        time.sleep(0.2)
    assert_fn(lambda: file_input is not None,
              f'Ленивый file-input аватара появился на body за {timeout}s после клика по хосту')
    if driver.name.lower() in ('safari', 'firefox'):
        upload_file_via_js(driver, file_input, local_path)
    else:
        file_input.send_keys(local_path)


def is_clickable_via_js(driver, element) -> bool:
    """JS-проверка реальной кликабельности элемента: ненулевые размеры, не скрыт,
    не disabled и не перекрыт другим узлом (`elementFromPoint` в центре попадает
    в сам элемент или его потомка)."""
    return driver.execute_script(
        """
        const el = arguments[0];
        const rect = el.getBoundingClientRect();
        const style = window.getComputedStyle(el);
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        const topElement = document.elementFromPoint(centerX, centerY);

        return rect.width > 0
            && rect.height > 0
            && style.display !== 'none'
            && style.visibility !== 'hidden'
            && style.pointerEvents !== 'none'
            && !el.disabled
            && !el.hasAttribute('disabled')
            && el.getAttribute('aria-disabled') !== 'true'
            && (el === topElement || el.contains(topElement));
        """,
        element,
    )


def wait_clickable_via_js(driver, element_getter, timeout: float = 10.0) -> bool:
    end_time = time.time() + timeout
    stable_checks_count = 0
    while time.time() < end_time:
        try:
            is_clickable = is_clickable_via_js(driver, element_getter())
        except (StaleElementReferenceException, NoSuchElementException):
            # Список перерисовался между ре-локейтом и JS-проверкой (optimistic UI/фильтр) —
            # узел детачился: stale-ссылка либо промах find_element сразу после успешного
            # presence-wait. Трактуем как «ещё не кликабельно»: следующая итерация ре-локейтит.
            stable_checks_count = 0
            time.sleep(0.1)
            continue
        if is_clickable:
            stable_checks_count += 1
        else:
            stable_checks_count = 0
        if stable_checks_count >= 3:
            return True
        time.sleep(0.1)
    return False

def click_via_js(driver, element) -> None:
    """JS-клик по элементу через `element.click()`.

    Обходит Safari `ElementNotInteractableException` на кастомных контейнерах
    (cdk-tree-node/treeitem, contacts-contact-name, role=menuitem), где click-хендлер
    висит на контейнере, а кликабельна внутренняя нода: Chromium целится в центр и
    попадает, Safari строже и считает контейнер неинтерактивным. Событие `click`
    всплывает к Angular `(click)`-хендлеру так же, как настоящий клик."""
    driver.execute_script('arguments[0].click();', element)


def get_browser_timestamp_ms(driver) -> int:
    return int(driver.execute_script('return Date.now();'))


def install_blob_download_capture(driver, capture_name: str) -> None:
    """Перехватить browser-download, построенный через Blob -> objectURL -> anchor.click().

    Сохраняет в `window[capture_name]` имя файла из `a[download]` и текст Blob.
    """
    driver.execute_script(
        """
        const captureName = arguments[0];
        window[captureName] = {filename: null, text: null};
        if (!window.__blob_download_capture_originals__) {
            window.__blob_download_capture_originals__ = {
                createObjectURL: URL.createObjectURL.bind(URL),
                anchorClick: HTMLAnchorElement.prototype.click,
                createElement: document.createElement.bind(document)
            };
        }

        const originals = window.__blob_download_capture_originals__;
        URL.createObjectURL = function(blob) {
            if (blob && typeof blob.text === 'function') {
                blob.text()
                    .then(function(text) {
                        window[captureName].text = String(text || '');
                    })
                    .catch(function() {
                        window[captureName].text = '';
                    });
            } else {
                window[captureName].text = '';
            }
            return originals.createObjectURL(blob);
        };

        HTMLAnchorElement.prototype.click = function() {
            if (this && this.download) {
                window[captureName].filename = this.download;
            }
            return originals.anchorClick.apply(this, arguments);
        };

        document.createElement = function(tagName) {
            const element = originals.createElement.apply(document, arguments);
            if (String(tagName).toLowerCase() === 'a') {
                const nativeClick = originals.anchorClick.bind(element);
                element.click = function() {
                    if (element.download) {
                        window[captureName].filename = element.download;
                    }
                    return nativeClick();
                };
            }
            return element;
        };
        """,
        capture_name,
    )


def get_blob_download_capture(driver, capture_name: str) -> dict:
    return driver.execute_script('return window[arguments[0]] || {};', capture_name) or {}


def wait_api_idle(driver, idle_window_ms: int = 500, timeout: float = 5.0) -> bool:
    """
    Дождаться окна тишины по `/api/v1` запросам.

    Через `performance.getEntries()` отслеживает последний resource-запрос с путём
    `/api/v1/*` и возвращает True как только разница между `performance.now()` и
    `(startTime + duration)` последнего запроса достигнет `idle_window_ms`.

    Используется перед операциями, которые на бэке плохо переносят гонку с
    параллельными запросами (см. `upload_avatar` в profile_popup_account).
    """
    end_time = time.time() + timeout
    while time.time() < end_time:
        idle_for = driver.execute_script(
            """
            const now = performance.now();
            const entries = performance.getEntries()
                .filter(function(e) {
                    return e.entryType === 'resource' && /\\/api\\/v1/.test(e.name);
                });
            if (!entries.length) { return 99999; }
            const last = entries.reduce(function(m, e) {
                return Math.max(m, e.startTime + e.duration);
            }, 0);
            return Math.round(now - last);
            """
        )
        if isinstance(idle_for, (int, float)) and idle_for >= idle_window_ms:
            return True
        time.sleep(0.1)
    return False


def reset_upload_tracking(driver) -> None:
    """Очистить resource-тайминги и расширить буфер перед загрузкой файла, чтобы
    подсчёт `/uploads/<id>/parts` начинался с чистого листа и не упёрся в дефолтный
    лимит буфера (250). Вызвать ПЕРЕД attach. Используется в TC-338."""
    driver.execute_script(
        "try { performance.setResourceTimingBufferSize(2000); } catch (e) {}"
        "try { performance.clearResourceTimings(); } catch (e) {}"
    )


def count_upload_parts(driver) -> int:
    """Сколько чанков `POST /uploads/<id>/parts` реально доехало — по resource-таймингам
    (`performance.getEntries()`). Успешный чанк создаёт entry и счётчик растёт; при
    обрыве сети запросы падают и entry не создают → счётчик стоит. На этом строится
    детект паузы/докачки в TC-338 (а не на DOM-кольце, которое мелькает доли секунды)."""
    return driver.execute_script(
        "return performance.getEntries().filter(function (e) {"
        "  return e.entryType === 'resource' && /\\/uploads\\/.+\\/parts/.test(e.name);"
        "}).length;"
    )


def upload_completed(driver) -> bool:
    """Был ли финализирующий `POST /uploads/<id>/complete` — по performance API. Отличает
    «загрузка встала (неполная)» от «загрузка уже завершилась» в TC-338."""
    return bool(driver.execute_script(
        "return performance.getEntries().some(function (e) {"
        "  return e.entryType === 'resource' && /\\/uploads\\/.+\\/complete/.test(e.name);"
        "});"
    ))


def get_media_content_download_entries(driver, media_ids=None) -> list:
    """Resource-тайминги, по которым РЕАЛЬНО качался контент оригинала медиа с
    `/uploads/{id}/download` (фича IVAONE-11538: превью НЕ должны брать оригинал).

    Тонкость стенда (подтверждена на at-test-1-one):
    - DLP access-check вложения = HTTP HEAD на `/uploads/{id}/download` → entry с
      `decodedBodySize == 0` (`initiatorType == 'xmlhttprequest'`). Уходит ВСЕГДА — это не
      загрузка контента.
    - Аватары юзеров грузятся как `<img src=.../uploads/{avatarId}/download>` → GET,
      `decodedBodySize > 0`, `initiatorType == 'img'` — ложноположительные, отсекаем по типу.
    - Контент медиа идёт ТОЛЬКО через `/preview`, `/preview/video`, `/mp3` — никогда `/download`.
    `transferSize` всюду 0 (cache/timing-allow) — опираемся на `decodedBodySize`+`initiatorType`.

    «Качали оригинал» = entry на `/download` с `decodedBodySize > 0` И `initiatorType != 'img'`.
    `media_ids` (uploadId тестовых файлов из seed) сужают проверку только до них — самый
    точный вариант, аватары не мешают вовсе.
    """
    return driver.execute_script(
        """
        var ids = arguments[0];
        return performance.getEntriesByType('resource').filter(function (e) {
            if (e.name.indexOf('/uploads/') === -1) return false;
            if (e.name.indexOf('/download') === -1) return false;
            if (!(e.decodedBodySize > 0)) return false;     // HEAD access-check = 0
            if (e.initiatorType === 'img') return false;     // аватары грузятся <img>.../download
            if (ids && ids.length) {
                return ids.some(function (id) {
                    return e.name.indexOf('/uploads/' + id + '/download') !== -1;
                });
            }
            return true;
        }).map(function (e) {
            return {name: e.name, decodedBodySize: e.decodedBodySize, initiatorType: e.initiatorType};
        });
        """,
        list(media_ids) if media_ids else None,
    )


def assert_no_original_media_download(driver, media_ids=None,
                                      message='Клиент не качал оригинал медиа по /download (превью берутся из /preview*)'):
    """Ассерт инварианта IVAONE-11538: клиент не загружает оригинал медиа за превью.
    HEAD-access-check и аватары игнорируются (см. `get_media_content_download_entries`).
    Вызывать после того, как лента/галерея устаканилась (`wait_api_idle`)."""
    entries = get_media_content_download_entries(driver, media_ids)
    assert_fn(lambda: not entries,
              f'{message}; обнаружены загрузки оригинала: {entries}')


def media_resource_loaded(driver, upload_id, suffix) -> bool:
    """Был ли загружен с контентом (`decodedBodySize > 0`) ресурс
    `/uploads/{upload_id}/{suffix}`. Для положительной проверки, что превью/аудио пришло
    из нужного поля: suffix = 'preview' | 'preview/video' | 'mp3' | 'download'."""
    return bool(driver.execute_script(
        "var url = '/uploads/' + arguments[0] + '/' + arguments[1];"
        "return performance.getEntriesByType('resource').some(function (e) {"
        "  return e.name.indexOf(url) !== -1 && e.decodedBodySize > 0;"
        "});",
        upload_id, suffix,
    ))


def _install_clipboard_capture(driver) -> None:
    """
    Internal: перехватить все три способа копирования в буфер, которые могут
    использоваться Angular SPA, и сохранять скопированный текст в
    `window.__clipboard_capture__`:

    1. `navigator.clipboard.writeText(text)` — простой String API.
    2. `navigator.clipboard.write([ClipboardItem({ "text/plain": blob })])` —
       async Clipboard API (это то, что использует IVA ONE WEB).
    3. `document.execCommand('copy')` со снапшотом `getSelection().toString()`.

    Зачем перехват, а не `navigator.clipboard.readText()`: последний требует
    permission `clipboard-read` (Selenoid его не даёт по умолчанию, и async-скрипт
    залипает на 30 секунд). Перехват writeText/write/execCommand даёт ровно тот
    текст, который app пытается положить в буфер — это эквивалент «что пользователь
    реально получает при копировании».

    Не использовать напрямую — публичный API: `with_clipboard_capture(...)`.
    """
    driver.execute_script(
        """
        window.__clipboard_capture__ = '';
        if (navigator.clipboard && navigator.clipboard.writeText) {
            const orig = navigator.clipboard.writeText.bind(navigator.clipboard);
            navigator.clipboard.writeText = function(text) {
                window.__clipboard_capture__ = String(text || '');
                try { return orig(text).catch(function(){}); }
                catch (e) { return Promise.resolve(); }
            };
        }
        if (navigator.clipboard && navigator.clipboard.write) {
            const origWrite = navigator.clipboard.write.bind(navigator.clipboard);
            navigator.clipboard.write = function(items) {
                try {
                    if (items && items.length) {
                        for (var i = 0; i < items.length; i++) {
                            var ci = items[i];
                            if (ci && ci.getType) {
                                ci.getType('text/plain')
                                    .then(function(blob) { return blob.text(); })
                                    .then(function(text) {
                                        window.__clipboard_capture__ = String(text || '');
                                    })
                                    .catch(function(){});
                            }
                        }
                    }
                } catch (e) {}
                try { return origWrite(items).catch(function(){}); }
                catch (e) { return Promise.resolve(); }
            };
        }
        const origExec = document.execCommand.bind(document);
        document.execCommand = function(name) {
            if (name === 'copy') {
                const sel = (window.getSelection && window.getSelection().toString()) || '';
                if (sel) { window.__clipboard_capture__ = sel; }
            }
            return origExec.apply(document, arguments);
        };
        """
    )


def _read_clipboard_capture(driver, timeout: float = 3.0) -> str:
    """
    Internal: прочитать текст, перехваченный `_install_clipboard_capture`. Ждёт до
    `timeout` секунд, пока приложение асинхронно вызовет `clipboard.writeText`/`write`.

    Не использовать напрямую — публичный API: `with_clipboard_capture(...)`.
    """
    end_time = time.time() + timeout
    while time.time() < end_time:
        value = driver.execute_script("return window.__clipboard_capture__ || '';")
        if value:
            return value
        time.sleep(0.05)
    return ''


def with_clipboard_capture(driver, action, timeout: float = 3.0) -> str:
    """
    Установить перехват clipboard API, выполнить `action()`, прочитать перехваченный
    текст. Удобный one-shot wrapper для типового кейса «сделать что-то, что приводит
    к copy-в-буфер, и узнать, что попало в буфер».

    Пример:
        url = with_clipboard_capture(self.driver,
            lambda: self.get_object(self.L_COPY_BTN()).click())

    `action` — любой callable без аргументов. Внутри него обычно идёт клик по
    UI-кнопке копирования + опциональный wait тоста / спиннера (что-то, что
    гарантирует, что приложение успело вызвать clipboard API).

    Это публичный API. Внутрянка — `_install_clipboard_capture` /
    `_read_clipboard_capture` (закрыты префиксом `_`, использовать только
    из этого helper'а).
    """
    _install_clipboard_capture(driver)
    action()
    return _read_clipboard_capture(driver, timeout=timeout)


def scroll_chat_to_bottom_via_js(driver):
    """
    Прокрутить чат-скроллер вниз через JS.
    Обход auto-scroll бага в Safari/Firefox под WebDriver: после отправки
    сообщения Angular CDK virtual-scroll не скроллит viewport, и свежий
    `<chat-message-container>` виртуализуется из DOM. Под реальным юзером
    скролл к низу происходит, под Selenium — нет.
    """
    driver.execute_script(
        """
        const sc = document.evaluate(
            '//chat-scroller', document, null,
            XPathResult.FIRST_ORDERED_NODE_TYPE, null
        ).singleNodeValue;
        if (sc) {
            const inner = sc.querySelector('cdk-virtual-scroll-viewport') || sc;
            inner.scrollTop = inner.scrollHeight;
        }
        """
    )


def scroll_element_to_bottom_via_js(driver, element):
    """Прокрутить переданный скролл-контейнер к низу (scrollTop = scrollHeight)."""
    driver.execute_script('arguments[0].scrollTop = arguments[0].scrollHeight;', element)


def element_bg_matches_token(driver, element, css_var: str) -> bool:
    """Совпадает ли фон элемента с цветом CSS-переменной (по RGB-каналам, без альфы).

    Сырое значение переменной и computed background различаются по формату/альфе —
    нормализуем токен через временный probe-элемент и сравниваем RGB-каналы. Альфа
    фона появляется через transition, поэтому проверяем только что она > 0 (фон
    реально применён), а оттенок сверяем по каналам.
    """
    return bool(driver.execute_script(
        'const el = arguments[0];'
        'const bg = getComputedStyle(el).backgroundColor;'
        'const token = getComputedStyle(el).getPropertyValue(arguments[1]).trim();'
        'if (!token) return false;'
        'const probe = document.createElement("div");'
        'probe.style.backgroundColor = token;'
        'document.body.appendChild(probe);'
        'const tokenComputed = getComputedStyle(probe).backgroundColor;'
        'probe.remove();'
        'const ch = c => (c.match(/[\\d.]+/g) || []).slice(0, 3).join();'
        'const alpha = (bg.match(/[\\d.]+/g) || [])[3];'
        'return ch(bg) === ch(tokenComputed) && (alpha === undefined || Number(alpha) > 0);',
        element, css_var))
