"""REST-гейт готовности группового чата/канала после создания через REST.

Тест-слой: поллинг поверх REST API IVA ONE. POST /chats отдаёт id сразу, но участники
материализуются на бэке асинхронно: первые секунды GET /chats/{id} возвращает 404 либо
membersCount=0. UI, открытый до материализации, показывает «0 участников» / ловит 404
и сам не восстанавливается — поэтому перед открытием чата в браузере ждём готовности
по REST. Тонкой обёртки GET /chats/{id} в autocore iva_one нет — запрос делается напрямую.
"""
import time

import requests

from autocore.clients.rest.iva_one import conf, env
from autocore.test.logger import get_log

log = get_log()


def wait_group_chat_materialized(token, chat_id, min_members, timeout=60, interval=3):
    """Дождаться материализации не меньше `min_members` участников в чате `chat_id`.

    404 в пределах таймаута — тоже ожидание (чат может быть ещё не виден читателю).
    :param token: токен пользователя-создателя чата
    :param chat_id: id чата из iva_one.create_chat
    :param min_members: минимальное число участников (создатель входит в счёт)
    :raises TimeoutError: чат не материализовался за timeout (с фактическим состоянием)
    """
    url = f"{conf[env]['web_url']}/api/v1/chats/{chat_id}"
    headers = {"Authorization": f"Bearer {token}"}
    deadline = time.time() + timeout
    state = 'ответ не получен'
    while time.time() < deadline:
        response = requests.get(url=url, headers=headers, verify=False)
        if response.status_code == 404:
            state = '404 (чат ещё не виден)'
        else:
            response.raise_for_status()
            members_count = response.json().get('membersCount', 0)
            if members_count >= min_members:
                log.info(f'Чат {chat_id} материализован: membersCount={members_count}')
                return
            state = f'membersCount={members_count} < {min_members}'
        time.sleep(interval)
    raise TimeoutError(f'Чат {chat_id} не материализовался за {timeout}s: {state}')


def wait_favorites_chat_materialized(token, user_id, timeout=180, interval=5):
    """Дождаться появления чата «Избранное» в списке чатов пользователя.

    Бэк создаёт favorites-чат свежего пользователя асинхронным job'ом (наблюдённый лаг
    75–120s от создания юзера); до этого GET /chats список его не отдаёт, а поиск в
    диалоге пересылки — уже находит (search-индекс), поэтому форвард проходит, а строка
    в левом списке чатов отсутствует. id favorites-чата детерминирован и равен
    keycloak-id владельца.
    :param token: токен владельца
    :param user_id: keycloak-id владельца (= id чата «Избранное»)
    :raises TimeoutError: чат не появился в списке за timeout
    """
    url = f"{conf[env]['web_url']}/api/v1/chats"
    headers = {"Authorization": f"Bearer {token}"}
    deadline = time.time() + timeout
    while time.time() < deadline:
        response = requests.get(url=url, headers=headers, verify=False)
        response.raise_for_status()
        data = response.json()
        chats = data if isinstance(data, list) else data.get('items', [])
        if any(chat.get('id') == user_id for chat in chats):
            log.info(f'Чат «Избранное» ({user_id}) материализован')
            return
        time.sleep(interval)
    raise TimeoutError(f'Чат «Избранное» ({user_id}) не появился в списке чатов за {timeout}s')
