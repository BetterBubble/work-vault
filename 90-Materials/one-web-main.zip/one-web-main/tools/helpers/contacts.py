"""REST-верификация данных личного контакта (композиция поверх autocore iva_one).

Чтение/композиция поверх тонких autocore-обёрток — тест-слой one-web (см. конвенцию
«autocore REST vs тест-слой»). Источник правды по isPrimary/firstName — список
`POST /contacts/list` (`iva_one.get_contacts`): detail `GET /contacts/{id}` НЕ возвращает
firstName/lastName (только displayName), поэтому для сверки имени берём именно список.
"""
from autocore.clients.rest import iva_one
from autocore.test.assertions import assert_fn


def assert_contact_primary_invariant(token, group_id, first_name, phone_count):
    """Свериться с REST после редактирования контакта: контакт с именем `first_name` есть в
    книге `group_id`, у него `phone_count` телефонов, и ровно один телефон и одна почта
    помечены основными (isPrimary=true) — инвариант единственности основного (шаг 5 TC-46998).
    """
    contacts = iva_one.get_contacts(token, group_id)['contacts']
    contact = next((c for c in contacts if c.get('firstName') == first_name), None)
    assert_fn(lambda: contact is not None,
              f'Контакт с обновлённым именем "{first_name}" найден в книге (REST)')
    phones = contact.get('phones', [])
    emails = contact.get('emails', [])
    assert_fn(lambda: len(phones) == phone_count,
              f'У контакта телефонов: {phone_count} (основной + добавленные дополнительные)')
    assert_fn(lambda: sum(1 for p in phones if p.get('isPrimary')) == 1,
              'Ровно один телефон помечен основным (isPrimary=true)')
    assert_fn(lambda: sum(1 for e in emails if e.get('isPrimary')) == 1,
              'Ровно одна почта помечена основной (isPrimary=true)')
