"""Управление сетью браузера для теста обрыва соединения во время загрузки файла (TC-338).

Цель — РЕАЛЬНО оборвать передачу во время чанковой загрузки файла, чтобы загрузка
встала (лоадер замирает), и восстановить, чтобы она догрузилась. Обрыв — настоящий,
не `navigator.onLine`-фейк: запросы чанков реально перестают доходить, поэтому
`POST /uploads/<id>/parts` не растёт во время обрыва и снова растёт после восстановления.

Механизм обрыва зависит от браузера (CDP/BiDi доступны не везде):

- Chromium (chrome/ya/edge): реальный OS-level обрыв через CDP
  `Network.emulateNetworkConditions(offline=True)`. На Selenoid у Remote-драйвера нет
  `execute_cdp_cmd`, но endpoint `goog/cdp/execute` проксируется в chromedriver.
- Firefox: реальный Gecko-offline через Marionette chrome-context `Services.io.offline`
  (endpoint `moz/context` проксируется Selenoid'ом). Требует запуск Firefox с
  `-remote-allow-system-access` (выставляется в autocore FF-опциях).
- Safari: CDP/BiDi/chrome-context недоступны, safaridriver игнорит proxy → обрываем
  транспорт чанков на уровне страницы: перехватываем XHR/fetch и роняем запросы к
  `/uploads/<id>/parts`. Это тот же приём монки-патча через `execute_script`, что уже
  используется в `page_helpers` для clipboard-capture; запросы реально не уходят на
  бэк, загрузка встаёт, снятие блока → приложение ретраит → догрузка.

Троттлинг (замедление загрузки, аналог шага сценария «ограничить скорость до 3G»)
делается одним и тем же app-layer перехватчиком на всех браузерах — он лишь задерживает
отправку чанков, чтобы окно «середина загрузки» было устойчиво ловимым на быстром
внутреннем стенде (где без замедления 30-50 МБ улетают за доли секунды). Сам обрыв при
этом остаётся настоящим (CDP/moz/page-block выше).

Используется в TC-338.
"""
from autocore.test.logger import get_log

log = get_log()


# --- Chromium: реальный обрыв через CDP ------------------------------------

def cdp_cmd(driver, cmd: str, params: dict = None):
    """Выполнить CDP-команду на локальном Chrome или Selenoid Chromium."""
    if hasattr(driver, 'execute_cdp_cmd'):  # локальный ChromeWebDriver
        return driver.execute_cdp_cmd(cmd, params or {})
    driver.command_executor._commands['executeCdpCommand'] = ('POST', '/session/$sessionId/goog/cdp/execute')
    return driver.execute('executeCdpCommand', {'cmd': cmd, 'params': params or {}})


def _set_offline_chromium(driver, offline: bool):
    cdp_cmd(driver, 'Network.enable', {})
    cdp_cmd(driver, 'Network.emulateNetworkConditions', {
        'offline': offline,
        'latency': 0,
        'downloadThroughput': -1,
        'uploadThroughput': -1,
    })


# --- Firefox: реальный Gecko-offline через Marionette chrome-context --------

def _set_offline_firefox(driver, offline: bool):
    driver.command_executor._commands['setMozContext'] = ('POST', '/session/$sessionId/moz/context')
    driver.execute('setMozContext', {'context': 'chrome'})
    try:
        driver.execute_script(
            "var off = arguments[0];"
            "try { Services.io.offline = off; }"
            "catch (e) {"
            "  var io = Components.classes['@mozilla.org/network/io-service;1']"
            "           .getService(Components.interfaces.nsIIOService);"
            "  io.offline = off;"
            "}",
            offline,
        )
    finally:
        driver.execute('setMozContext', {'context': 'content'})


# --- Safari (и троттлинг везде): app-layer перехватчик чанков ---------------

# Перехватывает fetch и XHR, матчит запросы к `/uploads/<id>/parts` и:
#   - при window.__tc338_block__ === true роняет их (эмуляция сетевой ошибки),
#   - при window.__tc338_delay_ms__ > 0 задерживает отправку (троттлинг).
# Идемпотентен (ставится один раз). Переопределяет prototype XHR (надёжно для
# Angular HttpClient, который создаёт XMLHttpRequest на каждый запрос).
_INSTALL_INTERCEPTOR_JS = r"""
(function () {
  if (window.__tc338_net_installed__) return;
  window.__tc338_net_installed__ = true;
  window.__tc338_block__ = false;
  window.__tc338_delay_ms__ = 0;
  var RX = /\/uploads\/[^/]+\/parts/;
  function isParts(u) { return RX.test(String(u || '')); }

  if (window.fetch) {
    var of = window.fetch.bind(window);
    window.fetch = function (input, init) {
      var url = (typeof input === 'string') ? input : (input && input.url) || '';
      if (isParts(url)) {
        if (window.__tc338_block__) return Promise.reject(new TypeError('Failed to fetch'));
        var d = window.__tc338_delay_ms__ | 0;
        if (d > 0) return new Promise(function (res, rej) {
          setTimeout(function () { of(input, init).then(res, rej); }, d);
        });
      }
      return of(input, init);
    };
  }

  var oo = XMLHttpRequest.prototype.open;
  var os = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (m, u) { this.__tc338_url__ = u; return oo.apply(this, arguments); };
  XMLHttpRequest.prototype.send = function () {
    var xhr = this, args = arguments;
    if (isParts(xhr.__tc338_url__)) {
      if (window.__tc338_block__) {
        setTimeout(function () {
          try { xhr.dispatchEvent(new ProgressEvent('error')); } catch (e) {}
          try { xhr.upload && xhr.upload.dispatchEvent(new ProgressEvent('error')); } catch (e) {}
          try { xhr.dispatchEvent(new ProgressEvent('loadend')); } catch (e) {}
        }, 0);
        return;
      }
      var d = window.__tc338_delay_ms__ | 0;
      if (d > 0) { setTimeout(function () { os.apply(xhr, args); }, d); return; }
    }
    return os.apply(xhr, args);
  };
})();
"""


def _install_interceptor(driver):
    driver.execute_script(_INSTALL_INTERCEPTOR_JS)


def _set_offline_safari(driver, offline: bool):
    # Реальный транспорт чанков: page-block (это и есть реальная остановка загрузки).
    _install_interceptor(driver)
    driver.execute_script("window.__tc338_block__ = arguments[0];", bool(offline))
    # Доп. ИМИТАЦИЯ для UI: реальную сеть Safari здесь не рвём, поэтому приложение само
    # не покажет тост о потере/восстановлении связи. Эмулируем `navigator.onLine` +
    # событие online/offline, чтобы тост появился (как на Chromium/Firefox от настоящего
    # обрыва). На остановку загрузки это НЕ влияет — её делает page-block выше.
    driver.execute_script(
        "var v = arguments[0];"
        "Object.defineProperty(navigator, 'onLine', {configurable: true, get: function () { return v; }});"
        "window.dispatchEvent(new Event(arguments[1]));",
        not offline, 'offline' if offline else 'online',
    )


# --- Публичный API ---------------------------------------------------------

def prepare(driver, throttle_ms: int = 1500):
    """Подготовить страницу перед загрузкой: поставить app-layer перехватчик и задать
    троттлинг чанков (задержка отправки `/uploads/<id>/parts`), чтобы окно «середина
    загрузки» было устойчиво ловимым на быстром стенде. Вызывать ПЕРЕД attach файла.

    Перехватчик ставится на всех браузерах (он же используется как механизм обрыва
    для Safari). На Chromium/Firefox обрыв делается реальным механизмом (CDP/moz), а
    перехватчик там работает только как троттлинг.
    """
    _install_interceptor(driver)
    driver.execute_script("window.__tc338_delay_ms__ = arguments[0];", int(throttle_ms))


def set_offline(driver, offline: bool):
    """«Разорвать» (offline=True) / «восстановить» (offline=False) передачу для загрузки.

    Механизм выбирается по браузеру: Chromium — CDP, Firefox — Marionette
    `Services.io.offline`, Safari — app-layer блок чанков. Безопасно вызывать повторно.
    """
    name = (getattr(driver, 'name', '') or '').lower()
    if 'firefox' in name:
        _set_offline_firefox(driver, offline)
    elif 'safari' in name:
        _set_offline_safari(driver, offline)
    else:
        _set_offline_chromium(driver, offline)
