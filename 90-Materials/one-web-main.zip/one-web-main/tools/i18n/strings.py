from autocore import consts


strings = {
    'profile_popup_account_header': {
        consts.LANG_RU: 'Аккаунт',
        consts.LANG_EN: 'Account',
    },
    'account_tab_name': {
        consts.LANG_RU: 'Аккаунт',
        consts.LANG_EN: 'Account',
    },
    'allow_notifications_title': {
        consts.LANG_RU: 'Разрешить уведомления?',
        consts.LANG_EN: 'TODO',
    },
    'allow_notifications_allow_btn': {
        consts.LANG_RU: 'Разрешить',
        consts.LANG_EN: 'TODO',
    },
    'wrong_auth_text': {
        consts.LANG_RU: 'Неправильное имя пользователя или пароль',
        consts.LANG_EN: 'TODO',
    },
    'profile_popup_account_logout_button': {
        consts.LANG_RU: 'Выйти из аккаунта',
        consts.LANG_EN: 'Log out',
    },
    'chats_header': {
        consts.LANG_RU: 'Чаты',
        consts.LANG_EN: 'Chats',
    },
    'chat_chats_header_threads_tab': {
        consts.LANG_RU: 'Треды',
        consts.LANG_EN: 'TODO',
    },
    'chat_list_search_placeholder': {
        consts.LANG_RU: 'Поиск',
        consts.LANG_EN: 'TODO',
    },
    'contacts_search_input': {
        consts.LANG_RU: 'ФИО, отдел, должность',
        consts.LANG_EN: 'TODO',
    },
    'user_profile_type_message_button': {
        consts.LANG_RU: 'Написать',
        consts.LANG_EN: 'TODO',
    },
    'contact_tree_personal_root': {
        consts.LANG_RU: 'Личные',
        consts.LANG_EN: 'TODO',
    },
    'contact_tree_all_contacts': {
        consts.LANG_RU: 'Все контакты',
        consts.LANG_EN: 'TODO',
    },
    'contacts_multiselect_selected_count': {
        consts.LANG_RU: 'Выбрано:',
        consts.LANG_EN: 'TODO',
    },
    'contacts_multiselect_reset_button': {
        consts.LANG_RU: 'Сбросить',
        consts.LANG_EN: 'TODO',
    },
    'contacts_create_chat_dialog_title': {
        consts.LANG_RU: 'Создать чат',
        consts.LANG_EN: 'TODO',
    },
    'contacts_create_chat_cancel_button': {
        consts.LANG_RU: 'Отмена',
        consts.LANG_EN: 'TODO',
    },
    'contacts_move_dialog_title': {
        consts.LANG_RU: 'Перемещение',
        consts.LANG_EN: 'TODO',
    },
    'contacts_move_unavailable_text': {
        consts.LANG_RU: 'перемещение недоступно',
        consts.LANG_EN: 'TODO',
    },
    'contacts_move_confirm_button': {
        consts.LANG_RU: 'Переместить доступных',
        consts.LANG_EN: 'TODO',
    },
    'contacts_create_chat_unavailable_text': {
        consts.LANG_RU: 'чат недоступен',
        consts.LANG_EN: 'TODO',
    },
    'contacts_delete_dialog_title': {
        consts.LANG_RU: 'Удалить контакты?',
        consts.LANG_EN: 'TODO',
    },
    'contacts_delete_unavailable_text': {
        consts.LANG_RU: 'удаление недоступно',
        consts.LANG_EN: 'TODO',
    },
    'contacts_delete_confirm_button': {
        consts.LANG_RU: 'Удалить доступных',
        consts.LANG_EN: 'TODO',
    },
    'contact_card_more_button': {
        consts.LANG_RU: 'Ещё',
        consts.LANG_EN: 'TODO',
    },
    'contact_card_call_button': {
        consts.LANG_RU: 'Позвонить',
        consts.LANG_EN: 'TODO',
    },
    'contact_card_menu_delete': {
        consts.LANG_RU: 'Удалить',
        consts.LANG_EN: 'TODO',
    },
    'contact_card_menu_move': {
        consts.LANG_RU: 'Переместить',
        consts.LANG_EN: 'TODO',
    },
    'contact_card_menu_mcu': {
        consts.LANG_RU: 'ВКС-встреча',
        consts.LANG_EN: 'TODO',
    },
    'contact_card_menu_event': {
        consts.LANG_RU: 'Событие',
        consts.LANG_EN: 'TODO',
    },
    'contact_delete_dialog_title': {
        consts.LANG_RU: 'Удалить контакт "{name}"?',
        consts.LANG_EN: 'TODO',
    },
    'contact_delete_dialog_confirm_button': {
        consts.LANG_RU: 'Удалить',
        consts.LANG_EN: 'TODO',
    },
    'contact_deleted_toast': {
        consts.LANG_RU: 'Контакт удален',
        consts.LANG_EN: 'TODO',
    },
    'contact_moved_toast': {
        consts.LANG_RU: 'Контакт перемещен',
        consts.LANG_EN: 'TODO',
    },
    'contact_personal_book_empty_stub': {
        consts.LANG_RU: 'Создайте свой первый личный контакт',
        consts.LANG_EN: 'TODO',
    },
    'mcu_conference_theme_placeholder': {
        consts.LANG_RU: 'Новая встреча',
        consts.LANG_EN: 'TODO',
    },
    'mcu_conference_create_button': {
        consts.LANG_RU: 'Создать встречу',
        consts.LANG_EN: 'TODO',
    },
    'mcu_conference_participants_tab': {
        consts.LANG_RU: 'Участники',
        consts.LANG_EN: 'TODO',
    },
    'offline_event_theme_placeholder': {
        consts.LANG_RU: 'Новое событие',
        consts.LANG_EN: 'TODO',
    },
    'offline_event_create_button': {
        consts.LANG_RU: 'Создать событие',
        consts.LANG_EN: 'TODO',
    },
    'calendar_menu_vks_title': {
        consts.LANG_RU: 'ВКС-встреча',
        consts.LANG_EN: 'Online meeting',
    },
    'calendar_menu_event_title': {
        consts.LANG_RU: 'Событие',
        consts.LANG_EN: 'Meeting',
    },
    'calendar_participants_required_section': {
        consts.LANG_RU: 'Обязательные',
        consts.LANG_EN: 'Required',
    },
    'calendar_add_participant_btn': {
        consts.LANG_RU: 'Добавить',
        consts.LANG_EN: 'Add',
    },
    'calendar_add_participants_dialog_title': {
        consts.LANG_RU: 'Добавить участников',
        consts.LANG_EN: 'Add participants',
    },
    'calendar_add_participants_confirm_btn': {
        consts.LANG_RU: 'Добавить',
        consts.LANG_EN: 'Add',
    },
    'calendar_conference_extra_links_btn': {
        consts.LANG_RU: 'Дополнительные ссылки',
        consts.LANG_EN: 'Additional links',
    },
    'calendar_conference_edit_menu_item': {
        consts.LANG_RU: 'Изменить',
        consts.LANG_EN: 'Edit',
    },
    'calendar_conference_edit_save_btn': {
        consts.LANG_RU: 'Сохранить',
        consts.LANG_EN: 'Save',
    },
    'meeting_invitation_status_accept': {
        consts.LANG_RU: 'Принять',
        consts.LANG_EN: 'Accept',
    },
    'meeting_invitation_status_maybe': {
        consts.LANG_RU: 'Возможно',
        consts.LANG_EN: 'Maybe',
    },
    'meeting_invitation_status_decline': {
        consts.LANG_RU: 'Отклонить',
        consts.LANG_EN: 'Decline',
    },
    'general_attachments_label': {
        consts.LANG_RU: 'Вложения',
        consts.LANG_EN: 'Attachments',
    },
    'chat_message_context_menu_reply_button': {
        consts.LANG_RU: 'Ответить',
        consts.LANG_EN: 'TODO',
    },
    'chat_message_context_menu_copy_button': {
        consts.LANG_RU: 'Скопировать',
        consts.LANG_EN: 'TODO',
    },
    'chat_message_context_menu_copy_link_button': {
        consts.LANG_RU: 'Скопировать ссылку',
        consts.LANG_EN: 'TODO',
    },
    'chat_message_context_menu_edit_button': {
        consts.LANG_RU: 'Редактировать',
        consts.LANG_EN: 'Edit',
    },
    'chat_message_context_menu_forward_button': {
        consts.LANG_RU: 'Переслать',
        consts.LANG_EN: 'Forward',
    },
    'chat_message_context_menu_start_thread_button': {
        consts.LANG_RU: 'Начать тред',
        consts.LANG_EN: 'Start thread',
    },
    'chat_message_context_menu_select_button': {
        consts.LANG_RU: 'Выбрать',
        consts.LANG_EN: 'Select',
    },
    'profile_popup_account_user_display_name_label': {
        consts.LANG_RU: 'Имя',
        consts.LANG_EN: 'Full name',
    },
    'profile_popup_account_save_btn': {
        consts.LANG_RU: 'Сохранить',
        consts.LANG_EN: 'Save',
    },
    'profile_popup_account_cancel_btn': {
        consts.LANG_RU: 'Отмена',
        consts.LANG_EN: 'Cancel',
    },
    'profile_popup_changes_saved_toast': {
        consts.LANG_RU: 'Изменения сохранены',
        consts.LANG_EN: 'TODO',
    },
    'profile_popup_avatar_success_uploaded_toast': {
        consts.LANG_RU: 'Изображение загружено успешно, обновление появится после проверки безопасности',
        consts.LANG_EN: 'TODO',
    },
    'chat_message_forward_dialog_title': {
        consts.LANG_RU: 'Переслать сообщение',
        consts.LANG_EN: 'Forward message',
    },
    'chat_message_forwarded_message_label': {
        consts.LANG_RU: 'Пересланное сообщение от',
        consts.LANG_EN: 'Forwarded message from',
    },
    'favorites_chat_name': {
        consts.LANG_RU: 'Избранное',
        consts.LANG_EN: 'Favorites',
    },
    'chat_input_menu_item_edit_link_btn': {
        consts.LANG_RU: 'Изменить ссылку',
        consts.LANG_EN: 'TODO',
    },
    'chat_input_disabled_plug': {
        consts.LANG_RU: 'Здесь нельзя писать',
        consts.LANG_EN: 'TODO',
    },
    'chat_input_edit_link_popup_add_btn': {
        consts.LANG_RU: 'Сохранить',
        consts.LANG_EN: 'TODO',
    },
    'chat_input_edit_link_popup_text_label': {
        consts.LANG_RU: 'Текст',
        consts.LANG_EN: 'TODO',
    },
    'chat_input_edit_link_popup_link_label': {
        consts.LANG_RU: 'Ссылка',
        consts.LANG_EN: 'TODO',
    },
    'group_chat_profile_kick_member_btn': {
        consts.LANG_RU: 'Удалить участника',
        consts.LANG_EN: 'Remove from group',
    },
    'group_chat_profile_make_admin_btn': {
        consts.LANG_RU: 'Назначить админом',
        consts.LANG_EN: 'TODO',
    },
    'group_chat_profile_admin_role_label': {
        consts.LANG_RU: 'Админ',
        consts.LANG_EN: 'TODO',
    },
    'group_chat_profile_transfer_owner_btn': {
        consts.LANG_RU: 'Передать права владельца',
        consts.LANG_EN: 'TODO',
    },
    'group_chat_profile_transfer_owner_confirm_btn': {
        consts.LANG_RU: 'Передать',
        consts.LANG_EN: 'TODO',
    },
    'group_chat_profile_owner_role_label': {
        consts.LANG_RU: 'Владелец',
        consts.LANG_EN: 'TODO',
    },
    'group_chat_profile_edit_btn': {
        consts.LANG_RU: 'Редактировать',
        consts.LANG_EN: 'TODO',
    },
    'group_chat_profile_description_label': {
        consts.LANG_RU: 'Описание',
        consts.LANG_EN: 'TODO',
    },
    'group_chat_profile_save_btn': {
        consts.LANG_RU: 'Сохранить',
        consts.LANG_EN: 'TODO',
    },
    'group_chat_profile_public_toggle_label': {
        consts.LANG_RU: 'Публичный чат',
        consts.LANG_EN: 'Public chat',
    },
    'info_channel_profile_public_toggle_label': {
        consts.LANG_RU: 'Публичный канал',
        consts.LANG_EN: 'Public channel',
    },
    'group_chat_profile_copy_link_btn': {
        consts.LANG_RU: 'Копировать',
        consts.LANG_EN: 'TODO',
    },
    'group_chat_profile_public_chat_label': {
        consts.LANG_RU: 'Это публичный чат',
        consts.LANG_EN: 'TODO',
    },
    'info_channel_profile_public_chat_label': {
        consts.LANG_RU: 'Это публичный канал',
        consts.LANG_EN: 'TODO',
    },
    'info_channel_profile_reactions_toggle_label': {
        consts.LANG_RU: 'Реакции',
        consts.LANG_EN: 'Reactions',
    },
    'info_channel_profile_threads_toggle_label': {
        consts.LANG_RU: 'Треды',
        consts.LANG_EN: 'Threads',
    },
    'chat_system_message_renamed_channel': {
        # Инвариантный фрагмент incoming-сообщения «{actor} изменил(-а) название канала на "{name}"»
        # (в чате рендерится incoming-, не backend-формулировка «Изменено название канала на»); без
        # спрягаемого «изменил(-а)» — матчер дополняется уникальным new_name в локаторе.
        consts.LANG_RU: 'название канала на',
        consts.LANG_EN: 'renamed the channel to',
    },
    'chat_system_message_pinned_by': {
        consts.LANG_RU: 'закрепил',
        consts.LANG_EN: 'TODO',
    },
    'chat_system_message_user_added': {
        consts.LANG_RU: 'добавил',
        consts.LANG_EN: 'TODO',
    },
    'group_chat_profile_notifications_muted_toast': {
        consts.LANG_RU: 'Уведомления отключены',
        consts.LANG_EN: 'TODO',
    },
    'group_chat_profile_notifications_unmuted_toast': {
        consts.LANG_RU: 'Уведомления включены',
        consts.LANG_EN: 'TODO',
    },
    'group_chat_profile_copy_link_toast': {
        consts.LANG_RU: 'Ссылка скопирована',
        consts.LANG_EN: 'TODO',
    },
    'chat_upload_no_internet_toast': {
        consts.LANG_RU: 'Нет подключения к интернету',
        consts.LANG_EN: 'TODO',
    },
    'chat_upload_connection_restored_toast': {
        consts.LANG_RU: 'Подключение к сети установлено',
        consts.LANG_EN: 'TODO',
    },
    'group_chat_profile_more_btn': {
        consts.LANG_RU: 'Ещё',
        consts.LANG_EN: 'TODO',
    },
    'group_chat_profile_delete_chat_btn': {
        consts.LANG_RU: 'Удалить',
        consts.LANG_EN: 'TODO',
    },
    'group_chat_profile_delete_chat_confirm_dialog_title': {
        consts.LANG_RU: 'Вы хотите удалить чат?',
        consts.LANG_EN: 'TODO',
    },
    'group_chat_profile_delete_channel_confirm_dialog_title': {
        consts.LANG_RU: 'Вы хотите удалить канал?',
        consts.LANG_EN: 'TODO',
    },
    'group_chat_profile_delete_chat_confirm_btn': {
        consts.LANG_RU: 'Удалить',
        consts.LANG_EN: 'TODO',
    },
    'not_found_page_message': {
        consts.LANG_RU: 'Страница не найдена',
        consts.LANG_EN: 'TODO',
    },
    'chat_join_channel_btn': {
        consts.LANG_RU: 'Подписаться',
        consts.LANG_EN: 'TODO',
    },
    'chat_message_context_menu_delete_button': {
        consts.LANG_RU: 'Удалить',
        consts.LANG_EN: 'TODO',
    },
    'chat_message_delete_confirm_btn': {
        consts.LANG_RU: 'Удалить',
        consts.LANG_EN: 'TODO',
    },
    'p2p_chat_profile_more_btn': {
        consts.LANG_RU: 'Ещё',
        consts.LANG_EN: 'TODO',
    },
    'p2p_chat_profile_mute_menu_item': {
        consts.LANG_RU: 'Выключить уведомления',
        consts.LANG_EN: 'TODO',
    },
    'p2p_chat_profile_unmute_menu_item': {
        consts.LANG_RU: 'Включить уведомления',
        consts.LANG_EN: 'TODO',
    },
    'p2p_chat_profile_notifications_muted_toast': {
        consts.LANG_RU: 'Уведомления отключены',
        consts.LANG_EN: 'TODO',
    },
    'p2p_chat_profile_notifications_unmuted_toast': {
        consts.LANG_RU: 'Уведомления включены',
        consts.LANG_EN: 'TODO',
    },
    'chat_search_input_placeholder': {
        consts.LANG_RU: 'Поиск по сообщениям',
        consts.LANG_EN: 'TODO',
    },
    'chat_message_context_menu_pin_button': {
        consts.LANG_RU: 'Закрепить',
        consts.LANG_EN: 'TODO',
    },
    'chats_context_menu_item_pin': {
        consts.LANG_RU: 'Закрепить',
        consts.LANG_EN: 'Pin',
    },
    'chats_context_menu_item_delete': {
        consts.LANG_RU: 'Удалить',
        consts.LANG_EN: 'Delete',
    },
    'chat_message_context_menu_reactions_stem': {
        consts.LANG_RU: 'реакц',
        consts.LANG_EN: 'TODO',
    },
    'chat_message_context_menu_info_button': {
        consts.LANG_RU: 'Информация',
        consts.LANG_EN: 'TODO',
    },
    'chat_thread_subscribe_button': {
        consts.LANG_RU: 'Подписаться',
        consts.LANG_EN: 'TODO',
    },
    'chat_thread_unsubscribe_button': {
        consts.LANG_RU: 'Отписаться',
        consts.LANG_EN: 'TODO',
    },
    'chat_thread_subscribed_state': {
        consts.LANG_RU: 'Вы подписаны / Подписан',
        consts.LANG_EN: 'TODO',
    },
    'chat_message_edited_mark': {
        consts.LANG_RU: 'Ред.',
        consts.LANG_EN: 'TODO',
    },
    'chat_join_group_btn': {
        consts.LANG_RU: 'Вступить в группу',
        consts.LANG_EN: 'TODO',
    },
    'create_chat_menu_group_title': {
        consts.LANG_RU: 'Групповой чат',
        consts.LANG_EN: 'TODO',
    },
    'create_chat_menu_channel_title': {
        consts.LANG_RU: 'Информационный канал',
        consts.LANG_EN: 'TODO',
    },
    'create_chat_step1_group_title': {
        consts.LANG_RU: 'Создание группового чата',
        consts.LANG_EN: 'TODO',
    },
    'create_chat_step1_channel_title': {
        consts.LANG_RU: 'Создание информационного канала',
        consts.LANG_EN: 'TODO',
    },
    'create_chat_next_btn': {
        consts.LANG_RU: 'Далее',
        consts.LANG_EN: 'TODO',
    },
    'create_chat_create_group_btn': {
        consts.LANG_RU: 'Создать группу',
        consts.LANG_EN: 'TODO',
    },
    'create_chat_create_channel_btn': {
        consts.LANG_RU: 'Создать канал',
        consts.LANG_EN: 'TODO',
    },
    'chat_profile_add_members_dialog_title': {
        consts.LANG_RU: 'Добавить участников',
        consts.LANG_EN: 'TODO',
    },
    'chat_profile_add_members_dialog_confirm_btn': {
        consts.LANG_RU: 'Добавить',
        consts.LANG_EN: 'TODO',
    },
    'chat_profile_gallery_category_video': {
        consts.LANG_RU: 'Видео',
        consts.LANG_EN: 'TODO',
    },
    'chat_profile_gallery_category_images': {
        consts.LANG_RU: 'Изображения',
        consts.LANG_EN: 'TODO',
    },
    'chat_profile_gallery_category_audio': {
        consts.LANG_RU: 'Аудио',
        consts.LANG_EN: 'TODO',
    },
    'media_header_pictures': {
        consts.LANG_RU: 'Изображения',
        consts.LANG_EN: 'Images',
    },
    'media_header_video': {
        consts.LANG_RU: 'Видео',
        consts.LANG_EN: 'Video',
    },
    'media_header_audio': {
        consts.LANG_RU: 'Аудио',
        consts.LANG_EN: 'Audio',
    },
    'call_equipment_menu_item': {
        consts.LANG_RU: 'Настройка оборудования',
        consts.LANG_EN: 'TODO',
    },
    'call_equipment_dialog_title': {
        consts.LANG_RU: 'Настройка оборудования',
        consts.LANG_EN: 'TODO',
    },
    'call_equipment_section_camera': {
        consts.LANG_RU: 'Камера',
        consts.LANG_EN: 'TODO',
    },
    'call_equipment_section_microphone': {
        consts.LANG_RU: 'Микрофон',
        consts.LANG_EN: 'TODO',
    },
    'call_equipment_section_speakers': {
        consts.LANG_RU: 'Динамики',
        consts.LANG_EN: 'TODO',
    },
    'address_book_call_unavailability_screen_title': {
        consts.LANG_RU: 'Начать звонок',
        consts.LANG_EN: 'Start a call',
    },
    'address_book_call_unavailability_screen_action_button': {
        consts.LANG_RU: 'Позвонить доступным',
        consts.LANG_EN: 'Call available contacts',
    },
    'address_book_call_unavailability_screen_text_invariant': {
        consts.LANG_RU: 'звонок недоступен',
        consts.LANG_EN: 'the call is unavailable',
    },
    'contact_profile_header_position': {
        consts.LANG_RU: 'Должность',
        consts.LANG_EN: 'Job title',
    },
    'contact_profile_header_department': {
        consts.LANG_RU: 'Отдел',
        consts.LANG_EN: 'Department',
    },
    'contact_profile_button_audio_call': {
        consts.LANG_RU: 'Позвонить',
        consts.LANG_EN: 'Audio call',
    },
    'contact_profile_button_video_call': {
        consts.LANG_RU: 'Видео',
        consts.LANG_EN: 'Video call',
    },
    'contact_profile_button_more': {
        consts.LANG_RU: 'Ещё',
        consts.LANG_EN: 'More',
    },
    'contact_profile_header_org_structure_subordinate': {
        consts.LANG_RU: 'В подчинении у',
        consts.LANG_EN: 'Subordinate to:',
    },
    'contact_profile_header_org_structure_manager': {
        consts.LANG_RU: 'Руководитель для:',
        consts.LANG_EN: 'Manager for:',
    },
    'address_book_contact_primary_email_title': {
        consts.LANG_RU: 'Email основной',
        consts.LANG_EN: 'Primary email',
    },
    'address_book_edit_book_screen_title_web': {
        consts.LANG_RU: 'Редактировать книгу',
        consts.LANG_EN: 'Edit the book',
    },
    'address_book_delete_button_text': {
        consts.LANG_RU: 'Удалить',
        consts.LANG_EN: 'Delete',
    },
    'address_book_edit_screen_button_text_web': {
        consts.LANG_RU: 'Сохранить',
        consts.LANG_EN: 'Save',
    },
    'address_book_edit_contact_action_button_web': {
        consts.LANG_RU: 'Редактировать',
        consts.LANG_EN: 'Edit',
    },
    'address_book_create_book_screen_title_web': {
        consts.LANG_RU: 'Создать книгу',
        consts.LANG_EN: 'Create personal book',
    },
    'address_book_create_screen_button_text_web': {
        consts.LANG_RU: 'Создать',
        consts.LANG_EN: 'Create',
    },
    'address_book_create_contact_text_button': {
        consts.LANG_RU: 'Создать контакт',
        consts.LANG_EN: 'Create a contact',
    },
    'address_book_contact_add_phone_text': {
        consts.LANG_RU: 'Добавить телефон',
        consts.LANG_EN: 'Add phone',
    },
    'address_book_contact_primary_phone_required_error': {
        consts.LANG_RU: 'Сначала укажите основной телефон',
        consts.LANG_EN: 'Enter the primary phone first',
    },
    'address_book_contact_additional_title': {
        consts.LANG_RU: 'Дополнительный',
        consts.LANG_EN: 'Additional',
    },
    'address_book_delete_book_title': {
        consts.LANG_RU: 'Удалить адресную книгу?',
        consts.LANG_EN: 'Delete address book?',
    },
    'general_cancel_label': {
        consts.LANG_RU: 'Отмена',
        consts.LANG_EN: 'Cancel',
    },
    'chat_create_success_toast': {
        consts.LANG_RU: 'Чат создан',
        consts.LANG_EN: 'Chat created',
    },
    'group_chat_created_toast': {
        consts.LANG_RU: 'Вы успешно создали групповой чат',
        consts.LANG_EN: 'Group chat created',
    },
    'toast_go_to_title': {
        consts.LANG_RU: 'Перейти',
        consts.LANG_EN: 'Open',
    },
    'profile_menu_sessions': {
        consts.LANG_RU: 'Мои сеансы',
        consts.LANG_EN: 'Sessions',
    },
    'profile_menu_about': {
        consts.LANG_RU: 'О приложении',
        consts.LANG_EN: 'About',
    },
    'profile_menu_support': {
        consts.LANG_RU: 'Поддержка',
        consts.LANG_EN: 'Support',
    },
    'profile_about_label_build': {
        consts.LANG_RU: 'Сборка',
        consts.LANG_EN: 'Build',
    },
    'profile_support_develop_enable_hint_after_6_clicks': {
        consts.LANG_RU: 'Чтобы включить develop режим, нажмите еще 4 раза',
        consts.LANG_EN: 'To enable develop mode, press 4 more times',
    },
    'profile_support_develop_disable_hint_after_6_clicks': {
        consts.LANG_RU: 'Чтобы выключить develop режим, нажмите еще 4 раза',
        consts.LANG_EN: 'To disable develop mode, press 4 more times',
    },
    'profile_support_develop_enabled_toast': {
        consts.LANG_RU: 'Develop режим активирован',
        consts.LANG_EN: 'Develop mode is enabled',
    },
    'profile_support_develop_disabled_toast': {
        consts.LANG_RU: 'Develop режим выключен',
        consts.LANG_EN: 'Develop mode is disabled',
    },
    'profile_support_develop_logging_enabled_toggle': {
        consts.LANG_RU: 'Включить логирование',
        consts.LANG_EN: 'Enable logging',
    },
    'profile_support_develop_console_proxy_toggle': {
        consts.LANG_RU: 'Проксировать консоль',
        consts.LANG_EN: 'Proxy console',
    },
    'profile_support_develop_console_title': {
        consts.LANG_RU: 'Настройки вывода в консоль (DevTools Console)',
        consts.LANG_EN: 'Console output settings (DevTools Console)',
    },
    'profile_support_develop_idb_title': {
        consts.LANG_RU: 'Настройки хранения логов (IndexedDB)',
        consts.LANG_EN: 'Log storage settings (IndexedDB)',
    },
    'profile_support_develop_sentry_title': {
        consts.LANG_RU: 'Настройки Sentry',
        consts.LANG_EN: 'Sentry Settings',
    },
    'profile_support_develop_log_levels_title': {
        consts.LANG_RU: 'Уровни логирования',
        consts.LANG_EN: 'Logging levels',
    },
    'profile_sessions_header_active_session': {
        consts.LANG_RU: 'Текущий сеанс',
        consts.LANG_EN: 'Active session',
    },
    'profile_sessions_header_other_sessions': {
        consts.LANG_RU: 'Другие сеансы',
        consts.LANG_EN: 'Other sessions',
    },
    'profile_sessions_button_terminate': {
        consts.LANG_RU: 'Завершить',
        consts.LANG_EN: 'Terminate',
    },
    'profile_sessions_button': {
        consts.LANG_RU: 'Завершить другие сеансы',
        consts.LANG_EN: 'Terminate other sessions',
    },
    'profile_sessions_modal_header_terminate': {
        consts.LANG_RU: 'Завершить выбранный сеанс?',
        consts.LANG_EN: 'Terminate selected session?',
    },
    'profile_settings_tab_name': {
        consts.LANG_RU: 'Настройки',
        consts.LANG_EN: 'Settings',
    },
    'profile_settings_language_section_title': {
        consts.LANG_RU: 'Язык',
        consts.LANG_EN: 'Language',
    },
    'profile_settings_language_russian': {
        consts.LANG_RU: 'Русский',
        consts.LANG_EN: 'Русский',
    },
    'profile_settings_language_english': {
        consts.LANG_RU: 'English',
        consts.LANG_EN: 'English',
    },
    'profile_settings_equipment_tab_name': {
        consts.LANG_RU: 'Оборудование',
        consts.LANG_EN: 'Media',
    },
    'profile_media_settings_microphone': {
        consts.LANG_RU: 'Микрофон',
        consts.LANG_EN: 'Microphone',
    },
    'profile_media_settings_speakers': {
        consts.LANG_RU: 'Динамики',
        consts.LANG_EN: 'Speakers',
    },
    'profile_media_settings_video': {
        consts.LANG_RU: 'Видео',
        consts.LANG_EN: 'Video',
    },
    'profile_media_settings_sensitivity_label': {
        consts.LANG_RU: 'Чувствительность',
        consts.LANG_EN: 'Sensitivity',
    },
    'profile_media_settings_volume_label': {
        consts.LANG_RU: 'Громкость',
        consts.LANG_EN: 'Volume',
    },
    'profile_support_logging_title': {
        consts.LANG_RU: 'Логирование',
        consts.LANG_EN: 'Logging',
    },
    'profile_support_logging_button_export': {
        consts.LANG_RU: 'Экспортировать логи в файл',
        consts.LANG_EN: 'Export logs to file',
    },
    'profile_support_logging_button_clear': {
        consts.LANG_RU: 'Очистить логи',
        consts.LANG_EN: 'Clear logs',
    },
    'notification_logs_export': {
        consts.LANG_RU: 'Логи успешно экспортированы',
        consts.LANG_EN: 'Logs exported successfully',
    },
    'notification_logs_deleted': {
        consts.LANG_RU: 'Логи успешно очищены',
        consts.LANG_EN: 'Log files deleted',
    },
}
