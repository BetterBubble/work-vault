import enum


class ProfilePopupEditActions(enum.StrEnum):
    SAVE = 'save'
    CANCEL = 'cancel'

class ChatScrollOffsetDirections(enum.IntEnum):
    TOP = -1
    BOTTOM = 1

class ChatBubbleContentSearchMode(enum.StrEnum):
    TEXT = 'text'
    VISUAL_LINK = 'visual_link'
    REAL_LINK = 'real_link'

class ChatInputEditLinkPopupLabels(enum.StrEnum):
    TEXT = 'text'
    LINK = 'link'

class AddressBookGroupIcon(enum.StrEnum):
    """Теги iva-icon иконок личной книги (iconKey продукта → iva-icon-* в пикере и в узле дерева)."""
    PERSONAL = 'iva-icon-book-user'
    CROWN = 'iva-icon-crown'

class CalendarMeetingType(enum.StrEnum):
    """Тип мероприятия в меню создания календаря («+»): обычное Событие (через imail/jump)
    или ВКС-встреча (через MCU). Значение = i18n-ключ пункта меню."""
    EVENT = 'calendar_menu_event_title'
    VKS = 'calendar_menu_vks_title'

class ProfileLanguage(enum.StrEnum):
    """Язык интерфейса в разделе профиля «Настройки → Язык». Значение = i18n-ключ
    названия языка (тексты опций «Русский»/«English» языко-независимы)."""
    RUSSIAN = 'profile_settings_language_russian'
    ENGLISH = 'profile_settings_language_english'


class ProfileEquipmentSection(enum.StrEnum):
    """Секция экрана профиля «Настройки → Оборудование». Значение = i18n-ключ
    заголовка секции (h2.section-title)."""
    MICROPHONE = 'profile_media_settings_microphone'
    SPEAKERS = 'profile_media_settings_speakers'
    VIDEO = 'profile_media_settings_video'
