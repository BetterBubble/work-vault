import os

import allure
import pytest

from autocore.test.logger import get_log
from autocore.test.generate_data import get_random_string, generate_cyryllic_name, generate_email
from autocore.clients.rest import iva_one
from autocore.consts import TEST_DATA_DIR
from tools.helpers.page_helpers import grant_notifications
from tools.helpers.session import web_preamble, iva_one_web_login
from tools.helpers.mcu import ensure_mcu_profile
from tools.helpers import contacts as contacts_helper
from tools import enums
from tests import pages
from tests.pages import chunks


log = get_log()


@allure.id("454")
@allure.title("Аватар по умолчанию")
@allure.label("owner", "Simon")
@allure.tag("web", "RFA")
@allure.story("Аккаунт")
@allure.feature("Личный профиль")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_default_avatar(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]
    contact_data = users_factory[1]

    log.tc('454')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data.get('username'), user_data.get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_address_book()
    address_book = chunks.get_chunk(version, 'address_book')(driver, lang=lang, check_primary_element=False)
    address_book.search_user(contact_data)
    address_book.check_default_avatar_ds_first_letters(contact_data)
    address_book.check_default_avatar_gradient(contact_data)


@allure.id("52502")
@allure.title("Удаление личного контакта — подтверждение и каскадное удаление")
@allure.tag("Delete", "SingleContact", "WEB")
@allure.story("Мультиселект и действия с контактами")
@allure.feature("Адресная книга")
@allure.label("IVAQA", "IVAONE-10446")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_delete_personal_contact(setup_aut, users_factory, teardown):
    """Удаление личного контакта из карточки: «Ещё» → «Удалить» → confirm-попап с
    именем контакта → подтверждение. Проверяется: тост «Контакт удален»; сайдбар
    закрывается (в текущей сборке баг — ассерт красный); опустевшая личная книга
    показывает заглушку; удалённый контакт не находится поиском."""
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]

    # Setup: изолированная личная книга с единственным контактом (через REST).
    # Книга живёт под ephemeral-пользователем, которого удаляет users_factory teardown;
    # отдельный teardown книги не делаем — после delete_user токен владельца невалиден.
    token = iva_one_web_login(setup_aut, user_data)
    book_name = f'Книга {get_random_string(6)}'
    book = iva_one.create_contact_group(token, book_name, 'personal')
    contact = generate_cyryllic_name()
    iva_one.create_contact(token, book['id'], contact['first_name'], contact['last_name'],
                           phones=[{'phone': '79990001122', 'isPrimary': True}])
    contact_full_name = f'{contact["last_name"]} {contact["first_name"]}'

    log.tc('52502')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_address_book()
    address_book = chunks.get_chunk(version, 'address_book')(driver, lang=lang, check_primary_element=False)
    address_book.open_personal_book(book_name)
    contact_card = address_book.open_contact_card(contact_full_name)

    contact_card.open_delete_contact_dialog()
    contact_card.assert_delete_contact_dialog(contact_full_name)
    contact_card.confirm_delete_contact()

    toast = chunks.get_chunk(version, 'toast')(driver=driver, lang=lang)
    toast.assert_i18n_visible('contact_deleted_toast', 'Отображается тост "Контакт удален"')
    # Сценарий (шаг 2): сайдбар автоматически закрывается. В текущей сборке он НЕ
    # закрывается (остаётся с данными удалённого контакта на ya/Safari/FF) — ассерт
    # намеренно оставлен «красным», позеленеет после фикса продукта.
    contact_card.assert_card_closed()
    # После удаления приложение уходит на «Все контакты» — переоткрываем книгу,
    # чтобы проверить её пустое состояние: контакт удалён из книги (заглушка) и не ищется.
    address_book.open_personal_book(book_name)
    address_book.assert_personal_book_empty_stub()
    address_book.assert_contact_not_found_by_search(contact_full_name)


@allure.id("52498")
@allure.title("Перемещение личного контакта — проверка доступности и флоу перемещения")
@allure.tag("Move", "SingleContact", "WEB")
@allure.story("Мультиселект и действия с контактами")
@allure.feature("Адресная книга")
@allure.label("IVAQA", "IVAONE-10446")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_move_personal_contact(setup_aut, users_factory, teardown):
    """Перемещение личного контакта между личными книгами из карточки: «Ещё» →
    «Переместить» → picker книг → выбор целевой книги. Проверяется тост «Контакт
    перемещен», контакт в целевой книге, исходная книга стала пустой. Текущая книга
    контакта показывается в picker'е, но недоступна для выбора (_not-selectable) —
    задизейблена тем же механизмом, что системные категории."""
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]

    # Setup: две личные книги (исходная + целевая) и контакт в исходной — через REST.
    token = iva_one_web_login(setup_aut, user_data)
    src_book_name = f'Книга {get_random_string(6)}'
    dst_book_name = f'Книга {get_random_string(6)}'
    src_book = iva_one.create_contact_group(token, src_book_name, 'personal')
    iva_one.create_contact_group(token, dst_book_name, 'personal')
    contact = generate_cyryllic_name()
    iva_one.create_contact(token, src_book['id'], contact['first_name'], contact['last_name'],
                           phones=[{'phone': '79990001122', 'isPrimary': True}])
    contact_full_name = f'{contact["last_name"]} {contact["first_name"]}'

    log.tc('52498')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_address_book()
    address_book = chunks.get_chunk(version, 'address_book')(driver, lang=lang, check_primary_element=False)
    address_book.open_personal_book(src_book_name)
    contact_card = address_book.open_contact_card(contact_full_name)

    contact_card.open_move_contact_menu()
    contact_card.assert_move_picker_book_present(dst_book_name)
    # Текущая книга контакта показывается в picker'е, но недоступна для выбора (_not-selectable).
    contact_card.assert_move_picker_book_not_selectable(src_book_name)
    contact_card.move_contact_to_book(dst_book_name)

    toast = chunks.get_chunk(version, 'toast')(driver=driver, lang=lang)
    toast.assert_i18n_visible('contact_moved_toast', 'Отображается тост "Контакт перемещен"')

    # Контакт переехал: в целевой книге есть, исходная стала пустой (список не
    # авто-обновляется — переоткрываем книги через дерево).
    address_book.open_personal_book(dst_book_name)
    address_book.assert_contact_in_book(contact_full_name)
    address_book.open_personal_book(src_book_name)
    address_book.assert_personal_book_empty_stub()


@allure.id("52490")
@allure.title("Мультиселект контактов с использованием поиска")
@allure.tag("Multiselect", "Search", "WEB")
@allure.story("Мультиселект и действия с контактами")
@allure.feature("Адресная книга")
@allure.label("IVAQA", "IVAONE-10446")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_multiselect_contacts_with_search(setup_aut, users_factory, teardown):
    """Мультиселект в «Все контакты»: отметить чекбоксами 2 личных контакта (без chat)
    → ввести поиск (выбранные остаются чипами, счётчик сохраняется) → отметить
    корпоративного из результатов (счётчик растёт). Клик «Написать» открывает диалог
    «Создать чат» с cans-разделителем: личные (без chat) недоступны, корпоративный
    доступен. «Сбросить» закрывает плашку и очищает поиск — список возвращается.

    Корп-контакт = второй тест-юзер (users_factory[1]): он виден в «Все контакты»
    первого как корпоративный (type=user, cans с chat)."""
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]
    corporate_user = users_factory[1]

    # Setup: 2 личных контакта (без chat) в книге первого юзера. Фамилия «Аалтонен»
    # сортирует их в самый верх «Все контакты» — видимы для отметки чекбоксами до поиска.
    token = iva_one_web_login(setup_aut, user_data)
    book = iva_one.create_contact_group(token, f'Книга {get_random_string(6)}', 'personal')
    iva_one.create_contact(token, book['id'], 'Анна', 'Аалтонен')
    iva_one.create_contact(token, book['id'], 'Борис', 'Аалтонен')
    personal_a = 'Аалтонен Анна'
    personal_b = 'Аалтонен Борис'
    # Корпоративный контакт (есть chat) = второй тест-юзер, виден в «Все контакты» первого.
    corporate = f"{corporate_user['last_name']} {corporate_user['first_name']}"

    log.tc('52490')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_address_book()
    address_book = chunks.get_chunk(version, 'address_book')(driver, lang=lang, check_primary_element=False)
    address_book.open_all_contacts()

    # Отметить чекбоксами 2 личных → режим мультиселекта, «Выбрано: 2».
    address_book.select_contact(personal_a)
    address_book.select_contact(personal_b)
    address_book.assert_selected_count(2)

    # Поиск не сбрасывает выборку: выбранные остаются чипами, счётчик держится.
    address_book.multiselect_search(corporate_user['last_name'])
    address_book.assert_contact_chip(personal_a)
    address_book.assert_contact_chip(personal_b)
    address_book.assert_selected_count(2)

    # Отметить корпоративного из отфильтрованных результатов → «Выбрано: 3».
    address_book.select_contact(corporate)
    address_book.assert_selected_count(3)

    # Клик «Написать» → диалог «Создать чат» с cans-разделителем: личные (без chat)
    # недоступны, корпоративный доступен.
    address_book.click_bulk_write()
    address_book.assert_create_chat_dialog()
    address_book.assert_create_chat_unavailable_info()
    address_book.assert_contact_unavailable_in_create_chat(personal_a)
    address_book.assert_contact_unavailable_in_create_chat(personal_b)
    address_book.assert_contact_available_in_create_chat(corporate)
    address_book.cancel_create_chat()

    # «Сбросить» → плашка ушла, поиск очищен (скрытый личный снова виден в списке).
    address_book.reset_multiselect()
    address_book.assert_multiselect_inactive()
    address_book.assert_contact_in_book(personal_a)


@allure.id("52493")
@allure.title("Мультиселект: Перемещение личных и корпоративных контактов — окно доступности")
@allure.tag("Move", "Multiselect", "WEB")
@allure.story("Мультиселект и действия с контактами")
@allure.feature("Адресная книга")
@allure.label("IVAQA", "IVAONE-10446")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_move_mixed_contacts_with_availability(setup_aut, users_factory, teardown):
    """Перемещение mixed-выборки (1 личный + 1 корпоративный) из мультиселекта: «Ещё» →
    «Переместить» → выбор целевой книги → экран-разделитель «Перемещение» (корпоративный
    недоступен — чужой контакт, личный доступен) → «Переместить доступных». Проверяется:
    разделитель с разделением доступности, тост «Контакт перемещен», личный переехал в
    целевую книгу. После перемещения мультиселект НЕ деактивируется (в текущей сборке —
    расхождение со сценарием), финальный ассерт намеренно красный до фикса.

    Корп-контакт = второй тест-юзер (users_factory[1], type=user — недоступен для перемещения)."""
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]
    corporate_user = users_factory[1]

    # Setup: 2 личные книги (src+dst) + сгенерированный личный контакт в src.
    token = iva_one_web_login(setup_aut, user_data)
    src_book = iva_one.create_contact_group(token, f'Книга {get_random_string(6)}', 'personal')
    dst_book_name = f'Книга {get_random_string(6)}'
    iva_one.create_contact_group(token, dst_book_name, 'personal')
    contact = generate_cyryllic_name()
    iva_one.create_contact(token, src_book['id'], contact['first_name'], contact['last_name'])
    personal = f"{contact['last_name']} {contact['first_name']}"
    corporate = f"{corporate_user['last_name']} {corporate_user['first_name']}"

    log.tc('52493')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_address_book()
    address_book = chunks.get_chunk(version, 'address_book')(driver, lang=lang, check_primary_element=False)
    address_book.open_all_contacts()

    # Выбрать 1 корпоративный (обычный поиск) + 1 личный (поиск мультиселекта) → «Выбрано: 2».
    # Обоих ищем по фамилии — позиция в «Все контакты» не задаётся хардкодом.
    address_book.search_contact(corporate_user['last_name'])
    address_book.select_contact(corporate)
    address_book.multiselect_search(contact['last_name'])
    address_book.select_contact(personal)
    address_book.assert_selected_count(2)

    # «Ещё» → «Переместить» → picker → выбор целевой книги → экран-разделитель «Перемещение».
    address_book.bulk_move_select_book(dst_book_name)
    address_book.assert_move_divider_dialog()
    address_book.assert_move_divider_unavailable_info()
    address_book.assert_contact_unavailable_in_move_divider(corporate)
    address_book.assert_contact_available_in_move_divider(personal)

    # «Переместить доступных» → переезжает только личный.
    address_book.confirm_move_available()
    toast = chunks.get_chunk(version, 'toast')(driver=driver, lang=lang)
    toast.assert_i18n_visible('contact_moved_toast', 'Отображается тост "Контакт перемещен"')

    # Сценарий (шаг 3): режим мультиселекта деактивируется. В текущей сборке плашка
    # «Выбрано: N» остаётся (подтверждено скриншотом) — ассерт намеренно красный до фикса.
    address_book.assert_multiselect_inactive('Плашка мультиселекта закрылась после перемещения')

    # Личный контакт переехал в целевую книгу (проверяем в самой книге, не в агрегате
    # «Все контакты»). Шаг недостижим, пока ассерт выше красный; позеленеет после фикса.
    address_book.open_personal_book(dst_book_name)
    address_book.assert_contact_in_book(personal)


@allure.id("52497")
@allure.title("Мультиселект: Удаление личных и корпоративных контактов — окно доступности")
@allure.tag("Delete", "Multiselect", "WEB")
@allure.story("Мультиселект и действия с контактами")
@allure.feature("Адресная книга")
@allure.label("IVAQA", "IVAONE-10446")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_delete_mixed_contacts_with_availability(setup_aut, users_factory, teardown):
    """Удаление mixed-выборки (1 личный + 1 корпоративный) из мультиселекта: «Ещё» →
    «Удалить» → экран-разделитель «Удалить контакты?» (корпоративный недоступен — чужой
    контакт, личный доступен) → «Удалить доступных». Проверяется: разделитель с разделением
    доступности, тост «Контакт удален», удалён только личный (корпоративный остаётся).
    Отдельного confirm-попапа после «Удалить доступных» нет — разделитель и есть подтверждение.

    Ядро (разделитель + удаление только личного) проверяется первым и зеленеет. После
    удаления мультиселект должен деактивироваться (сценарий, шаг 3) — в текущей сборке плашка
    остаётся («Выбрано: 1»), финальный ассерт намеренно красный до фикса.

    Корп-контакт = второй тест-юзер (users_factory[1], type=user — недоступен для удаления)."""
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]
    corporate_user = users_factory[1]

    # Setup: личная книга + сгенерированный личный контакт в ней (через REST).
    token = iva_one_web_login(setup_aut, user_data)
    book = iva_one.create_contact_group(token, f'Книга {get_random_string(6)}', 'personal')
    contact = generate_cyryllic_name()
    iva_one.create_contact(token, book['id'], contact['first_name'], contact['last_name'])
    personal = f"{contact['last_name']} {contact['first_name']}"
    corporate = f"{corporate_user['last_name']} {corporate_user['first_name']}"

    log.tc('52497')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_address_book()
    address_book = chunks.get_chunk(version, 'address_book')(driver, lang=lang, check_primary_element=False)
    address_book.open_all_contacts()

    # Выбрать 1 корпоративный (обычный поиск) + 1 личный (поиск мультиселекта) → «Выбрано: 2».
    # Обоих ищем по фамилии — позиция в «Все контакты» не задаётся хардкодом.
    address_book.search_contact(corporate_user['last_name'])
    address_book.select_contact(corporate)
    address_book.multiselect_search(contact['last_name'])
    address_book.select_contact(personal)
    address_book.assert_selected_count(2)

    # «Ещё» → «Удалить» → экран-разделитель «Удалить контакты?» (без picker, сразу).
    address_book.bulk_delete()
    address_book.assert_delete_divider_dialog()
    address_book.assert_delete_divider_unavailable_info()
    address_book.assert_contact_unavailable_in_delete_divider(corporate)
    address_book.assert_contact_available_in_delete_divider(personal)

    # «Удалить доступных» → удаляется только личный (доп. confirm-попапа нет).
    address_book.confirm_delete_available()
    toast = chunks.get_chunk(version, 'toast')(driver=driver, lang=lang)
    toast.assert_i18n_visible('contact_deleted_toast', 'Отображается тост "Контакт удален"')

    # Ядро: личный удалён из «Все контакты», корпоративный остался.
    address_book.assert_contact_absent_in_list(personal)
    address_book.assert_contact_in_book(corporate)

    # Сценарий (шаг 3): режим мультиселекта деактивируется. В текущей сборке плашка
    # остаётся («Выбрано: 1», удалённый личный выпал из выборки) — ассерт намеренно красный.
    address_book.assert_multiselect_inactive('Плашка мультиселекта закрылась после удаления')


@allure.id("52499")
@allure.title("Звонок по личному контакту — проверка доступности и инициация вызова")
@allure.tag("Call", "SingleContact", "WEB")
@allure.story("Мультиселект и действия с контактами")
@allure.feature("Адресная книга")
@allure.label("IVAQA", "IVAONE-10446")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_call_personal_contact(setup_aut, users_factory, teardown):
    """Звонок личному контакту из карточки: «Позвонить» → окно исходящего звонка
    («Ожидание ответа») открывается напрямую, без окна конфликта (контакт один) →
    завершение звонка (кнопка сброса) закрывает окно.

    Проверяется UI-флоу. Шаг сценария про payload («profileId» в запросе, отсутствие
    запросов к UserService) не автоматизируется: тело запроса инициации звонка через
    Selenium/performance API недоступно, а инвариант «аватар через ProfileService» в
    этой сборке недостижим (как в TC-52498). Окно звонка у звонящего рендерится надёжно
    только при выданном разрешении на уведомления — grant_notifications до login."""
    lang, version, driver = web_preamble(setup_aut, teardown)
    config = setup_aut['setup']['config']
    web_url = config['web_url']
    user_data = users_factory[0]

    # Setup: личная книга + личный контакт с основным телефоном (через REST).
    token = iva_one_web_login(setup_aut, user_data)
    book_name = f'Книга {get_random_string(6)}'
    book = iva_one.create_contact_group(token, book_name, 'personal')
    contact = generate_cyryllic_name()
    iva_one.create_contact(token, book['id'], contact['first_name'], contact['last_name'],
                           phones=[{'phone': '79990001122', 'isPrimary': True}])
    contact_full_name = f'{contact["last_name"]} {contact["first_name"]}'

    log.tc('52499')

    # grant_notifications ДО login — окно звонка у звонящего рендерится надёжно только при granted.
    grant_notifications(driver, web_url)
    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_address_book()
    address_book = chunks.get_chunk(version, 'address_book')(driver, lang=lang, check_primary_element=False)
    address_book.open_personal_book(book_name)
    contact_card = address_book.open_contact_card(contact_full_name)

    # «Позвонить» → окно исходящего звонка открывается напрямую (окна конфликта нет — контакт один).
    contact_card.start_call()
    call = chunks.get_chunk(version, 'call')(driver, lang=lang)
    call.assert_outgoing_call_started()

    # Завершить звонок → окно закрывается.
    call.end_call()
    call.assert_call_window_closed()


@allure.id("52500")
@allure.title("Создание ВКС-встречи с личным контактом")
@allure.tag("MCU", "SingleContact", "WEB")
@allure.story("Мультиселект и действия с контактами")
@allure.feature("Адресная книга")
@allure.label("IVAQA", "IVAONE-10446")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.xfail(reason='IVAONE-12308 [Web] Календарь. Не синхронизирует аватар личного контакта')
def test_create_mcu_conference_with_personal_contact(setup_aut, users_factory, teardown):
    """Создание ВКС-встречи из карточки личного контакта: «Ещё» → «ВКС-встреча» →
    форма → ввод темы → «Создать встречу». Проверяется: открыта карточка созданной
    встречи (заголовок = тема), контакт авто-добавлен в участники («Участники 2»)."""
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]

    # Setup: личная книга + личный контакт с телефоном (для пункта «Ещё») и аватаром
    # (для проверки отображения аватара участника) — через REST.
    token = iva_one_web_login(setup_aut, user_data)
    book_name = f'Книга {get_random_string(6)}'
    book = iva_one.create_contact_group(token, book_name, 'personal')
    avatar_id = iva_one.upload_file(token, os.path.join(TEST_DATA_DIR, 'test_image_sample.jpeg'))
    contact = generate_cyryllic_name()
    iva_one.create_contact(token, book['id'], contact['first_name'], contact['last_name'],
                           phones=[{'phone': '79990001122', 'isPrimary': True}], avatar_file_id=avatar_id)
    contact_full_name = f'{contact["last_name"]} {contact["first_name"]}'

    log.tc('52500')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_address_book()
    address_book = chunks.get_chunk(version, 'address_book')(driver, lang=lang, check_primary_element=False)
    address_book.open_personal_book(book_name)
    contact_card = address_book.open_contact_card(contact_full_name)

    # «Ещё» → «ВКС-встреча» → форма создания → ввод темы → «Создать встречу».
    contact_card.open_mcu_conference_form()
    mcu_conference = chunks.get_chunk(version, 'mcu_conference_sidebar')(driver, lang=lang)
    theme = f'ВКС с контактом {get_random_string(5)}'
    mcu_conference.fill_theme(theme)
    mcu_conference.create_conference()

    # Встреча создана: открыта карточка ВКС-события; контакт авто-добавлен (Участники 2).
    mcu_conference.assert_conference_created(theme)
    mcu_conference.assert_participants_count(2)

    # Участник отображается по «Фамилия Имя» (зелёный). Шаг 3 — аватар контакта: в текущей
    # сборке аватар приглашённого контакта не подтягивается (инициалы вместо фото) —
    # ассерт намеренно красный до фикса.
    mcu_conference.assert_participant_by_name(contact_full_name)
    mcu_conference.assert_participant_avatar(contact_full_name)


@allure.id("52495")
@allure.title("Мультиселект: Создание ВКС-встречи для смешанных контактов")
@allure.tag("MCU", "Multiselect", "WEB")
@allure.story("Мультиселект и действия с контактами")
@allure.feature("Адресная книга")
@allure.label("IVAQA", "IVAONE-10446")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
@pytest.mark.xfail(reason='IVAONE-12308 [Web] Календарь. Не синхронизирует аватар личного контакта')
def test_create_mcu_conference_with_mixed_contacts(setup_aut, users_factory, teardown):
    """Мультиселект (личный + корпоративный) → «ВКС-встреча» в плашке мультиселекта →
    форма → тема → «Создать встречу». Проверяется: открыта карточка встречи (заголовок =
    тема), оба контакта отображаются в участниках («Участники 3»)."""
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]
    corporate_user = users_factory[1]

    # Setup: личный контакт (телефон+аватар) в книге первого юзера; аватар корп-юзеру.
    avatar_path = os.path.join(TEST_DATA_DIR, 'test_image_sample.jpeg')
    token = iva_one_web_login(setup_aut, user_data)
    book = iva_one.create_contact_group(token, f'Книга {get_random_string(6)}', 'personal')
    personal_avatar = iva_one.upload_file(token, avatar_path)
    contact = generate_cyryllic_name()
    iva_one.create_contact(token, book['id'], contact['first_name'], contact['last_name'],
                           phones=[{'phone': '79990001122', 'isPrimary': True}], avatar_file_id=personal_avatar)
    personal = f"{contact['last_name']} {contact['first_name']}"
    # Корп = 2-й юзер: ставим ему аватар профиля, чтобы он отображался в участниках встречи.
    corp_token = iva_one_web_login(setup_aut, corporate_user)
    iva_one.set_profile_avatar(corp_token, iva_one.upload_file(corp_token, avatar_path))
    corporate = f"{corporate_user['last_name']} {corporate_user['first_name']}"

    log.tc('52495')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_address_book()
    address_book = chunks.get_chunk(version, 'address_book')(driver, lang=lang, check_primary_element=False)
    address_book.open_all_contacts()

    # Выбрать 1 корп (обычный поиск) + 1 личный (поиск мультиселекта) → «Выбрано: 2».
    address_book.search_contact(corporate_user['last_name'])
    address_book.select_contact(corporate)
    address_book.multiselect_search(contact['last_name'])
    address_book.select_contact(personal)
    address_book.assert_selected_count(2)

    # «ВКС-встреча» в плашке мультиселекта → форма (разделителя нет — оба event.mcu) →
    # тема → «Создать встречу».
    address_book.open_mcu_conference_form()
    mcu_conference = chunks.get_chunk(version, 'mcu_conference_sidebar')(driver, lang=lang)
    theme = f'ВКС mixed {get_random_string(5)}'
    mcu_conference.fill_theme(theme)
    mcu_conference.create_conference()

    # Встреча создана: карточка ВКС-события; организатор + оба контакта → «Участники 3».
    mcu_conference.assert_conference_created(theme)
    mcu_conference.assert_participants_count(3)

    # Корпоративный резолвится в профиль → имя и аватар отображаются (зелёные).
    mcu_conference.assert_participant_by_name(corporate)
    mcu_conference.assert_participant_avatar(corporate)

    # Личный контакт резолвится по «Фамилия Имя» (зелёный); аватар — намеренно красный:
    # аватар приглашённого контакта не подтягивается (как TC-52500), позеленеет после фикса.
    mcu_conference.assert_participant_by_name(personal)
    mcu_conference.assert_participant_avatar(personal)


@allure.id("52501")
@allure.title("Создание оффлайн-события с личным контактом")
@allure.tag("OfflineEvent", "SingleContact", "WEB")
@allure.story("Мультиселект и действия с контактами")
@allure.feature("Адресная книга")
@allure.label("IVAQA", "IVAONE-10446")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.require_ldap_user
@pytest.mark.xfail(reason='IVAONE-12308 [Web] Календарь. Не синхронизирует аватар личного контакта')
def test_create_offline_event_with_personal_contact(setup_aut, teardown):
    """Создание оффлайн-события из карточки личного контакта: «Ещё» → «Событие» →
    форма → тема → «Создать событие». Проверяется: форма загрузилась, событие создано,
    контакт отображается в участниках."""
    lang, version, driver = web_preamble(setup_aut, teardown, register_quit=False)
    config = setup_aut['setup']['config']
    mail_user = config['credentials']['mail_user']

    # Setup: личный контакт (email — для пункта «Событие», телефон, аватар) в книге
    # mail-пользователя — через REST.
    avatar_path = os.path.join(TEST_DATA_DIR, 'test_image_sample.jpeg')
    token = iva_one_web_login(setup_aut, mail_user)
    book_name = f'Книга {get_random_string(6)}'
    book = iva_one.create_contact_group(token, book_name, 'personal')
    avatar_id = iva_one.upload_file(token, avatar_path)
    contact = generate_cyryllic_name()
    contact_email = f'{get_random_string(8)}@example.com'.lower()
    iva_one.create_contact(token, book['id'], contact['first_name'], contact['last_name'],
                           phones=[{'phone': '79990001122', 'isPrimary': True}],
                           emails=[{'email': contact_email, 'isPrimary': True}],
                           avatar_file_id=avatar_id)
    contact_full_name = f'{contact["last_name"]} {contact["first_name"]}'

    # Очистка. mail_user — персистентный, ephemeral-автоочистки нет. Событие живёт в imail
    # (REST API в IVA One нет) — чистим через imail jump (нужен живой driver, поэтому ДО
    # quit; uid проставится после создания). Книга контакта — обычным REST.
    event = chunks.get_chunk(version, 'offline_event')(driver, lang=lang)
    created_uid = []
    teardown.append((lambda b: iva_one.delete_contact_group(token, b), book['id']))
    teardown.append((lambda _: created_uid and event.cancel_event_via_jump(created_uid[0]), None))
    teardown.append((lambda el: el.quit(), driver))

    log.tc('52501')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(mail_user['username'], mail_user['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_address_book()
    address_book = chunks.get_chunk(version, 'address_book')(driver, lang=lang, check_primary_element=False)
    address_book.open_personal_book(book_name)
    contact_card = address_book.open_contact_card(contact_full_name)

    # Перехватить id imail-сессии (для удаления события в teardown) ДО загрузки формы.
    event.start_imail_session_capture()

    # «Ещё» → «Событие» → форма события (грузится из imail — у mail-юзера не зависает).
    contact_card.open_event_form()
    event.assert_form_loaded()

    # Заполнить тему → «Создать событие».
    theme = f'Событие {get_random_string(5)}'
    event.fill_theme(theme)
    event.create_event()
    created_uid.append(event.get_event_uid())

    # Событие создано: открыта карточка события, контакт в участниках по «Фамилия Имя».
    event.assert_event_created()
    event.assert_participant_by_name(contact_full_name)

    # Шаг 3 — аватар контакта у участника: в текущей сборке аватар приглашённого личного
    # контакта не подтягивается (инициалы вместо фото) — ассерт намеренно красный до фикса.
    event.assert_participant_avatar(contact_full_name)


@allure.id("52496")
@allure.title("Мультиселект: Создание оффлайн-события для смешанных контактов")
@allure.tag("OfflineEvent", "Multiselect", "WEB")
@allure.story("Мультиселект и действия с контактами")
@allure.feature("Адресная книга")
@allure.label("IVAQA", "IVAONE-10446")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.require_ldap_user
@pytest.mark.xfail(reason='IVAONE-12308 [Web] Календарь. Не синхронизирует аватар личного контакта')
def test_create_offline_event_with_mixed_contacts(setup_aut, users_factory, teardown):
    """Мультиселект (личный + корпоративный, оба event.offline) → «Ещё» → «Событие» в
    плашке мультиселекта → форма → тема → «Создать событие». Проверяется: форма
    загрузилась (разделителя нет — оба доступны), событие создано, оба контакта
    отображаются в участниках."""
    lang, version, driver = web_preamble(setup_aut, teardown, register_quit=False)
    config = setup_aut['setup']['config']
    mail_user = config['credentials']['mail_user']
    corporate_user = users_factory[0]

    # Setup: личный контакт (email — для event.offline, телефон, аватар) в книге mail-юзера —
    # через REST. Корп = эфемерный юзер: ставим ему аватар профиля, чтобы он показывался в
    # участниках по имени+аватару (как в ВКС mixed TC-52495).
    avatar_path = os.path.join(TEST_DATA_DIR, 'test_image_sample.jpeg')
    token = iva_one_web_login(setup_aut, mail_user)
    book_name = f'Книга {get_random_string(6)}'
    book = iva_one.create_contact_group(token, book_name, 'personal')
    avatar_id = iva_one.upload_file(token, avatar_path)
    contact = generate_cyryllic_name()
    contact_email = f'{get_random_string(8)}@example.com'.lower()
    iva_one.create_contact(token, book['id'], contact['first_name'], contact['last_name'],
                           phones=[{'phone': '79990001122', 'isPrimary': True}],
                           emails=[{'email': contact_email, 'isPrimary': True}],
                           avatar_file_id=avatar_id)
    personal = f"{contact['last_name']} {contact['first_name']}"
    corp_token = iva_one_web_login(setup_aut, corporate_user)
    iva_one.set_profile_avatar(corp_token, iva_one.upload_file(corp_token, avatar_path))
    corporate = f"{corporate_user['last_name']} {corporate_user['first_name']}"

    # Очистка. mail_user — персистентный, ephemeral-автоочистки нет. Событие живёт в imail
    # (REST API в IVA One нет) — чистим через imail jump (нужен живой driver, поэтому ДО
    # quit; uid проставится после создания). Книга контакта — обычным REST.
    event = chunks.get_chunk(version, 'offline_event')(driver, lang=lang)
    created_uid = []
    teardown.append((lambda b: iva_one.delete_contact_group(token, b), book['id']))
    teardown.append((lambda _: created_uid and event.cancel_event_via_jump(created_uid[0]), None))
    teardown.append((lambda el: el.quit(), driver))

    log.tc('52496')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(mail_user['username'], mail_user['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_address_book()
    address_book = chunks.get_chunk(version, 'address_book')(driver, lang=lang, check_primary_element=False)
    address_book.open_all_contacts()

    # Выбрать 1 корп (обычный поиск) + 1 личный (поиск мультиселекта) → «Выбрано: 2».
    address_book.search_contact(corporate_user['last_name'])
    address_book.select_contact(corporate)
    address_book.multiselect_search(contact['last_name'])
    address_book.select_contact(personal)
    address_book.assert_selected_count(2)

    # Перехватить id imail-сессии (для удаления события в teardown) ДО загрузки формы.
    event.start_imail_session_capture()

    # «Ещё» → «Событие» в плашке мультиселекта → форма (разделителя нет — оба event.offline).
    address_book.open_event_form()
    event.assert_form_loaded()

    # Заполнить тему → «Создать событие».
    theme = f'Событие mixed {get_random_string(5)}'
    event.fill_theme(theme)
    event.create_event()
    created_uid.append(event.get_event_uid())

    # Событие создано: открыта карточка события, оба контакта в участниках.
    event.assert_event_created()

    # Корпоративный резолвится в профиль → имя и аватар отображаются (зелёные).
    event.assert_participant_by_name(corporate)
    event.assert_participant_avatar(corporate)

    # Личный резолвится по «Фамилия Имя» (зелёный).
    event.assert_participant_by_name(personal)

    # Шаг 2 — аватар личного контакта у участника: в текущей сборке аватар приглашённого
    # контакта не подтягивается (инициалы вместо фото) — ассерт намеренно красный (как
    # TC-52501), позеленеет после фикса.
    event.assert_participant_avatar(personal)


@allure.id("46795")
@allure.title("Просмотр информации о пользователе. профиль")
@allure.label("owner", "Simon")
@allure.tag("web", "RFA")
@allure.story("создание\\удаление\\редактирование личного контакта")
@allure.feature("Адресная книга")
@allure.label("IVAQA", "IVAONE-11238")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_view_user_profile(setup_aut, users_factory, teardown):
    """Поиск пользователя в адресной книге, hover на ФИ (подсветка строки), клик
    по ФИ — карточка профиля: аватар, ФИО, должность, отдел, email."""
    lang, version, driver = web_preamble(setup_aut, teardown)
    config = setup_aut['setup']['config']
    user_data = users_factory[0]

    # Setup: целевой юзер — прямым create_user: users_factory не пробрасывает
    # Keycloak-атрибуты position/department (они дают Должность/Отдел в карточке).
    admin_token = iva_one.login(**config['credentials']['admin'])
    realm = config['web-realm']
    target_email = f'02_web_{generate_email(full_name=False)}'
    target_cyr_name = generate_cyryllic_name()
    target_data = {
        'username': target_email,
        'first_name': target_cyr_name['first_name'],
        'last_name': target_cyr_name['last_name'],
    }
    position = 'Ведущий инженер'
    department = 'Отдел тестирования'
    iva_one.create_user(admin_token, realm, target_email, target_email,
                        target_data['first_name'], target_data['last_name'],
                        attributes={'position': [position], 'department': [department]})
    iva_one.set_user_password(admin_token, realm, target_email, 'DnUx0o')
    teardown.append(lambda: iva_one.delete_user(realm=realm, username=target_email))

    log.tc('46795')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_address_book()
    address_book = chunks.get_chunk(version, 'address_book')(driver, lang=lang, check_primary_element=False)

    address_book.search_user(target_data)
    address_book.assert_row_highlight_on_hover(target_data)
    user_profile = address_book.click_user_row_name(target_data)
    user_profile.assert_profile_sidebar_with_name_opened(target_data)
    user_profile.assert_avatar_displayed()
    user_profile.assert_profile_field('contact_profile_header_position', position,
                                      f'В карточке отображается должность "{position}"')
    user_profile.assert_profile_field('contact_profile_header_department', department,
                                      f'В карточке отображается отдел "{department}"')
    user_profile.assert_profile_field('address_book_contact_primary_email_title', target_email,
                                      f'В карточке отображается Email основной "{target_email}"')


@allure.id("46562")
@allure.title("Открытие карточки контакта и проверка действий")
@allure.label("owner", "Simon")
@allure.tag("RFA")
@allure.story("создание\\удаление\\редактирование личного контакта")
@allure.feature("Адресная книга")
@allure.label("IVAQA", "IVAONE-11273")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_open_contact_card_actions(setup_aut, users_factory, teardown):
    """Клик по строке контакта: карточка (ФИО, должность, отдел, email), выделение
    строки цветом bg-highlighting, кнопки действий Позвонить/Видео/Ещё и пункт
    «Написать» в меню «Ещё», переходы по орг-структуре: подчинённый → руководитель
    → подчинённый."""
    lang, version, driver = web_preamble(setup_aut, teardown)
    config = setup_aut['setup']['config']
    user_data = users_factory[0]

    # Setup: пара руководитель→подчинённый — атрибут manager даёт managerId/team,
    # без которых кнопка орг-структуры не рендерится; пароли целевым юзерам не нужны.
    admin_token = iva_one.login(**config['credentials']['admin'])
    realm = config['web-realm']
    # get_random_string-вставка — та же защита от коллизий faker.email() между
    # xdist-воркерами, что и в users_factory (conftest).
    boss_email = f'02_web_{get_random_string(6)}_{generate_email(full_name=False)}'
    sub_email = f'03_web_{get_random_string(6)}_{generate_email(full_name=False)}'
    boss_cyr = generate_cyryllic_name()
    sub_cyr = generate_cyryllic_name()
    boss_data = {'username': boss_email, 'first_name': boss_cyr['first_name'], 'last_name': boss_cyr['last_name']}
    sub_data = {'username': sub_email, 'first_name': sub_cyr['first_name'], 'last_name': sub_cyr['last_name']}
    department = 'Отдел тестирования'
    boss_position = 'Директор по тестированию'
    sub_position = 'Ведущий инженер'
    boss = iva_one.create_user(admin_token, realm, boss_email, boss_email,
                               boss_data['first_name'], boss_data['last_name'],
                               attributes={'position': [boss_position], 'department': [department]})
    teardown.append(lambda: iva_one.delete_user(realm=realm, username=boss_email))
    iva_one.create_user(admin_token, realm, sub_email, sub_email,
                        sub_data['first_name'], sub_data['last_name'],
                        attributes={'position': [sub_position], 'department': [department],
                                    'manager': [boss['id']]})
    teardown.append(lambda: iva_one.delete_user(realm=realm, username=sub_email))
    boss_full_name = f'{boss_data["last_name"]} {boss_data["first_name"]}'
    sub_full_name = f'{sub_data["last_name"]} {sub_data["first_name"]}'

    log.tc('46562')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_address_book()
    address_book = chunks.get_chunk(version, 'address_book')(driver, lang=lang, check_primary_element=False)

    address_book.search_user(sub_data)
    user_profile = address_book.click_user_row_name(sub_data)
    address_book.assert_row_selected(sub_data)
    user_profile.assert_profile_sidebar_with_name_opened(sub_data)
    user_profile.assert_profile_field('contact_profile_header_position', sub_position,
                                      f'В карточке отображается должность "{sub_position}"')
    user_profile.assert_profile_field('contact_profile_header_department', department,
                                      f'В карточке отображается отдел "{department}"')
    user_profile.assert_profile_field('address_book_contact_primary_email_title', sub_email,
                                      f'В карточке отображается Email основной "{sub_email}"')

    # Прямые кнопки карточки — Позвонить/Видео/Ещё; «Написать» перенесена продуктом
    # из карточки в меню «Ещё» (2026-07-02) — проверяется как пункт этого меню.
    user_profile.assert_action_button('contact_profile_button_audio_call', 'Кнопка "Позвонить" отображается в карточке')
    user_profile.assert_action_button('contact_profile_button_video_call', 'Кнопка "Видео" отображается в карточке')
    user_profile.assert_action_button('contact_profile_button_more', 'Кнопка "Ещё" отображается в карточке')
    user_profile.assert_write_in_more_menu()

    org_structure = user_profile.open_org_structure()
    org_structure.assert_manager_block(boss_full_name)
    user_profile = org_structure.open_manager_card(boss_full_name)
    user_profile.assert_profile_sidebar_with_name_opened(boss_data)

    org_structure = user_profile.open_org_structure()
    org_structure.assert_subordinate_block(sub_full_name)
    user_profile = org_structure.open_subordinate_card(sub_full_name)
    user_profile.assert_profile_sidebar_with_name_opened(sub_data)


@allure.id("46561")
@allure.title("Проверка загрузки списка контактов и навигации по группам")
@allure.label("owner", "Simon")
@allure.tag("RFA")
@allure.story("создание\\удаление\\редактирование личного контакта")
@allure.feature("Адресная книга")
@allure.label("IVAQA", "IVAONE-11273")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
# Ассерты на абсолютное состояние общего корп-справочника («не более 50») — соседние
# xdist-воркеры сеют туда своих эфемерных юзеров. Сериализация не спасает (загрязняют
# ДРУГИЕ тесты) → выводится из параллельного прогона, гоняется последовательным хвостом.
@pytest.mark.parallel_unsafe
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_contacts_list_navigation(setup_aut, users_factory, teardown):
    """Загрузка списка адресной книги и навигация по группам: дефолтная группа
    «Все контакты» (не более 50 записей, сортировка по ФИО), выделение личной книги
    и буквенный разделитель «А», hover-подсветка контакта, открытие чата иконкой
    из строки (у личных контактов иконки чата нет — cans без chat, поэтому чат
    открывается с корпоративным контактом)."""
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]
    corp_data = users_factory[1]

    # Setup: личная книга с контактом на «А» — гарантия буквенного разделителя.
    token = iva_one_web_login(setup_aut, user_data)
    book_name = f'Книга {get_random_string(6)}'
    book = iva_one.create_contact_group(token, book_name, 'personal')
    contact_first_name = generate_cyryllic_name()['first_name']
    iva_one.create_contact(token, book['id'], contact_first_name, 'Аалтонен')
    personal_full_name = f'Аалтонен {contact_first_name}'

    log.tc('46561')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_address_book()
    address_book = chunks.get_chunk(version, 'address_book')(driver, lang=lang, check_primary_element=False)

    address_book.assert_all_contacts_selected()
    address_book.assert_contacts_count_max(50)
    address_book.assert_contacts_sorted_by_name()

    address_book.open_personal_book(book_name)
    address_book.assert_book_selected(book_name)
    address_book.assert_contact_in_book(personal_full_name)
    address_book.assert_alphabet_divider('А')

    address_book.open_all_contacts()
    address_book.search_user(corp_data)
    address_book.assert_row_highlight_on_hover(corp_data)

    chat = address_book.open_chat_from_row(corp_data)
    chat.assert_chat_with_chat_name_opened(f'{corp_data["last_name"]} {corp_data["first_name"]}')


@allure.id("46821")
@allure.title("Скрол пользователей")
@allure.label("owner", "Simon")
@allure.tag("RFA")
@allure.story("Папки Адресной книги")
@allure.feature("Адресная книга")
@allure.label("IVAQA", "IVAONE-11348")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
# Ассерты на абсолютный размер общего корп-справочника (>100 после догрузки, потолок
# скролла ~500 строк) — чужие эфемерные юзеры параллельных воркеров ломают счётчики.
@pytest.mark.parallel_unsafe
def test_corporate_contacts_scroll_pagination(setup_aut, users_factory, teardown):
    """Скролл-догрузка корпоративной директории: первая страница пагинации ровно
    100 строк (page-size) с активным лоудером под списком, скролл вниз догружает
    следующую страницу (строк больше 100), после загрузки всех контактов триггер
    догрузки скрывается."""
    lang, version, driver = web_preamble(setup_aut, teardown)
    config = setup_aut['setup']['config']
    user_data = users_factory[0]

    # Setup: +100 юзеров без паролей — гарантия полной первой страницы (page-size 100)
    # и наличия второй страницы для догрузки.
    realm = config['web-realm']
    run_id = get_random_string(6)
    batch_last_name = generate_cyryllic_name()['last_name']
    seed_users = [{
        'username': f'scroll46821_{run_id}_{i:03d}@example.com',
        'email': f'scroll46821_{run_id}_{i:03d}@example.com',
        'first_name': generate_cyryllic_name()['first_name'],
        'last_name': batch_last_name,
    } for i in range(100)]

    # Cleanup — по префиксу run_id и ДО сида: прогон, упавший посреди сида, иначе
    # оставляет уже созданных юзеров на стенде (их id теряются вместе с исключением).
    def _delete_seeded():
        token = iva_one.login(**config['credentials']['admin'])
        seeded = iva_one.list_users(token, realm, search=f'scroll46821_{run_id}', limit=100)
        seeded_ids = [user['id'] for user in seeded]
        for start in range(0, len(seeded_ids), 40):
            iva_one.bulk_delete_users(realm, seeded_ids[start:start + 40])
    teardown.append(_delete_seeded)

    # Admin-токен Keycloak живёт 60s, а 100 POST'ов создания занимают дольше (~0.7s/шт
    # на стенде) — сеем порциями по 40 со свежим токеном на порцию, иначе 401 посреди сида.
    for start in range(0, len(seed_users), 40):
        admin_token = iva_one.login(**config['credentials']['admin'])
        iva_one.bulk_create_users(admin_token, realm, seed_users[start:start + 40])

    log.tc('46821')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_address_book()
    address_book = chunks.get_chunk(version, 'address_book')(driver, lang=lang, check_primary_element=False)

    corp_group = 'Корпоративные'
    address_book.open_book_node(corp_group)
    address_book.assert_book_selected(corp_group)
    # Справочник индексирует свежесозданных (bulk) юзеров асинхронно — до минуты;
    # листинг в это время отвечает медленно (в т.ч. <contacts-table> нет в DOM до XHR).
    address_book.assert_contacts_count(100, timeout=60)
    address_book.assert_load_trigger_active()

    address_book.scroll_contacts_until_count_above(100)

    address_book.scroll_contacts_until_all_loaded()
    address_book.assert_load_trigger_hidden()


@allure.id("46581")
@allure.title("Сохранение мультиселекта, при переходе между вкладками")
@allure.label("owner", "Simon")
@allure.tag("RFA")
@allure.story("Мультиселект и действия с контактами")
@allure.feature("Адресная книга")
@allure.label("IVAQA", "IVAONE-10860")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [4], indirect=True)
def test_multiselect_persists_across_tabs(setup_aut, users_factory, teardown):
    """Персистентность мультиселекта между разделами: отметить чекбоксами 3 корпоративных
    контакта в «Все контакты» (счётчик «Выбрано: 3», чипы) → уйти на вкладку «Чаты» →
    вернуться в адресную книгу → выбор сохранён (счётчик, чипы, отмеченные чекбоксы).

    Корпоративные контакты = доп. тест-юзеры (users_factory[1..3]), видны в «Все контакты»
    главного. Возврат leftbar-ссылкой ведёт на «Все контакты» (не в исходную книгу) — там
    выбранные корп-контакты остаются видимыми и отмеченными."""
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]
    contacts = [f"{u['last_name']} {u['first_name']}" for u in users_factory[1:4]]

    log.tc('46581')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_address_book()
    address_book = chunks.get_chunk(version, 'address_book')(driver, lang=lang, check_primary_element=False)
    address_book.open_all_contacts()

    # Отметить чекбоксами 3 корпоративных → режим мультиселекта, «Выбрано: 3».
    for contact in contacts:
        address_book.select_contact(contact)
    address_book.assert_selected_count(3)
    for contact in contacts:
        address_book.assert_contact_chip(contact)

    # Перейти на вкладку «Чаты» и вернуться в адресную книгу.
    left_menu.open_chats()
    left_menu.assert_section_active('chat', 'Открыт раздел "Чаты"')
    left_menu.open_address_book()
    # iva-билд: раздел адресной книги живёт на /contacts (href-фрагмент 'contacts', не 'address-book').
    left_menu.assert_section_active('contacts', 'Снова открыт раздел "Адресная книга"')

    # Выбор сохранён: счётчик, чипы и отмеченные чекбоксы — те же 3 контакта.
    address_book.assert_selected_count(3)
    for contact in contacts:
        address_book.assert_contact_chip(contact)
    for contact in contacts:
        address_book.assert_contact_checkbox_selected(contact)


@allure.id("411")
@allure.title("Мультиселект. Отмена выбора")
@allure.label("owner", "Simon")
@allure.tag("RFA", "web")
@allure.story("Мультиселект и действия с контактами")
@allure.feature("Адресная книга")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [4], indirect=True)
def test_multiselect_reset_selection(setup_aut, users_factory, teardown):
    """Сброс мультиселекта: отметить чекбоксами 3 корпоративных контакта («Выбрано: 3»)
    → «Сбросить» → плашка мультиселекта закрывается, чекбоксы сняты (начальное состояние).

    На RC кнопка сброса называется «Сбросить» (старый TestOps-сценарий — «Отмена»).
    Корп-контакты = доп. тест-юзеры (users_factory[1..3])."""
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]
    contacts = [f"{u['last_name']} {u['first_name']}" for u in users_factory[1:4]]

    log.tc('411')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_address_book()
    address_book = chunks.get_chunk(version, 'address_book')(driver, lang=lang, check_primary_element=False)
    address_book.open_all_contacts()

    # Отметить чекбоксами 3 корпоративных → «Выбрано: 3».
    for contact in contacts:
        address_book.select_contact(contact)
    address_book.assert_selected_count(3)

    # «Сбросить» → плашка закрывается, выбор снят (начальное состояние).
    address_book.reset_multiselect()
    address_book.assert_multiselect_inactive('Плашка мультиселекта закрылась — выбор сброшен')
    for contact in contacts:
        address_book.assert_contact_checkbox_not_selected(contact)


@allure.id("412")
@allure.title("Мультиселект. Убрать пользователя из выбора")
@allure.label("owner", "Simon")
@allure.tag("RFA", "web")
@allure.story("Мультиселект и действия с контактами")
@allure.feature("Адресная книга")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [4], indirect=True)
def test_multiselect_remove_one_from_selection(setup_aut, users_factory, teardown):
    """Удаление одного контакта из выборки крестиком чипа: отметить чекбоксами 3 корпоративных
    («Выбрано: 3») → навести на чип одного (крестик появляется по hover) → клик «Х» →
    «Выбрано: 2», чип удалён, чекбокс этого контакта снят, остальные 2 ещё выбраны (плашка остаётся).

    Корп-контакты = доп. тест-юзеры (users_factory[1..3])."""
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]
    contacts = [f"{u['last_name']} {u['first_name']}" for u in users_factory[1:4]]
    removed, remaining = contacts[0], contacts[1:]

    log.tc('412')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_address_book()
    address_book = chunks.get_chunk(version, 'address_book')(driver, lang=lang, check_primary_element=False)
    address_book.open_all_contacts()

    # Отметить чекбоксами 3 корпоративных → «Выбрано: 3».
    for contact in contacts:
        address_book.select_contact(contact)
    address_book.assert_selected_count(3)

    # Убрать одного крестиком его чипа → «Выбрано: 2», чип и отметка ушли, остальные 2 на месте.
    address_book.remove_chip(removed)
    address_book.assert_selected_count(2)
    address_book.assert_contact_chip_absent(removed)
    address_book.assert_contact_checkbox_not_selected(removed)
    for contact in remaining:
        address_book.assert_contact_chip(contact)


@allure.id("405")
@allure.title("Мультиселект. Создать групповой чат")
@allure.label("owner", "Simon")
@allure.tag("RFA", "web")
@allure.story("Мультиселект и действия с контактами")
@allure.feature("Адресная книга")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [4], indirect=True)
def test_multiselect_create_group_chat(setup_aut, users_factory, teardown):
    """Создание группового чата из мультиселекта: отметить 3 корпоративных → «Написать» →
    окно создания группового чата с 3 предзаполненными участниками → ввести название →
    «Создать группу» → тост об успешном создании с кнопкой «Перейти» → клик «Перейти» →
    открывается созданный чат с этим названием."""
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]
    contacts = [f"{u['last_name']} {u['first_name']}" for u in users_factory[1:4]]
    chat_name = get_random_string(10)

    log.tc('405')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_address_book()
    address_book = chunks.get_chunk(version, 'address_book')(driver, lang=lang, check_primary_element=False)
    address_book.open_all_contacts()

    # Отметить чекбоксами 3 корпоративных → «Выбрано: 3».
    for contact in contacts:
        address_book.select_contact(contact)
    address_book.assert_selected_count(3)

    # «Написать» → окно создания группового чата с предзаполненными 3 участниками.
    address_book.click_bulk_write()
    create_popup = chunks.get_chunk(version, 'create_chat_popup')(driver, lang=lang)
    create_popup.assert_step2_group_opened()
    for contact in contacts:
        create_popup.assert_member_in_list(contact)

    # Ввести название → «Создать группу».
    create_popup.type_chat_name(chat_name)
    create_popup.click_create_group()

    # Тост об успешном создании с кнопкой «Перейти» → клик «Перейти» → открывается созданный чат.
    toast = chunks.get_chunk(version, 'toast')(driver=driver, lang=lang)
    toast.assert_i18n_contains('group_chat_created_toast')
    toast.assert_go_to_button_visible()
    toast.click_go_to()
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chat.assert_chat_with_chat_name_opened(chat_name)


@allure.id("410")
@allure.title("Мультиселект. Создать звонок")
@allure.label("owner", "Simon")
@allure.tag("RFA", "web")
@allure.story("Мультиселект и действия с контактами")
@allure.feature("Адресная книга")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [4], indirect=True)
def test_multiselect_create_group_call(setup_aut, users_factory, teardown):
    """Групповой звонок из мультиселекта: отметить 3 корпоративных → «Позвонить» в плашке →
    начинается групповой исходящий вызов (окно звонка «Ожидание ответа» внизу слева) →
    сброс закрывает окно."""
    lang, version, driver = web_preamble(setup_aut, teardown)
    web_url = setup_aut['setup']['config']['web_url']
    user_data = users_factory[0]
    contacts = [f"{u['last_name']} {u['first_name']}" for u in users_factory[1:4]]

    log.tc('410')

    # grant_notifications ДО login — окно звонка у звонящего рендерится надёжно только при granted.
    grant_notifications(driver, web_url)
    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_address_book()
    address_book = chunks.get_chunk(version, 'address_book')(driver, lang=lang, check_primary_element=False)
    address_book.open_all_contacts()

    # Отметить чекбоксами 3 корпоративных → «Выбрано: 3».
    for contact in contacts:
        address_book.select_contact(contact)
    address_book.assert_selected_count(3)

    # «Позвонить» → групповой исходящий звонок: окно звонка открывается внизу слева.
    address_book.click_bulk_call()
    call = chunks.get_chunk(version, 'call')(driver, lang=lang)
    call.assert_outgoing_call_started()

    # Завершить звонок → окно закрывается.
    call.end_call()
    call.assert_call_window_closed()


@allure.id("406")
@allure.title("Мультиселект. Создать ВКС-встречу")
@allure.label("owner", "Simon")
@allure.tag("RFA", "web")
@allure.story("Мультиселект и действия с контактами")
@allure.feature("Адресная книга")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [4], indirect=True)
def test_multiselect_create_mcu_conference(setup_aut, users_factory, teardown):
    """Создание ВКС-встречи из мультиселекта: отметить 3 корпоративных → «ВКС-встреча» в
    плашке → форма создания → ввести тему → «Создать встречу» → карточка созданной встречи
    (заголовок = тема), организатор + 3 выбранных в участниках («Участники 4»)."""
    lang, version, driver = web_preamble(setup_aut, teardown)
    config = setup_aut['setup']['config']
    user_data = users_factory[0]
    contacts = [f"{u['last_name']} {u['first_name']}" for u in users_factory[1:4]]

    # MCU отвергает встречу с непровизионированным участником (POST /conferences → 400
    # Profile not found, форма молча остаётся открытой); эфемерные users_factory-юзеры сами
    # не логинятся — провизионируем каждого выбираемого его же токеном. Организатору не нужно:
    # его профиль MCU создаёт при открытии формы.
    for participant in users_factory[1:4]:
        ensure_mcu_profile(iva_one_web_login(setup_aut, participant), config['web_url'])

    log.tc('406')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_address_book()
    address_book = chunks.get_chunk(version, 'address_book')(driver, lang=lang, check_primary_element=False)
    address_book.open_all_contacts()

    # Отметить чекбоксами 3 корпоративных → «Выбрано: 3».
    for contact in contacts:
        address_book.select_contact(contact)
    address_book.assert_selected_count(3)

    # «ВКС-встреча» (поз. 4 bulk-bar) → форма создания → тема → «Создать встречу».
    address_book.open_mcu_conference_form()
    mcu_conference = chunks.get_chunk(version, 'mcu_conference_sidebar')(driver, lang=lang)
    theme = f'ВКС-ТЕСТ {get_random_string(5)}'
    mcu_conference.fill_theme(theme)
    mcu_conference.create_conference()

    # Встреча создана: карточка ВКС-события (заголовок = тема); организатор + 3 → «Участники 4».
    mcu_conference.assert_conference_created(theme)
    mcu_conference.assert_participants_count(4)


@allure.id("409")
@allure.title("Мультиселект. Создать Событие")
@allure.label("owner", "Simon")
@allure.tag("RFA", "web")
@allure.story("Мультиселект и действия с контактами")
@allure.feature("Адресная книга")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.require_ldap_user
@pytest.mark.parametrize("users_factory", [3], indirect=True)
def test_multiselect_create_offline_event(setup_aut, users_factory, teardown):
    """Создание оффлайн-события из мультиселекта: отметить 3 корпоративных → «Событие» в
    плашке → форма создания календарного события с 3 предзаполненными участниками → ввести
    тему → «Создать событие» → событие создано → перейти в «Календарь» → событие в сетке дня."""
    lang, version, driver = web_preamble(setup_aut, teardown, register_quit=False)
    config = setup_aut['setup']['config']
    # Логинимся mail-юзером: форма события грузится из imail, у эфемерных юзеров зависает.
    mail_user = config['credentials']['mail_user']
    contacts = [f"{u['last_name']} {u['first_name']}" for u in users_factory]

    # Очистка: событие живёт в imail (REST API в IVA One нет) — удаляем jump-протоколом
    # (нужен живой driver, поэтому ДО quit; uid проставится после создания).
    event = chunks.get_chunk(version, 'offline_event')(driver, lang=lang)
    created_uid = []
    teardown.append((lambda _: created_uid and event.cancel_event_via_jump(created_uid[0]), None))
    teardown.append((lambda el: el.quit(), driver))

    log.tc('409')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(mail_user['username'], mail_user['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_address_book()
    address_book = chunks.get_chunk(version, 'address_book')(driver, lang=lang, check_primary_element=False)
    address_book.open_all_contacts()

    # Отметить чекбоксами 3 корпоративных → «Выбрано: 3».
    for contact in contacts:
        address_book.select_contact(contact)
    address_book.assert_selected_count(3)

    # Перехватить id imail-сессии (для удаления события в teardown) ДО загрузки формы.
    event.start_imail_session_capture()

    # «Ещё» → «Событие» → форма оффлайн-события; 3 выбранных предзаполнены в участники.
    address_book.open_event_form()
    event.assert_form_loaded()
    for contact in contacts:
        event.assert_create_participant_by_name(contact)

    # Заполнить тему → «Создать событие» → событие создано (открыта карточка).
    theme = f'Событие {get_random_string(5)}'
    event.fill_theme(theme)
    event.create_event()
    created_uid.append(event.get_event_uid())
    event.assert_event_created()

    # Перейти в «Календарь» → созданное событие отображается в сетке дня (по умолчанию сегодня).
    left_menu.open_calendar()
    calendar = chunks.get_chunk(version, 'calendar')(driver, lang=lang)
    calendar.assert_event_in_grid(theme)


@allure.id("52040")
@allure.title("Мультиселект контактов и обработка частично доступных действий")
@allure.tag("agent", "Contacts", "RFA", "UX", "WEB")
@allure.story("создание\\удаление\\редактирование личного контакта")
@allure.feature("Адресная книга")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_multiselect_call_partial_availability(setup_aut, users_factory, teardown):
    """Мультиселект контактов с разной доступностью звонка: выбрать 3 (2 с call, 1 без) →
    «Позвонить» → экран-разделитель «Начать звонок» (недоступные сверху, доступные снизу) →
    «Позвонить доступным» → звонок для доступных, мультиселект закрывается, разделитель исчезает."""
    lang, version, driver = web_preamble(setup_aut, teardown)
    config = setup_aut['setup']['config']
    web_url = config['web_url']
    user_data = users_factory[0]

    # Setup книги с 3 личными контактами под главным юзером (REST): 2 с телефоном (звонок
    # доступен) + 1 без телефона/email (звонок недоступен — нет commutation target).
    token = iva_one_web_login(setup_aut, user_data)
    book_name = f'Книга {get_random_string(6)}'
    book = iva_one.create_contact_group(token, book_name, 'personal')
    callable_1 = generate_cyryllic_name()
    callable_2 = generate_cyryllic_name()
    no_call = generate_cyryllic_name()
    iva_one.create_contact(token, book['id'], callable_1['first_name'], callable_1['last_name'],
                           phones=[{'phone': '79990001111', 'isPrimary': True}])
    iva_one.create_contact(token, book['id'], callable_2['first_name'], callable_2['last_name'],
                           phones=[{'phone': '79990002222', 'isPrimary': True}])
    iva_one.create_contact(token, book['id'], no_call['first_name'], no_call['last_name'])
    callable_1_name = f"{callable_1['last_name']} {callable_1['first_name']}"
    callable_2_name = f"{callable_2['last_name']} {callable_2['first_name']}"
    no_call_name = f"{no_call['last_name']} {no_call['first_name']}"

    # Книгу/контакты отдельно не чистим — они привязаны к эфемерному юзеру и удаляются вместе
    # с ним в teardown users_factory.

    log.tc('52040')

    # grant_notifications ДО login — окно исходящего звонка рендерится надёжно при granted.
    grant_notifications(driver, web_url)
    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_address_book()
    address_book = chunks.get_chunk(version, 'address_book')(driver, lang=lang, check_primary_element=False)
    address_book.open_personal_book(book_name)

    # Выбрать 3 контакта → «Выбрано: 3».
    for name in (callable_1_name, callable_2_name, no_call_name):
        address_book.select_contact(name)
    address_book.assert_selected_count(3)

    # «Позвонить» (call есть не у всех) → экран-разделитель «Начать звонок»: недоступный сверху,
    # доступные снизу.
    address_book.click_bulk_call()
    address_book.assert_call_divider_dialog()
    address_book.assert_call_divider_unavailable_info()
    address_book.assert_contact_unavailable_in_call_divider(no_call_name)
    address_book.assert_contact_available_in_call_divider(callable_1_name)
    address_book.assert_contact_available_in_call_divider(callable_2_name)

    # «Позвонить доступным» → звонок стартует (для доступных), разделитель исчезает.
    address_book.confirm_call_available()
    call = chunks.get_chunk(version, 'call')(driver, lang=lang)
    call.assert_outgoing_call_started()
    address_book.assert_call_divider_closed()
    # Мультиселект закрывается. Баг незакрытия исправлен на at-test-1; на RC-стенд фикс ещё не
    # приехал → ассерт временно красный, позеленеет вместе с фиксом. Звонок гасится driver.quit
    # в teardown (надёжно, даже если ассерт ниже упадёт).
    address_book.assert_multiselect_closed()


@allure.id("38116")
@allure.title("Редактировать папку")
@allure.label("owner", "Simon")
@allure.tag("RFA")
@allure.story("Папки Адресной книги")
@allure.feature("Адресная книга")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_edit_personal_book(setup_aut, users_factory, teardown):
    """ПКМ по личной книге → «Редактировать книгу» → ввод нового имени + выбор иконки «Корона»
    → «Сохранить». Меню содержит пункты «Редактировать книгу» и «Удалить»; после сохранения
    книга в дереве переименована и сменила иконку на корону."""
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]

    # Setup: личная книга через REST (под ephemeral-юзером — уходит с ним, отдельный teardown
    # книги не нужен). Стартовая иконка personal; в тесте переименуем и сменим на корону.
    token = iva_one_web_login(setup_aut, user_data)
    init_name = f'Книга {get_random_string(6)}'
    iva_one.create_contact_group(token, init_name, 'personal')
    new_name = f'Личная книга {get_random_string(6)}'

    log.tc('38116')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_address_book()
    address_book = chunks.get_chunk(version, 'address_book')(driver, lang=lang, check_primary_element=False)
    address_book.open_personal_book(init_name)

    address_book.open_book_context_menu(init_name)
    address_book.assert_book_context_menu_items()
    address_book.open_edit_book_dialog()
    address_book.assert_edit_book_dialog_open()
    address_book.set_book_name(new_name)
    address_book.select_book_icon_crown()
    address_book.assert_book_icon_crown_selected()
    address_book.save_book_edit()

    # Видимый эффект (реальная проверка): книга переименована и сменила иконку на корону.
    # Тост-уведомление (шаг 5 TC) убран продуктом 2026-07-02 (success-тостов на операциях
    # с книгами нет, IVAONE-12312) — сигнал успеха именно эти эффект-ассерты.
    address_book.assert_book_renamed(new_name)
    address_book.assert_book_icon(new_name, enums.AddressBookGroupIcon.CROWN)


@allure.id("38119")
@allure.title("Редактировать папку. Название свыше 256 символов")
@allure.label("owner", "Simon")
@allure.tag("RFA")
@allure.story("Папки Адресной книги")
@allure.feature("Адресная книга")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_edit_personal_book_name_over_limit(setup_aut, users_factory, teardown):
    """ПКМ по личной книге → «Редактировать книгу» → ввод названия длиннее лимита поля →
    поле не даёт превысить лимит (символы сверх лимита не вводятся); выбор иконки «Корона»
    → «Сохранить»."""
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]

    # Setup: личная книга через REST (под ephemeral-юзером — уходит с ним).
    token = iva_one_web_login(setup_aut, user_data)
    init_name = f'Книга {get_random_string(6)}'
    iva_one.create_contact_group(token, init_name, 'personal')
    long_name = 'Я' * 300  # длиннее maxlength=255 поля имени → должно обрезаться

    log.tc('38119')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_address_book()
    address_book = chunks.get_chunk(version, 'address_book')(driver, lang=lang, check_primary_element=False)
    address_book.open_personal_book(init_name)

    address_book.open_book_context_menu(init_name)
    address_book.assert_book_context_menu_items()
    address_book.open_edit_book_dialog()
    address_book.assert_edit_book_dialog_open()
    address_book.set_book_name(long_name)
    address_book.assert_book_name_truncated()
    address_book.select_book_icon_crown()
    address_book.save_book_edit()
    address_book.assert_book_edit_dialog_closed()


@allure.id("38117")
@allure.title("Удалить папку")
@allure.label("owner", "Simon")
@allure.tag("RFA")
@allure.story("Папки Адресной книги")
@allure.feature("Адресная книга")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_delete_personal_book(setup_aut, users_factory, teardown):
    """ПКМ по личной книге → «Удалить» → окно подтверждения «Удалить адресную книгу?» →
    «Удалить». После удаления книга исчезает из дерева, происходит переход в «Личные»."""
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]

    # Setup: личная книга через REST (под ephemeral-юзером — уходит с ним).
    token = iva_one_web_login(setup_aut, user_data)
    book_name = f'Книга {get_random_string(6)}'
    iva_one.create_contact_group(token, book_name, 'personal')

    log.tc('38117')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_address_book()
    address_book = chunks.get_chunk(version, 'address_book')(driver, lang=lang, check_primary_element=False)
    address_book.open_personal_book(book_name)

    address_book.open_book_context_menu(book_name)
    address_book.assert_book_context_menu_items()
    address_book.open_delete_book_dialog()
    address_book.assert_delete_book_dialog()
    address_book.confirm_delete_book()

    # Видимый эффект (реальная проверка): книга исчезла из дерева, переход в «Личные».
    # Тост-уведомление (шаг 3 TC) убран продуктом 2026-07-02 (success-тостов на операциях
    # с книгами нет, IVAONE-12312) — сигнал успеха именно эти эффект-ассерты.
    address_book.assert_book_absent(book_name)
    address_book.assert_personal_root_selected()


@allure.id("38120")
@allure.title("Удалить папку. Отмена")
@allure.label("owner", "Simon")
@allure.tag("RFA")
@allure.story("Папки Адресной книги")
@allure.feature("Адресная книга")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_delete_personal_book_cancel(setup_aut, users_factory, teardown):
    """ПКМ по личной книге → «Удалить» → окно подтверждения «Удалить адресную книгу?» →
    «Отмена». Книга не удаляется: окно подтверждения закрывается, книга остаётся в дереве."""
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]

    # Setup: личная книга через REST (под ephemeral-юзером — уходит с ним).
    token = iva_one_web_login(setup_aut, user_data)
    book_name = f'Книга {get_random_string(6)}'
    iva_one.create_contact_group(token, book_name, 'personal')

    log.tc('38120')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_address_book()
    address_book = chunks.get_chunk(version, 'address_book')(driver, lang=lang, check_primary_element=False)
    address_book.open_personal_book(book_name)

    address_book.open_book_context_menu(book_name)
    address_book.assert_book_context_menu_items()
    address_book.open_delete_book_dialog()
    address_book.assert_delete_book_dialog()
    address_book.cancel_delete_book()

    # Эффект: окно закрылось, книга не удалена (осталась в дереве).
    address_book.assert_delete_book_dialog_closed()
    address_book.assert_book_present(book_name)


@allure.id("52042")
@allure.title("Удаление личной книги контактов с каскадным удалением вложенных контактов")
@allure.tag("agent", "Cascade", "CRUD", "RFA", "WEB")
@allure.story(r"создание\удаление\редактирование личного контакта")
@allure.feature("Адресная книга")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_delete_personal_book_cascade(setup_aut, users_factory, teardown):
    """Внутри открытой личной книги с 2 контактами: ПКМ по книге → «Удалить» →
    подтверждение каскадного удаления → «Удалить». Книга и оба контакта удаляются
    (каскад), происходит переход в «Личные»."""
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]

    # Setup: личная книга с 2 контактами через REST (под ephemeral-юзером — уходит с ним).
    token = iva_one_web_login(setup_aut, user_data)
    book_name = f'Книга {get_random_string(6)}'
    book = iva_one.create_contact_group(token, book_name, 'personal')
    c1 = generate_cyryllic_name()
    c2 = generate_cyryllic_name()
    iva_one.create_contact(token, book['id'], c1['first_name'], c1['last_name'])
    iva_one.create_contact(token, book['id'], c2['first_name'], c2['last_name'])
    c1_full = f"{c1['last_name']} {c1['first_name']}"
    c2_full = f"{c2['last_name']} {c2['first_name']}"

    log.tc('52042')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_address_book()
    address_book = chunks.get_chunk(version, 'address_book')(driver, lang=lang, check_primary_element=False)
    address_book.open_personal_book(book_name)
    # STATE: внутри открытой книги, оба контакта на месте.
    address_book.assert_contact_in_book(c1_full)
    address_book.assert_contact_in_book(c2_full)

    address_book.open_book_context_menu(book_name)
    address_book.open_delete_book_dialog()
    address_book.assert_delete_book_dialog()
    address_book.assert_delete_book_cascade_warning(book_name)
    address_book.confirm_delete_book()

    # Эффект: книга исчезла из дерева, переход в «Личные». TC ждёт «Все контакты», фактически —
    # «Личные» (выбор родителя удалённой книги); ассертим реальное поведение.
    address_book.assert_book_absent(book_name)
    address_book.assert_personal_root_selected()

    # Каскад (TC шаг 3): DELETE группы удалил книгу и её контакты на бэке.
    address_book.assert_book_cascade_deleted(token, book['id'])


@allure.id("38115")
@allure.title("Создать папку")
@allure.label("owner", "Simon")
@allure.tag("RFA")
@allure.story("Папки Адресной книги")
@allure.feature("Адресная книга")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_create_personal_book(setup_aut, users_factory, teardown):
    """«Новая книга» → диалог «Создать книгу» → ввод имени + выбор иконки «Корона» →
    «Создать». После создания — переход в новую книгу (узел выделен в дереве), у книги
    иконка-корона, книга пустая."""
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]

    # У эфемерного юзера 0 личных книг — кнопка «Новая книга» доступна (лимит 10 не достигнут),
    # REST-сетап не нужен.
    book_name = f'Книга {get_random_string(6)}'

    log.tc('38115')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_address_book()
    address_book = chunks.get_chunk(version, 'address_book')(driver, lang=lang, check_primary_element=False)

    address_book.open_create_book_dialog()
    address_book.assert_create_book_dialog_open()
    address_book.set_book_name(book_name)
    address_book.select_book_icon_crown()
    address_book.assert_book_icon_crown_selected()
    address_book.confirm_create_book()

    # Видимый эффект (реальная проверка): переход в созданную книгу — узел выделен в дереве,
    # иконка короны, книга пустая. Тост-уведомление (шаг 4 TC) убран продуктом 2026-07-02
    # (подтверждено MutationObserver'ом при создании книги, IVAONE-12312) — сигнал успеха
    # именно эти эффект-ассерты (книга появилась в дереве).
    address_book.assert_book_selected(book_name)
    address_book.assert_book_icon(book_name, enums.AddressBookGroupIcon.CROWN)
    address_book.assert_personal_book_empty_stub()


@allure.id("38118")
@allure.title("Создать папку. Название свыше 256 символов")
@allure.label("owner", "Simon")
@allure.tag("RFA")
@allure.story("Папки Адресной книги")
@allure.feature("Адресная книга")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_create_personal_book_name_over_limit(setup_aut, users_factory, teardown):
    """«Новая книга» → ввод названия длиннее лимита поля → поле не даёт превысить лимит
    (символы сверх maxlength не вводятся); выбор иконки «Корона» → «Создать» → книга создана."""
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]

    long_name = 'Я' * 300  # длиннее maxlength=255 поля имени → должно обрезаться

    log.tc('38118')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_address_book()
    address_book = chunks.get_chunk(version, 'address_book')(driver, lang=lang, check_primary_element=False)

    address_book.open_create_book_dialog()
    address_book.assert_create_book_dialog_open()
    address_book.set_book_name(long_name)
    address_book.assert_book_name_truncated()
    address_book.select_book_icon_crown()
    address_book.confirm_create_book()
    address_book.assert_book_edit_dialog_closed()


@allure.id("46564")
@allure.title("Создание личной адресной книги и контакта")
@allure.label("owner", "Simon")
@allure.tag("RFA")
@allure.story("Папки Адресной книги")
@allure.feature("Адресная книга")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_create_personal_book_and_contact(setup_aut, users_factory, teardown):
    """Создание книги и контакта: «Новая книга» → диалог → имя/иконка → «Создать»; затем
    «Создать контакт» → форма с предвыбранной (только что созданной) книгой → Имя + основной
    телефон + основной email → «Создать контакт». Контакт появляется в списке книги."""
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]

    # Эфемерный юзер, 0 личных книг — REST-сетап не нужен.
    book_name = f'Книга {get_random_string(6)}'
    contact = generate_cyryllic_name()

    log.tc('46564')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_address_book()
    address_book = chunks.get_chunk(version, 'address_book')(driver, lang=lang, check_primary_element=False)

    # Шаг 1-2: создать книгу (реюз инфры волны 1) — попадаем в новую пустую книгу.
    address_book.open_create_book_dialog()
    address_book.assert_create_book_dialog_open()
    address_book.set_book_name(book_name)
    address_book.select_book_icon_crown()
    address_book.confirm_create_book()
    address_book.assert_book_selected(book_name)

    # Шаг 3: открыть форму создания контакта — созданная книга предвыбрана в селекте.
    contact_form = address_book.open_create_contact_form()
    contact_form.assert_book_preselected(book_name)

    # Шаг 4: заполнить Имя + основной телефон + основной email → «Создать контакт».
    contact_form.set_first_name(contact['first_name'])
    contact_form.set_primary_phone('79990001122')
    contact_form.set_primary_email(f'{get_random_string(8)}@example.com')
    contact_form.submit_create()

    # Контакт создан: форма закрылась, контакт отображается в списке книги.
    contact_form.assert_form_closed()
    address_book.assert_contact_in_book(contact['first_name'])


@allure.id("52041")
@allure.title("Создание личного контакта с валидацией основных и дополнительных данных")
@allure.label("owner", "Simon")
@allure.tag("agent", "CRUD", "RFA", "Validation", "WEB")
@allure.story("создание\\удаление\\редактирование личного контакта")
@allure.feature("Адресная книга")
@allure.label("IVAQA", "IVAONE-11790")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_create_personal_contact_validation(setup_aut, users_factory, teardown):
    """Валидация формы контакта «доп. данные требуют основное» + валидный путь создания:
    Имя + только доп. телефон (основной пуст) → inline-ошибка «Сначала укажите основной
    телефон» + кнопка «Создать контакт» неактивна, контакт не создаётся; затем основной
    телефон + почта → «Создать контакт» → контакт появляется в списке книги.

    TC ждёт текст «Для сохранения доп. данных…» — в продукте его нет, фактический текст
    другой (ассертим фактический). POST /api/v1/contacts проверяется появлением контакта
    в списке (тело запроса через Selenium недоступно)."""
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]

    # Setup: личная книга (precondition «≥1 личная книга») — через REST, не предмет теста.
    token = iva_one_web_login(setup_aut, user_data)
    book_name = f'Книга {get_random_string(6)}'
    iva_one.create_contact_group(token, book_name, 'personal')
    contact = generate_cyryllic_name()

    log.tc('52041')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_address_book()
    address_book = chunks.get_chunk(version, 'address_book')(driver, lang=lang, check_primary_element=False)
    address_book.open_personal_book(book_name)

    # Открыть форму создания контакта — активная книга предвыбрана в селекте.
    contact_form = address_book.open_create_contact_form()
    contact_form.assert_book_preselected(book_name)

    # Шаг 1-2: Имя + только доп. телефон (основной пуст) → валидация блокирует сохранение.
    contact_form.set_first_name(contact['first_name'])
    contact_form.add_additional_phone('79990002233')
    contact_form.assert_primary_phone_required_error()
    contact_form.assert_submit_disabled()

    # Шаг 3: указать основной телефон (ошибка снимается) и почту → «Создать контакт».
    contact_form.set_primary_phone('79990001122')
    contact_form.set_primary_email(f'{get_random_string(8)}@example.com')
    contact_form.submit_create()

    # Контакт создан: форма закрылась, контакт отображается в списке книги.
    contact_form.assert_form_closed()
    address_book.assert_contact_in_book(contact['first_name'])


@allure.id("47001")
@allure.title("Превышение лимита дополнительных телефонов (негативный кейс)")
@allure.label("owner", "Simon")
@allure.tag("RFA")
@allure.story("создание\\удаление\\редактирование личного контакта")
@allure.feature("Адресная книга")
@allure.label("IVAQA", "IVAONE-10213")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_additional_phones_limit(setup_aut, users_factory, teardown):
    """После добавления 4 доп. телефонов кнопка «Добавить телефон» блокируется (5-й добавить
    нельзя); сохранение проходит — контакт создаётся со всеми 4 доп. телефонами."""
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]

    # Setup: личная книга (precondition формы) — через REST, не предмет теста.
    token = iva_one_web_login(setup_aut, user_data)
    book_name = f'Книга {get_random_string(6)}'
    iva_one.create_contact_group(token, book_name, 'personal')
    contact = generate_cyryllic_name()

    log.tc('47001')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_address_book()
    address_book = chunks.get_chunk(version, 'address_book')(driver, lang=lang, check_primary_element=False)
    address_book.open_personal_book(book_name)
    contact_form = address_book.open_create_contact_form()

    # Шаг 2: имя + основной телефон + основная почта.
    contact_form.set_first_name(contact['first_name'])
    contact_form.set_primary_phone('79990001100')
    contact_form.set_primary_email(f'{get_random_string(8)}@example.com')

    # Шаг 3: добавить 4 доп. телефона → кнопка «Добавить телефон» блокируется (5-й нельзя).
    # Лимит=4 ловится клиентским дизейблом кнопки (серверного 400 нет; precondition TC
    # «лимит=2» устарел — актуальные шаги TC ждут именно 4).
    for i in range(1, 5):
        contact_form.add_additional_phone(f'7999000110{i}')
    contact_form.assert_add_phone_disabled()

    # Шаг 4: сохранить → открывается карточка созданного контакта. Раскрываем доп. телефоны
    # и проверяем, что сохранились все 4.
    contact_form.submit_create()
    contact_card = chunks.get_chunk(version, 'contact_card')(driver, lang=lang)
    contact_card.expand_additional_phones()
    contact_card.assert_additional_phones_count(4)


@allure.id("46998")
@allure.title("Редактирование личного контакта (успешный сценарий)")
@allure.label("owner", "Simon")
@allure.tag("RFA")
@allure.story("создание\\удаление\\редактирование личного контакта")
@allure.feature("Адресная книга")
@allure.label("IVAQA", "IVAONE-10213")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_edit_personal_contact(setup_aut, users_factory, teardown):
    """Редактирование контакта из карточки: «Ещё» → «Редактировать» → форма (основной
    телефон предзаполнен) → изменить Имя + добавить доп. телефон → «Сохранить». Контакт в
    списке книги показывает новое имя; по REST имя обновлено, добавленный доп. телефон
    сохранён, и ровно один телефон и одна почта помечены основными (isPrimary)."""
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]

    # Setup: личная книга + контакт (Имя/Фамилия, основной телефон, основная почта) — через REST.
    token = iva_one_web_login(setup_aut, user_data)
    book_name = f'Книга {get_random_string(6)}'
    book = iva_one.create_contact_group(token, book_name, 'personal')
    contact = generate_cyryllic_name()
    primary_phone = '79990001122'
    iva_one.create_contact(token, book['id'], contact['first_name'], contact['last_name'],
                           phones=[{'phone': primary_phone, 'isPrimary': True}],
                           emails=[{'email': f'{get_random_string(8)}@example.com', 'isPrimary': True}])
    contact_full_name = f'{contact["last_name"]} {contact["first_name"]}'
    # Новое имя — отдельный сгенерированный first_name (отличный от исходного): по нему
    # ассертим обновление. Доп. телефон — второй номер, добавляется в форме.
    new_first_name = generate_cyryllic_name()['first_name']
    additional_phone = '79990002233'

    log.tc('46998')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_address_book()
    address_book = chunks.get_chunk(version, 'address_book')(driver, lang=lang, check_primary_element=False)
    address_book.open_personal_book(book_name)
    contact_card = address_book.open_contact_card(contact_full_name)

    # Шаг 1-2: открыть карточку → «Ещё» → «Редактировать». Форма edit открывается с
    # предзаполненным основным телефоном (Имя/Фамилия сервер не эхоит → поля пустые).
    contact_form = contact_card.open_edit_contact()
    contact_form.assert_primary_phone_prefilled(primary_phone)

    # Шаг 3: изменить Имя (ввод в пустое поле) + добавить доп. телефон.
    contact_form.set_first_name(new_first_name)
    contact_form.add_additional_phone(additional_phone)

    # Шаг 4 («установить флаг Основной, если заменяется основной») пропущен: основной телефон
    # не заменяем — добавленный остаётся дополнительным (isPrimary=false).

    # Шаг 5: «Сохранить» → форма закрывается, данные обновлены.
    contact_form.submit_save()
    contact_form.assert_form_closed()

    # На экране обновлённые данные: контакт в списке показывает новое имя (фамилия не стирается).
    address_book.assert_contact_in_book(new_first_name)

    # API-инвариант шага 5 (через REST /contacts/list): имя обновлено, всего 2 телефона
    # (основной + добавленный доп.), ровно один основной телефон и одна основная почта.
    contacts_helper.assert_contact_primary_invariant(token, book['id'], new_first_name, phone_count=2)
