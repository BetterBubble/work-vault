import allure
import pytest

from autocore import driver_sessions
from autocore.test.logger import get_log
from autocore.test.generate_data import get_random_string
from tools.helpers.session import web_preamble, iva_one_web_login, relogin_session, get_user_position
from tools.helpers.mcu import delete_conferences_by_name, ensure_mcu_profile
from tools.enums import CalendarMeetingType
from tests import pages
from tests.pages import chunks


log = get_log()


@allure.id("345")
@allure.title("Создание ВКС-Встречи")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Создание мероприятия ВКС")
@allure.feature("Календарь")
@allure.label("IVAQA", "IVAONE-12111")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.require_ldap_user
@pytest.mark.parametrize(
    "users_factory",
    [[{'position': ['Ведущий инженер'], 'department': ['Отдел тестирования']}]],
    indirect=True,
)
def test_create_vks_meeting(setup_aut, users_factory, teardown):
    """Календарь → «+» → «ВКС-встреча» → ввод названия → добавление участника с должностью
    и отделом через попап → полноэкранный режим (планировщик/слоты) → «Создать встречу».
    Проверяется: участник в форме с должностью, в fullscreen доступен блок слотов, встреча
    создана в сетке календаря и открыта карточка созданной ВКС-встречи."""
    lang, version, driver = web_preamble(setup_aut, teardown)
    config = setup_aut['setup']['config']
    # Организатор — провизионный mail-юзер: форма ВКС инициализирует секцию участников только
    # для заведённого в MCU пользователя (свежий эфемерный организатор оставляет её пустой).
    organizer = config['credentials']['mail_user']
    participant = users_factory[0]
    participant_full_name = f'{participant["last_name"]} {participant["first_name"]}'
    participant_position = participant['attributes']['position'][0]
    meeting_name = f'Встреча ВКС {get_random_string(5)}'

    # Cleanup: ВКС-конференция создаётся в MCU и в IVA ONE REST не удаляется — чистим по имени
    # (mail_user персистентный, ephemeral-автоочистки нет). Регистрируем до создания.
    token = iva_one_web_login(setup_aut, organizer)
    teardown.append((lambda name: delete_conferences_by_name(token, config['web_url'], name), meeting_name))

    # MCU отвергает встречу с непровизионированным участником (POST /conferences → 400
    # Profile not found, форма молча остаётся открытой); эфемерный users_factory-юзер сам
    # не логинится — провизионируем его профиль в MCU его же токеном до UI-флоу.
    ensure_mcu_profile(iva_one_web_login(setup_aut, participant), config['web_url'])

    log.tc('345')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(organizer['username'], organizer['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_calendar()
    calendar = chunks.get_chunk(version, 'calendar')(driver, lang=lang)

    # «+» → «ВКС-встреча» → ввод названия.
    calendar.click_create_btn()
    calendar.select_meeting_type(CalendarMeetingType.VKS)
    calendar.fill_name(meeting_name)

    # «Добавить» → попап участников → найти и выбрать участника с должностью/отделом.
    add_participants = calendar.open_add_required_participants()
    add_participants.search_and_select(participant['last_name'], participant_full_name)
    add_participants.confirm()
    calendar.assert_form_participant_with_position(participant_full_name, participant_position)

    # Полноэкранный режим — доступен блок планировщика «Свободные слоты».
    calendar.open_fullscreen()
    calendar.assert_fullscreen_slots_visible()

    # «Создать встречу» → встреча в сетке календаря и открыта карточка созданной ВКС.
    calendar.submit_create()
    calendar.assert_event_in_grid(meeting_name)
    mcu_conference = chunks.get_chunk(version, 'mcu_conference_sidebar')(driver, lang=lang)
    mcu_conference.assert_conference_created(meeting_name)
    mcu_conference.assert_guest_link_available()
    mcu_conference.assert_extra_links_available()


@allure.id("52476")
@allure.title("Создание мероприятие")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Создание мероприятия")
@allure.feature("Календарь")
@allure.label("IVAQA", "IVAONE-12111")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.require_ldap_user
@pytest.mark.parametrize(
    "users_factory",
    [[{'position': ['Ведущий инженер'], 'department': ['Отдел тестирования']}]],
    indirect=True,
)
def test_create_event(setup_aut, users_factory, teardown):
    """Календарь → «+» → «Событие» → ввод названия → добавление участника с должностью
    и отделом через попап → полноэкранный режим (планировщик/слоты) → «Создать событие».
    Проверяется: участник в форме с должностью, в fullscreen доступен блок слотов, событие
    создано в сетке календаря и открыта карточка созданного события."""
    # register_quit=False: оффлайн-событие удаляется через imail jump (живой driver) —
    # quit регистрируем последним, после cleanup.
    lang, version, driver = web_preamble(setup_aut, teardown, register_quit=False)
    config = setup_aut['setup']['config']
    # Организатор — провизионный mail-юзер: форма Событие грузится через imail/jump, у юзера
    # без почты зависает на спиннере.
    organizer = config['credentials']['mail_user']
    participant = users_factory[0]
    participant_full_name = f'{participant["last_name"]} {participant["first_name"]}'
    participant_position = participant['attributes']['position'][0]
    event_name = f'Событие {get_random_string(5)}'

    # Cleanup: оффлайн-событие в IVA ONE REST не удаляется — чистим через imail jump
    # (calObjCancel) живым driver'ом; uid проставится после создания (ленивое чтение списка).
    event = chunks.get_chunk(version, 'offline_event')(driver, lang=lang)
    created_uid = []
    teardown.append((lambda _: created_uid and event.cancel_event_via_jump(created_uid[0]), None))
    teardown.append((lambda el: el.quit(), driver))

    log.tc('52476')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(organizer['username'], organizer['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_calendar()
    calendar = chunks.get_chunk(version, 'calendar')(driver, lang=lang)

    # Перехватить id imail-сессии (для удаления события в teardown) ДО открытия формы.
    event.start_imail_session_capture()

    # «+» → «Событие» → дождаться загрузки формы (через imail, асинхронно) → ввод названия.
    calendar.click_create_btn()
    calendar.select_meeting_type(CalendarMeetingType.EVENT)
    event.assert_form_loaded()
    calendar.fill_name(event_name)

    # «Добавить» → попап участников → найти и выбрать участника с должностью/отделом.
    add_participants = calendar.open_add_required_participants()
    add_participants.search_and_select(participant['last_name'], participant_full_name)
    add_participants.confirm()
    calendar.assert_form_participant_with_position(participant_full_name, participant_position)

    # Полноэкранный режим — доступен блок планировщика «Свободные слоты».
    calendar.open_fullscreen()
    calendar.assert_fullscreen_slots_visible()

    # «Создать событие» → событие в сетке календаря и открыта карточка созданного события.
    calendar.submit_create()
    calendar.assert_event_in_grid(event_name)
    event.assert_event_created()
    created_uid.append(event.get_event_uid())


@allure.id("1419")
@allure.title("Редактирование ВКС встречи. Состав участников")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Создание мероприятия ВКС")
@allure.feature("Календарь")
@allure.label("IVAQA", "IVAONE-12111")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.require_ldap_user
@pytest.mark.parametrize(
    "users_factory",
    [[{'position': ['Ведущий инженер'], 'department': ['Отдел тестирования']}]],
    indirect=True,
)
def test_edit_vks_meeting_participants(setup_aut, users_factory, teardown):
    """Создание ВКС-встречи (организатор) → редактирование её состава: «Ещё» → «Изменить» →
    «Добавить» → выбор участника с должностью и отделом через попап → «Сохранить» →
    переоткрытие встречи из сетки. Проверяется: участник с должностью добавлен в форму
    редактирования и отображается в карточке встречи после сохранения."""
    lang, version, driver = web_preamble(setup_aut, teardown)
    config = setup_aut['setup']['config']
    # Организатор — провизионный mail-юзер: форма ВКС инициализирует секцию участников только
    # для заведённого в MCU пользователя (свежий эфемерный организатор оставляет её пустой).
    organizer = config['credentials']['mail_user']
    participant = users_factory[0]
    participant_full_name = f'{participant["last_name"]} {participant["first_name"]}'
    participant_position = participant['attributes']['position'][0]
    meeting_name = f'Встреча ВКС {get_random_string(5)}'

    # Cleanup: ВКС-конференция живёт в MCU и в IVA ONE REST не удаляется — чистим по имени
    # (mail_user персистентный). Регистрируем до создания.
    token = iva_one_web_login(setup_aut, organizer)
    teardown.append((lambda name: delete_conferences_by_name(token, config['web_url'], name), meeting_name))

    # Провизия участника в MCU: сабмит встречи с юзером без MCU-профиля получает 400
    # Profile not found при молчащей форме (как в 345) — эфемерал сам не логинится.
    ensure_mcu_profile(iva_one_web_login(setup_aut, participant), config['web_url'])

    log.tc('1419')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(organizer['username'], organizer['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_calendar()
    calendar = chunks.get_chunk(version, 'calendar')(driver, lang=lang)
    mcu_conference = chunks.get_chunk(version, 'mcu_conference_sidebar')(driver, lang=lang)

    # Setup: создать ВКС-встречу без участников (организатор — текущий юзер), reuse флоу TC-345.
    calendar.click_create_btn()
    calendar.select_meeting_type(CalendarMeetingType.VKS)
    calendar.fill_name(meeting_name)
    calendar.submit_create()
    calendar.assert_event_in_grid(meeting_name)
    mcu_conference.assert_conference_created(meeting_name)

    # «Ещё» → «Изменить» → форма редактирования → «Добавить» → участник с должностью/отделом.
    mcu_conference.click_edit_btn()
    add_participants = calendar.open_add_required_participants()
    add_participants.search_and_select(participant['last_name'], participant_full_name)
    add_participants.confirm()
    calendar.assert_form_participant_with_position(participant_full_name, participant_position)

    # «Сохранить» → переоткрыть встречу из сетки → участник с должностью в карточке.
    calendar.submit_edit()
    calendar.open_event_in_grid(meeting_name)
    mcu_conference.assert_participant_with_position(participant_full_name, participant_position)


@allure.id("52477")
@allure.title("Редактирование созданного мероприятия. Участники")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Создание мероприятия")
@allure.feature("Календарь")
@allure.label("IVAQA", "IVAONE-12111")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.require_ldap_user
@pytest.mark.parametrize(
    "users_factory",
    [[{'position': ['Ведущий инженер'], 'department': ['Отдел тестирования']}]],
    indirect=True,
)
def test_edit_event_participants(setup_aut, users_factory, teardown):
    """Создание Событие (организатор) → редактирование его состава: «Ещё» → «Изменить» →
    «Добавить» → выбор участника с должностью и отделом через попап → полноэкранный режим
    (планировщик/слоты) → «Сохранить» → переоткрытие из сетки. Проверяется: участник с
    должностью добавлен в форму редактирования и отображается в карточке события после сохранения."""
    # register_quit=False: оффлайн-событие удаляется через imail jump (живой driver) —
    # quit регистрируем последним, после cleanup.
    lang, version, driver = web_preamble(setup_aut, teardown, register_quit=False)
    config = setup_aut['setup']['config']
    # Организатор — провизионный mail-юзер: форма Событие грузится через imail/jump, у юзера
    # без почты зависает на спиннере.
    organizer = config['credentials']['mail_user']
    participant = users_factory[0]
    participant_full_name = f'{participant["last_name"]} {participant["first_name"]}'
    participant_position = participant['attributes']['position'][0]
    event_name = f'Событие {get_random_string(5)}'

    # Cleanup: оффлайн-событие в IVA ONE REST не удаляется — чистим через imail jump
    # (calObjCancel) живым driver'ом; uid проставится после создания (ленивое чтение списка).
    event = chunks.get_chunk(version, 'offline_event')(driver, lang=lang)
    created_uid = []
    teardown.append((lambda _: created_uid and event.cancel_event_via_jump(created_uid[0]), None))
    teardown.append((lambda el: el.quit(), driver))

    log.tc('52477')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(organizer['username'], organizer['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_calendar()
    calendar = chunks.get_chunk(version, 'calendar')(driver, lang=lang)

    # Перехватить id imail-сессии (для удаления события в teardown) ДО открытия формы.
    event.start_imail_session_capture()

    # Setup: создать Событие без участников (организатор — текущий юзер), reuse флоу TC-52476.
    calendar.click_create_btn()
    calendar.select_meeting_type(CalendarMeetingType.EVENT)
    event.assert_form_loaded()
    calendar.fill_name(event_name)
    calendar.submit_create()
    calendar.assert_event_in_grid(event_name)
    event.assert_event_created()
    created_uid.append(event.get_event_uid())

    # «Ещё» → «Изменить» → форма редактирования → «Добавить» → участник с должностью.
    # (форму не ждём через assert_form_loaded — в edit поле названия предзаполнено, placeholder
    # отсутствует; синхронизацию даёт open_add_required_participants, ждущий кнопку «Добавить»).
    event.click_edit_btn()
    add_participants = calendar.open_add_required_participants()
    add_participants.search_and_select(participant['last_name'], participant_full_name)
    add_participants.confirm()
    calendar.assert_form_participant_with_position(participant_full_name, participant_position)

    # Полноэкранный режим — доступен блок планировщика «Свободные слоты».
    calendar.open_fullscreen()
    calendar.assert_fullscreen_slots_visible()

    # «Сохранить» → переоткрыть событие из сетки → участник с должностью в карточке.
    calendar.submit_edit()
    calendar.open_event_in_grid(event_name)
    event.assert_participant_with_position(participant_full_name, participant_position)


@allure.id("1427")
@allure.title("Просмотр настроек вкс встречи за приглашенного пользователя")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Создание мероприятия ВКС")
@allure.feature("Календарь")
@allure.label("IVAQA", "IVAONE-12111")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.require_ldap_user
@pytest.mark.parametrize(
    "users_factory",
    [[{'position': ['Ведущий инженер'], 'department': ['Отдел тестирования']}]],
    indirect=True,
)
def test_accept_vks_meeting_invitation(setup_aut, users_factory, teardown):
    """Организатор создаёт ВКС-встречу и приглашает участника с должностью и второго
    участника-зрителя → перелогин за приглашённого зрителя → выбор встречи в сетке: в карточке
    отображаются участник с должностью, ответ участника на приглашение и приглашение с
    вариантами «Принять/Возможно/Отклонить» → полноэкранный просмотр: участник с должностью,
    вложения, приглашение → «Принять». Проверяется: после принятия рядом с ФИ приглашённого
    отображается зелёная галочка принятого приглашения."""
    lang, version, driver = web_preamble(setup_aut, teardown)
    config = setup_aut['setup']['config']
    # Организатор — провизионный mail-юзер (форма ВКС инициализирует секцию участников только
    # для заведённого в MCU). Приглашённый зритель — второй реальный mail/LDAP-юзер: только
    # реальный юзер видит MCU-встречу в своей сетке (эфемерному она в UI не приходит — как в 345).
    organizer = config['credentials']['mail_user']
    invited = config['credentials']['mail_user_2']
    # ФИО at-test-mail-user в справочнике = логин, повторённый трижды (LDAP: firstName="X X", lastName="X").
    invited_full_name = f'{invited["username"]} {invited["username"]} {invited["username"]}'
    participant = users_factory[0]
    participant_full_name = f'{participant["last_name"]} {participant["first_name"]}'
    participant_position = participant['attributes']['position'][0]
    meeting_name = f'Встреча ВКС {get_random_string(5)}'

    # Cleanup: ВКС живёт в MCU и в IVA ONE REST не удаляется — чистим по имени токеном организатора
    # (REST, от драйвера не зависит). Регистрируем ПОСЛЕ relogin_session (он делает pop(-1),
    # ожидая quit браузера последним в teardown).
    token = iva_one_web_login(setup_aut, organizer)

    # Провизия участника в MCU: сабмит встречи с юзером без MCU-профиля получает 400
    # Profile not found при молчащей форме (как в 345) — эфемерал сам не логинится.
    # mail_user_2 (приглашённый) провизирован собственными логинами — его не трогаем.
    ensure_mcu_profile(iva_one_web_login(setup_aut, participant), config['web_url'])

    log.tc('1427')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(organizer['username'], organizer['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_calendar()
    calendar = chunks.get_chunk(version, 'calendar')(driver, lang=lang)

    # Setup (организатор): создать ВКС и пригласить участника с должностью + зрителя-приглашённого.
    calendar.click_create_btn()
    calendar.select_meeting_type(CalendarMeetingType.VKS)
    calendar.fill_name(meeting_name)
    # Двумя отдельными циклами (каждый — свежий попап): один попап на два поиска подряд
    # не отрисовывает вторую строку выдачи.
    add_participants = calendar.open_add_required_participants()
    add_participants.search_and_select(participant['last_name'], participant_full_name)
    add_participants.confirm()
    add_participants = calendar.open_add_required_participants()
    add_participants.search_and_select(invited['username'], invited_full_name)
    add_participants.confirm()
    calendar.submit_create()
    calendar.assert_event_in_grid(meeting_name)

    # Перелогин за приглашённого зрителя; cleanup регистрируем уже здесь (quit нового driver
    # последний в teardown — инвариант relogin_session соблюдён).
    driver = relogin_session(setup_aut, teardown)
    teardown.append((lambda name: delete_conferences_by_name(token, config['web_url'], name), meeting_name))
    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(invited['username'], invited['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_calendar()
    calendar = chunks.get_chunk(version, 'calendar')(driver, lang=lang)
    mcu_conference = chunks.get_chunk(version, 'mcu_conference_sidebar')(driver, lang=lang)

    # Выбрать встречу в сетке → сайдбар: название, участник с должностью, ответ на приглашение,
    # приглашение «Принять/Возможно/Отклонить».
    calendar.open_event_in_grid(meeting_name)
    mcu_conference.assert_conference_created(meeting_name)
    mcu_conference.assert_participant_with_position(participant_full_name, participant_position)
    mcu_conference.assert_invitation_response_visible(invited_full_name)
    mcu_conference.assert_invitation_actions_available()

    # Полноэкранный просмотр: участник с должностью, вложения, приглашение.
    mcu_conference.open_view_fullscreen()
    mcu_conference.assert_fullscreen_participant_with_position(participant_full_name, participant_position)
    mcu_conference.assert_attachments_section_visible()
    mcu_conference.assert_fullscreen_invitation_actions_available()

    # «Принять» → рядом с ФИ приглашённого зелёная галочка принятого приглашения.
    mcu_conference.accept_invitation_fullscreen()
    mcu_conference.assert_fullscreen_invitation_accepted_mark(invited_full_name)


@allure.id("52479")
@allure.title("Просмотр созданного мероприятия. Приглашение")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Создание мероприятия")
@allure.feature("Календарь")
@allure.label("IVAQA", "IVAONE-12111")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.require_ldap_user
@pytest.mark.multiple_browsers
@pytest.mark.parametrize(
    "users_factory",
    [[{'position': ['Ведущий инженер'], 'department': ['Отдел тестирования']}]],
    indirect=True,
)
def test_accept_event_invitation(setup_multiple_auts, users_factory, teardown):
    """Организатор создаёт Событие и приглашает участника и второго участника-зрителя →
    в сессии зрителя выбор события в сетке: в карточке отображаются участник, ответ участника
    на приглашение и приглашение с вариантами «Принять/Возможно/Отклонить» → полноэкранный
    просмотр: участник, вложения, приглашение → «Принять». Проверяется: после принятия рядом
    с ФИ приглашённого отображается зелёная галочка принятого приглашения."""
    auts = setup_multiple_auts(2)
    lang = auts['setup']['cmd']['lang']
    version = auts['setup']['cmd']['ver']
    config = auts['setup']['config']
    org_driver, viewer_driver = auts['driver']
    # Организатор — провизионный mail-юзер (форма Событие грузится через imail/jump). Приглашённый
    # зритель — второй реальный mail/LDAP-юзер: только реальный юзер видит событие в своей сетке.
    organizer = config['credentials']['mail_user']
    invited = config['credentials']['mail_user_2']
    # ФИО mail-юзеров в справочнике = логин, повторённый трижды (LDAP: firstName="X X", lastName="X").
    invited_full_name = f'{invited["username"]} {invited["username"]} {invited["username"]}'
    organizer_full_name = f'{organizer["username"]} {organizer["username"]} {organizer["username"]}'
    # Должность отображается только у реального LDAP-участника (у эфемерного users_factory imail
    # не проносит ivaId в копию приглашённого → должность скрыта). Ассертим должность организатора
    # (реальный LDAP-юзер) — её значение задано на стенде, читаем из Keycloak, а не хардкодим.
    organizer_position = get_user_position(config, organizer['username'])
    assert organizer_position, (
        f'Организатор {organizer["username"]} должен иметь должность на стенде (Keycloak-атрибут '
        f'position) — иначе шаг "участники (отображается должность)" не покрыть.'
    )
    participant = users_factory[0]
    participant_full_name = f'{participant["last_name"]} {participant["first_name"]}'
    event_name = f'Событие {get_random_string(5)}'

    # Cleanup: Событие удаляется через imail jump живым драйвером организатора (REST-удаления нет;
    # sid и куки imail-сессии живут только в окне организатора → relogin не подходит, держим обе
    # сессии живыми). jump-cancel регистрируем первым — teardown идёт прямым обходом, и удаление
    # отрабатывает, пока org_driver жив (потом quit обоих).
    event_org = chunks.get_chunk(version, 'offline_event')(org_driver, lang=lang)
    created_uid = []
    teardown.append((lambda _: created_uid and event_org.cancel_event_via_jump(created_uid[0]), None))
    teardown.append((lambda el: el.quit(), viewer_driver))
    teardown.append((lambda el: el.quit(), org_driver))

    log.tc('52479')

    # --- Организатор (сессия 1): создать Событие и пригласить участника + зрителя ---
    driver_sessions.set_active(org_driver)
    login_page = pages.get_page(version, 'login')(org_driver, lang=lang)
    login_page.login(organizer['username'], organizer['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(org_driver, lang=lang)
    left_menu.open_calendar()
    calendar = chunks.get_chunk(version, 'calendar')(org_driver, lang=lang)

    # Перехватить id imail-сессии (для удаления события в teardown) ДО открытия формы.
    event_org.start_imail_session_capture()
    calendar.click_create_btn()
    calendar.select_meeting_type(CalendarMeetingType.EVENT)
    event_org.assert_form_loaded()
    calendar.fill_name(event_name)
    # Двумя отдельными циклами (каждый — свежий попап): один попап на два поиска подряд
    # не отрисовывает вторую строку выдачи.
    add_participants = calendar.open_add_required_participants()
    add_participants.search_and_select(participant['last_name'], participant_full_name)
    add_participants.confirm()
    add_participants = calendar.open_add_required_participants()
    add_participants.search_and_select(invited['username'], invited_full_name)
    add_participants.confirm()
    calendar.submit_create()
    calendar.assert_event_in_grid(event_name)
    event_org.assert_event_created()
    created_uid.append(event_org.get_event_uid())

    # --- Приглашённый зритель (сессия 2): просмотр + принять ---
    driver_sessions.set_active(viewer_driver)
    login_page = pages.get_page(version, 'login')(viewer_driver, lang=lang)
    login_page.login(invited['username'], invited['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(viewer_driver, lang=lang)
    left_menu.open_calendar()
    calendar = chunks.get_chunk(version, 'calendar')(viewer_driver, lang=lang)
    event = chunks.get_chunk(version, 'offline_event')(viewer_driver, lang=lang)

    # Выбрать Событие в сетке → сайдбар: участники (у организатора-LDAP отображается должность,
    # эфемерного участника проверяем по имени), ответ на приглашение, приглашение
    # «Принять/Возможно/Отклонить».
    calendar.open_event_in_grid(event_name)
    event.assert_event_created()
    event.assert_participant_with_position(organizer_full_name, organizer_position)
    event.assert_participant_by_name(participant_full_name)
    event.assert_invitation_response_visible(invited_full_name)
    event.assert_invitation_actions_available()

    # Полноэкранный просмотр: участники (должность организатора), вложения, приглашение.
    event.open_view_fullscreen()
    event.assert_participant_with_position(organizer_full_name, organizer_position)
    event.assert_participant_by_name(participant_full_name)
    event.assert_attachments_section_visible()
    event.assert_fullscreen_invitation_actions_available()

    # «Принять» → рядом с ФИ приглашённого зелёная галочка принятого приглашения.
    event.accept_invitation_fullscreen()
    event.assert_invitation_accepted_mark(invited_full_name)
