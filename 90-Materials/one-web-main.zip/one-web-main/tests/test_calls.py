import allure
import pytest

from autocore.test.logger import get_log
from autocore import driver_sessions
from autocore.clients.rest import iva_one
from tools.helpers.session import iva_one_web_login
from tools.helpers.page_helpers import grant_notifications
from tests import pages
from tests.pages import chunks

log = get_log()


@allure.id("52275")
@allure.title("Позвонить в p2p чат. Настройки оборудования")
@allure.label("owner", "Simon")
@allure.tag("web")
@allure.feature("Звонки")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.multiple_browsers
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_p2p_call_open_equipment_settings(setup_multiple_auts, users_factory, teardown):
    auts = setup_multiple_auts(2)
    lang = auts['setup']['cmd']['lang']
    version = auts['setup']['cmd']['ver']
    config = auts['setup']['config']
    web_url = config['web_url']
    users_data = users_factory
    usernames = [creds['username'] for creds in users_data]

    token = iva_one_web_login(auts, users_data[0])
    iva_one.create_p2p_chat(token, usernames[1])

    driver_1, driver_2 = auts['driver']
    teardown.append((lambda el: el.quit(), driver_1))
    teardown.append((lambda el: el.quit(), driver_2))

    log.tc('52275')

    # User 2 (принимающий) логинится первым: звонок без ответа авто-сбрасывается ~10с.
    # grant_notifications ДО login — иначе окно звонка рендерится ненадёжно.
    driver_sessions.set_active(driver_2)
    grant_notifications(driver_2, web_url)
    login_page_2 = pages.get_page(version, 'login')(driver_2, lang=lang)
    login_page_2.login(usernames[1], users_data[1].get('password'))
    chunks.get_chunk(version, 'left_menu')(driver_2, lang=lang).open_chats()
    call_2 = chunks.get_chunk(version, 'call')(driver_2, lang=lang)

    # User 1 (звонящий): логин, открыть p2p-чат с user 2, начать аудио-звонок
    driver_sessions.set_active(driver_1)
    grant_notifications(driver_1, web_url)
    login_page_1 = pages.get_page(version, 'login')(driver_1, lang=lang)
    login_page_1.login(usernames[0], users_data[0].get('password'))
    chunks.get_chunk(version, 'left_menu')(driver_1, lang=lang).open_chats()
    chats_list_1 = chunks.get_chunk(version, 'chats_list')(driver=driver_1, lang=lang)
    chat_1 = pages.get_page(version, 'chat')(driver_1, lang=lang, open_page=False)
    chats_list_1.open_chat(users_data[1]['last_name'])
    chat_1.click_audio_call_btn()
    call_1 = chunks.get_chunk(version, 'call')(driver_1, lang=lang)
    call_1.assert_outgoing_call_started()

    # User 2 принимает вызов. Меню «3 точки» делаем у него: его окно разворачивается на
    # весь экран, у звонящего остаётся маленьким без меню (TC шаги 4-5 к участнику не привязывает).
    driver_sessions.set_active(driver_2)
    call_2.accept_incoming_call()
    call_2.assert_call_active()

    # «3 точки» → «Настройка оборудования»: разделы Видео/Аудио/Звук = Камера/Микрофон/Динамики
    call_2.open_more_actions_menu()
    call_2.assert_equipment_menu_item_visible()
    call_2.open_equipment_settings()
    call_2.assert_equipment_dialog_sections()
