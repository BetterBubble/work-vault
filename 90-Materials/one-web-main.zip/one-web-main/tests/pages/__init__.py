from .chat_input_edit_link_popup import PVersion2ChatInputEditLinkPopup
from .login import PVersion2Login
from .profile_popup import PVersion2ProfilePopup
from .allow_notifications_popup import PVersion2AllowNotificationsPopup
from .chat import PVersion2Chat

from autocore.test.logger import get_log

log = get_log()


def get_page(version, page_name):
    if version == 'Version2':
        log.debug(f'Using page/chunk page-{page_name}')
        if page_name == 'login':
            return PVersion2Login
        if page_name == 'profile_popup':
            return PVersion2ProfilePopup
        if page_name == 'allow_notifications_popup':
            return PVersion2AllowNotificationsPopup
        if page_name == 'chat':
            return PVersion2Chat
        if page_name == 'chat_input_edit_link_popup':
            return PVersion2ChatInputEditLinkPopup
        else:
            raise ValueError(f'Page {page_name} was not registered.')
    else:
        raise ValueError(f'Version {version} is not supported.')
