from typing import TYPE_CHECKING

from .locators import Version2 as Version2Locators
from autocore.test.logger import get_log
from autocore.base.web.base_page import PBase

if TYPE_CHECKING:
    from .locators.Version2.profile_popup import LProfilePopup as _LocatorsTypingBase
else:
    class _LocatorsTypingBase:
        pass

log = get_log()


class _PVersionProfilePopup(PBase, _LocatorsTypingBase):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_ROOT()
        self.page_path = ''
        super().__init__(*args, **kwargs)

    def close_popup(self):
        log.step('Закрыть попап с профилем пользователя', where='IVA ONE WEB Клиент')
        self.get_object(self.L_CLOSE_POPUP_BTN()).click()
        self.wait_absence(self.L_ROOT())

    def open_account_chunk(self):
        log.step('Открыть вкладку "Аккаунт"', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_ACCOUNT_TAB(self.lang)).click()

    def open_sessions_chunk(self):
        log.step('Открыть вкладку "Мои сеансы"', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_SESSIONS_TAB(self.lang)).click()

    def open_about_chunk(self):
        log.step('Открыть вкладку "О приложении"', where='IVA ONE WEB Клиент')
        self.get_object(self.L_ABOUT_TAB()).click()

    def open_support_chunk(self):
        log.step('Открыть вкладку "Поддержка"', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_SUPPORT_TAB(self.lang)).click()

    def open_settings_language_chunk(self):
        # Клик по «Настройки» ведёт на под-вкладку «Оборудование» (дефолт), поэтому до
        # языковой секции нужен второй клик по под-вкладке «Язык».
        log.step('Открыть вкладку "Настройки"', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_SETTINGS_TAB(self.lang)).click()
        log.step('Открыть под-вкладку "Язык"', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_LANGUAGE_SUBTAB(self.lang)).click()

    def open_settings_equipment_chunk(self):
        # Клик по «Настройки» ведёт на под-вкладку «Оборудование» (дефолт); клик по под-вкладке
        # «Оборудование» делает переход явным (симметрично open_settings_language_chunk).
        log.step('Открыть вкладку "Настройки"', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_SETTINGS_TAB(self.lang)).click()
        log.step('Открыть под-вкладку "Оборудование"', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_EQUIPMENT_SUBTAB(self.lang)).click()

    def assert_img_avatar_exist(self):
        self.assert_presence(self.L_LEFT_BAR_HEADER_DS_AVATAR_IMG(), 'В левом верхнем углу окна профиля отображается аватар-изображение')


class PVersion2ProfilePopup(_PVersionProfilePopup, Version2Locators.LProfilePopup):
    pass
