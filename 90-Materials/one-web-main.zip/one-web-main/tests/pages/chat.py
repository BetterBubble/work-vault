import os
import time
from typing import Union, TYPE_CHECKING

from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait

from autocore.test.logger import get_log
from autocore.base.web.base_page import PBase
from autocore.test.assertions import assert_fn
from autocore.clients.rest.enums import ChatUsersReactions
from autocore.consts import TEST_DATA_DIR
from selenium.common.exceptions import TimeoutException, ElementClickInterceptedException, WebDriverException
from selenium.webdriver import TouchActions
from selenium.webdriver.common.action_chains import ActionChains

from tools import i18n, enums
from tools.helpers import network
from tools.helpers.page_helpers import (
    upload_file_via_js,
    scroll_chat_to_bottom_via_js,
    reset_upload_tracking,
    count_upload_parts,
    upload_completed,
    media_resource_loaded,
    assert_no_original_media_download,
)
from .locators import Version2 as Version2Locators
from tests.pages import chunks

if TYPE_CHECKING:
    from .locators.Version2.chat import (
        LChat as _LocatorsTypingBase,
    )
else:
    class _LocatorsTypingBase:
        pass

log = get_log()


class _PVersionChat(PBase, _LocatorsTypingBase):  # chat-room ядро; список чатов вынесен в chunk chats_list
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_I18N_HEADER(self.lang)
        self.page_path = ''
        super().__init__(*args, **kwargs)

    def assert_chat_with_chat_name_opened(self, chat_name: str):
        self.assert_presence(self.L_CHAT_WITH_CHAT_NAME_HEADER(chat_name), f'Чат "{chat_name}" открыт')

    def click_audio_call_btn(self):
        log.step('Нажать кнопку "Позвонить" (аудио-звонок) в шапке чата', where='IVA ONE WEB Клиент')
        self.get_object(self.L_CHAT_AUDIO_CALL_BTN()).click()

    def open_via_notification_link(self, link: str):
        """Перейти в чат по ссылке из push-уведомления (поле link в notification.new).
        В текущей сборке кликабельного in-app уведомления нет (нативный Notification из Selenium
        не кликается), поэтому «клик по уведомлению» воспроизводим переходом по его ссылке. См. TC-1154."""
        log.step('Перейти в чат по ссылке из уведомления', where='IVA ONE WEB Клиент')
        self.open_url(link)
        self.wait_presence(self.L_CHAT_ROOM())

    def open_chat_profile(self, chunk_name: str = 'group_chat_profile'):
        """Открыть профиль чата кликом по шапке. Side-effect: ранний wait_presence
        primary_element соответствующего chunk'а — fail-fast, если sidebar не появился.
        Допустимые значения `chunk_name`:
        - `'group_chat_profile'` (по умолчанию) — групповой чат, корень `<chat-sidebar>`.
        - `'info_channel_profile'` — информационный канал, корень `<chat-sidebar>` (тот же DOM, но channel-специфичные методы).
        - `'p2p_chat_profile'` — личный чат, корень `<profile-sidebar>` (ds→iva: был `<user-sidebar>`)."""
        log.step(f'Открыть профиль чата"', where='IVA ONE WEB Клиент')
        self.get_object(self.L_CHAT_TOPBAR()).click()
        _ = chunks.get_chunk(self.version, chunk_name)(driver=self.driver, lang=self.lang)

    def type_message(self, message: str, check_value=True):
        if self.driver.name in ['Safari']:
            time.sleep(3)
        log.step(f'Написать текстовое сообщение "{message}"', where='IVA ONE WEB Клиент')
        input_locator = self.L_CHAT_INPUT()
        self.get_object(input_locator).send_keys(message)
        if check_value:
            self.check_input_field_value(message)

    def _wait_input_value(self, locator, expected_value: str, timeout: float = 5.0) -> bool:
        end_time = time.time() + timeout
        while time.time() < end_time:
            elements = self.driver.find_elements(*locator)
            for el in elements:
                if (el.text or '') == expected_value:
                    return True
                if (el.get_attribute('textContent') or '') == expected_value:
                    return True
            combined = ''.join((el.text or el.get_attribute('textContent') or '') for el in elements)
            if combined == expected_value:
                return True
            time.sleep(0.1)
        return False

    def check_input_field_value(self, expected_value: str):
        assert_fn(checker=lambda: self._wait_input_value(self.L_INPUT_VALUE(), expected_value),
                  message=f'В строке ввода отображается ожидаемый текст "{expected_value}"')

    def send(self, mode: str):
        if self.driver.name in ['Safari']:
            time.sleep(3)
        if mode == 'enter':
            log.step('Нажать кнопку "enter" для отправки сообщения', where='IVA ONE WEB Клиент')
            self.get_object(self.L_CHAT_INPUT()).send_keys(Keys.ENTER)
        if mode == 'click':
            log.step('Нажать кнопку "Отправить" с помощью мыши', where='IVA ONE WEB Клиент')
            send_button = self.get_object(self.L_SEND_BUTTON())
            try:
                send_button.click()
            except (ElementClickInterceptedException, WebDriverException):
                log.warning('Клик по кнопке "Отправить" не удался, выполняется ожидание исчезнования toast-уведомления')
                self.toast.wait_disappear()
                send_button.click()
        if self.driver.name in ['Safari', 'firefox']:
            scroll_chat_to_bottom_via_js(self.driver)

    def send_text_message(self, message: str, message_type: enums.ChatBubbleContentSearchMode = enums.ChatBubbleContentSearchMode.TEXT, mode='enter'):
        self.type_message(message, False)
        self.send(mode)
        if message_type == enums.ChatBubbleContentSearchMode.TEXT:
            msg_bubble_locator = self.L_CHAT_MESSAGE_WITH_TEXT(message)
        elif message_type == enums.ChatBubbleContentSearchMode.VISUAL_LINK:
            msg_bubble_locator = self.L_CHAT_MESSAGE_WITH_VISIBLE_LINK(message)
        else:
            msg_bubble_locator = self.L_CHAT_MESSAGE_WITH_REAL_LINK(message)
        self.wait_presence(msg_bubble_locator, 5)

    def assert_sent_message_exists(self, message: str):
        self.assert_presence(locator=self.L_CHAT_MESSAGE_WITH_TEXT(text=message),
                             message=f'Отправленное сообщение "{message}" присутствует в чате')

    def assert_sent_message_status_is_sent(self, message: str):
        self.assert_presence(locator=self.L_CHAT_MESSAGE_SENT_STATUS(text=message),
                             message=f'Статус сообщения "{message}" — "отправлено"')

    def assert_chat_is_empty(self):
        self.wait_presence(self.L_CHAT_SCROLLER())
        assert_fn(lambda: self.wait_absence(self.L_CHAT_MESSAGE_IN_SCROLLER()),
                  'В открытом диалоге нет сообщений')

    def select_message_for_reply(self, message_for_reply: str):
        self.open_bubble_context_menu_by_text(message_for_reply)
        self.click_reply_button_in_context_menu()
        self.assert_chat_message_replying_container_exists(message_for_reply)

    def assert_sent_message_is_reply_for(self, sent_message: str, message_for_reply: str):
        self.assert_presence(self.L_CHAT_MESSAGE_WITH_REPLY(sent_message, message_for_reply),
                             f'Над сообщением "{sent_message}" отображается сообщение "{message_for_reply}"')
        self.click_replying_text_above_the_message(sent_message, message_for_reply)

    def scroll_chat(self, direction: enums.ChatScrollOffsetDirections):
        step_direction_message = "вверх" if direction == enums.ChatScrollOffsetDirections.TOP else "вниз"
        log.step(f'Прокрутить чат {step_direction_message}', where='IVA ONE WEB Клиент')

        chat_scroller_element = self.get_object(self.L_CHAT_SCROLLER())

        if self.driver.name in ['Safari', 'firefox', 'MicrosoftEdge']:
            # Fallback для Safari/Firefox/MicrosoftEdge: так как TouchActions не работают,
            # мы кликаем в элемент скролла и эмулируем нажатие PageUp/PageDown
            chat_scroller_element.click()
            key_to_press = Keys.PAGE_UP if direction == enums.ChatScrollOffsetDirections.TOP else Keys.PAGE_DOWN
            # Нажимаем кнопку несколько раз для надежной прокрутки на нужную высоту
            for _ in range(10):
                chat_scroller_element.send_keys(key_to_press)
                time.sleep(0.1)
        else:
            y_offset_multiplier = direction
            max_y_offset_delta = 5000 * y_offset_multiplier
            touch_actions = TouchActions(self.driver)
            touch_actions.scroll_from_element(chat_scroller_element, 0, max_y_offset_delta).perform()

    def open_bubble_context_menu(self, by: enums.ChatBubbleContentSearchMode, text: str):
        log_step_msg = f'Открыть контекстное меню сообщения "{text}"'
        log_warn_msg = f'Сообщение "{text}" не найдено в DOM, будет осуществлена прокрутка чата вверх'
        if by == enums.ChatBubbleContentSearchMode.VISUAL_LINK:
            right_click_bubble_locator = ('xpath', self.L_CHAT_MESSAGE_WITH_VISIBLE_LINK(text)[1] + '/../../..//chat-message-info')
        else:
            right_click_bubble_locator = self.L_CHAT_MESSAGE_WITH_TEXT(text)
        open_message_context_action = lambda: self.click_right(right_click_bubble_locator, 5)
        log.step(log_step_msg, where='IVA ONE WEB Клиент')
        try:
            open_message_context_action()
        except TimeoutException:
            log.warn(log_warn_msg)
            self.scroll_chat(enums.ChatScrollOffsetDirections.TOP)
            open_message_context_action()
        self.wait_presence(self.L_CHAT_MESSAGE_CONTEXT_MENU())


    def open_bubble_context_menu_by_text(self, message):
        self.open_bubble_context_menu(enums.ChatBubbleContentSearchMode.TEXT, message)


    def open_bubble_context_menu_by_visual_link(self, visual_link):
        self.open_bubble_context_menu(enums.ChatBubbleContentSearchMode.VISUAL_LINK, visual_link)

    def open_context_menu_on_mention(self, user_name: str):
        log.step(f'Открыть контекстное меню правым кликом по упоминанию "{user_name}" в сообщении',
                 where='IVA ONE WEB Клиент')
        self.click_right(self.L_MENTION_IN_MESSAGE(user_name), 5)
        self.wait_presence(self.L_CHAT_MESSAGE_CONTEXT_MENU())

    def open_context_menu_on_link(self, visual_link: str):
        # ПКМ именно по узлу <a> (не по баблу): только так в меню сообщения появляется
        # пункт "Скопировать ссылку". open_bubble_context_menu_by_visual_link бьёт по
        # chat-message-info и даёт меню без этого пункта.
        log.step(f'Открыть контекстное меню правым кликом по ссылке "{visual_link}" в сообщении',
                 where='IVA ONE WEB Клиент')
        self.click_right(self.L_CHAT_MESSAGE_WITH_VISIBLE_LINK(visual_link), 5)
        self.wait_presence(self.L_CHAT_MESSAGE_CONTEXT_MENU())

    def click_edit_message_in_context_menu(self):  # when context menu opened
        edit_button_name = i18n.get_str('chat_message_context_menu_edit_button', self.lang)
        log.step(f'Нажать кнопку "{edit_button_name}" в контекстном меню сообщения', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_CONTEXT_MENU_EDIT_BTN(self.lang)).click()
        self.wait_absence(self.L_CHAT_MESSAGE_CONTEXT_MENU())

    def click_reply_button_in_context_menu(self):  # when context menu opened
        reply_button_name = i18n.get_str('chat_message_context_menu_reply_button', self.lang)
        log.step(f'Нажать кнопку "{reply_button_name}" в контекстном меню сообщения', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_CONTEXT_MENU_REPLY_BTN(self.lang)).click()
        self.wait_absence(self.L_CHAT_MESSAGE_CONTEXT_MENU())

    def click_start_thread_button_in_context_menu(self):  # when context menu opened
        start_thread_button_name = i18n.get_str('chat_message_context_menu_start_thread_button', self.lang)
        log.step(f'Нажать кнопку "{start_thread_button_name}" в контекстном меню сообщения', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_CONTEXT_MENU_START_THREAD_BTN(self.lang)).click()
        self.wait_absence(self.L_CHAT_MESSAGE_CONTEXT_MENU())

    def click_edit_link_in_input(self):  # when edit message mode activated
        edit_link_button_name = i18n.get_str('chat_input_menu_item_edit_link_btn', self.lang)
        log.step(f'Нажать кнопку "{edit_link_button_name}" в инпуте ввода', where='IVA ONE WEB Клиент')
        chat_input_link_locator = self.L_CHAT_INPUT_HREF_CONTENT()
        menu_item_edit_link_btn_locator = self.L_I18N_INPUT_MENU_ITEM_EDIT_LINK_BTN(self.lang)
        self.get_object(chat_input_link_locator).click()
        self.click_right(chat_input_link_locator, 5)
        self.get_object(menu_item_edit_link_btn_locator).click()
        self.wait_absence(menu_item_edit_link_btn_locator)


    def assert_chat_message_replying_container_exists(self, message_for_reply):
        self.assert_presence(self.L_REPLYING_CONTAINER(message_for_reply),
                             'Предпросмотр сообщения присутствует над полем ввода')

    def assert_forward_preview_above_input(self, message: str):
        """Проверить превью пересылаемого сообщения над полем ввода и активность кнопки отправки."""
        self.assert_presence(self.L_FORWARD_PREVIEW_ABOVE_INPUT(message),
                             f'Превью пересылаемого сообщения "{message}" отображается над полем ввода')
        assert_fn(checker=lambda: self.get_object(self.L_SEND_BUTTON()).is_enabled(),
                  message='Кнопка отправки активна')

    def assert_editing_container_exists(self, message: str):
        self.assert_presence(self.L_EDITING_CONTAINER(message),
                             f'Контейнер редактируемого сообщения "{message}" отображается над полем ввода')

    def assert_message_is_edited(self, message: str):
        self.assert_presence(self.L_I18N_CHAT_MESSAGE_EDITED_MARK(message, self.lang),
                             f'Сообщение "{message}" содержит пометку "Ред."')

    def click_replying_text_above_the_message(self, sent_message, message_for_reply):
        log.step(f'Нажать на отвечаемый текст над сообщением "{sent_message}"', where='IVA ONE WEB Клиент')
        self.get_object(self.L_CHAT_MESSAGE_REPLIED_TEXT_BTN(sent_message)).click()
        self.assert_presence(self.L_MESSAGE_HIGHLIGHTING(message_for_reply),
                             f'Сообщение "{message_for_reply}" выделено после перехода к отвечаемому сообщению')

    def open_thread_by_message_text(self, message_text: str):
        log.step(f'Открыть тред по сообщению "{message_text}"', where='IVA ONE WEB Клиент')
        comments_button_locator = self.L_CHAT_MESSAGE_THREAD_COMMENTS_BTN(message_text)
        try:
            self.get_object(comments_button_locator, 5).click()
        except TimeoutException:
            log.warn(f'Кнопка комментариев у сообщения "{message_text}" не найдена, будет выполнена прокрутка чата вверх')
            self.scroll_chat(enums.ChatScrollOffsetDirections.TOP)
            self.get_object(comments_button_locator, 5).click()
        self.assert_presence(self.L_THREAD_WITH_MESSAGE(message_text),
                             f'Тред по сообщению "{message_text}" открыт')

    def create_thread_reply(self, message_text: str, reply_text: str):
        log.step(f'Создать ответ "{reply_text}" в треде сообщения "{message_text}"', where='IVA ONE WEB Клиент')
        self.open_bubble_context_menu_by_text(message_text)
        self.click_start_thread_button_in_context_menu()
        self.assert_presence(self.L_THREAD_WITH_MESSAGE(message_text),
                             f'Тред по сообщению "{message_text}" открыт')
        self.type_thread_message(reply_text, check_value=False)
        self.send_thread_message()
        self.wait_presence(self.L_CHAT_MESSAGE_WITH_TEXT(reply_text), 5)

    def open_thread_bubble_context_menu_by_text(self, text: str):
        log.step(f'Открыть контекстное меню сообщения "{text}" в треде', where='IVA ONE WEB Клиент')
        self.click_right(self.L_THREAD_MESSAGE_WITH_TEXT(text), 5)
        self.wait_presence(self.L_CHAT_MESSAGE_CONTEXT_MENU())

    def type_thread_message(self, message: str, check_value=True):
        if self.driver.name in ['Safari']:
            time.sleep(3)
        log.step(f'Написать текстовое сообщение "{message}" в треде', where='IVA ONE WEB Клиент')
        thread_input_locator = self.L_THREAD_INPUT()
        self.get_object(thread_input_locator).send_keys(message)
        if check_value:
            assert_fn(checker=lambda: self.get_object(thread_input_locator).text == message,
                      message=f'В строке ввода треда отображается ожидаемый текст "{message}"')

    def send_thread_message(self, mode: str = 'enter'):
        if self.driver.name in ['Safari']:
            time.sleep(3)
        if mode == 'enter':
            log.step('Нажать кнопку "enter" для отправки сообщения в тред', where='IVA ONE WEB Клиент')
            self.get_object(self.L_THREAD_INPUT()).send_keys(Keys.ENTER)
        if mode == 'click':
            log.step('Нажать кнопку "Отправить" в треде с помощью мыши', where='IVA ONE WEB Клиент')
            send_button = self.get_object(self.L_THREAD_SEND_BUTTON())
            try:
                send_button.click()
            except (ElementClickInterceptedException, WebDriverException):
                log.warning('Клик по кнопке "Отправить" в треде не удался, выполняется ожидание исчезнования toast-уведомления')
                self.toast.wait_disappear()
                send_button.click()

    def subscribe_to_thread(self):
        subscribe_button_name = i18n.get_str('chat_thread_subscribe_button', self.lang)
        log.step(f'Нажать кнопку "{subscribe_button_name}" в треде', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_THREAD_SUBSCRIBE_BTN(self.lang)).click()
        self.wait_presence(self.L_I18N_THREAD_UNSUBSCRIBE_BTN(self.lang), 5)

    def assert_thread_subscribed(self):
        self.assert_presence(self.L_I18N_THREAD_UNSUBSCRIBE_BTN(self.lang),
                             'Пользователь подписан на тред')

    def assert_thread_message_visible(self, text: str):
        self.assert_presence(self.L_THREAD_MESSAGE_WITH_TEXT(text),
                             f'Сообщение "{text}" отображается в треде')

    def close_thread(self):
        log.step('Закрыть тред (клик по back-arrow в шапке треда)', where='IVA ONE WEB Клиент')
        self.get_object(self.L_THREAD_CLOSE_BTN()).click()
        self.wait_absence(self.L_THREAD_ROOM())

    def assert_thread_count_in_bubble(self, parent_text: str, count: int):
        self.assert_presence(self.L_CHAT_MESSAGE_THREAD_COMMENTS_COUNT(parent_text, count),
                             f'В бабле сообщения "{parent_text}" отображается счётчик треда: {count}')

    def open_threads_tab(self):
        tab_name = i18n.get_str('chat_chats_header_threads_tab', self.lang)
        log.step(f'Открыть вкладку "{tab_name}" в списке чатов', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_THREADS_TAB(self.lang)).click()

    def assert_thread_in_threads_tab(self, parent_text: str):
        self.assert_presence(self.L_THREAD_LIST_ITEM_BY_PARENT_TEXT(parent_text),
                             f'Тред "{parent_text}" отображается во вкладке "Треды"')

    def assert_thread_not_in_threads_tab(self, parent_text: str):
        assert_fn(lambda: self.wait_absence(self.L_THREAD_LIST_ITEM_BY_PARENT_TEXT(parent_text)),
                  f'Тред "{parent_text}" отсутствует во вкладке "Треды"')

    def type_thread_mention(self, user_name: str):
        log.step(f'Ввести "@{user_name}" в поле ввода треда для упоминания', where='IVA ONE WEB Клиент')
        thread_input = self.get_object(self.L_THREAD_INPUT())
        thread_input.send_keys(f'@{user_name}')
        # Ждём именно СТРОКУ нужного пользователя в попапе (а не просто появление попапа): у
        # свежесозданного user'а строка подтягивается с задержкой по мере индексации в адресной
        # книге IVA после prewarm-login'а. Между окнами ожидания мягко перезапускаем поиск
        # (backspace + повтор последнего символа). Паттерн идентичен type_mention.
        user_item = self.L_MENTION_POPUP_USER_ITEM(user_name)
        for attempt in range(1, 7):
            try:
                self.wait_presence(user_item, 8)
                return
            except TimeoutException:
                if attempt == 6:
                    raise
                log.warning(f'Пользователь "{user_name}" не появился в попапе упоминания треда, повтор поиска ({attempt}/5)')
                thread_input.send_keys(Keys.BACKSPACE)
                thread_input.send_keys(user_name[-1])

    def assert_input(self, available=True):
        if available:
            self.assert_presence(self.L_CHAT_INPUT(), 'Поле для ввода сообщения доступно')
        else:
            assert_fn(lambda: self.wait_absence(self.L_CHAT_INPUT()), 'Поле для ввода сообщения НЕ доступно')

    def assert_input_disabled_plug_visible(self):
        self.assert_presence(self.L_I18N_INPUT_DISABLED_PLUG(self.lang),
                             'Вместо поля ввода отображается надпись "Здесь нельзя писать"')

    def click_select_in_context_menu(self):
        select_btn_name = i18n.get_str('chat_message_context_menu_select_button', self.lang)
        log.step(f'Нажать кнопку "{select_btn_name}" в контекстном меню сообщения', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_CONTEXT_MENU_SELECT_BTN(self.lang)).click()
        self.wait_absence(self.L_CHAT_MESSAGE_CONTEXT_MENU())

    def assert_select_mode_toolbar_visible(self):
        self.assert_presence(self.L_SELECT_MODE_TOOLBAR(), 'Тулбар режима выбора сообщений отображается')
        self.assert_presence(self.L_I18N_SELECT_MODE_CANCEL_BTN(self.lang), 'Кнопка "Сбросить" отображается в тулбаре выбора')
        self.assert_presence(self.L_SELECT_MODE_COPY_BTN(), 'Кнопка "Скопировать" отображается в тулбаре выбора')
        self.assert_presence(self.L_SELECT_MODE_DELETE_BTN(), 'Кнопка "Удалить" отображается в тулбаре выбора')
        self.assert_presence(self.L_SELECT_MODE_FORWARD_BTN(), 'Кнопка "Переслать" отображается в тулбаре выбора')

    def click_selectable_message_by_text_in_select_mode(self, message_text: str):
        log.step(f'Выбрать сообщение "{message_text}" в режиме мультивыбора', where='IVA ONE WEB Клиент')
        selectable_locator = self.L_CHAT_MESSAGE_SELECTABLE_WRAPPER_BY_TEXT(message_text)
        for attempt in range(3):
            selectable_message = self.get_object(selectable_locator)
            self.driver.execute_script('arguments[0].scrollIntoView({block: "center", inline: "nearest"});', selectable_message)
            try:
                selectable_message.click()
                return
            except ElementClickInterceptedException:
                if attempt < 2:
                    log.warning(
                        f'Клик по сообщению "{message_text}" перехвачен, повторяем попытку '
                        f'({attempt + 2}/3) после прокрутки'
                    )
                    self.scroll_chat(enums.ChatScrollOffsetDirections.TOP)
                    continue
                log.warning(f'Клик по сообщению "{message_text}" перехвачен, выполняется JS fallback-клик')
                self.driver.execute_script('arguments[0].click();', selectable_message)
                return

    def click_select_mode_forward_button(self):
        forward_button_name = i18n.get_str('chat_message_context_menu_forward_button', self.lang)
        log.step(f'Нажать кнопку «{forward_button_name}» в тулбаре режима выбора', where='IVA ONE WEB Клиент')
        self.get_object(self.L_SELECT_MODE_FORWARD_BTN()).click()
        self.forward_dialog.wait_open()

    def assert_forward_preview_title_contains_count(self, count: Union[int, str]):
        count_str = str(count)
        self.assert_presence(
            self.L_FORWARD_PREVIEW_TITLE_CONTAINS_COUNT(count_str),
            f'В превью пересылки в заголовке отображается число «{count_str}»'
        )

    def assert_forward_preview_author_names(self, expected_names: list[str]):
        def _names_match(expected_name: str, actual_name: str) -> bool:
            expected_tokens = expected_name.split()
            actual_tokens = actual_name.split()
            return expected_tokens == actual_tokens or expected_tokens == list(reversed(actual_tokens))

        self.wait_presence(self.L_FORWARD_PREVIEW_AUTHOR_NAME_ITEMS(), 10)
        name_elements = self.get_object(self.L_FORWARD_PREVIEW_AUTHOR_NAME_ITEMS(), multiple=True, multiple_no_wait=True)
        actual = [el.text.strip() for el in name_elements if el.text and el.text.strip()]
        actual_unique = list(dict.fromkeys(actual))
        missing_expected = [name for name in expected_names if not any(_names_match(name, actual_name) for actual_name in actual_unique)]
        assert_fn(
            checker=lambda: not missing_expected,
            message=(
                f'В превью пересылки присутствуют ожидаемые ФИ авторов: '
                f'ожидалось {expected_names}, получено {actual_unique}'
            )
        )

    def assert_send_button_active(self):
        assert_fn(checker=lambda: self.get_object(self.L_SEND_BUTTON()).is_enabled(),
                  message='Кнопка отправки активна')

    def click_forward_button_in_context_menu(self):
        forward_button_name = i18n.get_str('chat_message_context_menu_forward_button', self.lang)
        log.step(f'Нажать кнопку "{forward_button_name}" в контекстном меню сообщения', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_CONTEXT_MENU_FORWARD_BTN(self.lang)).click()
        self.wait_absence(self.L_CHAT_MESSAGE_CONTEXT_MENU())
        self.forward_dialog.wait_open()

    def forward_message(self, message: str, target_chat_name: str):
        self.open_bubble_context_menu_by_text(message)
        self.click_forward_button_in_context_menu()
        self.forward_dialog.select_chat(target_chat_name)
        self.send(mode='enter')

    def assert_message_is_forwarded(self, message: str):
        self.assert_presence(self.L_I18N_FORWARDED_CHAT_MESSAGE_CONTAINER(message, self.lang),
                           f'Пересланное сообщение "{message}" присутствует в чате')

    def click_forwarded_message_author_name(self, forwarded_message: str):
        """Клик по ФИО автора оригинала в forward-bubble — открывает sidebar профиля автора."""
        log.step(f'Нажать на ФИ автора в пересланном сообщении "{forwarded_message}"', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_FORWARDED_MESSAGE_AUTHOR_LINK(forwarded_message, self.lang)).click()

    def click_link_in_message(self, link_name: str):
        log.step(f'Нажать на видимую ссылку "{link_name}" в сообщении', where='IVA ONE WEB Клиент')
        self.get_object(self.L_CHAT_MESSAGE_WITH_VISIBLE_LINK(link_name)).click()

    def assert_not_found_page_displayed(self):
        self.assert_presence(
            self.L_I18N_NOT_FOUND_PAGE_MESSAGE(self.lang),
            'Сообщение "Страница не найдена" отображается',
        )

    def click_delete_message_in_context_menu(self):
        delete_btn_name = i18n.get_str('chat_message_context_menu_delete_button', self.lang)
        log.step(f'Нажать кнопку "{delete_btn_name}" в контекстном меню сообщения', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_CONTEXT_MENU_DELETE_BTN(self.lang)).click()
        self.wait_absence(self.L_CHAT_MESSAGE_CONTEXT_MENU())
        self.wait_presence(self.L_DELETE_MESSAGE_CONFIRM_DIALOG())

    def confirm_delete_message(self):
        log.step('Подтвердить удаление сообщения в диалоге', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_DELETE_MESSAGE_CONFIRM_BTN(self.lang)).click()
        self.wait_absence(self.L_DELETE_MESSAGE_CONFIRM_DIALOG())

    def assert_sent_message_absent(self, message: str):
        assert_fn(lambda: self.wait_absence(self.L_CHAT_MESSAGE_WITH_TEXT(text=message)),
                  f'Сообщение "{message}" отсутствует в чате')

    def assert_link_redirect_correct(self, real_link: str):
        windows = self.driver.window_handles
        self.driver.switch_to.window(windows[1])
        if self.driver.name == 'firefox':
            WebDriverWait(self.driver, 15).until(
                lambda _: self.driver.current_url != 'about:blank' and self.is_page_opened()
            )
        cur_url = self.driver.current_url
        log.info(f'Текущий url: "{cur_url}"')
        assert_fn(lambda: real_link in cur_url, f'Произошел переход на страницу "{real_link}"')

    def click_search_btn(self):
        log.step('Нажать кнопку поиска в чате', where='IVA ONE WEB Клиент')
        self.get_object(self.L_CHAT_SEARCH_BTN()).click()
        self.wait_presence(self.L_CHAT_SEARCH_PANEL())

    def assert_search_panel_visible(self):
        self.assert_presence(self.L_CHAT_SEARCH_PANEL(), 'Панель поиска по сообщениям отображается')
        self.assert_presence(self.L_CHAT_SEARCH_INPUT(), 'Поле ввода поиска отображается')

    def search_message(self, text: str):
        search_input = self.get_object(self.L_CHAT_SEARCH_INPUT())
        search_input.click()
        log.step(f'Ввести "{text}" в поле поиска сообщений', where='IVA ONE WEB Клиент')
        search_input.send_keys(text)

    def type_mention(self, user_name: str):
        log.step(f'Ввести "@{user_name}" в поле ввода для упоминания', where='IVA ONE WEB Клиент')
        chat_input = self.get_object(self.L_CHAT_INPUT())
        chat_input.send_keys(f'@{user_name}')
        # Ждём именно СТРОКУ нужного пользователя в попапе. У свежесозданного user'а строка
        # подтягивается с задержкой по мере индексации в адресной книге IVA (после prewarm-login'а):
        # ждём её достаточно долгим НЕпрерывным окном (повторный набор сбрасывает debounce-поиск),
        # а между окнами мягко перезапускаем поиск (backspace + повтор последнего символа) на случай,
        # если попап скрылся из-за пустого результата. Для уже проиндексированного user'а — мгновенно.
        user_item = self.L_MENTION_POPUP_USER_ITEM(user_name)
        for attempt in range(1, 7):
            try:
                self.wait_presence(user_item, 8)
                return
            except TimeoutException:
                if attempt == 6:
                    raise
                log.warning(f'Пользователь "{user_name}" не появился в попапе упоминания, повтор поиска ({attempt}/5)')
                chat_input.send_keys(Keys.BACKSPACE)
                chat_input.send_keys(user_name[-1])

    def trigger_mention_popup(self):
        # Ввести только "@" — попап покажет доступных адресатов без фильтра по имени.
        # В личном чате собеседник появляется в попапе именно так (по "@имя" попап не появляется).
        log.step('Ввести "@" в поле ввода для вызова попапа упоминаний', where='IVA ONE WEB Клиент')
        self.get_object(self.L_CHAT_INPUT()).send_keys('@')
        self.wait_presence(self.L_MENTION_POPUP())

    def assert_mention_popup_visible(self):
        self.assert_presence(self.L_MENTION_POPUP(), 'Попап выбора пользователей для упоминания отображается')

    def select_user_in_mention_popup(self, user_name: str):
        log.step(f'Выбрать пользователя "{user_name}" из попапа упоминания', where='IVA ONE WEB Клиент')
        self.get_object(self.L_MENTION_POPUP_USER_ITEM(user_name)).click()
        self.wait_absence(self.L_MENTION_POPUP())

    def assert_mention_in_input(self, user_name: str):
        self.assert_presence(self.L_MENTION_IN_INPUT(user_name),
                             f'Упоминание "@{user_name}" отображается в поле ввода')

    def assert_mention_in_message(self, user_name: str):
        self.assert_presence(self.L_MENTION_IN_MESSAGE(user_name),
                             f'Упоминание "@{user_name}" присутствует в отправленном сообщении')

    def assert_mention_color_differs_from_text(self, user_name: str, text: str):
        mention_color = self.get_object(self.L_MENTION_COLOR_NODE(user_name)).value_of_css_property('color')
        text_color = self.get_object(self.L_CHAT_MESSAGE_WITH_TEXT(text)).value_of_css_property('color')
        assert_fn(lambda: mention_color != text_color,
                  f'Цвет упоминания "{mention_color}" отличается от цвета обычного текста "{text_color}"')

    def assert_link_in_message(self, link: str):
        self.assert_presence(self.L_CHAT_MESSAGE_WITH_VISIBLE_LINK(link),
                             f'Ссылка "{link}" присутствует в отправленном сообщении')

    def assert_link_color_differs_from_text(self, link: str, text: str):
        # Узел цвета ссылки — сам <a> (L_CHAT_MESSAGE_WITH_VISIBLE_LINK).
        link_color = self.get_object(self.L_CHAT_MESSAGE_WITH_VISIBLE_LINK(link)).value_of_css_property('color')
        text_color = self.get_object(self.L_CHAT_MESSAGE_WITH_TEXT(text)).value_of_css_property('color')
        assert_fn(lambda: link_color != text_color,
                  f'Цвет ссылки "{link_color}" отличается от цвета обычного текста "{text_color}"')

    def assert_mention_chevron_visible(self):
        self.assert_presence(self.L_MENTION_CHEVRON(), 'Шеврон упоминания отображается в чате')

    def click_mention_chevron(self):
        log.step('Нажать на шеврон упоминания для перехода к сообщению', where='IVA ONE WEB Клиент')
        self.get_object(self.L_MENTION_CHEVRON()).click()
        self.wait_absence(self.L_MENTION_CHEVRON())

    def click_pin_in_context_menu(self):
        pin_button_name = i18n.get_str('chat_message_context_menu_pin_button', self.lang)
        log.step(f'Нажать кнопку "{pin_button_name}" в контекстном меню сообщения', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_CONTEXT_MENU_PIN_BTN(self.lang)).click()
        self.wait_absence(self.L_CHAT_MESSAGE_CONTEXT_MENU())

    def copy_message_from_context_menu(self):
        log.step('Нажать "Скопировать" в контекстном меню сообщения', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_CONTEXT_MENU_COPY_BTN(self.lang)).click()
        self.wait_absence(self.L_CHAT_MESSAGE_CONTEXT_MENU(), 2)

    def click_info_in_context_menu(self):
        log.step('Нажать "Информация" в контекстном меню сообщения', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_CONTEXT_MENU_INFO_BTN(self.lang)).click()
        self.wait_absence(self.L_CHAT_MESSAGE_CONTEXT_MENU(), 2)

    def assert_message_info_dialog_with_author(self, author_name: str):
        log.step(f'Открыто окно "Информация о сообщении", автор — "{author_name}"', where='IVA ONE WEB Клиент')
        self.wait_presence(self.L_MESSAGE_INFO_DIALOG())
        self.wait_presence(self.L_MESSAGE_INFO_AUTHOR_ITEM(author_name))

    def assert_message_in_clipboard(self, expected_text: str):
        log.step(f'Сообщение "{expected_text}" находится в буфере обмена', where='IVA ONE WEB Клиент')
        chat_input_locator = self.L_CHAT_INPUT()
        # Вставляем содержимое буфера в инпут чата (cross-browser paste из autocore.PBase)
        self.paste(chat_input_locator)
        actual = (self.get_object(chat_input_locator).text or '').strip()
        # Очистить инпут чата, чтобы не мешать teardown (cross-browser clear_input из autocore.PBase)
        self.clear_input(chat_input_locator)
        assert actual == expected_text, \
            f'В инпуте чата после вставки: "{actual}", ожидалось: "{expected_text}"'

    def hover_reactions_in_context_menu(self):
        log.step('Навести мышь на пункт "реакции" в контекстном меню сообщения', where='IVA ONE WEB Клиент')
        self.move_to_element(self.L_I18N_CONTEXT_MENU_REACTIONS_MENU_ITEM(self.lang))
        self.wait_presence(self.L_REACTIONS_USERS_POPOVER(), 5)

    def assert_context_menu_info_button_absent(self):
        log.step('Кнопка "Информация" отсутствует в контекстном меню сообщения', where='IVA ONE WEB Клиент')
        assert_fn(lambda: self.wait_absence(self.L_I18N_CONTEXT_MENU_INFO_BTN(self.lang), 2),
                  'Кнопка "Информация" отсутствует в контекстном меню сообщения')

    def assert_context_menu_info_button_visible(self):
        self.assert_presence(self.L_I18N_CONTEXT_MENU_INFO_BTN(self.lang),
                             'Кнопка "Информация" присутствует в контекстном меню сообщения')

    def assert_copy_link_menu_item_absent(self):
        assert_fn(lambda: self.wait_absence(self.L_I18N_CONTEXT_MENU_COPY_LINK_BTN(self.lang), 2),
                  'Пункт "Скопировать ссылку" отсутствует в контекстном меню сообщения')

    def assert_copy_link_menu_item_visible(self):
        self.assert_presence(self.L_I18N_CONTEXT_MENU_COPY_LINK_BTN(self.lang),
                             'Пункт "Скопировать ссылку" присутствует в контекстном меню сообщения')

    def assert_reaction_user_visible(self, user_name: str):
        self.assert_presence(
            self.L_REACTIONS_USERS_ROW_BY_NAME(user_name),
            f'Пользователь "{user_name}" отображается в попапе реакций'
        )

    def set_reaction_from_context_menu(self, reaction: ChatUsersReactions):
        log.step(f'Установить реакцию "{reaction.name}" из контекстного меню', where='IVA ONE WEB Клиент')
        self.get_object(self.L_REACTION_PICKER_BUTTON(reaction)).click()
        self.wait_absence(self.L_CHAT_MESSAGE_CONTEXT_MENU())

    def assert_reaction_under_message(self, message_text: str, reaction: ChatUsersReactions):
        self.assert_presence(
            self.L_MESSAGE_REACTION_CHIP(message_text, reaction),
            f'Под сообщением "{message_text}" установлена реакция "{reaction.name}"'
        )

    def assert_pin_system_message_exists(self, user_name: str):
        self.assert_presence(self.L_I18N_CHAT_PIN_SYSTEM_MESSAGE(user_name, self.lang),
                             f'Системное сообщение о закреплении от "{user_name}" присутствует в чате')

    def assert_channel_renamed_system_message(self, new_name: str):
        self.assert_presence(self.L_I18N_CHAT_SYSTEM_MESSAGE_RENAMED_CHANNEL(new_name, self.lang),
                             f'Системное сообщение об изменении названия канала на "{new_name}" присутствует в чате')

    def assert_user_added_system_message_exists(self, actor_name: str, member_name: str):
        self.assert_presence(
            self.L_I18N_CHAT_SYSTEM_MESSAGE_USER_ADDED(actor_name, member_name, self.lang),
            f'Системное сообщение о добавлении "{member_name}" пользователем "{actor_name}" присутствует в чате'
        )

    def close_message_context_menu(self):
        log.step('Закрыть контекстное меню сообщения', where='IVA ONE WEB Клиент')
        ActionChains(self.driver).send_keys(Keys.ESCAPE).perform()
        self.wait_absence(self.L_CHAT_MESSAGE_CONTEXT_MENU())

    def assert_reactions_picker_menu_visible(self):
        self.assert_presence(self.L_REACTIONS_PICKER_MENU(),
                             'Бар выбора реакций отображается в контекстном меню сообщения')

    def assert_reactions_picker_menu_absent(self):
        assert_fn(lambda: self.wait_absence(self.L_REACTIONS_PICKER_MENU()),
                  'Бар выбора реакций отсутствует в контекстном меню сообщения')

    def assert_thread_menu_item_visible(self):
        self.assert_presence(self.L_I18N_CONTEXT_MENU_START_THREAD_BTN(self.lang),
                             'Пункт "Начать тред" отображается в контекстном меню сообщения')

    def assert_thread_menu_item_absent(self):
        assert_fn(lambda: self.wait_absence(self.L_I18N_CONTEXT_MENU_START_THREAD_BTN(self.lang)),
                  'Пункт "Начать тред" отсутствует в контекстном меню сообщения')

    def assert_message_is_pinned(self, message_text: str):
        self.assert_presence(self.L_CHAT_PINNED_MESSAGE_BAR(message_text),
                             f'Сообщение "{message_text}" закреплено и отображается в панели закреплённого сообщения')

    def click_pinned_message(self, message_text: str):
        """Нажать на закреплённое сообщение сверху в чате — выполняется переход к сообщению в ленте."""
        log.step('Нажать на закрепленное сообщение (переход к сообщению)', where='IVA ONE WEB Клиент')
        self.get_object(self.L_CHAT_PINNED_MESSAGE_BAR(message_text)).click()

    def click_pinned_list_open_btn(self):
        """Открыть экран со списком закреплённых сообщений (иконка `list` рядом с pinned bar)."""
        log.step('Открыть список закреплённых сообщений', where='IVA ONE WEB Клиент')
        self.get_object(self.L_PINNED_LIST_OPEN_BTN()).click()

    def assert_message_highlighted(self, message: str):
        self.assert_presence(self.L_MESSAGE_HIGHLIGHTING(message),
                             f'Сообщение "{message}" выделено')

    def click_own_message_avatar(self):
        log.step('Нажать на аватар собственного сообщения в области чата', where='IVA ONE WEB Клиент')
        self.get_object(self.L_OWN_MESSAGE_AVATAR()).click()

    def attach_file(self, file_name: str):
        log.step(f'Прикрепить файл "{file_name}"', where='IVA ONE WEB Клиент')
        # Композер дорисовывается асинхронно после открытия чата: ждём видимую кнопку
        # прикрепления; сам input[type=file] скрыт (wait_presence его не дождётся).
        self.wait_presence(self.L_ATTACHMENT_BTN())
        file_input = self.driver.find_element(*self.L_ATTACHMENT_FILE_INPUT())
        local_path = os.path.join(TEST_DATA_DIR, file_name)

        if self.driver.name in ['Safari', 'firefox']:
            upload_file_via_js(self.driver, file_input, local_path)
        else:
            file_input.send_keys(local_path)
        self.wait_presence(self.L_ATTACHMENT_CONTAINER())
        self.wait_absence(self.L_ATTACHMENT_BTN())

    def start_file_upload(self, file_name: str, throttle_ms: int = 1500):
        """Прикрепить файл и дождаться, что чанковая загрузка реально пошла (но ещё не
        завершилась). Чанки `POST /uploads/<id>/parts` стартуют сразу при выборе файла
        (ДО клика «Отправить»). Троттлинг включается заранее, чтобы окно «середина
        загрузки» было устойчиво ловимым на быстром стенде (иначе 30-50 МБ улетают за
        доли секунды и оборвать в процессе не успеваем)."""
        reset_upload_tracking(self.driver)
        network.prepare(self.driver, throttle_ms=throttle_ms)
        self.attach_file(file_name)
        self.assert_presence(self.L_ATTACHMENT_CARD(),
                             f'Карточка загрузки файла "{file_name}" отображается')
        self._wait_upload_in_progress()

    def _wait_upload_in_progress(self, timeout: int = 20):
        log.step('Дождаться, что загрузка файла пошла (чанки отправляются)', where='IVA ONE WEB Клиент')
        end_time = time.time() + timeout
        while time.time() < end_time:
            if upload_completed(self.driver):
                break
            if count_upload_parts(self.driver) >= 1:
                return
            time.sleep(0.2)
        raise AssertionError(
            'Не удалось поймать загрузку в процессе: файл загрузился слишком быстро. '
            'Увеличь размер файла или throttle_ms.'
        )

    def assert_upload_stalled(self, settle: float = 2.0, freeze_window: int = 6):
        """Проверить, что во время обрыва сети загрузка ВСТАЛА: счётчик доехавших чанков
        не растёт freeze_window секунд и загрузка не завершилась. Перед замером — пауза
        settle, чтобы «хвосты» запросов, висевшие в полёте на момент обрыва, осели."""
        log.step('Проверить, что загрузка остановилась при обрыве сети', where='IVA ONE WEB Клиент')
        time.sleep(settle)
        parts_before = count_upload_parts(self.driver)
        time.sleep(freeze_window)
        parts_after = count_upload_parts(self.driver)
        completed = upload_completed(self.driver)
        assert_fn(
            lambda: parts_after == parts_before and not completed,
            f'Загрузка остановлена при обрыве: чанки заморожены ({parts_before}→{parts_after}), '
            f'загрузка не завершена (complete={completed})'
        )

    def assert_upload_resumed(self, timeout: int = 90):
        """Проверить, что после восстановления сети загрузка возобновилась и завершилась:
        счётчик чанков снова растёт и наступает `POST /uploads/<id>/complete`."""
        log.step('Проверить, что загрузка возобновилась и завершилась после восстановления сети',
                 where='IVA ONE WEB Клиент')
        parts_before = count_upload_parts(self.driver)
        end_time = time.time() + timeout
        grew = False
        while time.time() < end_time:
            if count_upload_parts(self.driver) > parts_before:
                grew = True
            if upload_completed(self.driver):
                break
            time.sleep(0.5)
        completed = upload_completed(self.driver)
        assert_fn(
            lambda: completed and grew,
            f'Загрузка возобновилась (чанки пошли: {grew}) и завершилась (complete={completed}) '
            f'после восстановления сети'
        )

    def assert_audio_message_exists(self, file_name: str):
        self.assert_presence(
            self.L_AUDIO_MESSAGE(file_name),
            f'Аудиосообщение "{file_name}" отображается в чате'
        )

    def click_audio_play(self, file_name: str):
        log.step(f'Нажать Play на аудиосообщении "{file_name}"', where='IVA ONE WEB Клиент')
        self.get_object(self.L_AUDIO_PLAY_BUTTON(file_name)).click()

    def assert_audio_playing(self, file_name: str, timeout: int = 10):
        """Воспроизведение запустилось по клику Play: внутри карточки аудио появился <audio>
        (источник — сконвертированный mp3 из поля audio.mp3Url) и его currentTime сдвинулся с нуля.

        Проверяем факт продвижения currentTime (>0), а не «не на паузе»: семпл короткий (~3с)
        и успевает доиграть и встать на паузу раньше первой проверки (paused тут рейсовый)."""
        js = (
            "const name = arguments[0];"
            "for (const m of document.querySelectorAll('chat-audio-message')) {"
            "  const n = m.querySelector('.name');"
            "  if (n && n.textContent.trim() === name) {"
            "    const a = m.querySelector('audio');"
            "    return !!a && a.error === null && a.currentTime > 0;"
            "  }"
            "}"
            "return false;"
        )
        end_time = time.time() + timeout
        playing = False
        while time.time() < end_time:
            playing = self.driver.execute_script(js, file_name)
            if playing:
                break
            time.sleep(0.3)
        assert_fn(lambda: playing,
                  f'Воспроизведение аудио "{file_name}" запустилось (создан <audio> из mp3, currentTime сдвинулся с нуля)')

    def assert_audio_loaded_via_mp3(self, audio_id: str):
        """Контент аудио загружен по новому полю audio.mp3Url (/uploads/{id}/mp3), не оригиналом."""
        assert_fn(lambda: media_resource_loaded(self.driver, audio_id, 'mp3'),
                  f'Аудио загружено по ссылке /uploads/{audio_id}/mp3 (поле audio.mp3Url)')

    def click_video_message(self, file_name: str):
        log.step(f'Открыть видео "{file_name}" в просмотрщике', where='IVA ONE WEB Клиент')
        self.get_object(self.L_VIDEO_OPEN_BUTTON(file_name)).click()

    def assert_media_resource_loaded(self, upload_id: str, suffix: str, message: str, timeout: int = 10):
        """Дождаться, что ресурс /uploads/{upload_id}/{suffix} загружен с контентом
        (decodedBodySize>0). suffix: 'preview' | 'preview/video' | 'mp3' | 'download'."""
        end_time = time.time() + timeout
        loaded = False
        while time.time() < end_time:
            loaded = media_resource_loaded(self.driver, upload_id, suffix)
            if loaded:
                break
            time.sleep(0.3)
        assert_fn(lambda: loaded, message)

    def assert_no_original_download(self, media_ids=None):
        """Клиент не качал оригинал медиа по /download (превью берутся из /preview*).
        HEAD-access-check и аватары игнорируются (см. page_helpers)."""
        assert_no_original_media_download(self.driver, media_ids)

    def assert_feed_rendered(self):
        """Лента чата отрендерилась (нет white-screen / WSOD): есть скроллер и сообщения."""
        self.assert_presence(self.L_CHAT_SCROLLER(), 'Лента чата отрендерилась (без white-screen)')
        self.assert_presence(self.L_CHAT_MESSAGE_CONTAINER(), 'В ленте отображаются сообщения')

    def scroll_feed_to_oldest_message(self, oldest_text: str, max_scrolls: int = 40):
        """Проскроллить ленту вверх к самым ранним сообщениям реальным wheel-жестом (CDP).

        Backward-скроллер (`<chat-scroller>`) игнорирует программный scrollTop (сам держит
        позицию по якорю) и подгружает старые сообщения только на доверенный wheel —
        поэтому крутим CDP `Input.dispatchMouseEvent type=mouseWheel`, а не scrollTop.
        Скроллим, пока не подгрузится сообщение с точным текстом `oldest_text` (самое раннее
        за прослойкой) — это доказательство, что прошли всю прослойку (иначе зелёный assert
        медиа мог бы сматчить тот же файл из нижнего набора). Затем ещё несколько прокруток —
        поднять первый набор медиа (он выше `oldest_text`) в загруженную/отрисованную область.
        """
        log.step(f'Проскроллить ленту вверх к самым ранним сообщениям (до "{oldest_text}")',
                 where='IVA ONE WEB Клиент')
        locator = self.L_CHAT_MESSAGE_WITH_EXACT_TEXT(oldest_text)
        center = self.driver.execute_script(
            "const sc = document.evaluate('//chat-scroller', document, null, 9, null).singleNodeValue;"
            "const r = sc.getBoundingClientRect();"
            "return {x: Math.round(r.x + r.width / 2), y: Math.round(r.y + r.height / 2)};")
        reached = False
        extra = 0
        for _ in range(max_scrolls):
            if not reached and self.driver.find_elements(locator[0], locator[1]):
                reached = True
            if reached:
                extra += 1
                if extra > 4:
                    break
            network.cdp_cmd(self.driver, 'Input.dispatchMouseEvent', {
                'type': 'mouseWheel', 'x': center['x'], 'y': center['y'],
                'deltaX': 0, 'deltaY': -700})
            time.sleep(0.5)
        assert_fn(lambda: reached,
                  f'Лента доскроллена вверх до самого раннего сообщения "{oldest_text}" (прослойка пройдена)')

    def click_voice_record_btn(self):
        log.step('Нажать кнопку микрофона для записи голосового сообщения', where='IVA ONE WEB Клиент')
        self.get_object(self.L_VOICE_RECORD_BTN()).click()
        self.wait_presence(self.L_VOICE_RECORDER())

    def send_voice_message(self, record_seconds: int = 2):
        log.step(f'Записать голосовое сообщение ({record_seconds}с) и нажать "Отправить"',
                 where='IVA ONE WEB Клиент')
        time.sleep(record_seconds)
        self.get_object(self.L_VOICE_RECORDING_SEND_BTN()).click()

    def assert_voice_message_visible(self, message='Голосовое сообщение отображается в чате'):
        self.assert_presence(self.L_VOICE_MESSAGE_IN_CHAT(), message)

    def assert_video_message_exists(self, file_name: str):
        self.assert_presence(
            self.L_VIDEO_MESSAGE(file_name),
            f'Видеосообщение "{file_name}" отображается в чате'
        )

    def assert_image_message_exists(self, file_name: str):
        self.assert_presence(
            self.L_IMAGE_MESSAGE(file_name),
            f'Изображение "{file_name}" отображается в чате'
        )

    def assert_document_message_exists(self, file_name: str):
        self.assert_presence(
            self.L_DOCUMENT_MESSAGE(file_name),
            f'Документ "{file_name}" отображается в чате'
        )

    def open_chat_by_url(self, url):
        log.step(f'Открыть чат по URL: {url}', where='IVA ONE WEB Клиент')
        self.open_url(url)

    def assert_join_btn_visible(self, is_channel: bool = False):
        self.assert_presence(
            self.L_I18N_JOIN_BTN(self.lang, is_channel),
            'Кнопка вступления отображается вместо поля ввода сообщения',
        )

    def click_join_btn(self, is_channel: bool = False):
        log.step('Нажать кнопку вступления в чат', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_JOIN_BTN(self.lang, is_channel)).click()
        # После присоединения кнопка «Вступить/Подписаться» уходит. У группы дополнительно
        # появляется поле ввода (новый member может писать); у канала рядовому подписчику
        # инпут не показывается (писать в инф.канал может только админ) — поэтому для
        # канала достаточно дождаться исчезновения кнопки вступления.
        self.wait_absence(self.L_I18N_JOIN_BTN(self.lang, is_channel))
        if not is_channel:
            self.wait_presence(self.L_CHAT_INPUT())

    def assert_message_found_in_search(self, text: str, max_retries: int = 8, retry_delay: int = 3):
        """Проверяет подсветку найденного сообщения. При задержке поискового индекса сбрасывает запрос кнопкой ✕ внутри поля поиска и повторяет поиск — это обходит кешированное состояние «0 результатов»."""
        for attempt in range(max_retries):
            try:
                self.wait_presence(self.L_CHAT_SEARCH_HIGHLIGHT(text), 4)
                break
            except TimeoutException:
                if attempt < max_retries - 1:
                    log.step(f'Результат не найден, сброс и повтор поиска (попытка {attempt + 2} из {max_retries})', where='IVA ONE WEB Клиент')
                    self.get_object(self.L_CHAT_SEARCH_RESET_BTN()).click()
                    time.sleep(retry_delay)
                    self.search_message(text)
        self.assert_presence(self.L_CHAT_SEARCH_HIGHLIGHT(text),
                             f'Сообщение "{text}" найдено и подсвечено в результатах поиска')


class PVersion2Chat(_PVersionChat, Version2Locators.LChat):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.version = 'Version2'
        self.toast = chunks.get_chunk(self.version, 'toast')(driver=self.driver, lang=self.lang)
        self.forward_dialog = chunks.get_chunk(self.version, 'forward_dialog')(driver=self.driver, lang=self.lang)
