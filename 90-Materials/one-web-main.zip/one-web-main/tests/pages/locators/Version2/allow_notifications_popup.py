from tools import i18n


class LAllowNotificationsPopup:
    @staticmethod
    def L_I18N_HEADER(lang):
        i18n_str = i18n.get_str('allow_notifications_title', lang)
        return 'xpath', f'//msg-enable-push-notifications-dialog//div[@class="title" and text()="{i18n_str}"]'

    @staticmethod
    def L_I18N_BTN_OK(lang):
        i18n_str = i18n.get_str('allow_notifications_allow_btn', lang)
        return 'xpath', f'//msg-enable-push-notifications-dialog//button[contains(.,"{i18n_str}")]'
