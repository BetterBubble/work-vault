from tools import i18n, enums


class LChatInputEditLinkPopup:
    @staticmethod
    def L_ROOT(lang=''):
        return 'xpath', '//pm-editor-link-dialog'

    @staticmethod
    def L_I18N_ADD_BTN(lang):
        i18n_str = i18n.get_str('chat_input_edit_link_popup_add_btn', lang)
        return 'xpath', f'{LChatInputEditLinkPopup.L_ROOT(lang)[1]}//button[contains(.,"{i18n_str}")]'

    @staticmethod
    def L_I18N_SECTION_BY_LABEL(lang, label: enums.ChatInputEditLinkPopupLabels):
        i18n_str = i18n.get_str(f'chat_input_edit_link_popup_{label}_label', lang)
        return 'xpath', f'//iva-form-field[.//label[contains(.,"{i18n_str}")]]'

    @staticmethod
    def L_I18N_LINK_INPUT(lang):
        return 'xpath', f'{LChatInputEditLinkPopup.L_I18N_SECTION_BY_LABEL(lang, enums.ChatInputEditLinkPopupLabels.LINK)[1]}//input'
