from tools import i18n


class LCreateChatPopup:
    """Локаторы wizard'а создания чата (`<chat-create-chat-dialog>`)."""

    @staticmethod
    def L_ROOT(lang=''):
        return 'xpath', '//chat-create-chat-dialog'

    @staticmethod
    def L_STEP1_ROOT(lang=''):
        return 'xpath', '//chat-contacts-list-step'

    @staticmethod
    def L_I18N_STEP1_GROUP_TITLE(lang):
        i18n_str = i18n.get_str('create_chat_step1_group_title', lang)
        # iva-сборка (2.1.0): заголовок шага — div.title в iva-header модалки (был <p>).
        return 'xpath', (
            f'{LCreateChatPopup.L_STEP1_ROOT()[1]}'
            f'//div[contains(@class,"title") and normalize-space()="{i18n_str}"]'
        )

    @staticmethod
    def L_I18N_SEARCH_INPUT(lang):
        i18n_str = i18n.get_str('contacts_search_input', lang)
        return 'xpath', (
            f'{LCreateChatPopup.L_STEP1_ROOT()[1]}'
            f'//input[@placeholder="{i18n_str}"]'
        )

    @staticmethod
    def L_CONTACT_ROW(full_name, lang=''):
        # ds→iva: таблица контактов переехала на contacts-table/contacts-contact-name (как в address_book).
        return 'xpath', (
            f'{LCreateChatPopup.L_STEP1_ROOT()[1]}'
            f'//contacts-table//div[contains(@class,"table-row")]'
            f'[.//contacts-contact-name[normalize-space()="{full_name}"]]'
        )

    @staticmethod
    def L_I18N_NEXT_BTN(lang):
        i18n_str = i18n.get_str('create_chat_next_btn', lang)
        return 'xpath', (
            f'{LCreateChatPopup.L_STEP1_ROOT()[1]}'
            f'//button[@ivabutton][normalize-space()="{i18n_str}"]'
        )

    @staticmethod
    def L_STEP2_GROUP_ROOT(lang=''):
        return 'xpath', '//chat-create-group-step'

    @staticmethod
    def L_STEP2_CHANNEL_ROOT(lang=''):
        return 'xpath', '//chat-create-channel-step'

    @staticmethod
    def L_STEP2_ROOT(lang=''):
        return 'xpath', (
            f'({LCreateChatPopup.L_STEP2_GROUP_ROOT()[1]}'
            f' | {LCreateChatPopup.L_STEP2_CHANNEL_ROOT()[1]})'
        )

    @staticmethod
    def L_I18N_STEP1_CHANNEL_TITLE(lang):
        i18n_str = i18n.get_str('create_chat_step1_channel_title', lang)
        # iva-сборка (2.1.0): заголовок шага — div.title в iva-header модалки (был <p>).
        return 'xpath', (
            f'{LCreateChatPopup.L_STEP1_ROOT()[1]}'
            f'//div[contains(@class,"title") and normalize-space()="{i18n_str}"]'
        )

    @staticmethod
    def L_NAME_INPUT(lang=''):
        return 'xpath', f'{LCreateChatPopup.L_STEP2_ROOT()[1]}//input[@formcontrolname="name"]'

    @staticmethod
    def L_I18N_CREATE_GROUP_BTN(lang):
        i18n_str = i18n.get_str('create_chat_create_group_btn', lang)
        # iva-билд: кнопка — <button ivaButton> с текстом прямо в кнопке (не во вложенном
        # элементе, как на ds с @dsprimarybutton) → матчим собственный текст кнопки.
        return 'xpath', (
            f'{LCreateChatPopup.L_STEP2_GROUP_ROOT()[1]}'
            f'//button[@ivabutton][normalize-space()="{i18n_str}"]'
        )

    @staticmethod
    def L_I18N_CREATE_CHANNEL_BTN(lang):
        i18n_str = i18n.get_str('create_chat_create_channel_btn', lang)
        return 'xpath', (
            f'{LCreateChatPopup.L_STEP2_CHANNEL_ROOT()[1]}'
            f'//button[@ivabutton][normalize-space()="{i18n_str}"]'
        )

    @staticmethod
    def L_PUBLIC_TOGGLE_INPUT(lang=''):
        return 'xpath', (
            f'{LCreateChatPopup.L_STEP2_ROOT()[1]}'
            f'//iva-toggle[@formcontrolname="isPublic"]//input[@type="checkbox"]'
        )

    @staticmethod
    def L_PUBLIC_TOGGLE_SWITCH(lang=''):
        return 'xpath', (
            f'{LCreateChatPopup.L_STEP2_ROOT()[1]}'
            f'//iva-toggle[@formcontrolname="isPublic"]'
        )

    @staticmethod
    def L_AVATAR_WIDGET(lang=''):
        return 'xpath', f'{LCreateChatPopup.L_STEP2_ROOT()[1]}//chat-avatar-loading'

    @staticmethod
    def L_AVATAR_EDIT_HOST(lang=''):
        # iva-сборка: кликабельный хост ivaFilePicker; по клику лениво создаёт <input type=file>
        # на document.body (см. page_helpers.upload_avatar_via_lazy_picker). Статического инпута нет.
        return 'xpath', f'{LCreateChatPopup.L_AVATAR_WIDGET()[1]}//iva-avatar-edit'

    @staticmethod
    def L_AVATAR_PREVIEW_IMAGE(lang=''):
        return 'xpath', f'{LCreateChatPopup.L_AVATAR_WIDGET()[1]}//iva-avatar//img'

    @staticmethod
    def L_MEMBER_ITEM(full_name, lang=''):
        # Участник в списке предзаполненных (окно создания группы из мультиселекта адресной книги).
        return 'xpath', f'{LCreateChatPopup.L_STEP2_GROUP_ROOT()[1]}//ul/li[.//*[contains(normalize-space(),"{full_name}")]]'
