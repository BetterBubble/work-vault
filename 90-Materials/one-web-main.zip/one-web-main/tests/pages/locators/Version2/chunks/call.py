from tools import i18n


class LCall:
    """Локаторы окна звонка `<web-call-window>` (входящий — с accept-button; активный —
    с `<calls-active-call-duration>`) и диалога «Настройка оборудования». Разделы диалога
    в UI: «Камера»/«Микрофон»/«Динамики»."""

    @staticmethod
    def L_CALL_WINDOW(lang=''):
        return 'xpath', '//web-call-window'

    @staticmethod
    def L_CALL_ACTIVE_MARKER(lang=''):
        return 'xpath', f'{LCall.L_CALL_WINDOW()[1]}//calls-active-call-duration'

    @staticmethod
    def L_INCOMING_CALL_NOTIFICATION(lang=''):
        return 'xpath', f'{LCall.L_CALL_WINDOW()[1]}[.//button[contains(@class,"accept-button")]]'

    @staticmethod
    def L_INCOMING_CALL_ACCEPT_BTN(lang=''):
        return 'xpath', f'{LCall.L_CALL_WINDOW()[1]}//button[contains(@class,"accept-button")]'

    @staticmethod
    def L_CALL_DECLINE_BTN(lang=''):
        # Красная кнопка завершения/сброса звонка (iva-icon-finish-call-line-big).
        return 'xpath', f'{LCall.L_CALL_WINDOW()[1]}//button[contains(@class,"decline-button")]'

    @staticmethod
    def L_CALL_MORE_MENU_BTN(lang=''):
        return 'xpath', '//calls-menu-button//button[contains(@class,"cdk-menu-trigger")]'

    @staticmethod
    def L_I18N_CALL_EQUIPMENT_MENU_ITEM(lang):
        i18n_str = i18n.get_str('call_equipment_menu_item', lang)
        # Меню звонка мигрировало на iva-menu: пункты — button[ivamenuitem], текст в div.label.
        return 'xpath', (
            f'//iva-menu[@role="menu"]'
            f'//button[@role="menuitem"][.//div[@class="label" and normalize-space()="{i18n_str}"]]'
        )

    @staticmethod
    def L_CALL_EQUIPMENT_DIALOG(lang=''):
        return 'xpath', '//call-settings-device-dialog'

    @staticmethod
    def L_I18N_CALL_EQUIPMENT_DIALOG_TITLE(lang):
        i18n_str = i18n.get_str('call_equipment_dialog_title', lang)
        return 'xpath', f'{LCall.L_CALL_EQUIPMENT_DIALOG()[1]}//div[contains(@class,"title")][normalize-space()="{i18n_str}"]'

    @staticmethod
    def L_I18N_CALL_EQUIPMENT_VIDEO_SECTION(lang):
        i18n_str = i18n.get_str('call_equipment_section_camera', lang)
        return 'xpath', f'{LCall.L_CALL_EQUIPMENT_DIALOG()[1]}//h3[contains(@class,"label")][normalize-space()="{i18n_str}"]'

    @staticmethod
    def L_I18N_CALL_EQUIPMENT_AUDIO_SECTION(lang):
        i18n_str = i18n.get_str('call_equipment_section_microphone', lang)
        return 'xpath', f'{LCall.L_CALL_EQUIPMENT_DIALOG()[1]}//h3[contains(@class,"label")][normalize-space()="{i18n_str}"]'

    @staticmethod
    def L_I18N_CALL_EQUIPMENT_SOUND_SECTION(lang):
        i18n_str = i18n.get_str('call_equipment_section_speakers', lang)
        return 'xpath', f'{LCall.L_CALL_EQUIPMENT_DIALOG()[1]}//h3[contains(@class,"label")][normalize-space()="{i18n_str}"]'
