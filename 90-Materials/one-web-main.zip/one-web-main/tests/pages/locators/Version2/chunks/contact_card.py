from tools import i18n


class LContactCard:
    """Локаторы карточки-сайдбара личного контакта (`<contacts-contact-sidebar>`).

    Меню «Ещё» и confirm-диалог рендерятся в CDK-overlay на уровне body (вне
    корня карточки), поэтому их локаторы — глобальные по role, не от L_ROOT.
    """

    @staticmethod
    def L_ROOT(lang=''):
        return 'xpath', '//contacts-contact-sidebar'

    @staticmethod
    def L_I18N_MORE_BTN(lang):
        text = i18n.get_str('contact_card_more_button', lang)
        return 'xpath', f'{LContactCard.L_ROOT()[1]}//button[normalize-space()="{text}"]'

    @staticmethod
    def L_I18N_CALL_BTN(lang):
        # Прямая кнопка «Позвонить» в карточке (рядом с «Видео»/«Ещё»).
        text = i18n.get_str('contact_card_call_button', lang)
        return 'xpath', f'{LContactCard.L_ROOT()[1]}//button[normalize-space()="{text}"]'

    @staticmethod
    def L_I18N_MENU_ITEM(key, lang):
        text = i18n.get_str(key, lang)
        return 'xpath', f'//*[@role="menu"]//*[@role="menuitem"][normalize-space()="{text}"]'

    # Секция телефонов карточки (employee-info-phone-list): доп. телефоны рендерятся lazy —
    # свёрнутые строки отсутствуют в DOM до раскрытия «Еще N» (см. dom-разведку).
    @staticmethod
    def L_ADDITIONAL_PHONE_ITEM(lang):
        # Все строки доп. телефонов (title = «Дополнительный»). Для подсчёта multiple=True.
        title = i18n.get_str('address_book_contact_additional_title', lang)
        return 'xpath', (
            f'{LContactCard.L_ROOT()[1]}//employee-info-phone-list'
            f'//employee-info-item[.//div[contains(@class,"title")][normalize-space()="{title}"]]'
        )

    @staticmethod
    def L_PHONE_EXPAND_TOGGLER(lang=''):
        # Кнопка «Еще N»/«Скрыть» секции телефонов. Якорь по классу (текст меняется);
        # scoped к employee-info-phone-list — у email-секции такая же button.toggler.
        return 'xpath', (
            f'{LContactCard.L_ROOT()[1]}//employee-info-phone-list'
            f'//button[contains(@class,"toggler")]'
        )

    @staticmethod
    def L_I18N_DELETE_DIALOG(full_name, lang):
        title = i18n.get_str('contact_delete_dialog_title', lang).format(name=full_name)
        return 'xpath', f"//*[@role='dialog'][.//*[normalize-space()='{title}']]"

    @staticmethod
    def L_I18N_DELETE_DIALOG_CONFIRM_BTN(lang):
        text = i18n.get_str('contact_delete_dialog_confirm_button', lang)
        return 'xpath', f'//*[@role="dialog"]//button[normalize-space()="{text}"]'

    # Move-picker книг (CDK-submenu из пункта «Переместить»).
    @staticmethod
    def L_MOVE_MENU(lang=''):
        return 'xpath', '//contacts-move-contacts-groups-menu'

    @staticmethod
    def L_MOVE_MENU_BOOK_NODE(book_name, lang=''):
        return 'xpath', (
            f'{LContactCard.L_MOVE_MENU()[1]}'
            f'//cdk-tree-node[.//div[contains(@class,"tree-node-name") and normalize-space()="{book_name}"]]'
            f'//a[contains(@class,"tree-node-content")]'
        )

    @staticmethod
    def L_MOVE_MENU_BOOK_NODE_ROW(book_name, lang=''):
        # Узел книги в picker'е по имени — независимо от выбираемости (для ассерта присутствия).
        return 'xpath', (
            f'{LContactCard.L_MOVE_MENU()[1]}'
            f'//cdk-tree-node[.//div[contains(@class,"tree-node-name") and normalize-space()="{book_name}"]]'
        )

    @staticmethod
    def L_MOVE_MENU_BOOK_NODE_DISABLED(book_name, lang=''):
        # Книга, недоступная для выбора: внутренний <div class="tree-node"> несёт класс
        # _not-selectable (тот же механизм, что у системных категорий). <a class="tree-node-content">
        # при этом сохраняется — поэтому маркер именно _not-selectable, а не отсутствие <a>.
        return 'xpath', (
            f'{LContactCard.L_MOVE_MENU_BOOK_NODE_ROW(book_name)[1]}'
            f'[.//div[contains(concat(" ", normalize-space(@class), " "), " _not-selectable ")]]'
        )
