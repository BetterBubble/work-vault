from tools import i18n


class LProfilePopupSettingsEquipment:

    @staticmethod
    def L_ROOT(lang=''):
        # Корень экрана оборудования (dialog:profile/settings/media-settings).
        return 'xpath', '//cdk-dialog-container//iva-media-settings'

    @staticmethod
    def L_I18N_SECTION(section_key, lang):
        # Секция устройства — HTML5 <section class="section"> (НЕ div), опознаётся по
        # заголовку h2.section-title. Микрофон/Динамики живут в <iva-audio-settings>,
        # Видео — в <iva-video-settings>; все три достижимы от корня media-settings.
        title = i18n.get_str(section_key, lang)
        return 'xpath', (
            f'{LProfilePopupSettingsEquipment.L_ROOT()[1]}'
            f'//section[@class="section"][.//h2[normalize-space()="{title}"]]'
        )

    @staticmethod
    def L_I18N_SECTION_DEVICE_RADIO(section_key, lang):
        # Radiobutton выбора устройства внутри секции. С фейковыми устройствами
        # (--use-fake-device-for-media-stream на Selenoid) в каждой секции ≥1 <iva-radio>.
        return 'xpath', f'{LProfilePopupSettingsEquipment.L_I18N_SECTION(section_key, lang)[1]}//iva-radio'

    @staticmethod
    def L_I18N_SECTION_SLIDER_LABEL(section_key, slider_label_key, lang):
        # Метка ползунка (Чувствительность/Громкость) — <label for="iva-slider-…"> внутри
        # своей секции; наличие метки подтверждает наличие соответствующего ползунка.
        label = i18n.get_str(slider_label_key, lang)
        return 'xpath', (
            f'{LProfilePopupSettingsEquipment.L_I18N_SECTION(section_key, lang)[1]}'
            f'//label[normalize-space()="{label}"]'
        )
