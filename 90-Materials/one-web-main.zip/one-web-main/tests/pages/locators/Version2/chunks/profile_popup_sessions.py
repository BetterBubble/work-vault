from tools import i18n


class LProfilePopupSessions:

    @staticmethod
    def L_ROOT(lang=''):
        return 'xpath', '//profile-ui-sessions-component'

    @staticmethod
    def L_I18N_CURRENT_SESSION_HEADER(lang):
        i18n_str = i18n.get_str('profile_sessions_header_active_session', lang)
        return 'xpath', f'{LProfilePopupSessions.L_ROOT()[1]}//h5[@class="header" and normalize-space()="{i18n_str}"]'

    @staticmethod
    def L_I18N_OTHER_SESSIONS_HEADER(lang):
        i18n_str = i18n.get_str('profile_sessions_header_other_sessions', lang)
        return 'xpath', f'{LProfilePopupSessions.L_ROOT()[1]}//h5[@class="header" and normalize-space()="{i18n_str}"]'

    @staticmethod
    def L_I18N_CURRENT_SESSION_TERMINATE_BTN(lang):
        i18n_str = i18n.get_str('profile_sessions_header_active_session', lang)
        # Кнопка «Завершить» именно в блоке «Текущий сеанс».
        # Блок = <div> (класс только ng-star-inserted, без семантики), у которого прямой child — h5.header.
        # НЕ путать с terminate-button'ами блока «Другие сеансы» (тот же class="terminate-button").
        return 'xpath', (
            f'{LProfilePopupSessions.L_ROOT()[1]}'
            f'//div[./h5[@class="header" and normalize-space()="{i18n_str}"]]'
            f'//button[contains(@class,"terminate-button")]'
        )

    @staticmethod
    def L_I18N_TERMINATE_OTHER_SESSIONS_BTN(lang):
        i18n_str = i18n.get_str('profile_sessions_button', lang)
        return 'xpath', (
            f'{LProfilePopupSessions.L_ROOT()[1]}'
            f'//div[contains(@class,"footer")]//button[normalize-space()="{i18n_str}"]'
        )

    @staticmethod
    def L_I18N_TERMINATE_SESSION_DIALOG(lang):
        i18n_str = i18n.get_str('profile_sessions_modal_header_terminate', lang)
        return 'xpath', f'//ds-dialog[.//div[contains(@class,"title") and normalize-space()="{i18n_str}"]]'

    @staticmethod
    def L_I18N_TERMINATE_SESSION_DIALOG_CONFIRM_BTN(lang):
        i18n_str = i18n.get_str('profile_sessions_button_terminate', lang)
        return 'xpath', f'{LProfilePopupSessions.L_I18N_TERMINATE_SESSION_DIALOG(lang)[1]}//button[normalize-space()="{i18n_str}"]'

    @staticmethod
    def L_I18N_TERMINATE_SESSION_DIALOG_CANCEL_BTN(lang):
        i18n_str = i18n.get_str('general_cancel_label', lang)
        return 'xpath', f'{LProfilePopupSessions.L_I18N_TERMINATE_SESSION_DIALOG(lang)[1]}//button[normalize-space()="{i18n_str}"]'

    @staticmethod
    def L_I18N_TERMINATE_OTHER_SESSIONS_DIALOG(lang):
        # В шаблоне заголовок = профиль-ключ + "?": {{ 'profile_sessions_button' | transloco }}?
        i18n_str = i18n.get_str('profile_sessions_button', lang) + '?'
        return 'xpath', f'//ds-dialog[.//div[contains(@class,"title") and normalize-space()="{i18n_str}"]]'

    @staticmethod
    def L_I18N_TERMINATE_OTHER_SESSIONS_DIALOG_CONFIRM_BTN(lang):
        i18n_str = i18n.get_str('profile_sessions_button_terminate', lang)
        return 'xpath', f'{LProfilePopupSessions.L_I18N_TERMINATE_OTHER_SESSIONS_DIALOG(lang)[1]}//button[normalize-space()="{i18n_str}"]'

    @staticmethod
    def L_I18N_TERMINATE_OTHER_SESSIONS_DIALOG_CANCEL_BTN(lang):
        i18n_str = i18n.get_str('general_cancel_label', lang)
        return 'xpath', f'{LProfilePopupSessions.L_I18N_TERMINATE_OTHER_SESSIONS_DIALOG(lang)[1]}//button[normalize-space()="{i18n_str}"]'
