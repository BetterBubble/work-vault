from tools import i18n


class LMcuConferenceSidebar:
    """Локаторы sidebar'а ВКС-конференции: форма создания и карточка созданной встречи.

    Состояния одного aux-route sidebar'а:
    - форма создания — `(sidebar:event/create/mcu)`, корень `calendar-mcu-conference-creation`
      (2.1.0; ранее `calendar-mcu-create-conference-sidebar`);
    - карточка созданной встречи — `(sidebar:event/mcu/{id})`, корень `mcu-conference-sidebar-view`;
    - форма редактирования — `(sidebar:event/mcu/conference-session-edit/{id})`, корень
      `calendar-mcu-conference-session-editing` (поля/сабмит кроются общими локаторами LCalendar).
    """

    # --- Форма создания ВКС-встречи ---
    @staticmethod
    def L_CREATE_FORM_ROOT(lang=''):
        # 2.1.0: компонент переименован (был calendar-mcu-create-conference-sidebar).
        return 'xpath', '//calendar-mcu-conference-creation'

    @staticmethod
    def L_I18N_THEME_INPUT(lang):
        placeholder = i18n.get_str('mcu_conference_theme_placeholder', lang)
        return 'xpath', f'{LMcuConferenceSidebar.L_CREATE_FORM_ROOT()[1]}//input[@placeholder="{placeholder}"]'

    @staticmethod
    def L_I18N_CREATE_BTN(lang):
        # 2.1.0: сабмит sidebar-формы — «Сохранить» даже при создании встречи
        # («Создать встречу» остался только в fullscreen-режиме формы).
        text = i18n.get_str('calendar_conference_edit_save_btn', lang)
        return 'xpath', f'{LMcuConferenceSidebar.L_CREATE_FORM_ROOT()[1]}//button[normalize-space()="{text}"]'

    # --- Карточка созданной встречи ---
    @staticmethod
    def L_DETAILS_ROOT(lang=''):
        return 'xpath', '//mcu-conference-sidebar-view'

    @staticmethod
    def L_DETAILS_TITLE(theme, lang=''):
        # Заголовок встречи = введённая тема (msg-expandable-text в шапке карточки).
        return 'xpath', (
            f'{LMcuConferenceSidebar.L_DETAILS_ROOT()[1]}'
            f'//msg-expandable-text[contains(normalize-space(.),"{theme}")]'
        )

    @staticmethod
    def L_GUEST_LINK(lang=''):
        # Гостевая ссылка организатора в карточке созданной ВКС-встречи.
        return 'xpath', f'{LMcuConferenceSidebar.L_DETAILS_ROOT()[1]}//mcu-conference-guest-link-copy'

    @staticmethod
    def L_I18N_EXTRA_LINKS_BTN(lang):
        # Сворачиваемая строка «Дополнительные ссылки» (открывает float-панель доп.ссылок).
        text = i18n.get_str('calendar_conference_extra_links_btn', lang)
        return 'xpath', (
            f'{LMcuConferenceSidebar.L_DETAILS_ROOT()[1]}'
            f'//button[contains(@class,"open-float-panel-button")][normalize-space()="{text}"]'
        )

    @staticmethod
    def L_I18N_PARTICIPANTS_COUNT(count, lang):
        # Вкладка «Участники N» — слово + счётчик отдельной нодой.
        word = i18n.get_str('mcu_conference_participants_tab', lang)
        return 'xpath', f'//iva-tab[contains(normalize-space(.),"{word}")][.//*[normalize-space()="{count}"]]'

    @staticmethod
    def L_PARTICIPANT_BY_NAME(full_name, lang=''):
        return 'xpath', (
            f'{LMcuConferenceSidebar.L_DETAILS_ROOT()[1]}'
            f'//li[contains(@class,"user")][contains(normalize-space(.),"{full_name}")]'
        )

    @staticmethod
    def L_PARTICIPANT_AVATAR_BY_NAME(full_name, lang=''):
        # Реально загруженный аватар = <img src>, не fallback-инициалы/номер телефона.
        return 'xpath', (
            f'{LMcuConferenceSidebar.L_PARTICIPANT_BY_NAME(full_name)[1]}'
            f'//img[@src and string-length(normalize-space(@src))>0]'
        )

    # --- Редактирование встречи (вход через меню «Ещё») ---
    @staticmethod
    def L_VIEW_MORE_MENU_BTN(lang=''):
        # Кнопка «More» (⋮) в шапке карточки ВКС — открывает меню Изменить/Удалить.
        # 2.1.0: у строк участников появилась своя ⋮ (participant-context-menu-button) —
        # сужаем до iva-header, иначе локатор матчит 2 кнопки.
        return 'xpath', (
            f'{LMcuConferenceSidebar.L_DETAILS_ROOT()[1]}'
            f'//iva-header//button[.//iva-icon-ellipsis-vertical]'
        )

    @staticmethod
    def L_I18N_MORE_MENU_EDIT_ITEM(lang):
        text = i18n.get_str('calendar_conference_edit_menu_item', lang)
        return 'xpath', (
            '//iva-menu[@role="menu"]'
            f'//button[@role="menuitem"][.//div[@class="label" and normalize-space()="{text}"]]'
        )

    @staticmethod
    def L_PARTICIPANT_POSITION_BY_NAME(full_name, position, lang=''):
        # Должность участника в списке участников view-карточки (рендерится при заполненной должности).
        # Зеркалит LCalendar.L_FORM_PARTICIPANT_POSITION — фильтрует по тексту должности (строгая проверка).
        return 'xpath', (
            f'{LMcuConferenceSidebar.L_PARTICIPANT_BY_NAME(full_name)[1]}'
            f'//participant-position[contains(normalize-space(),"{position}")]'
        )

    # --- Карточка глазами приглашённого: ответ на приглашение (sidebar-режим) ---
    @staticmethod
    def L_INVITATION_RESPONSE_BLOCK(lang=''):
        # Блок приглашения (Принять/Возможно/Отклонить) в подвале sidebar-карточки.
        # Рендерится только у приглашённого (hasInvitation()); после ответа исчезает.
        return 'xpath', (
            f'{LMcuConferenceSidebar.L_DETAILS_ROOT()[1]}'
            f'//calendar-event-invitation-response-sidebar'
        )

    @staticmethod
    def L_I18N_INVITATION_ACCEPT_BTN(lang):
        text = i18n.get_str('meeting_invitation_status_accept', lang)
        return 'xpath', (
            f'{LMcuConferenceSidebar.L_INVITATION_RESPONSE_BLOCK()[1]}'
            f'//button[.//span[contains(@class,"label") and normalize-space()="{text}"]]'
        )

    @staticmethod
    def L_I18N_INVITATION_MAYBE_BTN(lang):
        text = i18n.get_str('meeting_invitation_status_maybe', lang)
        return 'xpath', (
            f'{LMcuConferenceSidebar.L_INVITATION_RESPONSE_BLOCK()[1]}'
            f'//button[.//span[contains(@class,"label") and normalize-space()="{text}"]]'
        )

    @staticmethod
    def L_I18N_INVITATION_DECLINE_BTN(lang):
        text = i18n.get_str('meeting_invitation_status_decline', lang)
        return 'xpath', (
            f'{LMcuConferenceSidebar.L_INVITATION_RESPONSE_BLOCK()[1]}'
            f'//button[.//span[contains(@class,"label") and normalize-space()="{text}"]]'
        )

    @staticmethod
    def L_PARTICIPANT_STATUS_CIRCLE(full_name, lang=''):
        # Бейдж ответа участника на приглашение (кружок у аватара): _info=без ответа,
        # _success=принял, _critical=отклонил, _secondary=возможно. Отдельного текстового
        # лейбла «ответ участника» нет — это и есть индикатор (step 1.1/2.1).
        return 'xpath', (
            f'{LMcuConferenceSidebar.L_PARTICIPANT_BY_NAME(full_name)[1]}'
            f'//div[contains(@class,"status-circle")]'
        )

    @staticmethod
    def L_PARTICIPANT_ACCEPTED_MARK(full_name, lang=''):
        # Зелёная галочка (принял приглашение) рядом с ФИ участника в СПИСКЕ УЧАСТНИКОВ
        # карточки ВКС (НЕ в левом chats-list — там галочки нет). Организатор всегда _success,
        # поэтому скоуп по ФИ обязателен.
        return 'xpath', (
            f'{LMcuConferenceSidebar.L_PARTICIPANT_BY_NAME(full_name)[1]}'
            f'//div[contains(@class,"status-circle") and contains(@class,"_success")]'
        )

    @staticmethod
    def L_VIEW_MAXIMIZE_BTN(lang=''):
        # Разворот именно VIEW-карточки ВКС. НЕ путать с LCalendar.L_FULLSCREEN_BTN
        # (та целится в iva-header ФОРМЫ создания/редактирования внутри
        # calendar-event-sidebar-wrapper).
        return 'xpath', (
            f'{LMcuConferenceSidebar.L_DETAILS_ROOT()[1]}'
            f'//button[@aria-label="Maximize"][.//iva-icon-maximize-2]'
        )

    # --- Карточка глазами приглашённого: полноэкранный просмотр (fullscreen-режим) ---
    @staticmethod
    def L_FULLSCREEN_ROOT(lang=''):
        # Полноэкранный просмотр карточки ВКС. При нём mcu-conference-sidebar-view
        # из DOM удаляется — fullscreen-локаторы строить ТОЛЬКО под этим корнем.
        return 'xpath', '//mcu-conference-fullscreen-view'

    @staticmethod
    def L_FULLSCREEN_INVITATION_RESPONSE_BLOCK(lang=''):
        return 'xpath', (
            f'{LMcuConferenceSidebar.L_FULLSCREEN_ROOT()[1]}'
            f'//calendar-event-invitation-response-fullscreen'
        )

    @staticmethod
    def L_I18N_FULLSCREEN_INVITATION_ACCEPT_BTN(lang):
        text = i18n.get_str('meeting_invitation_status_accept', lang)
        return 'xpath', (
            f'{LMcuConferenceSidebar.L_FULLSCREEN_INVITATION_RESPONSE_BLOCK()[1]}'
            f'//button[normalize-space()="{text}"]'
        )

    @staticmethod
    def L_FULLSCREEN_ATTACHMENTS_SECTION(lang=''):
        # Секция «Вложения» — только в fullscreen-просмотре (в sidebar её нет).
        return 'xpath', (
            f'{LMcuConferenceSidebar.L_FULLSCREEN_ROOT()[1]}//attachments-section'
        )

    @staticmethod
    def L_I18N_FULLSCREEN_ATTACHMENTS_LABEL(lang):
        text = i18n.get_str('general_attachments_label', lang)
        return 'xpath', (
            f'{LMcuConferenceSidebar.L_FULLSCREEN_ATTACHMENTS_SECTION()[1]}'
            f'//p[contains(@class,"title") and normalize-space()="{text}"]'
        )

    @staticmethod
    def L_FULLSCREEN_PARTICIPANT_BY_NAME(full_name, lang=''):
        return 'xpath', (
            f'{LMcuConferenceSidebar.L_FULLSCREEN_ROOT()[1]}'
            f'//li[contains(@class,"user")][contains(normalize-space(.),"{full_name}")]'
        )

    @staticmethod
    def L_FULLSCREEN_PARTICIPANT_POSITION_BY_NAME(full_name, position, lang=''):
        return 'xpath', (
            f'{LMcuConferenceSidebar.L_FULLSCREEN_PARTICIPANT_BY_NAME(full_name)[1]}'
            f'//participant-position[contains(normalize-space(),"{position}")]'
        )

    @staticmethod
    def L_FULLSCREEN_PARTICIPANT_ACCEPTED_MARK(full_name, lang=''):
        return 'xpath', (
            f'{LMcuConferenceSidebar.L_FULLSCREEN_PARTICIPANT_BY_NAME(full_name)[1]}'
            f'//div[contains(@class,"status-circle") and contains(@class,"_success")]'
        )
