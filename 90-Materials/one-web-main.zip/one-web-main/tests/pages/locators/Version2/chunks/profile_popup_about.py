from tools import i18n


class LProfilePopupAbout:

    @staticmethod
    def L_ROOT(lang=''):
        return 'xpath', '//profile-about'

    @staticmethod
    def L_VERSIONS(lang=''):
        return 'xpath', f'{LProfilePopupAbout.L_ROOT()[1]}//profile-versions'

    @staticmethod
    def L_PRODUCT_VERSION(lang=''):
        return 'xpath', f'{LProfilePopupAbout.L_VERSIONS()[1]}//div[contains(@class,"production-version")]'

    @staticmethod
    def L_I18N_BUILD_VERSION_BTN(lang):
        i18n_str = i18n.get_str('profile_about_label_build', lang)
        return 'xpath', (
            f'{LProfilePopupAbout.L_VERSIONS()[1]}'
            f'//button[contains(@class,"assembly-version")][contains(normalize-space(),"{i18n_str}")]'
        )
