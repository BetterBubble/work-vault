from tools import i18n


class LChatProfileBase:
    _DELETE_CONFIRM_TITLE_KEY = None
    _PUBLIC_TOGGLE_KEY = None
    _PUBLIC_CHAT_LABEL_KEY = None
    _REACTIONS_TOGGLE_KEY = None
    _THREADS_TOGGLE_KEY = None

    @staticmethod
    def L_ROOT(lang=''):
        return 'xpath', '//chat-sidebar'

    @staticmethod
    def L_USER_ITEM(lang=''):
        return 'xpath', f'{LChatProfileBase.L_ROOT()[1]}//chat-users-list-item'

    @staticmethod
    def L_USER_ITEM_WITH_NAME(username, lang=''):
        return 'xpath', f'{LChatProfileBase.L_USER_ITEM()[1]}[contains(.,"{username}")]'

    @staticmethod
    def L_USERS_LIST(lang=''):
        return 'xpath', f'{LChatProfileBase.L_ROOT()[1]}//msg-users-list'

    @staticmethod
    def L_ADD_USER_BTN(lang=''):
        return 'xpath', (
            f'{LChatProfileBase.L_USERS_LIST()[1]}'
            f'//div[contains(@class,"title")]/div[contains(@class,"buttons")]'
            f'//button[.//iva-icon-user-plus]'
        )

    @staticmethod
    def L_I18N_ADD_MEMBERS_DIALOG(lang):
        i18n_str = i18n.get_str('chat_profile_add_members_dialog_title', lang)
        # 2.1.0: у диалога нет своего компонент-тега (ng-component) — якорим iva-modal
        # по заголовку div.title в iva-header (атрибут @dialogtitle из сборки удалён).
        return 'xpath', (
            f'//iva-modal'
            f'[.//div[contains(@class,"title") and normalize-space()="{i18n_str}"]]'
        )

    @staticmethod
    def L_I18N_ADD_MEMBERS_DIALOG_SEARCH_INPUT(lang):
        placeholder = i18n.get_str('contacts_search_input', lang)
        return 'xpath', (
            f'{LChatProfileBase.L_I18N_ADD_MEMBERS_DIALOG(lang)[1]}'
            f'//input[@placeholder="{placeholder}"]'
        )

    @staticmethod
    def L_I18N_ADD_MEMBERS_DIALOG_CONTACT_ROW(full_name, lang):
        # ds→iva: таблица контактов переехала на contacts-table/contacts-contact-name (как в address_book).
        return 'xpath', (
            f'{LChatProfileBase.L_I18N_ADD_MEMBERS_DIALOG(lang)[1]}'
            f'//contacts-table//div[contains(@class,"table-row")]'
            f'[.//contacts-contact-name[normalize-space()="{full_name}"]]'
        )

    @staticmethod
    def L_I18N_ADD_MEMBERS_DIALOG_CONFIRM_BTN(lang):
        i18n_str = i18n.get_str('chat_profile_add_members_dialog_confirm_btn', lang)
        # Кнопка «Добавить» — в footer.footer модалки; сужаем до footer, чтобы не
        # зацепить «Добавить» в других узлах поддерева диалога.
        return 'xpath', (
            f'{LChatProfileBase.L_I18N_ADD_MEMBERS_DIALOG(lang)[1]}'
            f'//footer//button[normalize-space()="{i18n_str}"]'
        )

    @staticmethod
    def L_MEMBER_CONTEXT_MENU(lang=''):
        return 'xpath', '//iva-menu[@role="menu"]'

    @staticmethod
    def L_I18N_MEMBER_CONTEXT_MENU_KICK_BTN(lang):
        i18n_str = i18n.get_str('group_chat_profile_kick_member_btn', lang)
        return 'xpath', f'{LChatProfileBase.L_MEMBER_CONTEXT_MENU()[1]}//button[@role="menuitem"][contains(.,"{i18n_str}")]'

    @staticmethod
    def L_I18N_MEMBER_CONTEXT_MENU_MAKE_ADMIN_BTN(lang):
        i18n_str = i18n.get_str('group_chat_profile_make_admin_btn', lang)
        return 'xpath', f'{LChatProfileBase.L_MEMBER_CONTEXT_MENU()[1]}//button[@role="menuitem"][contains(.,"{i18n_str}")]'

    @staticmethod
    def L_I18N_USER_ITEM_ADMIN_ROLE(username, lang):
        i18n_str = i18n.get_str('group_chat_profile_admin_role_label', lang)
        return 'xpath', f'{LChatProfileBase.L_USER_ITEM_WITH_NAME(username)[1]}//p[contains(@class,"role") and contains(text(),"{i18n_str}")]'

    @staticmethod
    def L_I18N_MEMBER_CONTEXT_MENU_TRANSFER_OWNER_BTN(lang):
        i18n_str = i18n.get_str('group_chat_profile_transfer_owner_btn', lang)
        return 'xpath', f'{LChatProfileBase.L_MEMBER_CONTEXT_MENU()[1]}//button[@role="menuitem"][contains(.,"{i18n_str}")]'

    @staticmethod
    def L_TRANSFER_OWNER_CONFIRM_DIALOG(lang=''):
        return 'xpath', '//chat-owner-modal'

    @staticmethod
    def L_I18N_TRANSFER_OWNER_CONFIRM_BTN(lang):
        i18n_str = i18n.get_str('group_chat_profile_transfer_owner_confirm_btn', lang)
        return 'xpath', f'{LChatProfileBase.L_TRANSFER_OWNER_CONFIRM_DIALOG()[1]}//button[contains(.,"{i18n_str}")]'

    @staticmethod
    def L_I18N_USER_ITEM_OWNER_ROLE(username, lang):
        i18n_str = i18n.get_str('group_chat_profile_owner_role_label', lang)
        return 'xpath', f'{LChatProfileBase.L_USER_ITEM_WITH_NAME(username)[1]}//p[contains(@class,"role") and contains(text(),"{i18n_str}")]'

    @staticmethod
    def L_EDIT_CHAT_BTN(lang=''):
        return 'xpath', f'{LChatProfileBase.L_ROOT()[1]}//button[.//iva-icon-pencil]'

    @staticmethod
    def L_EDIT_FORM(lang=''):
        # для канала корневой тег формы — <chat-sidebar-channel-edit>, для группового чата — <chat-sidebar-group-edit>
        return 'xpath', '(//chat-sidebar-channel-edit//form | //chat-sidebar-group-edit//form)'

    @staticmethod
    def L_AVATAR_SECTION(lang=''):
        return 'xpath', f'{LChatProfileBase.L_EDIT_FORM()[1]}//chat-sidebar-avatar-edit'

    @staticmethod
    def L_AVATAR_EDIT_HOST(lang=''):
        # iva-сборка: кликабельный хост ivaFilePicker; по клику лениво создаёт <input type=file>
        # на document.body (см. page_helpers.upload_avatar_via_lazy_picker). Статического инпута нет.
        return 'xpath', f'{LChatProfileBase.L_AVATAR_SECTION()[1]}//iva-avatar-edit'

    @staticmethod
    def L_AVATAR_PREVIEW_IMAGE(lang=''):
        # iva-сборка: msg-change-avatar убран — превью под iva-avatar-edit//iva-avatar.
        return 'xpath', f'{LChatProfileBase.L_AVATAR_EDIT_HOST()[1]}//iva-avatar//img'

    @staticmethod
    def L_AVATAR_LOADING(lang=''):
        return 'xpath', f'{LChatProfileBase.L_AVATAR_SECTION()[1]}//*[self::iva-spinner or self::ds-loader or self::ds-spinner or @role="progressbar" or contains(@class,"loader") or contains(@class,"spinner")]'

    @staticmethod
    def L_AVATAR_IMAGE(lang=''):
        return 'xpath', (
            f'({LChatProfileBase.L_ROOT()[1]}//chat-sidebar-channel-view//div[contains(@class,"header")]//iva-avatar//img'
            f' | {LChatProfileBase.L_ROOT()[1]}//chat-sidebar-group-view//div[contains(@class,"header")]//iva-avatar//img)'
        )

    @staticmethod
    def L_CHAT_NAME_INPUT(lang=''):
        # ds→iva: ds-input убран — поле имени теперь нативный <input ivainput formcontrolname="name">.
        return 'xpath', f'{LChatProfileBase.L_EDIT_FORM()[1]}//input[@formcontrolname="name"]'

    @staticmethod
    def L_CHAT_NAME_CLEAR_BTN(lang=''):
        # ds→iva: ds-input убран; кнопка очистки лежит в обёртке iva-form-field рядом с нативным input.
        return 'xpath', (
            f'{LChatProfileBase.L_EDIT_FORM()[1]}'
            f'//iva-form-field[.//input[@formcontrolname="name"]]'
            f'//button[.//iva-icon-circle-x-line]'
        )

    @staticmethod
    def L_DESCRIPTION_TEXTAREA(lang=''):
        # ds→iva: ds-text-area убран — описание теперь нативный <textarea ivatextarea formcontrolname="description">.
        # maxlength=500 — input Angular-директивы ivaTextarea (soft-limit); HTML-атрибута в DOM нет, не матчим.
        return 'xpath', f'{LChatProfileBase.L_EDIT_FORM()[1]}//textarea[@formcontrolname="description"]'

    @staticmethod
    def L_DESCRIPTION_COUNTER(lang=''):
        # iva-сборка: счётчик символов — div.counter (был p.count).
        return 'xpath', f'{LChatProfileBase.L_EDIT_FORM()[1]}//iva-form-field[.//textarea[@formcontrolname="description"]]//div[contains(@class,"counter")]'

    @staticmethod
    def L_I18N_SAVE_CHANGES_BTN(lang):
        i18n_str = i18n.get_str('group_chat_profile_save_btn', lang)
        # для канала кнопка лежит в <chat-sidebar-channel-edit>, для группового чата — в <chat-sidebar-group-edit>
        return 'xpath', (
            f'(//chat-sidebar-channel-edit//button[not(@disabled) and contains(normalize-space(),"{i18n_str}")]'
            f' | //chat-sidebar-group-edit//button[not(@disabled) and contains(normalize-space(),"{i18n_str}")])'
        )

    @staticmethod
    def L_DESCRIPTION_TEXT(description, lang=''):
        return 'xpath', f'{LChatProfileBase.L_ROOT()[1]}//msg-text-card//div[contains(@class,"description")]//msg-expandable-text[contains(normalize-space(),"{description}")]'

    @classmethod
    def L_I18N_PUBLIC_TOGGLE_CHECKBOX(cls, lang):
        i18n_str = i18n.get_str(cls._PUBLIC_TOGGLE_KEY, lang)
        return 'xpath', (
            f'{LChatProfileBase.L_EDIT_FORM()[1]}'
            f'//iva-toggle-field[.//label[contains(@class,"label") and normalize-space()="{i18n_str}"]]'
            f'//input[@type="checkbox"]'
        )

    @classmethod
    def L_I18N_PUBLIC_TOGGLE_SWITCH(cls, lang):
        # сам iva-toggle (целиком накрывает input) — кликабельная цель.
        # Контейнер iva-toggle-field шире и его центр попадает в пустое
        # место между текстовой меткой и тоглом — клик туда не переключает состояние.
        i18n_str = i18n.get_str(cls._PUBLIC_TOGGLE_KEY, lang)
        return 'xpath', (
            f'{LChatProfileBase.L_EDIT_FORM()[1]}'
            f'//iva-toggle-field[.//label[contains(@class,"label") and normalize-space()="{i18n_str}"]]'
            f'//iva-toggle'
        )

    @classmethod
    def L_I18N_PUBLIC_CHAT_LABEL(cls, lang):
        i18n_str = i18n.get_str(cls._PUBLIC_CHAT_LABEL_KEY, lang)
        return 'xpath', (
            f'{LChatProfileBase.L_ROOT()[1]}'
            f'//chat-info-mark[.//div[contains(@class,"text") and normalize-space()="{i18n_str}"]]'
        )

    @classmethod
    def L_I18N_REACTIONS_TOGGLE_CHECKBOX(cls, lang):
        i18n_str = i18n.get_str(cls._REACTIONS_TOGGLE_KEY, lang)
        return 'xpath', (
            f'{LChatProfileBase.L_EDIT_FORM()[1]}'
            f'//iva-toggle-field[.//label[contains(@class,"label") and normalize-space()="{i18n_str}"]]'
            f'//input[@type="checkbox"]'
        )

    @classmethod
    def L_I18N_REACTIONS_TOGGLE_SWITCH(cls, lang):
        i18n_str = i18n.get_str(cls._REACTIONS_TOGGLE_KEY, lang)
        return 'xpath', (
            f'{LChatProfileBase.L_EDIT_FORM()[1]}'
            f'//iva-toggle-field[.//label[contains(@class,"label") and normalize-space()="{i18n_str}"]]'
            f'//iva-toggle'
        )

    @classmethod
    def L_I18N_THREADS_TOGGLE_CHECKBOX(cls, lang):
        i18n_str = i18n.get_str(cls._THREADS_TOGGLE_KEY, lang)
        return 'xpath', (
            f'{LChatProfileBase.L_EDIT_FORM()[1]}'
            f'//iva-toggle-field[.//label[contains(@class,"label") and normalize-space()="{i18n_str}"]]'
            f'//input[@type="checkbox"]'
        )

    @classmethod
    def L_I18N_THREADS_TOGGLE_SWITCH(cls, lang):
        i18n_str = i18n.get_str(cls._THREADS_TOGGLE_KEY, lang)
        return 'xpath', (
            f'{LChatProfileBase.L_EDIT_FORM()[1]}'
            f'//iva-toggle-field[.//label[contains(@class,"label") and normalize-space()="{i18n_str}"]]'
            f'//iva-toggle'
        )

    @staticmethod
    def L_I18N_COPY_LINK_BTN(lang):
        # ds→iva: ds-icon-copy→iva-icon-copy; подпись кнопки сменилась «Копировать»→«Ссылка»,
        # поэтому матчим по уникальной в action-bar иконке, а не по тексту.
        return 'xpath', (
            f'{LChatProfileBase.L_ROOT()[1]}'
            f'//action-bar[@mode="sidebar"]'
            f'//button[.//iva-icon-copy]'
        )

    @staticmethod
    def L_NOTIFICATIONS_TOGGLE_BTN(lang=''):
        return 'xpath', (
            f'{LChatProfileBase.L_ROOT()[1]}'
            f'//action-bar[@mode="sidebar"]'
            f'//button[.//iva-icon-bell-line or .//iva-icon-bell-off]'
        )

    @staticmethod
    def L_I18N_MORE_MENU_BTN(lang):
        i18n_str = i18n.get_str('group_chat_profile_more_btn', lang)
        return 'xpath', (
            f'{LChatProfileBase.L_ROOT()[1]}'
            f'//action-bar[@mode="sidebar"]'
            f'//button[.//iva-icon-ellipsis and .//span[normalize-space()="{i18n_str}"]]'
        )

    @staticmethod
    def L_MORE_MENU(lang=''):
        return 'xpath', '//iva-menu[@role="menu"]'

    @staticmethod
    def L_I18N_DELETE_CHAT_MENU_ITEM(lang):
        i18n_str = i18n.get_str('group_chat_profile_delete_chat_btn', lang)
        return 'xpath', (
            f'{LChatProfileBase.L_MORE_MENU()[1]}'
            f'//button[@role="menuitem"][.//div[contains(@class,"label")][normalize-space()="{i18n_str}"]]'
        )

    @classmethod
    def L_I18N_DELETE_CONFIRM_DIALOG(cls, lang):
        i18n_str = i18n.get_str(cls._DELETE_CONFIRM_TITLE_KEY, lang)
        # 2.1.0: системный confirm — <iva-dialog> (ds-dialog удалён из сборки);
        # заголовок остался div.title.
        return 'xpath', (
            f'//iva-dialog'
            f'[.//div[contains(@class,"title") and contains(normalize-space(),"{i18n_str}")]]'
        )

    @classmethod
    def L_I18N_DELETE_CONFIRM_BTN(cls, lang):
        i18n_str = i18n.get_str('group_chat_profile_delete_chat_confirm_btn', lang)
        return 'xpath', (
            f'{cls.L_I18N_DELETE_CONFIRM_DIALOG(lang)[1]}'
            f'//button[normalize-space()="{i18n_str}"]'
        )

    @staticmethod
    def L_GALLERY_SECTION(lang=''):
        # Раздел галереи в карточке чата — набор кнопок-категорий внутри <msg-media-list>.
        # Блок появляется условно: только если в чате есть медиафайлы соответствующего типа.
        return 'xpath', f'{LChatProfileBase.L_ROOT()[1]}//msg-media-list'

    @staticmethod
    def L_I18N_GALLERY_CATEGORY_BTN(category_key, lang):
        """Кнопка категории галереи (Изображения / Видео / Файлы / Аудио).
        category_key — i18n ключ, например 'chat_profile_gallery_category_video'."""
        i18n_str = i18n.get_str(category_key, lang)
        return 'xpath', (
            f'{LChatProfileBase.L_GALLERY_SECTION()[1]}'
            f'//button[contains(@class,"item")]'
            f'[.//p[normalize-space()="{i18n_str}"]]'
        )
