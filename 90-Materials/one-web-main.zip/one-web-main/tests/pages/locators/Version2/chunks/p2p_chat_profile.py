from tools import i18n


class LP2pChatProfile:
    @staticmethod
    def L_ROOT(lang=''):
        return 'xpath', '//profile-sidebar'

    @staticmethod
    def L_I18N_MORE_MENU_BTN(lang):
        i18n_str = i18n.get_str('p2p_chat_profile_more_btn', lang)
        return 'xpath', (
            f'{LP2pChatProfile.L_ROOT()[1]}'
            f'//action-bar[@mode="sidebar"]'
            f'//button[.//iva-icon-ellipsis and .//span[normalize-space()="{i18n_str}"]]'
        )

    @staticmethod
    def L_MORE_MENU(lang=''):
        return 'xpath', '//iva-menu[@role="menu"]'

    @staticmethod
    def L_I18N_MUTE_MENU_ITEM(lang):
        i18n_str = i18n.get_str('p2p_chat_profile_mute_menu_item', lang)
        return 'xpath', (
            f'{LP2pChatProfile.L_MORE_MENU()[1]}'
            f'//button[@role="menuitem"][.//div[contains(@class,"label")][normalize-space()="{i18n_str}"]]'
        )

    @staticmethod
    def L_I18N_UNMUTE_MENU_ITEM(lang):
        i18n_str = i18n.get_str('p2p_chat_profile_unmute_menu_item', lang)
        return 'xpath', (
            f'{LP2pChatProfile.L_MORE_MENU()[1]}'
            f'//button[@role="menuitem"][.//div[contains(@class,"label")][normalize-space()="{i18n_str}"]]'
        )

    @staticmethod
    def L_GALLERY_SECTION(lang=''):
        # Раздел галереи в карточке p2p-чата — <msg-media-list> с кнопками-категориями.
        # Появляется условно: только если в чате есть медиафайлы соответствующего типа.
        return 'xpath', f'{LP2pChatProfile.L_ROOT()[1]}//msg-media-list'

    @staticmethod
    def L_I18N_GALLERY_CATEGORY_BTN(category_key, lang):
        """Кнопка категории галереи (Изображения / Видео / Файлы / Аудио).
        category_key — i18n ключ, например 'chat_profile_gallery_category_audio'."""
        i18n_str = i18n.get_str(category_key, lang)
        return 'xpath', (
            f'{LP2pChatProfile.L_GALLERY_SECTION()[1]}'
            f'//button[contains(@class,"item")]'
            f'[.//p[normalize-space()="{i18n_str}"]]'
        )

    @staticmethod
    def L_I18N_GALLERY_CATEGORY_BTN_COUNT(category_key, lang):
        """Счётчик файлов в кнопке категории — рендерится как просто число (например '1'),
        без слова 'файл'."""
        btn_xpath = LP2pChatProfile.L_I18N_GALLERY_CATEGORY_BTN(category_key, lang)[1]
        return 'xpath', f'{btn_xpath}//p[not(@class)]'
