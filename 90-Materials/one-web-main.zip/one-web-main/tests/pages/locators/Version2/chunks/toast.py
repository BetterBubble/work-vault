from tools import i18n


class LToast:
    """Локаторы глобального тоста IVA ONE WEB.

    Тост — глобальный UI-элемент `<iva-toast-container>`, появляется поверх любого
    экрана. Локаторы вынесены сюда, чтобы любой page/chunk проверял тосты через
    `CVersion2Toast`, а не плодил локальные `L_I18N_*_TOAST`.
    """

    @staticmethod
    def L_ROOT(lang=''):
        # ds→iva: тост мигрировал <ds-toast-wrapper>/<ds-toast> → <iva-toast-container>/<iva-toast>.
        return 'xpath', '//iva-toast-container'

    @staticmethod
    def L_TOAST(lang=''):
        return 'xpath', f'{LToast.L_ROOT()[1]}//iva-toast'

    @staticmethod
    def L_TOAST_BY_TEXT(text, lang=''):
        return 'xpath', (
            f'{LToast.L_TOAST()[1]}'
            f'//div[contains(@class,"content") and contains(normalize-space(),"{text}")]'
        )

    @staticmethod
    def L_I18N_TOAST(key, lang):
        text = i18n.get_str(key, lang)
        return LToast.L_TOAST_BY_TEXT(text)

    @staticmethod
    def L_TOAST_SUCCESS(lang=''):
        # Success-тост: в div.icon — иконка ds-icon-circle-check-line (внутри ds-toast → остаётся ds-icon).
        return 'xpath', f'{LToast.L_TOAST()[1]}[.//div[contains(@class,"icon")]//ds-icon-circle-check-line]'

    @staticmethod
    def L_TOAST_CONTAINS(text, lang=''):
        # Тост, содержащий текст где угодно внутри <ds-toast> (проецируемый span, напр. entity-created-toast).
        return 'xpath', f'{LToast.L_TOAST()[1]}[contains(normalize-space(),"{text}")]'

    @staticmethod
    def L_I18N_GO_TO_BTN(lang):
        # Кнопка «Перейти» в тосте создания сущности: <button ivatoastactionbutton> в div.actions
        # (была <a class="toast-link"> до миграции ds→iva).
        text = i18n.get_str('toast_go_to_title', lang)
        return 'xpath', (
            f'{LToast.L_TOAST()[1]}//div[contains(@class,"actions")]'
            f'//button[@ivatoastactionbutton][normalize-space()="{text}"]'
        )
