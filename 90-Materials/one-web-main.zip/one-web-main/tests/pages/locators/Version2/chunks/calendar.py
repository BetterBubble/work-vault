from tools import i18n


class LCalendar:
    """Локаторы раздела «Календарь». Корень вью — <lib-calendar>, события — блоки
    <calendar-grid-arrangement> в сетке по часам. Маршрут /calendar/<view>/<YYYY-MM-DD>,
    вид по умолчанию — «День» (сетка 00:00–23:00, текущая дата).

    Создание мероприятия (общее для Событие/ВКС): кнопка «+» в шапке → меню типа →
    форма в общей обёртке <calendar-event-sidebar-wrapper> (поля имени/участников/fullscreen
    и submit-кнопка шарятся; type-специфика — «Тип»/«Настройки» у ВКС, «Место»/«Приоритет»/
    «Папка» у Событие; карточка созданного — в chunk mcu_conference_sidebar / offline_event)."""

    @staticmethod
    def L_VIEW_ROOT(lang=''):
        return 'xpath', '//lib-calendar'

    @staticmethod
    def L_GRID_LOADER(lang=''):
        # Спиннер загрузки сетки: пока isLoading() — события не рендерятся вовсе, вместо
        # колонок только div.loader-container со спиннером (шаблоны day-grid/week-grid
        # продукта; тег спиннера покрыт обоими поколениями DS — ds-* и iva-*).
        return 'xpath', (
            f'{LCalendar.L_VIEW_ROOT()[1]}'
            '//*[self::ds-spinner or self::iva-spinner or contains(@class,"loader-container")]'
        )

    @staticmethod
    def L_EVENT_IN_GRID_BY_NAME(name, lang=''):
        # Блок события в сетке по названию. span.arrangement-name обёрнут пробелами по краям —
        # ищем через contains(normalize-space()). Host <calendar-grid-arrangement> нулевого
        # размера — для assert_presence годится, для клика см. L_EVENT_CARD_CLICKABLE_BY_NAME.
        return 'xpath', (
            f'{LCalendar.L_VIEW_ROOT()[1]}'
            f'//calendar-grid-arrangement[.//span[contains(@class,"arrangement-name")'
            f' and contains(normalize-space(),"{name}")]]'
        )

    @staticmethod
    def L_EVENT_CARD_CLICKABLE_BY_NAME(name, lang=''):
        # Кликабельная карточка события: host <calendar-grid-arrangement> нулевого размера,
        # визуальный блок — внутренний div.arrangement (несёт top/left/width/height). Точный
        # word-match класса "arrangement" (не "arrangement-content"/"arrangement-name").
        return 'xpath', (
            f'{LCalendar.L_EVENT_IN_GRID_BY_NAME(name)[1]}'
            f'//div[contains(concat(" ", normalize-space(@class), " "), " arrangement ")]'
        )

    # --- Кнопка «+» и меню типа мероприятия ---
    @staticmethod
    def L_CREATE_BTN(lang=''):
        return 'xpath', '//calendar-sidebar-header//button[@aria-label="Create"]'

    @staticmethod
    def L_CREATE_TYPE_MENU(lang=''):
        return 'xpath', '//iva-menu[@role="menu"]'

    @staticmethod
    def L_I18N_CREATE_TYPE_MENU_ITEM(type_i18n_key, lang):
        # Пункт меню несёт label + description, поэтому матчим по внутреннему div.label,
        # а не по тексту всей кнопки. type_i18n_key = значение enum CalendarMeetingType.
        text = i18n.get_str(type_i18n_key, lang)
        return 'xpath', (
            f'{LCalendar.L_CREATE_TYPE_MENU()[1]}'
            f'//button[@role="menuitem"][.//div[@class="label" and normalize-space()="{text}"]]'
        )

    # --- Общая форма создания мероприятия (Событие/ВКС шарят обёртку) ---
    @staticmethod
    def L_FORM_WRAPPER(lang=''):
        return 'xpath', '//calendar-event-sidebar-wrapper'

    @staticmethod
    def L_NAME_INPUT(lang=''):
        return 'xpath', '//calendar-event-name-field//input[@ivainput]'

    @staticmethod
    def L_I18N_SUBMIT_BTN(text, lang=''):
        # Submit-кнопка по тексту, якорь — общая обёртка. Текст зависит от типа И режима
        # (2.1.0): ВКС sidebar = «Сохранить» (даже при создании), ВКС fullscreen =
        # «Создать встречу»; Событие = «Создать событие» в обоих режимах. type/class кнопки
        # между режимами тоже меняются — по ним не якоримся.
        return 'xpath', f'{LCalendar.L_FORM_WRAPPER()[1]}//button[normalize-space()="{text}"]'

    # --- Участники в форме создания ---
    @staticmethod
    def L_I18N_ADD_REQUIRED_PARTICIPANT_BTN(lang):
        section = i18n.get_str('calendar_participants_required_section', lang)
        add = i18n.get_str('calendar_add_participant_btn', lang)
        return 'xpath', (
            '//calendar-event-create-edit-participants-list'
            f'//msg-adding-section[.//p[contains(@class,"title") and normalize-space()="{section}"]]'
            f'//button[normalize-space()="{add}"]'
        )

    @staticmethod
    def L_FORM_PARTICIPANT_BY_NAME(full_name, lang=''):
        return 'xpath', (
            '//calendar-event-create-edit-participants-list'
            f'//participant-item[.//contacts-contact-name[normalize-space()="{full_name}"]]'
        )

    @staticmethod
    def L_FORM_PARTICIPANT_POSITION(full_name, position, lang=''):
        # Должность участника в форме (participant-position рендерится только при заполненной должности).
        return 'xpath', (
            f'{LCalendar.L_FORM_PARTICIPANT_BY_NAME(full_name)[1]}'
            f'//participant-position[contains(normalize-space(),"{position}")]'
        )

    # --- Fullscreen ---
    @staticmethod
    def L_FULLSCREEN_BTN(lang=''):
        # Кнопка разворота — только в sidebar-режиме (в fullscreen шапка заменяется тулбаром
        # оверлея). 2.1.0: calendar-event-sidebar-header удалён — кнопка живёт в iva-header
        # sidebar-layout формы; иконка-предикат покрывает и Событие (кнопка без aria-label),
        # и ВКС (aria-label="Maximize").
        return 'xpath', f'{LCalendar.L_FORM_WRAPPER()[1]}//iva-header//button[.//iva-icon-maximize-2]'

    @staticmethod
    def L_SLOTS_BLOCK(lang=''):
        # Блок «Свободные слоты / Показать слоты» — появляется только в fullscreen-режиме формы.
        return 'xpath', '//calendar-event-slots'
