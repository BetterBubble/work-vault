from tools import i18n


class LProfilePopupSupport:

    @staticmethod
    def L_ROOT(lang=''):
        return 'xpath', '//cdk-dialog-container//profile-support'

    @staticmethod
    def L_LOGGING_BLOCK(lang=''):
        # 2.1.0-RC1: div.logging убран — блок логирования = <profile-section-page>
        # (заголовок в iva-header, кнопки экспорта/очистки в footer).
        return 'xpath', f'{LProfilePopupSupport.L_ROOT()[1]}//profile-section-page'

    @staticmethod
    def L_I18N_LOGGING_TITLE(lang):
        i18n_str = i18n.get_str('profile_support_logging_title', lang)
        return 'xpath', (
            f'{LProfilePopupSupport.L_ROOT()[1]}'
            f'//iva-header//div[contains(concat(" ", normalize-space(@class), " "), " title ") '
            f'and normalize-space(.)="{i18n_str}"]'
        )

    @staticmethod
    def L_I18N_EXPORT_LOGS_BUTTON(lang):
        i18n_str = i18n.get_str('profile_support_logging_button_export', lang)
        return 'xpath', (
            f'{LProfilePopupSupport.L_ROOT()[1]}'
            f'//button[.//span[contains(concat(" ", normalize-space(@class), " "), " label ") '
            f'and normalize-space(.)="{i18n_str}"]]'
        )

    @staticmethod
    def L_I18N_CLEAR_LOGS_BUTTON(lang):
        i18n_str = i18n.get_str('profile_support_logging_button_clear', lang)
        return 'xpath', (
            f'{LProfilePopupSupport.L_ROOT()[1]}'
            f'//button[@data-appearance="critical" '
            f'and .//span[contains(concat(" ", normalize-space(@class), " "), " label ") '
            f'and normalize-space(.)="{i18n_str}"]]'
        )

    @staticmethod
    def L_DEVELOP_LOGGING_OPTIONS(lang=''):
        return 'xpath', (
            f'{LProfilePopupSupport.L_ROOT()[1]}'
            f'//div[contains(@class,"controls-group")][./div[contains(@class,"controls")]//iva-toggle-field]'
        )

    @staticmethod
    def L_I18N_DEVELOP_TOGGLE(toggle_key, lang):
        i18n_str = i18n.get_str(toggle_key, lang)
        return 'xpath', (
            f'{LProfilePopupSupport.L_DEVELOP_LOGGING_OPTIONS()[1]}'
            f'//iva-toggle-field[.//*[normalize-space()="{i18n_str}"]]'
        )

    @staticmethod
    def L_I18N_DEVELOP_LOGGING_ENABLED_TOGGLE(lang):
        return LProfilePopupSupport.L_I18N_DEVELOP_TOGGLE('profile_support_develop_logging_enabled_toggle', lang)

    @staticmethod
    def L_I18N_DEVELOP_CONSOLE_PROXY_TOGGLE(lang):
        return LProfilePopupSupport.L_I18N_DEVELOP_TOGGLE('profile_support_develop_console_proxy_toggle', lang)

    @staticmethod
    def L_I18N_DEVELOP_SECTION_TITLE(section_key, lang):
        i18n_str = i18n.get_str(section_key, lang)
        return 'xpath', (
            f'{LProfilePopupSupport.L_DEVELOP_LOGGING_OPTIONS()[1]}'
            f'//*[normalize-space()="{i18n_str}"]'
        )

    @staticmethod
    def L_I18N_DEVELOP_CONSOLE_TITLE(lang):
        return LProfilePopupSupport.L_I18N_DEVELOP_SECTION_TITLE('profile_support_develop_console_title', lang)

    @staticmethod
    def L_I18N_DEVELOP_IDB_TITLE(lang):
        return LProfilePopupSupport.L_I18N_DEVELOP_SECTION_TITLE('profile_support_develop_idb_title', lang)

    @staticmethod
    def L_I18N_DEVELOP_SENTRY_TITLE(lang):
        return LProfilePopupSupport.L_I18N_DEVELOP_SECTION_TITLE('profile_support_develop_sentry_title', lang)

    @staticmethod
    def L_I18N_DEVELOP_LOG_LEVELS_TITLE(lang):
        return LProfilePopupSupport.L_I18N_DEVELOP_SECTION_TITLE('profile_support_develop_log_levels_title', lang)
