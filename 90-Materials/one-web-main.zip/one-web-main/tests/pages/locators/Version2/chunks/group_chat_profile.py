from .chat_profile_base import LChatProfileBase


class LGroupChatProfile(LChatProfileBase):
    _DELETE_CONFIRM_TITLE_KEY = 'group_chat_profile_delete_chat_confirm_dialog_title'
    _PUBLIC_TOGGLE_KEY = 'group_chat_profile_public_toggle_label'
    _PUBLIC_CHAT_LABEL_KEY = 'group_chat_profile_public_chat_label'
