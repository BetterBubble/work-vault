from tools import i18n


class LUserProfile:
    @staticmethod
    def L_ROOT(lang=''):
        # iva-билд: корень сайдбара профиля — <contacts-contact-sidebar>.
        return 'xpath', '//contacts-contact-sidebar'

    @staticmethod
    def L_I18N_TYPE_MESSAGE_BTN(lang):
        # Дрейф 2026-07-02: прямой кнопки «Написать» в карточке больше нет — продукт
        # перенёс её в меню «Ещё» (iva-menu в cdk-overlay, ВНЕ корня карточки).
        # Языконезависимый аналог по иконке — LAddressBook.L_ROW_MENU_WRITE_ITEM
        # (то же overlay-меню); он и используется в chunk'е.
        i18n_str = i18n.get_str('user_profile_type_message_button', lang)
        return 'xpath', f'//iva-menu[@role="menu"]//button[@role="menuitem"][normalize-space()="{i18n_str}"]'

    @staticmethod
    def L_SIDEBAR_USER_AVATAR(lang=''):
        return 'xpath', f'{LUserProfile.L_ROOT()[1]}//sidebar-user-avatar'

    @staticmethod
    def L_SIDEBAR_USER_INFO(lang=''):
        return 'xpath', f'{LUserProfile.L_SIDEBAR_USER_AVATAR()[1]}//div[@class="info"]'

    @staticmethod
    def L_SIDEBAR_USER_FULL_NAME(lang=''):
        return 'xpath', f'{LUserProfile.L_SIDEBAR_USER_INFO()[1]}//msg-expandable-text[@class="name"]'

    @staticmethod
    def L_SIDEBAR_USER_FULL_NAME_RENDER(lang=''):
        return 'xpath', f'{LUserProfile.L_SIDEBAR_USER_FULL_NAME()[1]}//span[@class="lc-render"]'

    @staticmethod
    def L_SIDEBAR_USER_AVATAR_RENDER(lang=''):
        # iva-билд: аватар карточки — sidebar-user-avatar → contact-avatar → iva-avatar.
        return 'xpath', f'{LUserProfile.L_SIDEBAR_USER_AVATAR()[1]}//iva-avatar'

    @staticmethod
    def L_I18N_PROFILE_FIELD(title_key, value, lang):
        title = i18n.get_str(title_key, lang)
        return 'xpath', (
            f'{LUserProfile.L_ROOT()[1]}//employee-info-item'
            f'[.//div[@class="title"][normalize-space()="{title}"]]'
            f'[.//div[contains(@class,"value-container")][contains(normalize-space(),"{value}")]]'
        )

    @staticmethod
    def L_ORG_STRUCTURE_BTN(lang=''):
        # Кнопка-chevron орг-структуры в строке «Должность» (есть только у юзера с managerId/team).
        return 'xpath', f'{LUserProfile.L_ROOT()[1]}//employee-info-position//button[contains(@class,"org-structure-button")]'

    @staticmethod
    def L_I18N_ACTION_BTN(key, lang):
        # Дрейф 2026-07-02: <sidebar-action-bar> умер — action'ы карточки теперь в
        # <action-bar mode="sidebar">: Позвонить / Видео / Ещё («Написать» ушла в меню «Ещё»).
        text = i18n.get_str(key, lang)
        return 'xpath', f'{LUserProfile.L_ROOT()[1]}//action-bar[@mode="sidebar"]//button[normalize-space()="{text}"]'
