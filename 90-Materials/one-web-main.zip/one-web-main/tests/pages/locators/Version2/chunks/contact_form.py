from tools import i18n


class LContactForm:
    """Локаторы формы создания/редактирования личного контакта (sidebar iva-*).

    Корень — `<sidebar-layout>` именованного outlet'а с `contacts-personal-contact-group-select`
    внутри (у самого компонента формы своего тега нет). Поля — `<iva-form-field>` + native
    `<input ivainput formcontrolname="...">`; formcontrolname виден в DOM на iva-сборке.
    """

    @staticmethod
    def L_ROOT(lang=''):
        return 'xpath', '//sidebar-layout[.//contacts-personal-contact-group-select]'

    @staticmethod
    def L_FIELD(control_name, lang=''):
        # Одиночное поле формы по formcontrolname:
        # firstName/lastName/middleName/primaryPhone/primaryEmail/companyName/position.
        return 'xpath', f'{LContactForm.L_ROOT()[1]}//input[@formcontrolname="{control_name}"]'

    @staticmethod
    def L_GROUP_SELECT(lang=''):
        # Селект «Адресная книга» (iva-select).
        return 'xpath', '//contacts-personal-contact-group-select//iva-select'

    @staticmethod
    def L_GROUP_SELECT_VALUE(book_name, lang=''):
        # Предвыбранная книга показывается значением iva-select (текст в самом компоненте;
        # опции дропдауна — в overlay на body, сюда не попадают).
        return 'xpath', (
            f'//contacts-personal-contact-group-select//iva-select'
            f'[contains(normalize-space(.),"{book_name}")]'
        )

    @staticmethod
    def L_I18N_SUBMIT_CREATE_BTN(lang):
        # Кнопка сохранения в режиме создания — «Создать контакт» (footer формы).
        text = i18n.get_str('address_book_create_contact_text_button', lang)
        return 'xpath', (
            f'{LContactForm.L_ROOT()[1]}//div[contains(@class,"footer")]'
            f'//button[@type="submit"][.//span[contains(@class,"label")][normalize-space()="{text}"]]'
        )

    @staticmethod
    def L_I18N_SUBMIT_SAVE_BTN(lang):
        # Кнопка сохранения в режиме редактирования — «Сохранить» (footer формы).
        # Та же форма, что create, но текст кнопки иной (create = «Создать контакт»).
        text = i18n.get_str('address_book_edit_screen_button_text_web', lang)
        return 'xpath', (
            f'{LContactForm.L_ROOT()[1]}//div[contains(@class,"footer")]'
            f'//button[@type="submit"][.//span[contains(@class,"label")][normalize-space()="{text}"]]'
        )

    @staticmethod
    def L_I18N_ADD_PHONE_BTN(lang):
        # Кнопка «Добавить телефон» — добавляет поле в FormArray доп. телефонов.
        # disabled при достижении лимита (4) — см. TC-47001.
        text = i18n.get_str('address_book_contact_add_phone_text', lang)
        return 'xpath', (
            f'{LContactForm.L_ROOT()[1]}//button[contains(@class,"add-field-button")]'
            f'[.//span[contains(@class,"label")][normalize-space()="{text}"]]'
        )

    @staticmethod
    def L_ADDITIONAL_PHONE(index, lang=''):
        # Доп. телефон по 1-based индексу. У полей FormArray formcontrolname НЕ задан —
        # якорь по контейнеру `additionalPhones` + позиции `additional-field-control`.
        # Скобки вокруг node-set обязательны: каждое доп. поле — в своей обёртке
        # `div.additional-field`, поэтому позиционный предикат без скобок (`...[2]`) считает
        # «2-е относительно родителя» и не находит ничего; `(...)[2]` берёт 2-е по документу.
        return 'xpath', (
            f'({LContactForm.L_ROOT()[1]}//div[@formarrayname="additionalPhones"]'
            f'//iva-form-field[contains(@class,"additional-field-control")])[{index}]//input'
        )

    @staticmethod
    def L_ADDITIONAL_PHONE_ALL(lang=''):
        # Все поля доп. телефонов (без индекса) — для подсчёта уже добавленных.
        return 'xpath', (
            f'{LContactForm.L_ROOT()[1]}//div[@formarrayname="additionalPhones"]'
            f'//iva-form-field[contains(@class,"additional-field-control")]//input'
        )

    @staticmethod
    def L_I18N_PRIMARY_PHONE_REQUIRED_ERROR(lang):
        # Form-level inline-ошибка «доп. телефон без основного». Лежит в div.field-group
        # (вне iva-form-field/formarray) — якорь только по тексту.
        text = i18n.get_str('address_book_contact_primary_phone_required_error', lang)
        return 'xpath', f'//iva-form-error[normalize-space()="{text}"]'
