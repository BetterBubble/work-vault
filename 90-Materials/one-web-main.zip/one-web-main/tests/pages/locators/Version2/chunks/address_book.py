from tools import i18n


class LAddressBook:
    @staticmethod
    def L_I18N_SEARCH_INPUT(lang):
        i18n_str = i18n.get_str('contacts_search_input', lang)
        return 'xpath', f'//input[@placeholder="{i18n_str}"]'

    @staticmethod
    def L_ADDRESS_BOOK_ITEMS(lang=''):
        # iva-билд: контейнер списка — <contacts-table>.
        return 'xpath', f'//contacts-table//div[contains(@class,"table-row")]'

    @staticmethod
    def L_ADDRESS_BOOK_ITEM(username, lang=''):
        return 'xpath', f'{LAddressBook.L_ADDRESS_BOOK_ITEMS()[1]}[contains(.,"{username}")]'

    @staticmethod
    def L_ADDRESS_BOOK_ITEM_AVATAR_INITIALS(username, lang=''):
        # iva-билд: дефолт-аватар = <iva-avatar>; инициалы — span.initials в слое fallback.
        return 'xpath', f'{LAddressBook.L_ADDRESS_BOOK_ITEM(username)[1]}//iva-avatar//span[contains(@class,"initials")]'

    @staticmethod
    def L_ADDRESS_BOOK_ITEM_AVATAR_BG(username, lang=''):
        # Резолвнутый appearance (цвет градиента) — атрибут data-appearance на <iva-avatar-background>.
        return 'xpath', f'{LAddressBook.L_ADDRESS_BOOK_ITEM(username)[1]}//iva-avatar//iva-avatar-background'

    @staticmethod
    def L_I18N_TREE_PERSONAL_ROOT(lang):
        text = i18n.get_str('contact_tree_personal_root', lang)
        return 'xpath', f'//*[@role="treeitem"][.//*[normalize-space()="{text}"]]'

    @staticmethod
    def L_I18N_TREE_PERSONAL_ROOT_TOGGLE(lang):
        # chevron-кнопка (cdk-tree toggle) внутри узла «Личные» — только раскрывает/сворачивает.
        return 'xpath', f'{LAddressBook.L_I18N_TREE_PERSONAL_ROOT(lang)[1]}//button[contains(@class,"toggle-button")]'

    @staticmethod
    def L_I18N_TREE_PERSONAL_ROOT_LINK(lang):
        # Ссылка-контент узла «Личные» (a.tree-node-content с cdkTreeNodeToggle) — клик
        # раскрывает/сворачивает узел. У пустой «Личные» (0 книг) отдельного chevron нет,
        # раскрытие — кликом по этой ссылке.
        return 'xpath', (
            f'{LAddressBook.L_I18N_TREE_PERSONAL_ROOT(lang)[1]}'
            f'//a[contains(@class,"tree-node-content")]'
        )

    @staticmethod
    def L_TREE_BOOK_NODE_LINK(book_name, lang=''):
        # Навигацию в книгу триггерит внутренний <a class="tree-node-content">, а не
        # сам контейнер cdk-tree-node (клик по контейнеру на Safari не навигирует).
        return 'xpath', (
            f'//*[@role="treeitem"][.//*[normalize-space()="{book_name}"]]'
            f'//a[contains(@class,"tree-node-content")]'
        )

    @staticmethod
    def L_CONTACT_ROW_NAME(full_name, lang=''):
        # Клик именно по имени (не по центру строки — там чекбокс/мультиселект) открывает карточку.
        return 'xpath', (
            f'//contacts-table//div[contains(@class,"table-row")]'
            f'//contacts-contact-name[contains(.,"{full_name}")]'
        )

    @staticmethod
    def L_I18N_PERSONAL_BOOK_EMPTY_STUB(lang):
        text = i18n.get_str('contact_personal_book_empty_stub', lang)
        return 'xpath', f'//*[normalize-space()="{text}"]'

    @staticmethod
    def L_I18N_TREE_ALL_CONTACTS_LINK(lang):
        text = i18n.get_str('contact_tree_all_contacts', lang)
        return 'xpath', (
            f'//*[@role="treeitem"][.//*[normalize-space()="{text}"]]'
            f'//a[contains(@class,"tree-node-content")]'
        )

    @staticmethod
    def L_ROW(name, lang=''):
        return 'xpath', (
            f'//contacts-table//div[contains(@class,"table-row")]'
            f'[.//contacts-contact-name[normalize-space()="{name}"]]'
        )

    @staticmethod
    def L_ROW_CHECKBOX(name, lang=''):
        # Кликабельный виджет чекбокса строки (iva-билд: ds-checkbox→iva-checkbox; целимся в
        # iva-checkbox, не в строку — клик по строке открывает карточку).
        return 'xpath', f'{LAddressBook.L_ROW(name)[1]}//iva-checkbox'

    @staticmethod
    def L_ROW_CHECKBOX_INPUT(name, lang=''):
        # input чекбокса строки — для чтения «отмечен» через is_selected() (checked-property).
        return 'xpath', f'{LAddressBook.L_ROW_CHECKBOX(name)[1]}//input[@type="checkbox"]'

    @staticmethod
    def L_ROW_SELECTED(name, lang=''):
        # Строка контакта в состоянии «выбрана» (открыт sidebar этого контакта).
        return 'xpath', f'{LAddressBook.L_ADDRESS_BOOK_ITEM(name)[1]}[contains(@class,"_sidebar-active")]'

    @staticmethod
    def L_ROW_NAMES(lang=''):
        # Имена всех строк списка (проверка сортировки). iva-билд: ФИО — в
        # contacts-contact-name//div.display-name (редеплой: класс div сменился ellipsis→display-name).
        return 'xpath', (
            f'{LAddressBook.L_ADDRESS_BOOK_ITEMS()[1]}'
            f'//contacts-contact-name//div[contains(@class,"display-name")]'
        )

    @staticmethod
    def L_ROW_CHAT_BTN(name, lang=''):
        # Дрейф 2026-07-02: прямой кнопки чата в строке больше нет — action'ы строки теперь
        # в <action-bar mode="table"> (телефон/видео/кебаб), «Написать» ушла в кебаб-меню
        # (см. L_ROW_MENU_WRITE_ITEM). Имя метода историческое; теперь это кебаб-кнопка строки.
        return 'xpath', f'{LAddressBook.L_ADDRESS_BOOK_ITEM(name)[1]}//action-bar//button[.//iva-icon-ellipsis-vertical]'

    @staticmethod
    def L_ROW_MENU_WRITE_ITEM(lang=''):
        # Пункт «Написать» кебаб-меню строки; <iva-menu role="menu"> рендерится в cdk-overlay,
        # вне table-row. Матч по иконке message-circle-line — языконезависимо.
        return 'xpath', '//iva-menu[@role="menu"]//button[@role="menuitem"][.//iva-icon-message-circle-line]'

    @staticmethod
    def L_ALPHABET_ROW(letter, lang=''):
        # Буквенный разделитель списка; «линия» — CSS border-bottom самого row, не элемент.
        return 'xpath', (
            f'//contacts-table//div[contains(@class,"alphabet-row")'
            f' and normalize-space(text())="{letter}"]'
        )

    @staticmethod
    def L_CONTACTS_SCROLL_CONTAINER(lang=''):
        # Реальный скролл-контейнер списка контактов (сборка 2.1.0-RC1): список обёрнут в
        # iva-scroll-area, скроллится его div.viewport (overflow-y:auto). Сам <contacts-table>
        # теперь overflow:visible — присвоение scrollTop на нём тихий no-op. Голый
        # //div[contains(@class,"viewport")] неоднозначен (первым матчится viewport дерева
        # книг contacts-groups-tree), поэтому якорим от contacts-table через ancestor.
        return 'xpath', '//contacts-table/ancestor::div[contains(@class,"viewport")][1]'

    @staticmethod
    def L_LOAD_TRIGGER(lang=''):
        # Триггер догрузки — последний элемент внутри contacts-table.
        return 'xpath', f'{LAddressBook.L_CONTACTS_SCROLL_CONTAINER()[1]}//msg-load-trigger'

    @staticmethod
    def L_LOAD_TRIGGER_ACTIVE(lang=''):
        # Триггер в состоянии «есть ещё страницы» (canLoadMore=true): внутренний div.root
        # БЕЗ класса _hidden. Сборка 2026-07-02: host-биндинга [class.hidden] на стенде нет
        # (host всегда class="accent-fill"), маркер живёт на div[ivainview].root.
        return 'xpath', (
            f'{LAddressBook.L_CONTACTS_SCROLL_CONTAINER()[1]}'
            f'//msg-load-trigger[div[not(contains(concat(" ", normalize-space(@class), " ")," _hidden "))]]'
        )

    @staticmethod
    def L_LOAD_TRIGGER_HIDDEN(lang=''):
        # Триггер скрыт (canLoadMore=false): div.root получил класс _hidden (см. ACTIVE выше).
        return 'xpath', (
            f'{LAddressBook.L_CONTACTS_SCROLL_CONTAINER()[1]}'
            f'//msg-load-trigger[div[contains(concat(" ", normalize-space(@class), " ")," _hidden ")]]'
        )

    @staticmethod
    def L_LOAD_TRIGGER_SPINNER(lang=''):
        # Сборка 2026-07-02: iva-spinner внутри триггера НЕ рендерится вовсе (семплирование
        # 100мс во время догрузки) — как позитивный детект мёртв; wait_absence на него
        # безвреден и остаётся у вызывающих.
        return 'xpath', f'{LAddressBook.L_LOAD_TRIGGER()[1]}//iva-spinner'

    @staticmethod
    def L_TREE_NODE_SELECTED(node_text, lang=''):
        # Активная нода дерева книг — модификатор _selected на div.tree-node.
        return 'xpath', (
            f'//*[@role="treeitem"][.//*[normalize-space()="{node_text}"]]'
            f'//div[contains(@class,"tree-node") and contains(@class,"_selected")]'
        )

    @staticmethod
    def L_BULK_BAR(lang=''):
        # Дрейф 2026-07-02: плашка пересобрана на <iva-header mode="content-area">
        # (div.selection-topbar умер). Дискриминатор от обычного контентного хедера —
        # наличие <action-bar mode="header"> с bulk-действиями; после «Сбросить» узла
        # нет (пригоден для wait_absence).
        return 'xpath', '//contacts-header//iva-header[.//action-bar[@mode="header"]]'

    @staticmethod
    def L_I18N_BULK_SELECTED_COUNT(n, lang):
        # Дрейф 2026-07-02: div.selected-count умер — текст «Выбрано: N» теперь прямо
        # в секции хедера (iva-header-section contenttype="content").
        text = i18n.get_str('contacts_multiselect_selected_count', lang)
        return 'xpath', f'{LAddressBook.L_BULK_BAR()[1]}//iva-header-section[@data-content-type="content"][normalize-space()="{text} {n}"]'

    @staticmethod
    def L_I18N_BULK_RESET_BTN(lang):
        text = i18n.get_str('contacts_multiselect_reset_button', lang)
        return 'xpath', f'{LAddressBook.L_BULK_BAR()[1]}//button[normalize-space()="{text}"]'

    # Контейнер bulk-действий — <action-bar mode="header"> (дрейф 2026-07-02: div.actions умер).

    @staticmethod
    def L_BULK_ACTION_WRITE(lang=''):
        # Кнопка «Написать» (создать чат) в bulk-bar — по тегу иконки (aria-label/title нет).
        return 'xpath', f'{LAddressBook.L_BULK_BAR()[1]}//action-bar[@mode="header"]//button[.//iva-icon-message-circle-line]'

    @staticmethod
    def L_BULK_ACTION_MORE(lang=''):
        # Кнопка «Ещё» (ellipsis) в bulk-bar — открывает меню с Переместить/Удалить и т.п.
        # Рендерится только при mixed-выборке (корп+личный): при corp-only и personal-only
        # действия помещаются в limit action-bar и ellipsis'а нет.
        return 'xpath', f'{LAddressBook.L_BULK_BAR()[1]}//action-bar[@mode="header"]//button[.//iva-icon-ellipsis-vertical]'

    @staticmethod
    def L_BULK_ACTION_EVENT_TRIGGER(lang=''):
        # Кнопка-триггер «Событие» в bulk-bar (iva-icon-calendar-line) — открывает меню
        # {ВКС-встреча, Событие}. Заменила прежнюю прямую иконку ВКС (calendar-video) и
        # пункт «Событие» в меню «Ещё».
        return 'xpath', f'{LAddressBook.L_BULK_BAR()[1]}//action-bar[@mode="header"]//button[.//iva-icon-calendar-line]'

    @staticmethod
    def L_BULK_ACTION_CALL(lang=''):
        # «Позвонить» (групповой звонок) в bulk-bar — по иконке iva-icon-phone-line
        # (контейнер кнопок — action-bar, как WRITE/MCU/MORE).
        return 'xpath', f'{LAddressBook.L_BULK_BAR()[1]}//action-bar[@mode="header"]//button[.//iva-icon-phone-line]'

    @staticmethod
    def L_CHIP(name, lang=''):
        # Чип выбранного контакта в chip-input (маркер pinning при поиске).
        return 'xpath', (
            f'//ds-chip-input[contains(@class,"selected-contacts-chips")]'
            f'//button[contains(@class,"chip-button")][contains(normalize-space(),"{name}")]'
        )

    @staticmethod
    def L_CHIP_REMOVE_BTN(name, lang=''):
        # Крестик удаления внутри чипа (iva-icon-circle-x-fill, отдельной <button> нет).
        # Виден только по hover на чип (вне hover display:none, 0×0).
        return 'xpath', f'{LAddressBook.L_CHIP(name)[1]}//iva-icon-circle-x-fill'

    @staticmethod
    def L_MULTISELECT_SEARCH_INPUT(lang=''):
        # Поле поиска внутри chip-input (обычный ds-input заменяется им в режиме мультиселекта).
        return 'xpath', '//ds-chip-input[contains(@class,"selected-contacts-chips")]//input'

    # Экран-разделитель доступности (cans-divider) — общая контентная модалка <iva-modal>
    # для действий из мультиселекта (Создать чат / Перемещение / Удаление / Звонок).
    # Параметризован i18n-ключами заголовка/инварианта/кнопки. Структура одинакова:
    # контакт — div.item, недоступный — с вложенным div.disabled-item-overlay.

    @staticmethod
    def L_I18N_ACTION_DIVIDER(title_key, lang):
        # iva-сборка 2.1.0: divider — <iva-modal> (ds-dialog удалён); заголовок остался
        # div.title (в iva-header, id динамический — не якорим).
        title = i18n.get_str(title_key, lang)
        return 'xpath', (
            f'//iva-modal[.//div[contains(@class,"title")][normalize-space()="{title}"]]'
        )

    @staticmethod
    def L_I18N_ACTION_DIVIDER_INFO(title_key, invariant_key, lang):
        # Текст-разделитель — по инвариантной подстроке (числа/склонение варьируются).
        invariant = i18n.get_str(invariant_key, lang)
        return 'xpath', (
            f'{LAddressBook.L_I18N_ACTION_DIVIDER(title_key, lang)[1]}'
            f'//div[contains(@class,"unavailable-info") and contains(normalize-space(),"{invariant}")]'
        )

    @staticmethod
    def L_I18N_ACTION_DIVIDER_CONTACT_UNAVAILABLE(title_key, name, lang):
        return 'xpath', (
            f'{LAddressBook.L_I18N_ACTION_DIVIDER(title_key, lang)[1]}'
            f'//div[contains(@class,"item")][.//contacts-contact-name[normalize-space()="{name}"]]'
            f'[.//div[contains(@class,"disabled-item-overlay")]]'
        )

    @staticmethod
    def L_I18N_ACTION_DIVIDER_CONTACT_AVAILABLE(title_key, name, lang):
        return 'xpath', (
            f'{LAddressBook.L_I18N_ACTION_DIVIDER(title_key, lang)[1]}'
            f'//div[contains(@class,"item")][.//contacts-contact-name[normalize-space()="{name}"]]'
            f'[not(.//div[contains(@class,"disabled-item-overlay")])]'
        )

    @staticmethod
    def L_I18N_ACTION_DIVIDER_CONFIRM(title_key, confirm_key, lang):
        # Кнопка «<действие> доступных» — primary в footer (класс save-action-button умер,
        # текст кнопки теперь в span.label).
        text = i18n.get_str(confirm_key, lang)
        return 'xpath', (
            f'{LAddressBook.L_I18N_ACTION_DIVIDER(title_key, lang)[1]}'
            f'//footer//button[.//span[contains(@class,"label")][normalize-space()="{text}"]]'
        )

    @staticmethod
    def L_I18N_ACTION_DIVIDER_CANCEL(title_key, lang):
        text = i18n.get_str('contacts_create_chat_cancel_button', lang)  # «Отмена» — общая для разделителей
        # Кнопка secondary в footer (класс cancel-action-button умер, текст в span.label);
        # ivadialogclose она НЕ несёт — закрытие крестиком это отдельная кнопка в header.
        return 'xpath', (
            f'{LAddressBook.L_I18N_ACTION_DIVIDER(title_key, lang)[1]}'
            f'//footer//button[.//span[contains(@class,"label")][normalize-space()="{text}"]]'
        )

    # --- Книги (папки) адресной книги: ПКМ по узлу дерева + диалог редактирования ---
    # Контекстное меню узла книги вызывается ТОЛЬКО правым кликом (contextmenu) по
    # ссылке узла ПОЛЬЗОВАТЕЛЬСКОЙ книги — гард продукта `isPersonalGroupTreeNode`
    # отсекает системные узлы («Все контакты»/«Корпоративные»/«Личные»). Hover-kebab'а нет.

    @staticmethod
    def L_TREE_BOOK_NODE(book_name, lang=''):
        # Контейнер узла книги в дереве (<cdk-tree-node role=treeitem>) по видимому имени.
        return 'xpath', (
            f'//cdk-tree-node[@role="treeitem"]'
            f'[.//div[contains(@class,"tree-node-name")][normalize-space()="{book_name}"]]'
        )

    @staticmethod
    def L_TREE_BOOK_NODE_ICON(book_name, icon_tag, lang=''):
        # Иконка книги в узле дерева (iva-билд: <contacts-group-icon [iconKey]> рендерит
        # <iva-icon-*> через getGroupIconComponent; напр. icon_tag="iva-icon-crown" для короны).
        return 'xpath', f'{LAddressBook.L_TREE_BOOK_NODE(book_name)[1]}//contacts-group-icon//{icon_tag}'

    @staticmethod
    def L_TREE_CONTEXT_MENU(lang=''):
        # iva-сборка: корень контекстного меню узла книги — <iva-menu role="menu"> (был ds-overlay div[@dsmenu]).
        return 'xpath', '//iva-menu[@role="menu"]'

    @staticmethod
    def L_I18N_TREE_CTX_EDIT_BOOK(lang):
        # Пункт меню «Редактировать книгу». iva-сборка: текст пункта в div.label (был ds-паттерн div.content).
        text = i18n.get_str('address_book_edit_book_screen_title_web', lang)
        return 'xpath', (
            f'{LAddressBook.L_TREE_CONTEXT_MENU()[1]}'
            f'//button[@role="menuitem"][.//div[contains(@class,"label")][normalize-space()="{text}"]]'
        )

    @staticmethod
    def L_I18N_TREE_CTX_DELETE_BOOK(lang):
        # Пункт меню «Удалить». iva-сборка: текст пункта в div.label (был ds-паттерн div.content).
        text = i18n.get_str('address_book_delete_button_text', lang)
        return 'xpath', (
            f'{LAddressBook.L_TREE_CONTEXT_MENU()[1]}'
            f'//button[@role="menuitem"][.//div[contains(@class,"label")][normalize-space()="{text}"]]'
        )

    @staticmethod
    def L_EDIT_BOOK_DIALOG(lang=''):
        # Корень диалога создания/редактирования книги (cdk-dialog-container с полем имени);
        # iva-сборка: ds-input → iva-form-field.personal-group-name-input; различать create/edit по заголовку.
        return 'xpath', '//cdk-dialog-container[@role="dialog"][.//iva-form-field[contains(@class,"personal-group-name-input")]]'

    @staticmethod
    def L_I18N_EDIT_BOOK_DIALOG_TITLE(lang):
        text = i18n.get_str('address_book_edit_book_screen_title_web', lang)
        return 'xpath', f'{LAddressBook.L_EDIT_BOOK_DIALOG()[1]}//*[normalize-space()="{text}"]'

    @staticmethod
    def L_EDIT_BOOK_NAME_INPUT(lang=''):
        # iva-сборка: ds-input → iva-form-field; имя — нативный input[ivainput formcontrolname="name"] (maxlength=255).
        return 'xpath', f'{LAddressBook.L_EDIT_BOOK_DIALOG()[1]}//iva-form-field[contains(@class,"personal-group-name-input")]//input[@formcontrolname="name"]'

    @staticmethod
    def L_EDIT_BOOK_ICON_OPTIONS(lang=''):
        return 'xpath', f'{LAddressBook.L_EDIT_BOOK_DIALOG()[1]}//div[contains(@class,"personal-group-icon-options")]'

    @staticmethod
    def L_EDIT_BOOK_ICON_BUTTON(icon_tag, lang=''):
        # Кнопка иконки пикера по тегу iva-icon (идентификация ТОЛЬКО по вложенному iva-icon —
        # title/aria у кнопок нет). icon_tag — член enums.AddressBookGroupIcon.
        return 'xpath', f'{LAddressBook.L_EDIT_BOOK_ICON_OPTIONS()[1]}//button[contains(@class,"option-button")][.//{icon_tag}]'

    @staticmethod
    def L_EDIT_BOOK_ICON_BUTTON_SELECTED(icon_tag, lang=''):
        # Выбрана ли иконка с данным iva-icon (выбранная кнопка пикера — класс _selected).
        return 'xpath', (
            f'{LAddressBook.L_EDIT_BOOK_ICON_OPTIONS()[1]}'
            f'//button[contains(@class,"option-button") and contains(@class,"_selected")][.//{icon_tag}]'
        )

    @staticmethod
    def L_I18N_EDIT_BOOK_SAVE_BTN(lang):
        # iva-сборка: текст кнопки в span.label (был ds-паттерн span.content).
        text = i18n.get_str('address_book_edit_screen_button_text_web', lang)
        return 'xpath', f'{LAddressBook.L_EDIT_BOOK_DIALOG()[1]}//button[.//span[contains(@class,"label")][normalize-space()="{text}"]]'

    # --- Создание книги: узел-кнопка «Новая книга» в дереве + диалог create ---
    # Диалог create = тот же корень L_EDIT_BOOK_DIALOG (различение по заголовку/кнопке).

    @staticmethod
    def L_TREE_CREATE_BOOK_BTN(lang=''):
        # Кнопка-узел «Новая книга» в дереве групп (leftbar). Якорь — уникальный тег-обёртка
        # + класс кнопки (текст «Новая книга» лежит в дочернем .tree-node-name).
        return 'xpath', '//contacts-create-personal-group-node//button[contains(@class,"create-personal-node-button")]'

    @staticmethod
    def L_I18N_CREATE_BOOK_DIALOG_TITLE(lang):
        text = i18n.get_str('address_book_create_book_screen_title_web', lang)
        return 'xpath', f'{LAddressBook.L_EDIT_BOOK_DIALOG()[1]}//*[normalize-space()="{text}"]'

    @staticmethod
    def L_I18N_CREATE_BOOK_BTN(lang):
        # Кнопка «Создать» в диалоге создания книги (текст в span.label, как у save-кнопки edit).
        text = i18n.get_str('address_book_create_screen_button_text_web', lang)
        return 'xpath', f'{LAddressBook.L_EDIT_BOOK_DIALOG()[1]}//button[.//span[contains(@class,"label")][normalize-space()="{text}"]]'

    @staticmethod
    def L_I18N_CREATE_CONTACT_BTN(lang):
        # Кнопка «+» создания контакта в шапке дерева (aria-label «Создать контакт»).
        # Дрейф 2026-07-02: класс add-button умер (теперь просто iva-button) —
        # якорь по contacts-header + локализованному aria-label.
        text = i18n.get_str('address_book_create_contact_text_button', lang)
        return 'xpath', f'//contacts-header//button[@aria-label="{text}"]'

    @staticmethod
    def L_I18N_DELETE_BOOK_DIALOG(lang):
        # Корень окна подтверждения удаления книги — по заголовку «Удалить адресную книгу?».
        title = i18n.get_str('address_book_delete_book_title', lang)
        return 'xpath', (
            f'//cdk-dialog-container[@role="dialog"]'
            f'[.//div[contains(@class,"title")][normalize-space()="{title}"]]'
        )

    @staticmethod
    def L_I18N_DELETE_BOOK_CONFIRM_BTN(lang):
        # Кнопка подтверждения «Удалить» — критическая (data-appearance="critical") в footer.
        # iva-сборка 2.1.0: классы bad-secondary-button/span.content умерли; обе кнопки футера
        # data-mode="secondary" → различаем только по тексту span.label.
        text = i18n.get_str('address_book_delete_button_text', lang)
        return 'xpath', (
            f'{LAddressBook.L_I18N_DELETE_BOOK_DIALOG(lang)[1]}'
            f'//footer//button[.//span[contains(@class,"label")][normalize-space()="{text}"]]'
        )

    @staticmethod
    def L_I18N_DELETE_BOOK_CANCEL_BTN(lang):
        # Кнопка «Отмена» (несёт ivadialogclose) в footer, текст в span.label. Обе кнопки
        # футера data-mode="secondary" — дискриминатор только текст (у подтверждения «Удалить»).
        text = i18n.get_str('general_cancel_label', lang)
        return 'xpath', (
            f'{LAddressBook.L_I18N_DELETE_BOOK_DIALOG(lang)[1]}'
            f'//footer//button[.//span[contains(@class,"label")][normalize-space()="{text}"]]'
        )

    @staticmethod
    def L_DELETE_BOOK_DIALOG_BODY(book_name, lang):
        # Предупреждение о каскаде «Книга "X" и N контактов будут удалены». iva-сборка 2.1.0:
        # div.dialog-body умер — текст теперь div.description в header (сосед div.title);
        # матчим по упоминанию имени книги (текст параметризован).
        return 'xpath', (
            f'{LAddressBook.L_I18N_DELETE_BOOK_DIALOG(lang)[1]}'
            f'//div[contains(@class,"description")][contains(normalize-space(),"{book_name}")]'
        )
