from tools import i18n


class LAddParticipantsDialog:
    """Локаторы попапа «Добавить участников» (выбор контактов в форме создания мероприятия
    календаря). Контейнер cdk-dialog → <iva-modal> (сборка 2.1.0; ds-dialog удалён);
    заголовок — div.title в iva-header (id динамический — в предикатах не использовать),
    кнопки — в footer.footer. Список — <contacts-table>, строка = div.table-row
    (НЕ <button>). Поиск оборачивает совпадение в <span class="messenger-search-
    highlight"> → матчим имя через normalize-space() (не text())."""

    @staticmethod
    def L_DIALOG(lang=''):
        # iva-сборка 2.1.0: попап — <iva-modal> (ds-dialog удалён из сборки).
        return 'xpath', '//iva-modal'

    @staticmethod
    def L_I18N_DIALOG_BY_TITLE(lang):
        title = i18n.get_str('calendar_add_participants_dialog_title', lang)
        return 'xpath', (
            f'{LAddParticipantsDialog.L_DIALOG()[1]}'
            f'[.//div[contains(@class,"title") and normalize-space()="{title}"]]'
        )

    @staticmethod
    def L_I18N_SEARCH_INPUT(lang):
        # Поиск по ФИО/отделу/должности — переиспользуем существующий ключ.
        placeholder = i18n.get_str('contacts_search_input', lang)
        return 'xpath', f'{LAddParticipantsDialog.L_DIALOG()[1]}//input[@placeholder="{placeholder}"]'

    @staticmethod
    def L_CONTACT_ROW(full_name, lang=''):
        return 'xpath', (
            f'{LAddParticipantsDialog.L_DIALOG()[1]}//contacts-table//div[contains(@class,"table-row")]'
            f'[.//contacts-contact-name[normalize-space()="{full_name}"]]'
        )

    @staticmethod
    def L_I18N_CONFIRM_BTN(lang):
        # iva-сборка 2.1.0: @dsprimarybutton умер — primary-кнопка в footer, различаем по тексту.
        text = i18n.get_str('calendar_add_participants_confirm_btn', lang)
        return 'xpath', f'{LAddParticipantsDialog.L_DIALOG()[1]}//footer//button[normalize-space()="{text}"]'
