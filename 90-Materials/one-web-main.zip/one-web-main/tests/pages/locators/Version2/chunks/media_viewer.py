class LMediaViewer:
    """Локаторы fullscreen media viewer'а (`<lib-media-viewer>` внутри `<cdk-dialog-container>`).

    Открывается кликом на медиа-карточку в gallery-view или в сообщении чата.
    Корень общий для image и video; отличаются только content-slide'ы внутри.
    Закрывается клавишей Esc или кнопкой X в header.
    """

    @staticmethod
    def L_ROOT(lang=''):
        return 'xpath', '//lib-media-viewer'

    @staticmethod
    def L_IMAGE_CONTENT_SLIDE(lang=''):
        # Отличительный маркер — «открыт image».
        return 'xpath', f'{LMediaViewer.L_ROOT()[1]}//lib-secure-image-content-slide'

    @staticmethod
    def L_VIDEO_CONTENT_SLIDE(lang=''):
        # Отличительный маркер — «открыто video».
        return 'xpath', f'{LMediaViewer.L_ROOT()[1]}//lib-secure-video-content-slide'
