from tools import i18n


class LOrgStructureSidebar:
    @staticmethod
    def L_ROOT(lang=''):
        return 'xpath', '//organization-structure-sidebar'

    @staticmethod
    def L_I18N_MANAGER_BLOCK_HEADER(lang):
        # Шаблон добавляет ':' после transloco-строки — матчим по началу.
        i18n_str = i18n.get_str('contact_profile_header_org_structure_subordinate', lang)
        return 'xpath', (
            f'{LOrgStructureSidebar.L_ROOT()[1]}'
            f'//span[contains(@class,"users-block-header") and starts-with(normalize-space(text()),"{i18n_str}")]'
        )

    @staticmethod
    def L_I18N_TEAM_BLOCK_HEADER(lang):
        i18n_str = i18n.get_str('contact_profile_header_org_structure_manager', lang)
        return 'xpath', (
            f'{LOrgStructureSidebar.L_ROOT()[1]}'
            f'//span[contains(@class,"users-block-header") and starts-with(normalize-space(text()),"{i18n_str}")]'
        )

    @staticmethod
    def L_MANAGER_ITEM(name, lang=''):
        # Руководитель в блоке «В подчинении у:» — имя в div.manager-name (у подчинённых — user-name).
        return 'xpath', (
            f'{LOrgStructureSidebar.L_ROOT()[1]}'
            f'//li[contains(@class,"user")][.//div[contains(@class,"manager-name") and normalize-space(text())="{name}"]]'
        )

    @staticmethod
    def L_TEAM_ITEM(name, lang=''):
        # Подчинённый в блоке «Руководитель для:» — имя в div.user-name.
        return 'xpath', (
            f'{LOrgStructureSidebar.L_ROOT()[1]}'
            f'//li[contains(@class,"user")][.//div[contains(@class,"user-name") and normalize-space(text())="{name}"]]'
        )
