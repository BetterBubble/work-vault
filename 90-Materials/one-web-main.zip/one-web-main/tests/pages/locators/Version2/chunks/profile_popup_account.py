from tools import i18n


class LProfilePopupAccount:

    @staticmethod
    def L_ROOT(lang=''):
        return 'xpath', '//profile-account-info'

    @staticmethod
    def L_I18N_HEADER(lang):
        i18n_str = i18n.get_str('profile_popup_account_header', lang)
        return 'xpath', f'{LProfilePopupAccount.L_ROOT()[1]}//h5[text()="{i18n_str}"]'

    @staticmethod
    def L_FOOTER(lang=''):
        # 2.1.0-RC1: футер Save/Cancel = HTML5 <footer class="footer"> (был div.footer);
        # условный рендер — появляется только при dirty-форме.
        return 'xpath', f'{LProfilePopupAccount.L_ROOT()[1]}//footer[contains(@class,"footer")]'

    @staticmethod
    def L_I18N_USER_INFO(lang):
        i18n_str = i18n.get_str('profile_popup_account_user_display_name_label', lang)
        return 'xpath', f'{LProfilePopupAccount.L_ROOT()[1]}//profile-ui-field-info//span[@class="label" and text()="{i18n_str}"]/following-sibling::span[@class="text"]'

    @staticmethod
    def L_I18N_BTN_LOGOUT(lang):
        i18n_str = i18n.get_str('profile_popup_account_logout_button', lang)
        # iva-сборка: текст в span.label внутри div.content (внук кнопки), а не прямой child-span.
        return 'xpath', f'{LProfilePopupAccount.L_ROOT()[1]}//button[.//span[contains(@class,"label")][normalize-space()="{i18n_str}"]]'

    @staticmethod
    def L_AVATAR_SECTION(lang=''):
        return 'xpath', f'{LProfilePopupAccount.L_ROOT()[1]}//msg-change-avatar'

    @staticmethod
    def L_DS_AVATAR_SECTION(lang=''):
        return 'xpath', f'{LProfilePopupAccount.L_AVATAR_SECTION()[1]}//iva-avatar'

    @staticmethod
    def L_SHOW_AVATAR_UPLOAD_INPUT_BTN(lang=''):  # TODO: кнопка открытия эксплорера для выбора файла, возможно не потребуется
        return 'xpath', f'{LProfilePopupAccount.L_AVATAR_SECTION()[1]}//button'

    @staticmethod
    def L_AVATAR_EDIT_HOST(lang=''):
        # iva-сборка: msg-file-control убран; кликабельный хост ivaFilePicker — <iva-avatar-edit>.
        # По клику лениво создаёт <input type=file> на document.body
        # (см. page_helpers.upload_avatar_via_lazy_picker).
        return 'xpath', f'{LProfilePopupAccount.L_AVATAR_SECTION()[1]}//iva-avatar-edit'

    @staticmethod
    def L_DEFAULT_AVATAR(lang=''):
        return 'xpath', f'{LProfilePopupAccount.L_DS_AVATAR_SECTION()[1]}//iva-avatar-fallback'

    @staticmethod
    def L_AVATAR_IMAGE(lang=''):
        return 'xpath', f'{LProfilePopupAccount.L_DS_AVATAR_SECTION()[1]}//img'

    @staticmethod
    def L_I18N_SAVE_BTN(lang):
        i18n_str = i18n.get_str('profile_popup_account_save_btn', lang)
        return 'xpath', f'{LProfilePopupAccount.L_FOOTER()[1]}//button[contains(.,"{i18n_str}")]'

    @staticmethod
    def L_I18N_CANCEL_BTN(lang):
        i18n_str = i18n.get_str('profile_popup_account_cancel_btn', lang)
        return 'xpath', f'{LProfilePopupAccount.L_FOOTER()[1]}//button[contains(.,"{i18n_str}")]'
