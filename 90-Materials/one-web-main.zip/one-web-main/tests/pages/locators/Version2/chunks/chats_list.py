from tools import i18n


class LChatsList:
    @staticmethod
    def L_I18N_HEADER(lang):
        # Дрейф 2026-07-02: заголовок — <iva-header-section data-content-type="content">
        # внутри iva-header (был h5); текст обрамлён пробелами → normalize-space(), не text()=.
        i18n_str = i18n.get_str('chats_header', lang)
        return 'xpath', (
            f'//chat-chats-header//iva-header-section[@data-content-type="content"]'
            f'[normalize-space()="{i18n_str}"]'
        )

    @staticmethod
    def L_CHAT_ITEM_NAME(chat_name, lang=''):
        return 'xpath', f'//chat-chat-list-item//span[@class="chat-name" and contains(text(),"{chat_name}")]'

    @staticmethod
    def L_CHAT_LIST_ITEM(chat_name, lang=''):
        # Корень элемента чата в списке — right-click target контекстного меню чата
        # ((contextmenu) висит на <chat-chat-list-item>, а не на внутреннем <a>).
        return 'xpath', (
            f'//chat-chat-list-item['
            f'.//chat-card-name//span[contains(@class,"chat-name") '
            f'and contains(normalize-space(.),"{chat_name}")]]'
        )

    @staticmethod
    def L_CHAT_LIST_CONTEXT_MENU(lang=''):
        # Контекстное меню чата в списке (<chat-chat-menu> → <iva-menu role="menu">).
        # Дискриминатор от create-chat/reactions меню — пункт pin/unpin (iva-icon-pin[-off]).
        return 'xpath', (
            '//iva-menu[@role="menu"]'
            '[.//button[@role="menuitem"][.//iva-icon-pin or .//iva-icon-pin-off]]'
        )

    @staticmethod
    def L_I18N_CHAT_LIST_PIN_BTN(lang):
        i18n_str = i18n.get_str('chats_context_menu_item_pin', lang)
        return 'xpath', (
            f'{LChatsList.L_CHAT_LIST_CONTEXT_MENU()[1]}'
            f'//button[@role="menuitem"]'
            f'[.//div[contains(@class,"label")][normalize-space()="{i18n_str}"]]'
        )

    @staticmethod
    def L_CHAT_ITEM_PINNED_ICON(chat_name, lang=''):
        # Признак закрепления: <iva-icon-pin class="pinned-icon"> в бейджах карточки чата.
        # Класс pinned-icon обязателен — отстраивает от iva-icon-pin внутри контекст-меню.
        return 'xpath', (
            f'//chat-chat-list-item['
            f'.//chat-card-name//span[contains(@class,"chat-name") '
            f'and contains(normalize-space(.),"{chat_name}")]]'
            f'//chat-card-badges//iva-icon-pin[contains(@class,"pinned-icon")]'
        )

    @staticmethod
    def L_I18N_CHAT_LIST_DELETE_BTN(lang):
        i18n_str = i18n.get_str('chats_context_menu_item_delete', lang)
        return 'xpath', (
            f'{LChatsList.L_CHAT_LIST_CONTEXT_MENU()[1]}'
            f'//button[@role="menuitem"]'
            f'[.//div[contains(@class,"label")][normalize-space()="{i18n_str}"]]'
        )

    @staticmethod
    def L_I18N_CHAT_DELETE_CONFIRM_DIALOG(lang):
        # Generic confirm «Вы хотите удалить чат?» — тот же, что у удаления группы/канала
        # (reuse i18n-ключа), идентификация по тексту title.
        # 2.1.0: системный confirm — <iva-dialog> (ds-dialog удалён из сборки).
        i18n_str = i18n.get_str('group_chat_profile_delete_chat_confirm_dialog_title', lang)
        return 'xpath', (
            f'//iva-dialog[.//div[contains(@class,"title") '
            f'and contains(normalize-space(),"{i18n_str}")]]'
        )

    @staticmethod
    def L_I18N_CHAT_DELETE_CONFIRM_BTN(lang):
        i18n_str = i18n.get_str('group_chat_profile_delete_chat_confirm_btn', lang)
        return 'xpath', (
            f'{LChatsList.L_I18N_CHAT_DELETE_CONFIRM_DIALOG(lang)[1]}'
            f'//button[normalize-space()="{i18n_str}"]'
        )

    @staticmethod
    def L_CHATS_LIST_SEARCH_BTN(lang=''):
        # ds→iva: ds-icon-search→iva-icon-search; класс обёртки title-row→title (убран промежуточный div).
        return 'xpath', '//chat-chats-header//button[.//iva-icon-search]'

    @staticmethod
    def L_CREATE_CHAT_BTN(lang=''):
        # ds→iva: @dsprimarybutton→@ivabuttonicon, ds-icon-plus→iva-icon-plus (теперь меню-триггер).
        return 'xpath', '//chat-chats-header//button[@ivabuttonicon][.//iva-icon-plus]'

    @staticmethod
    def L_CREATE_CHAT_TYPE_MENU(lang=''):
        # ds→iva: контекст-меню теперь тег <iva-menu> (был div[@dsmenu]).
        return 'xpath', '//iva-menu[@role="menu"]'

    @staticmethod
    def L_I18N_CREATE_CHAT_MENU_GROUP_BTN(lang):
        i18n_str = i18n.get_str('create_chat_menu_group_title', lang)
        return 'xpath', (
            f'{LChatsList.L_CREATE_CHAT_TYPE_MENU()[1]}'
            f'//button[@role="menuitem"][.//div[contains(@class,"label")][normalize-space()="{i18n_str}"]]'
        )

    @staticmethod
    def L_I18N_CREATE_CHAT_MENU_CHANNEL_BTN(lang):
        i18n_str = i18n.get_str('create_chat_menu_channel_title', lang)
        return 'xpath', (
            f'{LChatsList.L_CREATE_CHAT_TYPE_MENU()[1]}'
            f'//button[@role="menuitem"][.//div[contains(@class,"label")][normalize-space()="{i18n_str}"]]'
        )

    @staticmethod
    def L_I18N_CHATS_LIST_SEARCH_INPUT(lang):
        i18n_str = i18n.get_str('chat_list_search_placeholder', lang)
        # iva-сборка: обёртка div.search-title-row убрана; инпут поиска — под <iva-input-search>.
        return 'xpath', (
            f'//chat-chats-header//iva-input-search'
            f'//input[@type="search" and @placeholder="{i18n_str}"]'
        )

    @staticmethod
    def L_CHAT_SEARCH_RESULT_CHANNEL(channel_name, lang=''):
        # iva-сборка: тег имени — chat-card-name (был ошибочно удвоен chat-chat-card-name);
        # в результате поиска имя обёрнуто в span.messenger-search-highlight, поэтому normalize-space(.), не text().
        return 'xpath', (
            f'//chat-chat-list-item['
            f'.//chat-card-name//span[contains(@class,"chat-name") and contains(normalize-space(.),"{channel_name}")]'
            f']'
        )

    @staticmethod
    def L_CHAT_ITEM_MENTION_BADGE(chat_name, lang=''):
        # iva-сборка: бейджи в <chat-card-badges>; mention/unread различаются дочерней
        # иконкой counter'а, а НЕ @data-appearance (у muted-чата оба collapse в neutral).
        # mention = counter содержит <iva-icon-at-sign-bold>.
        return 'xpath', f'//chat-chat-list-item[.//span[@class="chat-name" and contains(text(),"{chat_name}")]]//chat-card-badges//iva-badge-counter[.//iva-icon-at-sign-bold]'

    @staticmethod
    def L_CHAT_ITEM_UNREAD_BADGE(chat_name, lang=''):
        # iva-сборка: см. L_CHAT_ITEM_MENTION_BADGE. unread = counter без дочерней иконки
        # (ни at-sign упоминания, ни thumbs-up реакции).
        return 'xpath', f'//chat-chat-list-item[.//span[@class="chat-name" and contains(text(),"{chat_name}")]]//chat-card-badges//iva-badge-counter[not(.//iva-icon-at-sign-bold) and not(.//iva-icon-thumbs-up)]'
