from .chat_profile_base import LChatProfileBase


class LInfoChannelProfile(LChatProfileBase):
    _DELETE_CONFIRM_TITLE_KEY = 'group_chat_profile_delete_channel_confirm_dialog_title'
    _PUBLIC_TOGGLE_KEY = 'info_channel_profile_public_toggle_label'
    _PUBLIC_CHAT_LABEL_KEY = 'info_channel_profile_public_chat_label'
    _REACTIONS_TOGGLE_KEY = 'info_channel_profile_reactions_toggle_label'
    _THREADS_TOGGLE_KEY = 'info_channel_profile_threads_toggle_label'
