from tools import i18n


class LChatAttachments:
    """Локаторы gallery-view sidebar'а `(sidebar:chat/<id>/attachments/<category>)`.

    Открывается из карточки чата по клику на категорию галереи (Изображения / Видео / Файлы / Аудио).
    Корневой тег `<chat-sidebar-attachments>` — отдельный sub-page чат-sidebar'а с собственным toolbar/tabs/панелью содержимого.
    """

    @staticmethod
    def L_ROOT(lang=''):
        return 'xpath', '//chat-sidebar-attachments'

    @staticmethod
    def L_VIDEO_LIST(lang=''):
        return 'xpath', f'{LChatAttachments.L_ROOT()[1]}//chat-sidebar-attachment-videos'

    @staticmethod
    def L_VIDEO_ITEM(lang=''):
        return 'xpath', f'{LChatAttachments.L_VIDEO_LIST()[1]}//chat-media-attachment'

    @staticmethod
    def L_VIDEO_ITEM_BY_NAME(filename, lang=''):
        return 'xpath', (
            f'{LChatAttachments.L_VIDEO_LIST()[1]}'
            f'//chat-media-attachment[.//img[@alt="{filename}"]]'
        )

    @staticmethod
    def L_IMAGE_LIST(lang=''):
        return 'xpath', f'{LChatAttachments.L_ROOT()[1]}//chat-sidebar-attachment-images'

    @staticmethod
    def L_IMAGE_ITEM_BY_NAME(filename, lang=''):
        return 'xpath', (
            f'{LChatAttachments.L_IMAGE_LIST()[1]}'
            f'//chat-media-attachment[.//img[@alt="{filename}"]]'
        )

    @staticmethod
    def L_AUDIO_LIST(lang=''):
        # Тег во множественном числе — `-audios` (как `-videos` и `-images`).
        return 'xpath', f'{LChatAttachments.L_ROOT()[1]}//chat-sidebar-attachment-audios'

    @staticmethod
    def L_AUDIO_ITEM_BY_NAME(filename, lang=''):
        # Audio item — отдельный тег <chat-audio-attachment> (НЕ <chat-media-attachment>).
        # iva-сборка: span.name убран; имя — атрибут @title хоста строки <msg-attachment-row> (устойчивее текста).
        return 'xpath', (
            f'{LChatAttachments.L_AUDIO_LIST()[1]}'
            f'//chat-audio-attachment[.//msg-attachment-row[@title="{filename}"]]'
        )

    @staticmethod
    def L_I18N_GALLERY_TAB(i18n_key, lang):
        # Вкладка галереи (iva-tab) по тексту-лейблу (media_header_pictures/video/audio).
        text = i18n.get_str(i18n_key, lang)
        return 'xpath', f'{LChatAttachments.L_ROOT()[1]}//iva-tab[normalize-space()="{text}"]'

    @staticmethod
    def L_CONTEXT_MENU(lang=''):
        # Тот же overlay `<iva-menu role="menu">`, что и для сообщений и participant'ов карточки чата.
        return 'xpath', '//iva-menu[@role="menu"]'

    @staticmethod
    def L_CONTEXT_MENU_DOWNLOAD_BTN(lang=''):
        # Пункт "Скачать" контекстного меню видео-плитки галереи.
        # Селектим по иконке iva-icon-download (без текста) — устойчиво к языку и
        # к историческому багу IVAONE-12098 (битый transloco-литерал текста пункта).
        return 'xpath', (
            f'{LChatAttachments.L_CONTEXT_MENU()[1]}'
            f'//button[@role="menuitem"][.//iva-icon-download]'
        )

    @staticmethod
    def L_CONTEXT_MENU_GO_TO_MESSAGE_BTN(lang=''):
        # Пункт "Перейти к сообщению" контекстного меню видео-плитки галереи.
        # Селектим по иконке iva-icon-thread (без текста) — устойчиво к языку.
        return 'xpath', (
            f'{LChatAttachments.L_CONTEXT_MENU()[1]}'
            f'//button[@role="menuitem"][.//iva-icon-thread]'
        )
