from tools import i18n


class LForwardDialog:
    @staticmethod
    def L_I18N_ROOT(lang):
        i18n_str = i18n.get_str('chat_message_forward_dialog_title', lang)
        return 'xpath', f'//cdk-dialog-container[.//div[contains(@class,"title") and normalize-space()="{i18n_str}"]]'

    @staticmethod
    def L_I18N_CHAT_ITEM(chat_name, lang):
        return 'xpath', f'{LForwardDialog.L_I18N_ROOT(lang)[1]}//chat-shared-forward-list-item[.//div[@class="text" and contains(.,"{chat_name}")]]'

    @staticmethod
    def L_I18N_SEARCH_INPUT(lang):
        return 'xpath', f'{LForwardDialog.L_I18N_ROOT(lang)[1]}//input[@type="search"]'
