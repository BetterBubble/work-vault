from tools import i18n


class LOfflineEvent:
    """Локаторы sidebar'а оффлайн-события: форма создания `(sidebar:event/create/jump)`
    и карточка созданного события `(sidebar:event/jump/{uid})`.

    Общий контейнер обоих состояний — `calendar-event-sidebar-wrapper`. Форма
    оффлайн-события (в отличие от ВКС) требует доступа к imail: у пользователя без
    почты форма зависает на `calendar-event-sidebar-loading`.
    """

    @staticmethod
    def L_FORM_ROOT(lang=''):
        return 'xpath', '//calendar-event-sidebar-wrapper'

    @staticmethod
    def L_FORM_LOADING(lang=''):
        return 'xpath', '//calendar-event-sidebar-loading'

    @staticmethod
    def L_I18N_THEME_INPUT(lang):
        placeholder = i18n.get_str('offline_event_theme_placeholder', lang)
        return 'xpath', f'{LOfflineEvent.L_FORM_ROOT()[1]}//input[@placeholder="{placeholder}"]'

    @staticmethod
    def L_I18N_CREATE_BTN(lang):
        text = i18n.get_str('offline_event_create_button', lang)
        return 'xpath', f'{LOfflineEvent.L_FORM_ROOT()[1]}//button[normalize-space()="{text}"]'

    # Участники в карточке созданного события. iva-билд: generic <participants-list>
    # убран, строки участников (li.user) — прямые потомки <iva-mail-event-participants-list>.
    @staticmethod
    def L_PARTICIPANTS_LIST(lang=''):
        return 'xpath', '//iva-mail-event-participants-list'

    @staticmethod
    def L_PARTICIPANT_BY_TEXT(text, lang=''):
        return 'xpath', (
            f'{LOfflineEvent.L_PARTICIPANTS_LIST()[1]}'
            f'//li[contains(@class,"user")][contains(normalize-space(.),"{text}")]'
        )

    @staticmethod
    def L_PARTICIPANT_AVATAR_BY_TEXT(text, lang=''):
        # Реально загруженный аватар = <img src>, не fallback-инициалы/буквы email.
        return 'xpath', (
            f'{LOfflineEvent.L_PARTICIPANT_BY_TEXT(text)[1]}'
            f'//img[@src and string-length(normalize-space(@src))>0]'
        )

    @staticmethod
    def L_CREATE_PARTICIPANTS_LIST(lang=''):
        return 'xpath', f'{LOfflineEvent.L_FORM_ROOT()[1]}//calendar-event-create-edit-participants-list'

    @staticmethod
    def L_CREATE_PARTICIPANT_BY_TEXT(text, lang=''):
        # iva-билд: имя участника рендерит компонент <participant-name> (не <p class="name">) —
        # матчим participant-item, содержащий текст имени.
        return 'xpath', (
            f'{LOfflineEvent.L_CREATE_PARTICIPANTS_LIST()[1]}'
            f'//participant-item[contains(normalize-space(.),"{text}")]'
        )

    @staticmethod
    def L_VIEW_ROOT(lang=''):
        # Корень view-карточки созданного события (sidebar:event/jump/{uid}). Якорь для шапки/More.
        return 'xpath', '//iva-mail-event-sidebar-view'

    @staticmethod
    def L_VIEW_MORE_MENU_BTN(lang=''):
        # Кнопка «More» (⋮) в шапке карточки события — открывает меню «Изменить»/«Удалить».
        # Прямой иконки-карандаша в шапке нет — вход в edit только через это меню.
        return 'xpath', f'{LOfflineEvent.L_VIEW_ROOT()[1]}//button[.//iva-icon-ellipsis-vertical]'

    @staticmethod
    def L_I18N_VIEW_EDIT_MENU_ITEM(lang):
        # Пункт «Изменить» в меню More. Меню — общий CDK-overlay //iva-menu[@role="menu"]; XPath
        # совпадает с ВКС-вариантом (LMcuConferenceSidebar) — DOM меню общий, но локатор живёт здесь
        # (offline_event владеет входом в edit карточки события). Ключ i18n reuse (уже в strings.py).
        text = i18n.get_str('calendar_conference_edit_menu_item', lang)
        return 'xpath', (
            '//iva-menu[@role="menu"]'
            f'//button[@role="menuitem"][.//div[@class="label" and normalize-space()="{text}"]]'
        )

    @staticmethod
    def L_PARTICIPANT_POSITION_BY_TEXT(text, position, lang=''):
        # Должность участника в списке участников view-карточки события (participant-position есть
        # только при заполненной должности). Фильтр по тексту должности — строгая проверка
        # (зеркало LMcuConferenceSidebar.L_PARTICIPANT_POSITION_BY_NAME из TC-1419).
        return 'xpath', (
            f'{LOfflineEvent.L_PARTICIPANT_BY_TEXT(text)[1]}'
            f'//participant-position[contains(normalize-space(),"{position}")]'
        )

    # --- Карточка Событие глазами приглашённого: ответ на приглашение (TC-52479) ---
    # Зеркало LMcuConferenceSidebar (TC-1427), но скоуп под Событие-корни
    # (iva-mail-event-sidebar-view / iva-mail-event-fullscreen-view). Компонент приглашения
    # (calendar-event-invitation-response-*) и бейдж статуса (status-circle) — общие с ВКС.

    @staticmethod
    def L_INVITATION_RESPONSE_BLOCK(lang=''):
        # Блок приглашения (Принять/Возможно/Отклонить) в подвале sidebar-карточки Событие.
        # Тот же компонент, что у ВКС (§4.7), но скоуп под iva-mail-event-sidebar-view.
        # Рендерится только у приглашённого (hasInvitation()); после ответа исчезает.
        return 'xpath', (
            f'{LOfflineEvent.L_VIEW_ROOT()[1]}'
            f'//calendar-event-invitation-response-sidebar'
        )

    @staticmethod
    def L_I18N_INVITATION_ACCEPT_BTN(lang):
        text = i18n.get_str('meeting_invitation_status_accept', lang)
        return 'xpath', (
            f'{LOfflineEvent.L_INVITATION_RESPONSE_BLOCK()[1]}'
            f'//button[.//span[contains(@class,"label") and normalize-space()="{text}"]]'
        )

    @staticmethod
    def L_I18N_INVITATION_MAYBE_BTN(lang):
        text = i18n.get_str('meeting_invitation_status_maybe', lang)
        return 'xpath', (
            f'{LOfflineEvent.L_INVITATION_RESPONSE_BLOCK()[1]}'
            f'//button[.//span[contains(@class,"label") and normalize-space()="{text}"]]'
        )

    @staticmethod
    def L_I18N_INVITATION_DECLINE_BTN(lang):
        text = i18n.get_str('meeting_invitation_status_decline', lang)
        return 'xpath', (
            f'{LOfflineEvent.L_INVITATION_RESPONSE_BLOCK()[1]}'
            f'//button[.//span[contains(@class,"label") and normalize-space()="{text}"]]'
        )

    @staticmethod
    def L_PARTICIPANT_STATUS_CIRCLE(text, lang=''):
        # Бейдж ответа участника (кружок у аватара): _info=без ответа, _success=принял,
        # _critical=отклонил, _secondary=возможно. Организатор всегда _success.
        # Список участников один и тот же (iva-mail-event-participants-list) в sidebar и fullscreen.
        return 'xpath', (
            f'{LOfflineEvent.L_PARTICIPANT_BY_TEXT(text)[1]}'
            f'//div[contains(@class,"status-circle")]'
        )

    @staticmethod
    def L_PARTICIPANT_ACCEPTED_MARK(text, lang=''):
        # Зелёная галочка (принял приглашение) рядом с ФИ в списке участников карточки Событие
        # (НЕ в левом chats-list). Организатор всегда _success → скоуп по ФИ обязателен.
        # Работает в sidebar и fullscreen (общий список участников).
        return 'xpath', (
            f'{LOfflineEvent.L_PARTICIPANT_BY_TEXT(text)[1]}'
            f'//div[contains(@class,"status-circle") and contains(@class,"_success")]'
        )

    @staticmethod
    def L_VIEW_MAXIMIZE_BTN(lang=''):
        # Разворот VIEW-карточки Событие в fullscreen. У Событие кнопка БЕЗ aria-label
        # (vs ВКС, где aria-label="Maximize") — матчим по иконке iva-icon-maximize-2.
        return 'xpath', (
            f'{LOfflineEvent.L_VIEW_ROOT()[1]}'
            f'//iva-header//button[.//iva-icon-maximize-2]'
        )

    @staticmethod
    def L_FULLSCREEN_ROOT(lang=''):
        # Полноэкранный просмотр карточки Событие. При нём iva-mail-event-sidebar-view
        # удаляется из DOM — fullscreen-локаторы строить ТОЛЬКО под этим корнем.
        return 'xpath', '//iva-mail-event-fullscreen-view'

    @staticmethod
    def L_FULLSCREEN_INVITATION_RESPONSE_BLOCK(lang=''):
        return 'xpath', (
            f'{LOfflineEvent.L_FULLSCREEN_ROOT()[1]}'
            f'//calendar-event-invitation-response-fullscreen'
        )

    @staticmethod
    def L_I18N_FULLSCREEN_INVITATION_ACCEPT_BTN(lang):
        text = i18n.get_str('meeting_invitation_status_accept', lang)
        return 'xpath', (
            f'{LOfflineEvent.L_FULLSCREEN_INVITATION_RESPONSE_BLOCK()[1]}'
            f'//button[normalize-space()="{text}"]'
        )

    @staticmethod
    def L_I18N_FULLSCREEN_ATTACHMENTS_SECTION(lang):
        # Секция «Вложения» в fullscreen Событие. У Событие — msg-adding-section с title,
        # а НЕ тег attachments-section (как у ВКС). Только в fullscreen (в sidebar её нет).
        text = i18n.get_str('general_attachments_label', lang)
        return 'xpath', (
            f'{LOfflineEvent.L_FULLSCREEN_ROOT()[1]}'
            f'//msg-adding-section[.//p[contains(@class,"title") and normalize-space()="{text}"]]'
        )

    @staticmethod
    def L_I18N_FULLSCREEN_ATTACHMENTS_LABEL(lang):
        text = i18n.get_str('general_attachments_label', lang)
        return 'xpath', (
            f'{LOfflineEvent.L_I18N_FULLSCREEN_ATTACHMENTS_SECTION(lang)[1]}'
            f'//p[contains(@class,"title") and normalize-space()="{text}"]'
        )
