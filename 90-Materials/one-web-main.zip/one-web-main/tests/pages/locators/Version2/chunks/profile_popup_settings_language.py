from tools import i18n


class LProfilePopupSettingsLanguage:

    @staticmethod
    def L_ROOT(lang=''):
        # 2.1.0-RC1: div.section убран — корень секции = <profile-section-page>,
        # предикат по profile-language-switcher отличает её от других секций профиля.
        return 'xpath', '//cdk-dialog-container//profile-section-page[.//profile-language-switcher]'

    @staticmethod
    def L_I18N_LANGUAGE_SECTION_TITLE(lang):
        i18n_str = i18n.get_str('profile_settings_language_section_title', lang)
        return 'xpath', (
            f'{LProfilePopupSettingsLanguage.L_ROOT()[1]}'
            f'//iva-header//div[contains(concat(" ", normalize-space(@class), " "), " title ")]'
            f'[normalize-space()="{i18n_str}"]'
        )

    @staticmethod
    def L_LANGUAGE_SELECT(lang=''):
        # Кликабельный триггер: div[role=combobox].trigger внутри iva-select.
        # Именно этот div несёт обработчик — его click раскрывает overlay (aria-expanded true).
        return 'xpath', f'{LProfilePopupSettingsLanguage.L_ROOT()[1]}//iva-select//div[@role="combobox"]'

    @staticmethod
    def L_I18N_LANGUAGE_SELECT_VALUE(language_key, lang):
        # Текущее значение показано текстом самого iva-select (.display-value); опции дропдауна
        # живут в overlay на body и в текст iva-select НЕ попадают. Паттерн из LContactForm.L_GROUP_SELECT_VALUE.
        value = i18n.get_str(language_key, lang)
        return 'xpath', (
            f'{LProfilePopupSettingsLanguage.L_ROOT()[1]}'
            f'//iva-select[contains(normalize-space(.),"{value}")]'
        )

    @staticmethod
    def L_I18N_LANGUAGE_OPTION(language_key, lang):
        # Опция overlay-дропдауна. Overlay рендерится на body (НЕ в cdk-dialog-container):
        #   div.cdk-overlay-pane > iva-popover > iva-scroll-area > div.viewport > div.content
        #   > div[role=listbox].listbox > iva-select-option[role=option]
        # Текст опции — в .language-label. Опции языко-независимы («Русский»/«English»
        # одинаковы в RU и EN) → тот же локатор работает при любом текущем языке UI.
        value = i18n.get_str(language_key, lang)
        return 'xpath', (
            f'//iva-select-option[.//div[contains(@class,"language-label")]'
            f'[normalize-space()="{value}"]]'
        )
