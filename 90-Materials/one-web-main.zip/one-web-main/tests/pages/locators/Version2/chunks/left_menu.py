class LLeftMenu:
    @staticmethod
    def L_ROOT(lang=''):
        return 'xpath', '//msg-leftbar'

    @staticmethod
    def L_USER_PROFILE_BTN(lang=''):
        # ds→iva: msg-user-avatar убран, кнопка профиля содержит iva-avatar.
        return 'xpath', f'{LLeftMenu.L_ROOT()[1]}//button[.//iva-avatar]'

    @staticmethod
    def L_USER_DS_AVATAR(lang=''):
        return 'xpath', f'{LLeftMenu.L_USER_PROFILE_BTN()[1]}//iva-avatar'

    @staticmethod
    def L_USER_DS_AVATAR_IMG(lang=''):
        return 'xpath', f'{LLeftMenu.L_USER_DS_AVATAR()[1]}//img'

    @staticmethod
    def L_USER_DS_AVATAR_DEFAULT(lang=''):
        # ds→iva: дефолт-аватар (инициалы) теперь iva-avatar-fallback.
        return 'xpath', f'{LLeftMenu.L_USER_DS_AVATAR()[1]}//iva-avatar-fallback'

    @staticmethod
    def L_NAV_BUTTONS_BAR(lang=''):
        return 'xpath', f'{LLeftMenu.L_ROOT()[1]}//ul[@class="navigation"]'

    @staticmethod
    def L_CHATS(lang=''):
        return 'xpath', f'{LLeftMenu.L_NAV_BUTTONS_BAR()[1]}//a[contains(@href,"chat")]'

    @staticmethod
    def L_ADDRESS_BOOK(lang=''):
        # На cmain-линии (ds→iva) раздел переехал на /contacts; старый /address-book оставлен для совместимости.
        return 'xpath', f'{LLeftMenu.L_NAV_BUTTONS_BAR()[1]}//a[contains(@href,"address-book") or contains(@href,"contacts")]'

    @staticmethod
    def L_CALENDAR(lang=''):
        # Раздел «Календарь» в leftbar (href=/calendar).
        return 'xpath', f'{LLeftMenu.L_ROOT()[1]}//a[contains(@href,"calendar")]'

    @staticmethod
    def L_NAV_ACTIVE(href_part, lang=''):
        # Активная вкладка навигации (модификатор _active на ссылке-пункте).
        return 'xpath', (
            f'{LLeftMenu.L_NAV_BUTTONS_BAR()[1]}'
            f'//a[contains(@href,"{href_part}")][contains(concat(" ",normalize-space(@class)," ")," _active ")]'
        )
