class LChatPinnedMessagesRoom:
    """Локаторы экрана со списком закреплённых сообщений чата (`<chat-pinned-room>`).

    Открывается из pinned bar в обычной chat-room по клику на иконку «list».
    URL вида `/chat/<id>/pin`. На этом экране отображается список pinned-сообщений
    и отсутствует поле ввода (`<chat-send-message-editor>`).
    """

    @staticmethod
    def L_ROOT(lang=''):
        return 'xpath', '//chat-pinned-room'

    @staticmethod
    def L_HEADER(lang=''):
        return 'xpath', f'{LChatPinnedMessagesRoom.L_ROOT()[1]}//chat-pinned-room-header'

    @staticmethod
    def L_BACK_BTN(lang=''):
        return 'xpath', f'{LChatPinnedMessagesRoom.L_HEADER()[1]}//button'

    @staticmethod
    def L_MESSAGE_WITH_TEXT(text, lang=''):
        return 'xpath', (
            f'{LChatPinnedMessagesRoom.L_ROOT()[1]}'
            f'//chat-base-message[.//chat-formatted-message-text//span[contains(text(),"{text}")]]'
        )

    @staticmethod
    def L_INPUT_EDITOR(lang=''):
        return 'xpath', '//chat-send-message-editor'
