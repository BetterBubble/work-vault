from autocore.clients.rest.enums import ChatUsersReactions

from tools import i18n


class LChat:  # chat-room локаторы; список чатов — в LChatsList (chunks/chats_list)
    @staticmethod
    def L_I18N_HEADER(lang):
        # Дрейф 2026-07-02: заголовок — <iva-header-section data-content-type="content">
        # внутри iva-header (был h5); текст обрамлён пробелами → normalize-space(), не text()=.
        i18n_str = i18n.get_str('chats_header', lang)
        return 'xpath', (
            f'//chat-chats-header//iva-header-section[@data-content-type="content"]'
            f'[normalize-space()="{i18n_str}"]'
        )

    @staticmethod
    def L_CHAT_TOPBAR(lang=''):
        return 'xpath', '//chat-topbar'

    @staticmethod
    def L_CHAT_HEADER(lang=''):
        # contains(@class): точный @class="title" ломается, когда Angular дописывает
        # ng-star-inserted (дрейф 2026-07-02, тот же класс поломки — память
        # project_ds_iva_dialog_title_predicate_drift).
        return 'xpath', f'{LChat.L_CHAT_TOPBAR()[1]}//p[contains(@class,"title")]'

    @staticmethod
    def L_CHAT_SCROLLER(lang=''):
        return 'xpath', '//chat-scroller'

    @staticmethod
    def L_CHAT_WITH_CHAT_NAME_HEADER(chat_name, lang=''):
        # normalize-space вместо text(): текст заголовка обрамляется пробелами/нодами.
        return 'xpath', f'{LChat.L_CHAT_HEADER()[1]}[contains(normalize-space(),"{chat_name}")]'

    @staticmethod
    def L_CHAT_ROOM(lang=''):
        return 'xpath', '//chat-chat-room'

    @staticmethod
    def L_CHAT_INPUT(lang=''):
        return 'xpath', '//chat-send-message-editor//div[@contenteditable="true"]'

    @staticmethod
    def L_I18N_INPUT_DISABLED_PLUG(lang):
        i18n_str = i18n.get_str('chat_input_disabled_plug', lang)
        return 'xpath', f'{LChat.L_CHAT_ROOM()[1]}//div[@class="plug" and text()="{i18n_str}"]'

    @staticmethod
    def L_CHAT_INPUT_HREF_CONTENT(lang=''):
        return 'xpath', f'{LChat.L_CHAT_INPUT(lang)[1]}//a'

    @staticmethod
    def L_SEND_BUTTON(lang=''):
        return 'xpath', '//chat-send-message//button[.//iva-icon-send-horizontal]'

    @staticmethod
    def L_VOICE_RECORD_BTN(lang=''):
        return 'xpath', '//chat-send-message//button[.//iva-icon-mic-line]'

    @staticmethod
    def L_VOICE_RECORDER(lang=''):
        return 'xpath', '//chat-send-message//chat-voice-record'

    @staticmethod
    def L_VOICE_RECORDING_SEND_BTN(lang=''):
        return 'xpath', f'{LChat.L_VOICE_RECORDER()[1]}//button[.//iva-icon-send-horizontal]'

    @staticmethod
    def L_VOICE_MESSAGE_IN_CHAT(lang=''):
        return 'xpath', '//chat-voice-message'

    @staticmethod
    def L_INPUT_VALUE(lang=''):
        return 'xpath', f'{LChat.L_CHAT_INPUT()[1]}//p[contains(@class,"pm-paragraph")]'

    @staticmethod
    def L_CHAT_MESSAGE_CONTAINER(lang=''):
        return 'xpath', '//chat-message-container'

    @staticmethod
    def L_CHAT_MESSAGE_IN_SCROLLER(lang=''):
        # Сообщение внутри ленты чата. Для assert "диалог пустой" — wait_absence по этому
        # локатору (в пустом p2p-диалоге chat-message-container в scroller'е нет).
        return 'xpath', f'{LChat.L_CHAT_SCROLLER()[1]}//chat-message-container'

    @staticmethod
    def L_CHAT_MESSAGE_WITH_TEXT(text, lang=''):
        return 'xpath', f'{LChat.L_CHAT_MESSAGE_CONTAINER()[1]}//chat-formatted-message-text/span[contains(normalize-space(.),"{text}")]'

    @staticmethod
    def L_CHAT_MESSAGE_WITH_EXACT_TEXT(text, lang=''):
        # Точное совпадение текста (в отличие от contains): "Сообщение 1" не матчит "Сообщение 10/100".
        return 'xpath', f'{LChat.L_CHAT_MESSAGE_CONTAINER()[1]}//chat-formatted-message-text/span[normalize-space(.)="{text}"]'

    @staticmethod
    def L_CHAT_MESSAGE_WITH_VISIBLE_LINK(link, lang=''):
        return 'xpath', f'{LChat.L_CHAT_MESSAGE_CONTAINER()[1]}//chat-formatted-message-text//a[normalize-space()="{link}"]'

    @staticmethod
    def L_CHAT_MESSAGE_WITH_REAL_LINK(link, lang=''):
        return 'xpath', f'{LChat.L_CHAT_MESSAGE_CONTAINER()[1]}//chat-formatted-message-text//a[@href="{link}"]'

    @staticmethod
    def L_CHAT_MESSAGE_CONTEXT_MENU(lang=''):
        return 'xpath', '//chat-message-context-menu'

    @staticmethod
    def L_I18N_CONTEXT_MENU_REPLY_BTN(lang):
        i18n_str = i18n.get_str('chat_message_context_menu_reply_button', lang)
        return 'xpath', f'{LChat.L_CHAT_MESSAGE_CONTEXT_MENU()[1]}//button[@role="menuitem"][contains(.,"{i18n_str}")]'

    @staticmethod
    def L_I18N_CONTEXT_MENU_COPY_BTN(lang):
        i18n_str = i18n.get_str('chat_message_context_menu_copy_button', lang)
        return 'xpath', f'{LChat.L_CHAT_MESSAGE_CONTEXT_MENU()[1]}//button[@role="menuitem"][contains(.,"{i18n_str}")]'

    @staticmethod
    def L_I18N_CONTEXT_MENU_COPY_LINK_BTN(lang):
        i18n_str = i18n.get_str('chat_message_context_menu_copy_link_button', lang)
        return 'xpath', f'{LChat.L_CHAT_MESSAGE_CONTEXT_MENU()[1]}//button[@role="menuitem"][contains(.,"{i18n_str}")]'

    @staticmethod
    def L_I18N_CONTEXT_MENU_EDIT_BTN(lang):
        i18n_str = i18n.get_str('chat_message_context_menu_edit_button', lang)
        return 'xpath', f'{LChat.L_CHAT_MESSAGE_CONTEXT_MENU()[1]}//button[@role="menuitem"][contains(.,"{i18n_str}")]'

    @staticmethod
    def L_I18N_CONTEXT_MENU_FORWARD_BTN(lang):
        i18n_str = i18n.get_str('chat_message_context_menu_forward_button', lang)
        return 'xpath', f'{LChat.L_CHAT_MESSAGE_CONTEXT_MENU()[1]}//button[@role="menuitem"][contains(.,"{i18n_str}")]'

    @staticmethod
    def L_I18N_CONTEXT_MENU_START_THREAD_BTN(lang):
        i18n_str = i18n.get_str('chat_message_context_menu_start_thread_button', lang)
        return 'xpath', f'{LChat.L_CHAT_MESSAGE_CONTEXT_MENU()[1]}//button[@role="menuitem"][contains(.,"{i18n_str}")]'

    @staticmethod
    def L_I18N_CONTEXT_MENU_DELETE_BTN(lang):
        i18n_str = i18n.get_str('chat_message_context_menu_delete_button', lang)
        return 'xpath', f'{LChat.L_CHAT_MESSAGE_CONTEXT_MENU()[1]}//button[@role="menuitem"][contains(.,"{i18n_str}")]'

    @staticmethod
    def L_DELETE_MESSAGE_CONFIRM_DIALOG(lang=''):
        return 'xpath', '//chat-delete-confirmation-dialog'

    @staticmethod
    def L_I18N_DELETE_MESSAGE_CONFIRM_BTN(lang):
        i18n_str = i18n.get_str('chat_message_delete_confirm_btn', lang)
        return 'xpath', (
            f'{LChat.L_DELETE_MESSAGE_CONFIRM_DIALOG()[1]}'
            f'//button[normalize-space()="{i18n_str}"]'
        )

    @staticmethod
    def L_I18N_FORWARDED_CHAT_MESSAGE_CONTAINER(forwarded_message, lang):
        i18n_str = i18n.get_str('chat_message_forwarded_message_label', lang)
        return 'xpath', f'{LChat.L_CHAT_MESSAGE_CONTAINER()[1]}//chat-forward-message[contains(.,"{forwarded_message}")][.//div[@class="title" and text()="{i18n_str}"]]'

    @staticmethod
    def L_I18N_FORWARDED_MESSAGE_AUTHOR_LINK(forwarded_message, lang):
        return 'xpath', (
            f'{LChat.L_I18N_FORWARDED_CHAT_MESSAGE_CONTAINER(forwarded_message, lang)[1]}'
            f'//a[contains(@class,"name")]'
        )

    @staticmethod
    def L_REPLYING_CONTAINER(replying_message, lang=''):
        return 'xpath', f'//chat-text-replying//span[text()="{replying_message}"]'

    @staticmethod
    def L_EDITING_CONTAINER(message, lang=''):
        return 'xpath', f'//chat-text-editing//span[text()="{message}"]'

    @staticmethod
    def L_FORWARD_PREVIEW(lang=''):
        return 'xpath', '//chat-text-forwarding'

    @staticmethod
    def L_FORWARD_PREVIEW_ABOVE_INPUT(message, lang=''):
        return 'xpath', f'{LChat.L_FORWARD_PREVIEW()[1]}[contains(.,"{message}")]'

    @staticmethod
    def L_CHAT_MESSAGE_SELECTABLE_WRAPPER_BY_TEXT(text, lang=''):
        return 'xpath', (
            f'{LChat.L_CHAT_MESSAGE_CONTAINER()[1]}'
            f'//div[contains(@class,"data-selectable-message")]'
            f'[.//chat-formatted-message-text//span[contains(normalize-space(.),"{text}")]]'
        )

    @staticmethod
    def L_FORWARD_PREVIEW_TITLE(lang=''):
        return 'xpath', f'{LChat.L_FORWARD_PREVIEW()[1]}//div[@class="title"]'

    @staticmethod
    def L_FORWARD_PREVIEW_TITLE_CONTAINS_COUNT(count, lang=''):
        return 'xpath', (
            f'{LChat.L_FORWARD_PREVIEW_TITLE()[1]}[contains(.,"{count}")]'
        )

    @staticmethod
    def L_FORWARD_PREVIEW_AUTHOR_NAME_ITEMS(lang=''):
        return 'xpath', (
            f'{LChat.L_FORWARD_PREVIEW()[1]}'
            f'//span[contains(@class,"authors")]//contacts-contact-name'
        )

    @staticmethod
    def L_FORWARD_PREVIEW_AUTHOR_NAME_BY_INDEX(index, lang=''):
        return 'xpath', (
            f'({LChat.L_FORWARD_PREVIEW_AUTHOR_NAME_ITEMS()[1]})[{index}]'
        )

    @staticmethod
    def L_I18N_CHAT_MESSAGE_EDITED_MARK(text, lang):
        i18n_str = i18n.get_str('chat_message_edited_mark', lang)
        return 'xpath', f'{LChat.L_CHAT_MESSAGE_CONTAINER()[1]}[.//chat-formatted-message-text//span[contains(normalize-space(.),"{text}")]]//chat-ui-message-time//span[text()="{i18n_str}"]'

    @staticmethod
    def L_MESSAGE_HIGHLIGHTING(message, lang=''):
        return 'xpath', f'{LChat.L_CHAT_MESSAGE_CONTAINER()[1]}[contains(.,"{message}")]//div[contains(@class,"highlight")]'

    @staticmethod
    def L_CHAT_MESSAGE_REPLIED_TEXT_BTN(message, lang=''):
        return 'xpath', f'{LChat.L_CHAT_MESSAGE_CONTAINER()[1]}//chat-reply-message[.//chat-text-message[contains(normalize-space(.),"{message}")]]//button[contains(@class,"reply-link")]'

    @staticmethod
    def L_CHAT_MESSAGE_THREAD_COMMENTS_BTN(message_text, lang=''):
        return 'xpath', (
            f'{LChat.L_CHAT_MESSAGE_CONTAINER()[1]}'
            f'[.//chat-formatted-message-text//span[contains(normalize-space(.),"{message_text}")]]'
            f'//chat-ui-message-thread-info//button'
        )

    @staticmethod
    def L_THREAD_ROOM(lang=''):
        return 'xpath', f'{LChat.L_CHAT_ROOM()[1]}[.//chat-topbar-thread]'

    @staticmethod
    def L_THREAD_WITH_MESSAGE(message_text, lang=''):
        return 'xpath', (
            f'{LChat.L_THREAD_ROOM()[1]}'
            f'[.//chat-topbar-thread//p[contains(@class,"title") and contains(normalize-space(.),"{message_text}")]]'
        )

    @staticmethod
    def L_THREAD_INPUT(lang=''):
        return 'xpath', f'{LChat.L_THREAD_ROOM()[1]}//chat-send-message-editor//div[@contenteditable="true"]'

    @staticmethod
    def L_THREAD_SEND_BUTTON(lang=''):
        return 'xpath', f'{LChat.L_THREAD_ROOM()[1]}//chat-send-message//button[.//iva-icon-send-horizontal]'

    @staticmethod
    def L_I18N_THREAD_SUBSCRIBE_BTN(lang):
        i18n_str = i18n.get_str('chat_thread_subscribe_button', lang)
        # iva-сборка: текст кнопки в span.label (был ds-паттерн span.content).
        return 'xpath', (
            f'{LChat.L_THREAD_ROOM()[1]}'
            f'//chat-topbar//button[.//span[contains(@class,"label") and normalize-space()="{i18n_str}"]]'
        )

    @staticmethod
    def L_I18N_THREAD_UNSUBSCRIBE_BTN(lang):
        i18n_str = i18n.get_str('chat_thread_unsubscribe_button', lang)
        # iva-сборка: текст кнопки в span.label (был ds-паттерн span.content).
        return 'xpath', (
            f'{LChat.L_THREAD_ROOM()[1]}'
            f'//chat-topbar//button[.//span[contains(@class,"label") and normalize-space()="{i18n_str}"]]'
        )

    @staticmethod
    def L_THREAD_CLOSE_BTN(lang=''):
        return 'xpath', f'{LChat.L_THREAD_ROOM()[1]}//chat-topbar//a[.//iva-icon-thread]'

    @staticmethod
    def L_THREAD_MESSAGE_WITH_TEXT(text, lang=''):
        return 'xpath', (
            f'{LChat.L_THREAD_ROOM()[1]}'
            f'//chat-message-container//chat-formatted-message-text/span[contains(normalize-space(.),"{text}")]'
        )

    @staticmethod
    def L_CHAT_MESSAGE_THREAD_COMMENTS_COUNT(message_text, count, lang=''):
        return 'xpath', (
            f'{LChat.L_CHAT_MESSAGE_THREAD_COMMENTS_BTN(message_text)[1]}'
            f'//div[@class="messages-count" and starts-with(normalize-space(.),"{count} ")]'
        )

    @staticmethod
    def L_I18N_THREADS_TAB(lang):
        i18n_str = i18n.get_str('chat_chats_header_threads_tab', lang)
        return 'xpath', (
            # ds→iva: ds-tabs→iva-tabs; структура схлопнута (li.tab>p>button[role=tab] → iva-tab[role=tab]>span).
            f'//chat-chats-list//iva-tabs//iva-tab[@role="tab"]'
            f'[.//span[normalize-space()="{i18n_str}"]]'
        )

    @staticmethod
    def L_THREAD_LIST_ITEM_BY_PARENT_TEXT(parent_text, lang=''):
        return 'xpath', (
            f'//chat-chat-list-item'
            f'[.//chat-thread-card//span[@class="thread-name" and contains(normalize-space(.),"{parent_text}")]]'
        )

    @staticmethod
    def L_CHAT_MESSAGE_WITH_REPLY(sent_message, message_for_reply, lang=''):
        return 'xpath', f'{LChat.L_CHAT_MESSAGE_CONTAINER()[1]}//chat-reply-message[.//button[contains(normalize-space(.),"{message_for_reply}")]][.//chat-text-message[contains(normalize-space(.),"{sent_message}")]]'

    @staticmethod
    def L_I18N_CONTEXT_MENU_SELECT_BTN(lang):
        i18n_str = i18n.get_str('chat_message_context_menu_select_button', lang)
        return 'xpath', f'{LChat.L_CHAT_MESSAGE_CONTEXT_MENU()[1]}//button[@role="menuitem"][contains(.,"{i18n_str}")]'

    @staticmethod
    def L_SELECT_MODE_TOOLBAR(lang=''):
        return 'xpath', '//chat-topbar-selection'

    @staticmethod
    def L_I18N_SELECT_MODE_CANCEL_BTN(lang):
        # Кнопка «Сбросить» — тот же RU-текст, что в мультиселекте контактов; реюз ключа.
        i18n_str = i18n.get_str('contacts_multiselect_reset_button', lang)
        return 'xpath', (
            f'{LChat.L_SELECT_MODE_TOOLBAR()[1]}'
            f'//button[.//span[contains(@class,"label") and normalize-space()="{i18n_str}"]]'
        )

    @staticmethod
    def L_SELECT_MODE_COPY_BTN(lang=''):
        return 'xpath', f'{LChat.L_SELECT_MODE_TOOLBAR()[1]}//button[.//iva-icon-copy]'

    @staticmethod
    def L_SELECT_MODE_DELETE_BTN(lang=''):
        # Кнопка стала icon-only (текста «Удалить» в тулбаре больше нет) — матчим по иконке.
        return 'xpath', f'{LChat.L_SELECT_MODE_TOOLBAR()[1]}//button[.//iva-icon-trash-2-line]'

    @staticmethod
    def L_SELECT_MODE_FORWARD_BTN(lang=''):
        # Кнопка стала icon-only (текста «Переслать» в тулбаре больше нет) — матчим по иконке.
        return 'xpath', f'{LChat.L_SELECT_MODE_TOOLBAR()[1]}//button[.//iva-icon-forward]'

    @staticmethod
    def L_I18N_INPUT_MENU_ITEM_EDIT_LINK_BTN(lang):
        i18n_str = i18n.get_str('chat_input_menu_item_edit_link_btn', lang)
        return 'xpath', f'//button[@role="menuitem"][contains(.,"{i18n_str}")]'

    @staticmethod
    def L_CHAT_MESSAGE_SENT_STATUS(text, lang=''):
        return 'xpath', f'{LChat.L_CHAT_MESSAGE_CONTAINER()[1]}[.//chat-formatted-message-text//span[contains(normalize-space(.),"{text}")]]//chat-ui-seen-status//iva-icon-check-bold[contains(@class,"icon_sent")]'

    @staticmethod
    def L_CHAT_SEARCH_BTN(lang=''):
        return 'xpath', f'{LChat.L_CHAT_TOPBAR()[1]}//button[.//iva-icon-search]'

    @staticmethod
    def L_CHAT_AUDIO_CALL_BTN(lang=''):
        # Топбар пересобран на iva-header: обёртки div.actions больше нет,
        # кнопки действий — в iva-header-section[@data-content-type="actions"].
        return 'xpath', (
            f'{LChat.L_CHAT_TOPBAR()[1]}'
            f'//iva-header-section[@data-content-type="actions"]//button[.//iva-icon-phone-line]'
        )

    @staticmethod
    def L_CHAT_SEARCH_PANEL(lang=''):
        return 'xpath', '//chat-topbar-search-panel'

    @staticmethod
    def L_CHAT_SEARCH_INPUT(lang=''):
        return 'xpath', f'{LChat.L_CHAT_SEARCH_PANEL()[1]}//input[@type="search"]'

    @staticmethod
    def L_CHAT_SEARCH_COUNTER(lang=''):
        return 'xpath', f'{LChat.L_CHAT_SEARCH_PANEL()[1]}//span[contains(@class,"current-message-text")]'

    @staticmethod
    def L_CHAT_SEARCH_CLOSE_BTN(lang=''):
        # Кнопка закрытия поиска — в actions-секции топбара, ВНЕ chat-topbar-search-panel.
        return 'xpath', '//chat-topbar[.//chat-topbar-search-panel]//button[.//iva-icon-close]'

    @staticmethod
    def L_CHAT_SEARCH_RESET_BTN(lang=''):
        return 'xpath', f'{LChat.L_CHAT_SEARCH_PANEL()[1]}//button[.//iva-icon-circle-x-line]'

    @staticmethod
    def L_CHAT_SEARCH_HIGHLIGHT(text, lang=''):
        return 'xpath', f'{LChat.L_CHAT_MESSAGE_CONTAINER()[1]}//span[contains(@class,"messenger-search-highlight") and text()="{text}"]'

    @staticmethod
    def L_MENTION_POPUP(lang=''):
        # ds→iva: попап упоминаний переехал на <iva-menu role="listbox">; якорь — chat-mention-description.
        return 'xpath', '//iva-menu[.//chat-mention-description]'

    @staticmethod
    def L_MENTION_POPUP_USER_ITEM(user_name, lang=''):
        # ds→iva: пункт — button[@role="option"]; ФИ в contacts-contact-name//div.display-name (редеплой: класс div сменился ellipsis→display-name).
        return 'xpath', (f'{LChat.L_MENTION_POPUP()[1]}//button[@role="option"]'
                         f'[.//contacts-contact-name//div[contains(@class,"display-name") '
                         f'and contains(normalize-space(),"{user_name}")]]')

    @staticmethod
    def L_MENTION_IN_INPUT(user_name, lang=''):
        return 'xpath', f'//chat-send-message-editor//chat-user-mention[contains(@data-user-name,"{user_name}")]'

    @staticmethod
    def L_MENTION_IN_MESSAGE(user_name, lang=''):
        return 'xpath', f'{LChat.L_CHAT_MESSAGE_CONTAINER()[1]}//chat-user-mention[contains(@data-user-name,"{user_name}")]'

    @staticmethod
    def L_MENTION_COLOR_NODE(user_name, lang=''):
        # Цвет упоминания живёт на внутреннем <a class="link user-mention">, а не на самом <chat-user-mention>.
        return 'xpath', f'{LChat.L_MENTION_IN_MESSAGE(user_name)[1]}//a[contains(@class,"user-mention")]'

    @staticmethod
    def L_MENTION_CHEVRON(lang=''):
        # Шеврон упоминания — chat-ui-jump-button с иконкой @; предикат обязателен:
        # голый chat-ui-jump-button матчит и кнопку «вниз к непрочитанным» (chevron-down).
        return 'xpath', '//chat-ui-jump-button[.//iva-icon-at-sign]'

    @staticmethod
    def L_I18N_CONTEXT_MENU_PIN_BTN(lang):
        i18n_str = i18n.get_str('chat_message_context_menu_pin_button', lang)
        return 'xpath', f'{LChat.L_CHAT_MESSAGE_CONTEXT_MENU()[1]}//button[@role="menuitem"][contains(.,"{i18n_str}")]'

    @staticmethod
    def L_I18N_CONTEXT_MENU_REACTIONS_MENU_ITEM(lang):
        i18n_str = i18n.get_str('chat_message_context_menu_reactions_stem', lang)
        return 'xpath', f'{LChat.L_CHAT_MESSAGE_CONTEXT_MENU()[1]}//button[@role="menuitem"][contains(.,"{i18n_str}")]'

    @staticmethod
    def L_I18N_CONTEXT_MENU_INFO_BTN(lang):
        i18n_str = i18n.get_str('chat_message_context_menu_info_button', lang)
        return 'xpath', f'{LChat.L_CHAT_MESSAGE_CONTEXT_MENU()[1]}//button[@role="menuitem"][contains(.,"{i18n_str}")]'

    @staticmethod
    def L_REACTIONS_USERS_POPOVER(lang=''):
        # ds→iva: попап реакций — <iva-menu role="menu"> (был div[@role="menu"]); строки
        # пользователей — button[@role="menuitem"] с contacts-contact-name. Дискриминатор
        # contacts-contact-name отделяет попап реакций от контекст-меню действий (того же тега).
        return 'xpath', '//iva-menu[@role="menu"][.//button[@role="menuitem"]//contacts-contact-name]'

    @staticmethod
    def L_REACTIONS_USERS_ROWS(lang=''):
        return 'xpath', f'{LChat.L_REACTIONS_USERS_POPOVER()[1]}//button[@role="menuitem"]'

    @staticmethod
    def L_REACTIONS_USERS_ROW_BY_NAME(user_name, lang=''):
        return 'xpath', (f'{LChat.L_REACTIONS_USERS_ROWS()[1]}'
                         f'[.//contacts-contact-name//div[contains(@class,"display-name") '
                         f'and contains(normalize-space(),"{user_name}")]]')

    @staticmethod
    def L_MESSAGE_INFO_DIALOG(lang=''):
        return 'xpath', '//app-message-info-dialog'

    @staticmethod
    def L_MESSAGE_INFO_AUTHOR_ITEM(author_name, lang=''):
        # ds→iva: span.name-text убран; ФИ в contacts-contact-name//div.display-name (как в L_MENTION_POPUP_USER_ITEM).
        return 'xpath', (
            f'{LChat.L_MESSAGE_INFO_DIALOG()[1]}'
            f'//chat-message-info-card-item'
            f'[.//contacts-contact-name//div[contains(@class,"display-name") and contains(normalize-space(),"{author_name}")]]'
        )

    @staticmethod
    def L_REACTIONS_PICKER_MENU(lang=''):
        # ds→iva: бар выбора реакций — div.top-bar в <chat-context-menu-full> (был div[@dsmenutopbar]).
        return 'xpath', f'{LChat.L_CHAT_MESSAGE_CONTEXT_MENU()[1]}//div[contains(@class,"top-bar")]'

    @staticmethod
    def L_REACTION_PICKER_BUTTON(reaction: ChatUsersReactions, lang=''):
        return 'xpath', (
            f'{LChat.L_REACTIONS_PICKER_MENU()[1]}'
            f'//button[contains(@class,"emoji-button")]'
            f'[.//emoji-ui[@data-emoji="{reaction.value}"]]'
        )

    @staticmethod
    def L_MESSAGE_REACTION_CHIP(message_text, reaction: ChatUsersReactions, lang=''):
        return 'xpath', (
            f'{LChat.L_CHAT_MESSAGE_CONTAINER()[1]}'
            f'[.//chat-formatted-message-text/span[contains(normalize-space(.),"{message_text}")]]'
            f'//chat-ui-message-reaction[.//emoji-ui[@data-emoji="{reaction.value}"]]'
        )

    @staticmethod
    def L_I18N_CHAT_PIN_SYSTEM_MESSAGE(user_name, lang):
        i18n_str = i18n.get_str('chat_system_message_pinned_by', lang)
        return 'xpath', f'//chat-system-message[contains(.,"{user_name}") and contains(.,"{i18n_str}")]'

    @staticmethod
    def L_I18N_CHAT_SYSTEM_MESSAGE_RENAMED_CHANNEL(new_name, lang):
        # Scope в ленту (chat-scroller): <chat-system-message> дублируется в превью карточки
        # списка чатов → без scroller'а инвариант+new_name даёт count=2.
        i18n_str = i18n.get_str('chat_system_message_renamed_channel', lang)
        return 'xpath', f'{LChat.L_CHAT_SCROLLER()[1]}//chat-system-message[contains(.,"{i18n_str}") and contains(.,"{new_name}")]'

    @staticmethod
    def L_I18N_CHAT_SYSTEM_MESSAGE_USER_ADDED(actor_name, member_name, lang):
        i18n_str = i18n.get_str('chat_system_message_user_added', lang)
        return 'xpath', (
            f'{LChat.L_CHAT_SCROLLER()[1]}//chat-system-message'
            f'[contains(.,"{actor_name}") and contains(.,"{i18n_str}") and contains(.,"{member_name}")]'
        )

    @staticmethod
    def L_CHAT_PINNED_MESSAGE_BAR(message_text, lang=''):
        return 'xpath', f'//chat-pinned-message[.//chat-formatted-message-text//span[contains(text(),"{message_text}")]]'

    @staticmethod
    def L_PINNED_LIST_OPEN_BTN(lang=''):
        return 'xpath', '//chat-pinned-message/..//a[.//iva-icon-list]'

    @staticmethod
    def L_OWN_MESSAGE_AVATAR(lang=''):
        return 'xpath', f'({LChat.L_CHAT_MESSAGE_CONTAINER()[1]}[.//div[contains(@class,"_theme-my")]]//iva-avatar)[1]'

    @staticmethod
    def L_ATTACHMENT_BTN(lang=''):
        return 'xpath', '//chat-send-message//button[.//iva-icon-paperclip]'

    @staticmethod
    def L_ATTACHMENT_FILE_INPUT(lang=''):
        return 'xpath', '//chat-send-message//input[@type="file"]'

    @staticmethod
    def L_ATTACHMENT_CONTAINER(lang=''):
        return 'xpath', '//chat-attachments-container'

    @staticmethod
    def L_ATTACHMENT_CARD(lang=''):
        return 'xpath', f'{LChat.L_ATTACHMENT_CONTAINER()[1]}//chat-compose-attachment-card'

    @staticmethod
    def L_AUDIO_MESSAGE(file_name, lang=''):
        return 'xpath', f'{LChat.L_CHAT_MESSAGE_CONTAINER()[1]}//chat-audio-message[.//div[@class="name" and text()="{file_name}"]]'

    @staticmethod
    def L_AUDIO_PLAY_BUTTON(file_name, lang=''):
        return 'xpath', f'{LChat.L_AUDIO_MESSAGE(file_name)[1]}//button[contains(@class, "play-button")]'

    @staticmethod
    def L_VIDEO_MESSAGE(file_name, lang=''):
        return 'xpath', f'{LChat.L_CHAT_MESSAGE_CONTAINER()[1]}//chat-video-message[.//img[@alt="{file_name}"]]'

    @staticmethod
    def L_VIDEO_OPEN_BUTTON(file_name, lang=''):
        return 'xpath', f'{LChat.L_VIDEO_MESSAGE(file_name)[1]}//button[@class="root"]'

    @staticmethod
    def L_IMAGE_MESSAGE(file_name, lang=''):
        return 'xpath', f'{LChat.L_CHAT_MESSAGE_CONTAINER()[1]}//chat-image-message[.//img[@alt="{file_name}"]]'

    @staticmethod
    def L_DOCUMENT_MESSAGE(file_name, lang=''):
        return 'xpath', f'{LChat.L_CHAT_MESSAGE_CONTAINER()[1]}//chat-file-message[.//div[@class="name" and text()="{file_name}"]]'

    @staticmethod
    def L_I18N_JOIN_BTN(lang, is_channel: bool = False):
        key = 'chat_join_channel_btn' if is_channel else 'chat_join_group_btn'
        i18n_str = i18n.get_str(key, lang)
        return 'xpath', (
            f'{LChat.L_CHAT_ROOM()[1]}'
            f'//button[contains(@class,"join-button") and normalize-space()="{i18n_str}"]'
        )

    @staticmethod
    def L_I18N_NOT_FOUND_PAGE_MESSAGE(lang):
        i18n_str = i18n.get_str('not_found_page_message', lang)
        return 'xpath', f'//msg-not-found//p[normalize-space()="{i18n_str}"]'
