from tools import i18n


class LProfilePopup:
    @staticmethod
    def L_ROOT(lang=''):
        return 'xpath', '//cdk-dialog-container'

    @staticmethod
    def L_CLOSE_POPUP_BTN(lang=''):
        # 2.1.0: класс close-button убран — кнопка закрытия несёт директиву ivadialogclose (iva-header секции).
        return 'xpath', f'{LProfilePopup.L_ROOT()[1]}//button[@ivadialogclose]'

    @staticmethod
    def L_LEFT_BAR(lang=''):
        return 'xpath', f'{LProfilePopup.L_ROOT()[1]}//div[contains(@class,"left-bar")]'

    @staticmethod
    def L_TABS_SECTION(lang=''):
        return 'xpath', f'{LProfilePopup.L_LEFT_BAR()[1]}//iva-scroll-area[contains(@class,"section-links")]'

    @staticmethod
    def L_I18N_ACCOUNT_TAB(lang):
        i18n_str = i18n.get_str('account_tab_name', lang)
        return 'xpath', f'{LProfilePopup.L_LEFT_BAR()[1]}//a[contains(text(),"{i18n_str}")]'

    @staticmethod
    def L_I18N_SESSIONS_TAB(lang):
        i18n_str = i18n.get_str('profile_menu_sessions', lang)
        return 'xpath', f'{LProfilePopup.L_LEFT_BAR()[1]}//a[contains(text(),"{i18n_str}")]'

    @staticmethod
    def L_I18N_SUPPORT_TAB(lang):
        i18n_str = i18n.get_str('profile_menu_support', lang)
        return 'xpath', (
            f'{LProfilePopup.L_LEFT_BAR()[1]}'
            f'//a[contains(@href,"dialog:profile/support") and contains(normalize-space(.),"{i18n_str}")]'
        )

    @staticmethod
    def L_ABOUT_TAB(lang=''):
        return 'xpath', f'{LProfilePopup.L_LEFT_BAR()[1]}//a[contains(@href,"dialog:profile/about")]'

    @staticmethod
    def L_I18N_SETTINGS_TAB(lang):
        # Родительская вкладка «Настройки». Клик по ней редиректит на под-вкладку
        # «Оборудование» (media-settings, дефолт), не на язык — до языка нужен второй
        # клик по L_I18N_LANGUAGE_SUBTAB.
        i18n_str = i18n.get_str('profile_settings_tab_name', lang)
        return 'xpath', f'{LProfilePopup.L_LEFT_BAR()[1]}//a[contains(text(),"{i18n_str}")]'

    @staticmethod
    def L_I18N_LANGUAGE_SUBTAB(lang):
        # Под-вкладка «Язык» раздела «Настройки». Появляется в left-bar, когда «Настройки»
        # активны. Текст совпадает с заголовком секции «Язык» → переиспользуем тот же ключ.
        i18n_str = i18n.get_str('profile_settings_language_section_title', lang)
        return 'xpath', f'{LProfilePopup.L_LEFT_BAR()[1]}//a[contains(text(),"{i18n_str}")]'

    @staticmethod
    def L_I18N_EQUIPMENT_SUBTAB(lang):
        # Под-вкладка «Оборудование» раздела «Настройки» (дефолтная под-вкладка, EN «Media»).
        i18n_str = i18n.get_str('profile_settings_equipment_tab_name', lang)
        return 'xpath', f'{LProfilePopup.L_LEFT_BAR()[1]}//a[contains(text(),"{i18n_str}")]'

    @staticmethod
    def L_LEFT_BAR_HEADER(lang=''):
        return 'xpath', f'{LProfilePopup.L_LEFT_BAR()[1]}//profile-left-bar-header'

    @staticmethod
    def L_LEFT_BAR_HEADER_DS_AVATAR(lang=''):
        # Дрейф 2026-07-02: шапка попапа профиля домигрировала на <iva-avatar>
        # (ds-avatar больше не существует). Имя метода историческое — не переименовываем.
        return 'xpath', f'{LProfilePopup.L_LEFT_BAR_HEADER()[1]}//iva-avatar'

    @staticmethod
    def L_LEFT_BAR_HEADER_DS_AVATAR_IMG(lang=''):
        return 'xpath', f'{LProfilePopup.L_LEFT_BAR_HEADER_DS_AVATAR()[1]}//img'

    @staticmethod
    def L_LEFT_BAR_HEADER_DS_AVATAR_DEFAULT(lang=''):
        return 'xpath', f'{LProfilePopup.L_LEFT_BAR_HEADER_DS_AVATAR()[1]}//iva-avatar-fallback'
