from tools import i18n


class LLogin:
    @staticmethod
    def L_HEADER(lang=''):
        return 'xpath', '//*[@id="kc-page-title"]'

    @staticmethod
    def L_INPUT_LOGIN(lang=''):
        return 'xpath', '//*[@id="username"]'

    @staticmethod
    def L_INPUT_PASSWORD(lang=''):
        return 'xpath', '//*[@id="password"]'

    @staticmethod
    def L_BTN_SUBMIT(lang=''):
        return 'xpath', '//*[@id="kc-login"]'

    @staticmethod
    def L_SHOW_HIDE_PWD(lang=''):
        return 'xpath', '//button[@aria-controls="password"]'

    @staticmethod
    def L_I18N_WRONG_AUTH_TEXT(lang):
        i18n_str = i18n.get_str('wrong_auth_text', lang)
        return 'xpath', f'//*[@id="input-error" and contains(text(),"{i18n_str}")]'
