import time
from typing import TYPE_CHECKING

from autocore.test.logger import get_log
from autocore.base.web.base_page import PBase
from .locators import Version2 as Version2Locators
from tools import i18n

if TYPE_CHECKING:
    from .locators.Version2.chat_input_edit_link_popup import (
        LChatInputEditLinkPopup as _LocatorsTypingBase,
    )
else:
    class _LocatorsTypingBase:
        pass

log = get_log()


class _PVersionChatInputEditLinkPopup(PBase, _LocatorsTypingBase):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_ROOT()
        self.page_path = ''
        kwargs['open_page'] = False
        super().__init__(*args, **kwargs)

    def confirm(self):
        btn_name = i18n.get_str('chat_input_edit_link_popup_add_btn', self.lang)
        log.step(f'Нажать кнопку "{btn_name}" в попапе редактирования ссылки', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_ADD_BTN(self.lang)).click()
        self.wait_absence(self.L_ROOT())

    def _input_new_value(self, input_locator, input_value):
        if self.driver.name in ['Safari']:
            time.sleep(3)
        self.clear_input(input_locator)
        if self.driver.name in ['Safari']:
            time.sleep(1)
        self.get_object(input_locator).send_keys(input_value)

    def edit_link(self, new_link):
        input_locator = self.L_I18N_LINK_INPUT(self.lang)
        log.step(f'Ввести значение "{new_link}" в поле "Ссылка"', where='IVA ONE WEB Клиент')
        self._input_new_value(input_locator, new_link)


class PVersion2ChatInputEditLinkPopup(_PVersionChatInputEditLinkPopup, Version2Locators.LChatInputEditLinkPopup):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.version = 'Version2'

