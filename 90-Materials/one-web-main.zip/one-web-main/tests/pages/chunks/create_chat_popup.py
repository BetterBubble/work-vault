import os
from typing import TYPE_CHECKING

from autocore.base.web.base_page import PBase
from autocore.consts import TEST_DATA_DIR
from autocore.test.assertions import assert_fn
from autocore.test.logger import get_log
from tests.pages.locators.Version2.chunks import create_chat_popup as Version2Locators
from tools import i18n
from tools.helpers.page_helpers import upload_avatar_via_lazy_picker

if TYPE_CHECKING:
    from tests.pages.locators.Version2.chunks.create_chat_popup import (
        LCreateChatPopup as _LocatorsTypingBase,
    )
else:
    class _LocatorsTypingBase:
        pass

log = get_log()


class _CCreateChatPopup(PBase, _LocatorsTypingBase):
    """Chunk wizard'а создания чата (`<chat-create-chat-dialog>`)."""

    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_ROOT()
        self.page_path = ''
        kwargs['open_page'] = False
        super().__init__(*args, **kwargs)

    def assert_step1_group_opened(self):
        self.assert_presence(self.L_I18N_STEP1_GROUP_TITLE(self.lang),
                             'Открыт шаг 1 wizard создания группового чата')

    def assert_step1_channel_opened(self):
        self.assert_presence(self.L_I18N_STEP1_CHANNEL_TITLE(self.lang),
                             'Открыт шаг 1 wizard создания информационного канала')

    def search_and_select_member(self, full_name: str):
        log.step(f'Найти и выбрать участника "{full_name}" в шаге выбора участников',
                 where='IVA ONE WEB Клиент')
        search_input = self.get_object(self.L_I18N_SEARCH_INPUT(self.lang))
        search_input.clear()
        search_input.send_keys(full_name)
        self.wait_presence(self.L_CONTACT_ROW(full_name))
        self.get_object(self.L_CONTACT_ROW(full_name)).click()

    def click_next(self):
        next_btn_name = i18n.get_str('create_chat_next_btn', self.lang)
        log.step(f'Нажать кнопку "{next_btn_name}" в шаге выбора участников',
                 where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_NEXT_BTN(self.lang)).click()
        self.wait_absence(self.L_STEP1_ROOT())

    def assert_step2_group_opened(self):
        self.assert_presence(self.L_STEP2_GROUP_ROOT(),
                             'Открыт шаг 2 wizard создания группового чата')

    def assert_step2_channel_opened(self):
        self.assert_presence(self.L_STEP2_CHANNEL_ROOT(),
                             'Открыт шаг 2 wizard создания информационного канала')

    def type_chat_name(self, name: str):
        log.step(f'Ввести название чата "{name}" в форме создания',
                 where='IVA ONE WEB Клиент')
        self.get_object(self.L_NAME_INPUT()).send_keys(name)

    def click_create_group(self):
        create_btn_name = i18n.get_str('create_chat_create_group_btn', self.lang)
        log.step(f'Нажать кнопку "{create_btn_name}" в форме создания',
                 where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_CREATE_GROUP_BTN(self.lang)).click()

    def click_create_channel(self):
        create_btn_name = i18n.get_str('create_chat_create_channel_btn', self.lang)
        log.step(f'Нажать кнопку "{create_btn_name}" в форме создания',
                 where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_CREATE_CHANNEL_BTN(self.lang)).click()

    def assert_create_group_btn_disabled(self):
        btn = self.get_object(self.L_I18N_CREATE_GROUP_BTN(self.lang))
        assert_fn(lambda: btn.get_attribute('disabled') is not None,
                  'Кнопка "Создать группу" недоступна')

    def assert_create_group_btn_enabled(self):
        btn = self.get_object(self.L_I18N_CREATE_GROUP_BTN(self.lang))
        assert_fn(lambda: btn.get_attribute('disabled') is None,
                  'Кнопка "Создать группу" доступна')

    def assert_create_channel_btn_disabled(self):
        btn = self.get_object(self.L_I18N_CREATE_CHANNEL_BTN(self.lang))
        assert_fn(lambda: btn.get_attribute('disabled') is not None,
                  'Кнопка "Создать канал" недоступна')

    def assert_create_channel_btn_enabled(self):
        btn = self.get_object(self.L_I18N_CREATE_CHANNEL_BTN(self.lang))
        assert_fn(lambda: btn.get_attribute('disabled') is None,
                  'Кнопка "Создать канал" доступна')

    def upload_avatar(self, file_name: str):
        log.step(f'Загрузить фото чата "{file_name}"', where='IVA ONE WEB Клиент')
        local_path = os.path.join(TEST_DATA_DIR, file_name)
        upload_avatar_via_lazy_picker(self.driver, self.get_object(self.L_AVATAR_EDIT_HOST()), local_path)

    def assert_avatar_uploaded(self):
        self.assert_presence(self.L_AVATAR_PREVIEW_IMAGE(),
                             'Фото чата загружено')

    def assert_public_toggle_off(self):
        toggle_input = self.get_object(self.L_PUBLIC_TOGGLE_INPUT())
        assert_fn(lambda: not toggle_input.is_selected(),
                  'Тоггл "Публичный чат" неактивен')

    def toggle_public_chat(self):
        log.step('Нажать тоггл "Публичный чат" в форме создания',
                 where='IVA ONE WEB Клиент')
        self.get_object(self.L_PUBLIC_TOGGLE_SWITCH()).click()

    def assert_public_toggle_on(self):
        toggle_input = self.get_object(self.L_PUBLIC_TOGGLE_INPUT())
        assert_fn(lambda: toggle_input.is_selected(),
                  'Тоггл "Публичный чат" активен')

    def assert_dialog_closed(self):
        assert_fn(lambda: self.wait_absence(self.L_ROOT()),
                  'Диалог создания чата закрыт')

    def assert_member_in_list(self, full_name: str):
        self.assert_presence(self.L_MEMBER_ITEM(full_name),
                             f'Участник "{full_name}" добавлен в создаваемый чат')


class CVersion2CreateChatPopup(_CCreateChatPopup, Version2Locators.LCreateChatPopup):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.version = 'Version2'
