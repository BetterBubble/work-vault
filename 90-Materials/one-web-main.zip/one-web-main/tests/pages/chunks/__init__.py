from .left_menu import CVersion2LeftMenu
from .profile_popup_account import CVersion2ProfilePopupAccount
from .profile_popup_about import CVersion2ProfilePopupAbout
from .profile_popup_sessions import CVersion2ProfilePopupSessions
from .profile_popup_settings_language import CVersion2ProfilePopupSettingsLanguage
from .profile_popup_settings_equipment import CVersion2ProfilePopupSettingsEquipment
from .profile_popup_support import CVersion2ProfilePopupSupport
from .address_book import CVersion2AddressBook
from .user_profile import CVersion2UserProfile
from .contact_card import CVersion2ContactCard
from .contact_form import CVersion2ContactForm
from .group_chat_profile import CVersion2GroupChatProfile
from .info_channel_profile import CVersion2InfoChannelProfile
from .p2p_chat_profile import CVersion2P2pChatProfile
from .toast import CVersion2Toast
from .chat_pinned_messages_room import CVersion2ChatPinnedMessagesRoom
from .create_chat_popup import CVersion2CreateChatPopup
from .chat_attachments import CVersion2ChatAttachments
from .media_viewer import CVersion2MediaViewer
from .call import CVersion2Call
from .mcu_conference_sidebar import CVersion2McuConferenceSidebar
from .offline_event import CVersion2OfflineEvent
from .org_structure_sidebar import CVersion2OrgStructureSidebar
from .calendar import CVersion2Calendar
from .add_participants_dialog import CVersion2AddParticipantsDialog
from .forward_dialog import CVersion2ForwardDialog
from .chats_list import CVersion2ChatsList

from autocore.test.logger import get_log

log = get_log()


def get_chunk(version, chunk_name):
    if version == 'Version2':
        log.debug(f'Using page/chunk chunk-{chunk_name}')
        if chunk_name == 'left_menu':
            return CVersion2LeftMenu
        if chunk_name == 'profile_popup_account':
            return CVersion2ProfilePopupAccount
        if chunk_name == 'profile_popup_about':
            return CVersion2ProfilePopupAbout
        if chunk_name == 'profile_popup_sessions':
            return CVersion2ProfilePopupSessions
        if chunk_name == 'profile_popup_settings_language':
            return CVersion2ProfilePopupSettingsLanguage
        if chunk_name == 'profile_popup_settings_equipment':
            return CVersion2ProfilePopupSettingsEquipment
        if chunk_name == 'profile_popup_support':
            return CVersion2ProfilePopupSupport
        if chunk_name == 'address_book':
            return CVersion2AddressBook
        if chunk_name == 'user_profile':
            return CVersion2UserProfile
        if chunk_name == 'contact_card':
            return CVersion2ContactCard
        if chunk_name == 'contact_form':
            return CVersion2ContactForm
        if chunk_name == 'group_chat_profile':
            return CVersion2GroupChatProfile
        if chunk_name == 'info_channel_profile':
            return CVersion2InfoChannelProfile
        if chunk_name == 'p2p_chat_profile':
            return CVersion2P2pChatProfile
        if chunk_name == 'toast':
            return CVersion2Toast
        if chunk_name == 'forward_dialog':
            return CVersion2ForwardDialog
        if chunk_name == 'chats_list':
            return CVersion2ChatsList
        if chunk_name == 'chat_pinned_messages_room':
            return CVersion2ChatPinnedMessagesRoom
        if chunk_name == 'create_chat_popup':
            return CVersion2CreateChatPopup
        if chunk_name == 'chat_attachments':
            return CVersion2ChatAttachments
        if chunk_name == 'media_viewer':
            return CVersion2MediaViewer
        if chunk_name == 'call':
            return CVersion2Call
        if chunk_name == 'mcu_conference_sidebar':
            return CVersion2McuConferenceSidebar
        if chunk_name == 'offline_event':
            return CVersion2OfflineEvent
        if chunk_name == 'org_structure_sidebar':
            return CVersion2OrgStructureSidebar
        if chunk_name == 'calendar':
            return CVersion2Calendar
        if chunk_name == 'add_participants_dialog':
            return CVersion2AddParticipantsDialog
        else:
            raise ValueError(f'Chunk {chunk_name} was not registered.')
    else:
        raise ValueError(f'Version {version} is not supported.')
