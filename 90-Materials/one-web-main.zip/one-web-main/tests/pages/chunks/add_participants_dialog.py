from typing import TYPE_CHECKING

from autocore.base.web.base_page import PBase
from autocore.test.logger import get_log

from tests.pages.locators.Version2.chunks import add_participants_dialog as Version2Locators
from tools.helpers import page_helpers

if TYPE_CHECKING:
    from tests.pages.locators.Version2.chunks.add_participants_dialog import (
        LAddParticipantsDialog as _LocatorsTypingBase,
    )
else:
    class _LocatorsTypingBase:
        pass

log = get_log()


class _CAddParticipantsDialog(PBase, _LocatorsTypingBase):
    """Попап «Добавить участников» формы создания мероприятия календаря (<iva-modal>
    внутри cdk-dialog + <contacts-table>). Открывается кликом «Добавить» в секции
    участников; поиск по ФИО/отделу/должности, выбор строки, подтверждение."""

    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_DIALOG()
        self.page_path = ''
        kwargs['open_page'] = False
        kwargs['check_primary_element'] = False
        super().__init__(*args, **kwargs)

    def search_and_select(self, query: str, full_name: str):
        """Найти контакт по запросу и выбрать его строку. Поиск повторяется: свежесозданный
        корп-юзер появляется в справочнике не мгновенно (индексация ~секунды, иногда промах —
        см. TODO 020), поэтому пере-вводим запрос, пока строка не появится."""
        log.step(f'Найти и выбрать контакта "{full_name}" в попапе участников', where='IVA ONE WEB Клиент')
        for _ in range(5):
            search = self.get_object(self.L_I18N_SEARCH_INPUT(self.lang))
            search.clear()
            search.send_keys(query)
            if self.wait_presence(self.L_CONTACT_ROW(full_name), timeout=6, mode='return'):
                # retry_on_rerender закрывает гонку пересоздания строки между wait и кликом
                # (результаты поиска перерисовываются вдогонку индексации — см. page_helpers).
                page_helpers.retry_on_rerender(
                    lambda: self.get_object(self.L_CONTACT_ROW(full_name)).click())
                return
        # Последняя попытка без mode='return' — пусть штатное исключение всплывёт с диагностикой.
        self.get_object(self.L_CONTACT_ROW(full_name)).click()

    def confirm(self):
        log.step('Нажать "Добавить" в попапе участников', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_CONFIRM_BTN(self.lang)).click()


class CVersion2AddParticipantsDialog(_CAddParticipantsDialog, Version2Locators.LAddParticipantsDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.version = 'Version2'
