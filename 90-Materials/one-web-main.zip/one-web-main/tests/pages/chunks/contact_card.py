import time
from typing import TYPE_CHECKING

from autocore.base.web.base_page import PBase
from autocore.test.logger import get_log
from autocore.test.assertions import assert_fn
from tests.pages import chunks
from tests.pages.locators.Version2.chunks import contact_card as Version2Locators
from tools.helpers import page_helpers

if TYPE_CHECKING:
    from tests.pages.locators.Version2.chunks.contact_card import (
        LContactCard as _LocatorsTypingBase,
    )
else:
    class _LocatorsTypingBase:
        pass

log = get_log()


class _CContactCard(PBase, _LocatorsTypingBase):
    """Карточка-сайдбар личного контакта (`<contacts-contact-sidebar>`).

    Открывается кликом по имени контакта в списке адресной книги. Несёт прямые
    кнопки действий (Позвонить/Видео/Ещё) и меню «Ещё» (ВКС-встреча/Событие/
    Редактировать/Переместить/Удалить). Это НЕ `user_profile` (тот — профиль
    пользователя в чат-контексте, корень `<address-book-contact-sidebar>`).
    """

    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_ROOT()
        self.page_path = ''
        kwargs['open_page'] = False
        super().__init__(*args, **kwargs)

    def open_more_menu(self):
        log.step('Открыть меню "Ещё" в карточке контакта', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_MORE_BTN(self.lang)).click()

    def expand_additional_phones(self):
        """Раскрыть свёрнутые доп. телефоны кнопкой «Еще N» в секции телефонов.
        Свёрнутые строки рендерятся lazy — до раскрытия их нет в DOM (видна только одна
        «Дополнительный»). Если телефонов мало и toggler'а нет — ничего не делаем."""
        toggler = self.L_PHONE_EXPAND_TOGGLER()
        if self.wait_presence(toggler, timeout=5, mode='return'):
            log.step('Раскрыть дополнительные телефоны ("Еще N")', where='IVA ONE WEB Клиент')
            self.get_object(toggler).click()

    def assert_additional_phones_count(self, count: int, timeout: float = 10):
        # Раскрытые строки дорисовываются лениво после клика «Еще N» — мгновенный
        # снимок count гонится с отрисовкой, поллим до совпадения.
        items = self.L_ADDITIONAL_PHONE_ITEM(self.lang)
        end = time.time() + timeout
        actual = len(self.get_object(items, multiple=True, multiple_no_wait=True))
        while actual != count and time.time() < end:
            time.sleep(0.5)
            actual = len(self.get_object(items, multiple=True, multiple_no_wait=True))
        assert_fn(
            lambda: actual == count,
            f'В карточке контакта отображается дополнительных телефонов: {count}',
        )

    def start_call(self):
        log.step('Нажать "Позвонить" в карточке контакта', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_CALL_BTN(self.lang)).click()

    def open_mcu_conference_form(self):
        self.open_more_menu()
        log.step('Выбрать пункт "ВКС-встреча" в меню карточки контакта', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_MENU_ITEM('contact_card_menu_mcu', self.lang)).click()

    def open_event_form(self):
        self.open_more_menu()
        log.step('Выбрать пункт "Событие" в меню карточки контакта', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_MENU_ITEM('contact_card_menu_event', self.lang)).click()

    def open_edit_contact(self):
        """«Ещё» → «Редактировать» (overflow-меню, `iva-icon-pencil`) → форма редактирования
        контакта (та же sidebar-форма, что create). Возвращает chunk формы."""
        self.open_more_menu()
        log.step('Выбрать пункт "Редактировать" в меню карточки контакта', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_MENU_ITEM('address_book_edit_contact_action_button_web', self.lang)).click()
        return chunks.get_chunk(self.version, 'contact_form')(driver=self.driver, lang=self.lang)

    def open_delete_contact_dialog(self):
        self.open_more_menu()
        log.step('Выбрать пункт "Удалить" в меню карточки контакта', where='IVA ONE WEB Клиент')
        page_helpers.click_via_js(self.driver, self.get_object(self.L_I18N_MENU_ITEM('contact_card_menu_delete', self.lang)))

    def assert_delete_contact_dialog(self, full_name: str):
        self.assert_presence(
            self.L_I18N_DELETE_DIALOG(full_name, self.lang),
            f'Отображается поп-ап подтверждения удаления контакта "{full_name}"',
        )

    def confirm_delete_contact(self):
        log.step('Нажать "Удалить" в поп-апе подтверждения удаления', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_DELETE_DIALOG_CONFIRM_BTN(self.lang)).click()

    def assert_card_closed(self):
        assert_fn(
            lambda: self.wait_absence(self.L_ROOT()),
            'Карточка-сайдбар контакта закрылась после удаления',
        )

    def open_move_contact_menu(self):
        self.open_more_menu()
        log.step('Выбрать пункт "Переместить" в меню карточки контакта', where='IVA ONE WEB Клиент')
        menu_item = self.L_I18N_MENU_ITEM('contact_card_menu_move', self.lang)
        self.get_object(menu_item).click()
        if not self.wait_presence(self.L_MOVE_MENU(), timeout=3, mode='return'):
            self.get_object(menu_item).click()  # submenu иногда раскрывается со второго клика
            self.wait_presence(self.L_MOVE_MENU(), timeout=5)

    def assert_move_picker_book_present(self, book_name: str):
        self.assert_presence(
            self.L_MOVE_MENU_BOOK_NODE(book_name),
            f'Книга "{book_name}" доступна для выбора в picker\'е перемещения',
        )

    def assert_move_picker_book_not_selectable(self, book_name: str):
        # Исходная книга контакта показывается в picker'е, но недоступна для выбора
        # (несёт класс _not-selectable, как системные категории). Проверяем оба факта —
        # присутствие И невыбираемость — чтобы при регрессе сигнал был однозначным.
        self.assert_presence(
            self.L_MOVE_MENU_BOOK_NODE_ROW(book_name),
            f'Книга "{book_name}" отображается в picker\'е перемещения',
        )
        self.assert_presence(
            self.L_MOVE_MENU_BOOK_NODE_DISABLED(book_name),
            f'Книга "{book_name}" недоступна для выбора в picker\'е перемещения',
        )

    def move_contact_to_book(self, book_name: str):
        log.step(f'Выбрать книгу "{book_name}" для перемещения контакта', where='IVA ONE WEB Клиент')
        self.get_object(self.L_MOVE_MENU_BOOK_NODE(book_name)).click()


class CVersion2ContactCard(_CContactCard, Version2Locators.LContactCard):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.version = 'Version2'
