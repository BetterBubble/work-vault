from typing import TYPE_CHECKING

from autocore.base.web.base_page import PBase
from tests.pages.locators.Version2.chunks import org_structure_sidebar as Version2Locators
from autocore.test.logger import get_log
from tests.pages import chunks
from tools.helpers import page_helpers

if TYPE_CHECKING:
    from tests.pages.locators.Version2.chunks.org_structure_sidebar import (
        LOrgStructureSidebar as _LocatorsTypingBase,
    )
else:
    class _LocatorsTypingBase:
        pass

log = get_log()


class _COrgStructureSidebar(PBase, _LocatorsTypingBase):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_ROOT()
        self.page_path = ''
        kwargs['open_page'] = False
        super().__init__(*args, **kwargs)

    def assert_manager_block(self, full_name: str):
        self.assert_presence(self.L_I18N_MANAGER_BLOCK_HEADER(self.lang), 'Отображается блок "В подчинении у:"')
        self.assert_presence(self.L_MANAGER_ITEM(full_name), f'Руководитель "{full_name}" отображается в орг-структуре')

    def open_manager_card(self, full_name: str):
        log.step(f'Открыть карточку руководителя "{full_name}" из орг-структуры', where='IVA ONE WEB Клиент')
        # Safari кидает WebDriverException на обычном клике по кастомному li.user — клик через JS.
        page_helpers.click_via_js(self.driver, self.get_object(self.L_MANAGER_ITEM(full_name)))
        return chunks.get_chunk(self.version, 'user_profile')(driver=self.driver, lang=self.lang)

    def assert_subordinate_block(self, full_name: str):
        self.assert_presence(self.L_I18N_TEAM_BLOCK_HEADER(self.lang), 'Отображается блок "Руководитель для:"')
        self.assert_presence(self.L_TEAM_ITEM(full_name), f'Подчинённый "{full_name}" отображается в орг-структуре')

    def open_subordinate_card(self, full_name: str):
        log.step(f'Открыть карточку подчинённого "{full_name}" из орг-структуры', where='IVA ONE WEB Клиент')
        # Тот же li.user, что в open_manager_card — JS-клик по той же причине.
        page_helpers.click_via_js(self.driver, self.get_object(self.L_TEAM_ITEM(full_name)))
        return chunks.get_chunk(self.version, 'user_profile')(driver=self.driver, lang=self.lang)


class CVersion2OrgStructureSidebar(_COrgStructureSidebar, Version2Locators.LOrgStructureSidebar):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.version = 'Version2'
