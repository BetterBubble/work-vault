from typing import TYPE_CHECKING

from selenium.common.exceptions import TimeoutException

from autocore.base.web.base_page import PBase
from autocore.test.logger import get_log
from tests.pages.locators.Version2.chunks import forward_dialog as Version2Locators
from tools.helpers import page_helpers

if TYPE_CHECKING:
    from tests.pages.locators.Version2.chunks.forward_dialog import (
        LForwardDialog as _LocatorsTypingBase,
    )
else:
    class _LocatorsTypingBase:
        pass

log = get_log()


class _CForwardDialog(PBase, _LocatorsTypingBase):
    """Chunk диалога пересылки сообщения (`<cdk-dialog-container>` со списком чатов).

    Открывается из чата (кнопка "Переслать" в контекстном меню сообщения или в тулбаре
    режима выбора). `check_primary_element=False` — диалога может не быть в момент создания
    chunk'а (его инстанцируют, чтобы дождаться открытия через `wait_open`).
    """

    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_I18N_ROOT(self.lang)
        self.page_path = ''
        kwargs['open_page'] = False
        kwargs['check_primary_element'] = False
        super().__init__(*args, **kwargs)

    def wait_open(self):
        self.wait_presence(self.L_I18N_ROOT(self.lang))

    def search_chat(self, chat_name: str):
        search_input_locator = self.L_I18N_SEARCH_INPUT(self.lang)
        search_input = self.get_object(search_input_locator)
        search_input.click()
        # Выдача идёт через search-индекс: свежий чат/юзер под параллельной нагрузкой
        # индексируется десятки секунд, и уже отданная пустая выдача сама не обновится —
        # ретраим перевводом запроса (до ~60s), а не одним длинным ожиданием.
        for _ in range(5):
            self.clear_input(search_input_locator)
            search_input.send_keys(chat_name)
            if self.wait_presence(self.L_I18N_CHAT_ITEM(chat_name, self.lang), 10, mode='return'):
                return
        self.wait_presence(self.L_I18N_CHAT_ITEM(chat_name, self.lang), 5)

    def select_chat(self, chat_name: str):
        log.step(f'Выбрать чат "{chat_name}" в диалоге пересылки', where='IVA ONE WEB Клиент')
        # Выдача может пересоздаться между поиском и кликом (доезд индексации) —
        # retry_on_rerender перечитывает item (см. page_helpers). Если строка пропала
        # из выдачи или диалог не закрылся после клика, повторяем поиск и клик один раз.
        last_error = None
        for _ in range(2):
            self.search_chat(chat_name)
            try:
                page_helpers.retry_on_rerender(
                    lambda: self.get_object(self.L_I18N_CHAT_ITEM(chat_name, self.lang)).click())
            except TimeoutException as error:
                last_error = error
                continue
            if self.wait_absence(self.L_I18N_ROOT(self.lang)):
                return
        raise TimeoutException(
            f'Не удалось выбрать чат "{chat_name}": '
            'диалог пересылки остался открыт после двух попыток'
        ) from last_error


class CVersion2ForwardDialog(_CForwardDialog, Version2Locators.LForwardDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.version = 'Version2'
