from typing import TYPE_CHECKING

from autocore.base.web.base_page import PBase
from autocore.test.logger import get_log
from autocore.test.assertions import assert_fn

from tools import i18n
from tools.helpers.page_helpers import wait_clickable_via_js
from tests.pages.locators.Version2.chunks import call as Version2Locators

if TYPE_CHECKING:
    from tests.pages.locators.Version2.chunks.call import (
        LCall as _LocatorsTypingBase,
    )
else:
    class _LocatorsTypingBase:
        pass

log = get_log()


class _CCall(PBase, _LocatorsTypingBase):
    """Chunk окна звонка `<web-call-window>` (входящий и активный — один компонент:
    входящий с accept-button, активный с `<calls-active-call-duration>`) и диалога
    «Настройка оборудования». У принявшего окно разворачивается на весь экран («3 точки»
    доступны сразу), у звонящего остаётся маленьким без них."""

    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_CALL_WINDOW()
        self.page_path = ''
        kwargs['open_page'] = False
        kwargs['check_primary_element'] = False
        super().__init__(*args, **kwargs)

    def assert_outgoing_call_started(self):
        self.assert_presence(self.L_CALL_WINDOW(),
                             'Окно исходящего звонка отображается в активной вкладке')

    def end_call(self):
        log.step('Завершить звонок (кнопка сброса)', where='IVA ONE WEB Клиент')
        self.get_object(self.L_CALL_DECLINE_BTN()).click()

    def assert_call_window_closed(self):
        assert_fn(
            lambda: self.wait_absence(self.L_CALL_WINDOW()),
            'Окно звонка закрылось после завершения',
        )

    def accept_incoming_call(self):
        log.step('Принять входящий вызов', where='IVA ONE WEB Клиент')
        self.wait_presence(self.L_INCOMING_CALL_NOTIFICATION(), 15)
        wait_clickable_via_js(self.driver, lambda: self.get_object(self.L_INCOMING_CALL_ACCEPT_BTN()))
        self.get_object(self.L_INCOMING_CALL_ACCEPT_BTN()).click()

    def assert_call_active(self):
        self.assert_presence(self.L_CALL_ACTIVE_MARKER(),
                             'Звонок перешёл в активную фазу (отображается таймер длительности)')

    def open_more_actions_menu(self):
        log.step('Открыть меню действий ("3 точки") в окне звонка', where='IVA ONE WEB Клиент')
        self.get_object(self.L_CALL_MORE_MENU_BTN()).click()
        self.wait_presence(self.L_I18N_CALL_EQUIPMENT_MENU_ITEM(self.lang), 5)

    def assert_equipment_menu_item_visible(self):
        self.assert_presence(self.L_I18N_CALL_EQUIPMENT_MENU_ITEM(self.lang),
                             'Пункт "Настройка оборудования" отображается в меню действий звонка')

    def open_equipment_settings(self):
        log.step('Нажать "Настройка оборудования" в меню действий звонка', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_CALL_EQUIPMENT_MENU_ITEM(self.lang)).click()
        self.wait_presence(self.L_CALL_EQUIPMENT_DIALOG(), 5)

    def assert_equipment_dialog_sections(self):
        self.assert_presence(self.L_I18N_CALL_EQUIPMENT_DIALOG_TITLE(self.lang),
                             'Окно "Настройка оборудования" открыто')
        self.assert_presence(self.L_I18N_CALL_EQUIPMENT_VIDEO_SECTION(self.lang),
                             'Раздел "Камера" (Видео) отображается в окне оборудования')
        self.assert_presence(self.L_I18N_CALL_EQUIPMENT_AUDIO_SECTION(self.lang),
                             'Раздел "Микрофон" (Аудио) отображается в окне оборудования')
        self.assert_presence(self.L_I18N_CALL_EQUIPMENT_SOUND_SECTION(self.lang),
                             'Раздел "Динамики" (Звук) отображается в окне оборудования')


class CVersion2Call(_CCall, Version2Locators.LCall):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.version = 'Version2'
