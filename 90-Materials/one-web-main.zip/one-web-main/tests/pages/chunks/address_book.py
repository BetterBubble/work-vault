import time
from typing import TYPE_CHECKING

import requests
from selenium.common.exceptions import NoSuchElementException, StaleElementReferenceException
from selenium.webdriver.common.action_chains import ActionChains

from autocore.base.web.base_page import PBase
from autocore.clients.rest import iva_one
from tests.pages.locators.Version2.chunks import address_book as Version2Locators
from tests.pages.locators.Version2.chunks.contact_card import LContactCard
from autocore.test.logger import get_log
from autocore.test.assertions import assert_fn
from tests import pages
from tests.pages import chunks
from tools import i18n
from tools import enums
from tools.helpers import page_helpers, get_gradient

if TYPE_CHECKING:
    from tests.pages.locators.Version2.chunks.address_book import (
        LAddressBook as _LocatorsTypingBase,
    )
else:
    class _LocatorsTypingBase:
        pass

log = get_log()


class _CAddressBook(PBase, _LocatorsTypingBase):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_ADDRESS_BOOK_ITEMS()
        self.page_path = ''
        kwargs['open_page'] = False
        super().__init__(*args, **kwargs)

    def search_user(self, user: dict):
        log.step(f'Найти пользователя "{user["username"]}" в адресной книге', where='IVA ONE WEB Клиент')
        search_input = self.get_object(self.L_I18N_SEARCH_INPUT(self.lang))
        time.sleep(5)  # Без паузы здесь поиск часто не выдаёт результаты
        search_input.send_keys(user["last_name"])
        log.info(f'В поисковую строку введено значение {user["last_name"]}')
        self.wait_presence(self.L_ADDRESS_BOOK_ITEM(user["last_name"] + ' ' + user["first_name"]))

    def open_user_profile(self, user_data: dict):
        self.search_user(user_data)
        log.step(f'Открыть профиль пользователя "{user_data["username"]}" в адресной книге', where='IVA ONE WEB Клиент')
        self.get_object(self.L_ADDRESS_BOOK_ITEM(user_data["last_name"] + ' ' + user_data["first_name"])).click()
        _ = chunks.get_chunk(self.version, 'user_profile')(driver=self.driver, lang=self.lang)

    def _get_default_avatars_letters(self, username):
        # Выдача таблицы справочника обновляется вдогонку индексации свежего юзера —
        # retry_on_rerender закрывает гонку пересоздания строки (см. page_helpers).
        content = page_helpers.retry_on_rerender(
            lambda: self.get_object(self.L_ADDRESS_BOOK_ITEM_AVATAR_INITIALS(username)).text)
        log.info(f'Из аватара по умолчанию получено содержимое: "{content}"')
        return content.strip()

    def check_default_avatar_ds_first_letters(self, user_data: dict):
        """
        Проверяет у указанного пользователя с ФИ корректное отображение букв на аватаре по умолчанию
        """
        expected_letters = page_helpers.get_expected_default_avatars_letters(user_data)
        actual_letters = self._get_default_avatars_letters(user_data["last_name"] + ' ' + user_data["first_name"])
        assert_fn(lambda: actual_letters == expected_letters,
                  f'Буквы "{actual_letters}" на аватаре у пользователя "{user_data['last_name']} {user_data['first_name']}" соответствуют ожидаемым "{expected_letters}"')

    def _get_default_avatar_actual_gradient(self, username):
        # iva-билд: цвет градиента задаётся не inline-style, а атрибутом data-appearance
        # на <iva-avatar-background> (имя бакета палитры — pink/apricot/...).
        gradient = page_helpers.retry_on_rerender(
            lambda: self.get_object(self.L_ADDRESS_BOOK_ITEM_AVATAR_BG(username)).get_attribute('data-appearance'))
        log.info(f'Из аватара по умолчанию получен градиент "{gradient}"')
        return gradient

    def check_default_avatar_gradient(self, user_data: dict):
        """
        Проверяет у указанного пользователя корректное отображение цвета аватара по умолчанию
        """
        expected_gradient = get_gradient(user_data['id'])
        actual_gradient = self._get_default_avatar_actual_gradient(user_data["last_name"] + ' ' + user_data["first_name"])
        assert_fn(lambda: actual_gradient == expected_gradient,
                  f'Градиент {actual_gradient} на аватаре у пользователя "{user_data['last_name']} {user_data['first_name']}" соответствует ожидаемому "{expected_gradient}"')

    def open_personal_book(self, book_name: str):
        log.step(f'Открыть личную адресную книгу "{book_name}"', where='IVA ONE WEB Клиент')
        # Раздел «Личные» бывает свёрнут (cdk-tree удаляет/скрывает дочерние книги).
        # Раскрываем по aria-expanded кликом по chevron-кнопке (только toggle).
        personal_root = self.get_object(self.L_I18N_TREE_PERSONAL_ROOT(self.lang))
        if personal_root.get_attribute('aria-expanded') == 'false':
            page_helpers.click_via_js(self.driver, self.get_object(self.L_I18N_TREE_PERSONAL_ROOT_TOGGLE(self.lang)))
        book_link = self.L_TREE_BOOK_NODE_LINK(book_name)
        page_helpers.wait_clickable_via_js(self.driver, lambda: self.get_object(book_link), timeout=5)
        page_helpers.click_via_js(self.driver, self.get_object(book_link))

    def open_contact_card(self, full_name: str):
        log.step(f'Открыть карточку контакта "{full_name}"', where='IVA ONE WEB Клиент')
        page_helpers.click_via_js(self.driver, self.get_object(self.L_CONTACT_ROW_NAME(full_name)))
        return chunks.get_chunk(self.version, 'contact_card')(driver=self.driver, lang=self.lang)

    def assert_contact_in_book(self, full_name: str):
        self.assert_presence(
            self.L_CONTACT_ROW_NAME(full_name),
            f'Контакт "{full_name}" отображается в списке книги',
        )

    def assert_personal_book_empty_stub(self):
        self.assert_presence(
            self.L_I18N_PERSONAL_BOOK_EMPTY_STUB(self.lang),
            'Отображается заглушка пустой личной книги "Создайте свой первый личный контакт"',
        )

    def assert_contact_not_found_by_search(self, contact_full_name: str):
        query = contact_full_name.split()[0]  # по фамилии, как в search_user
        log.step(f'Найти "{query}" в поиске — удалённого контакта "{contact_full_name}" нет', where='IVA ONE WEB Клиент')
        search_input = self.get_object(self.L_I18N_SEARCH_INPUT(self.lang))
        search_input.clear()
        time.sleep(2)  # без паузы поиск часто не фильтрует (как в search_user)
        search_input.send_keys(query)
        assert_fn(
            lambda: self.wait_absence(self.L_CONTACT_ROW_NAME(contact_full_name)),
            f'Удалённого контакта "{contact_full_name}" нет в результатах поиска',
        )

    def open_all_contacts(self):
        log.step('Открыть "Все контакты" в адресной книге', where='IVA ONE WEB Клиент')
        book_link = self.L_I18N_TREE_ALL_CONTACTS_LINK(self.lang)
        page_helpers.wait_clickable_via_js(self.driver, lambda: self.get_object(book_link), timeout=5)
        page_helpers.click_via_js(self.driver, self.get_object(book_link))

    def select_contact(self, name: str):
        log.step(f'Отметить чекбокс контакта "{name}"', where='IVA ONE WEB Клиент')
        self._scroll_to_contact_row(name)
        checkbox = self.L_ROW_CHECKBOX(name)
        # Гонка перерисовки: свежевставленный div.alphabet-row перехватывает нативный клик по
        # чекбоксу (ElementClickInterceptedException). Ждём наблюдаемой кликабельности, затем
        # кликаем через JS — событие всплывает к Angular (click) в обход elementFromPoint-перехвата.
        page_helpers.wait_clickable_via_js(self.driver, lambda: self.get_object(checkbox), timeout=5)
        page_helpers.retry_on_rerender(
            lambda: page_helpers.click_via_js(self.driver, self.get_object(checkbox)))

    def _scroll_to_contact_row(self, name: str, max_pages: int = 5, page_timeout: float = 15):
        """Догрузить страницы списка, пока строка контакта не появится в DOM.

        Список отсортирован по ФИО и пагинируется по 100 строк: контакт с фамилией
        из хвоста алфавита лежит за пределами загруженной части, и presence-wait его
        не дождётся без скролла. Дошли до конца списка без строки — выходим молча:
        внятную ошибку даст штатное ожидание чекбокса в select_contact.
        """
        row = self.L_ROW(name)
        # Первичный рендер: строки появляются после XHR списка.
        end = time.time() + page_timeout
        while not self._contacts_rows_count() and time.time() < end:
            time.sleep(0.5)
        for _ in range(max_pages):
            if self.get_object(row, multiple=True, multiple_no_wait=True):
                return
            if self._load_trigger_hidden():
                return
            before = self._contacts_rows_count()
            page_helpers.scroll_element_to_bottom_via_js(
                self.driver, self.get_object(self.L_CONTACTS_SCROLL_CONTAINER()))
            end = time.time() + page_timeout
            while time.time() < end:
                if (self.get_object(row, multiple=True, multiple_no_wait=True)
                        or self._load_trigger_hidden()
                        or self._contacts_rows_count() > before):
                    break
                time.sleep(0.5)

    def assert_selected_count(self, n: int):
        self.assert_presence(
            self.L_I18N_BULK_SELECTED_COUNT(n, self.lang),
            f'В плашке мультиселекта счётчик "Выбрано: {n}"',
        )

    def search_contact(self, query: str):
        """Обычный поиск контактов (до входа в мультиселект — ds-input, не chip-input)."""
        log.step(f'Найти "{query}" в поиске контактов', where='IVA ONE WEB Клиент')
        search_input = self.get_object(self.L_I18N_SEARCH_INPUT(self.lang))
        time.sleep(2)  # без паузы поиск часто не фильтрует (как в search_user)
        search_input.send_keys(query)

    def multiselect_search(self, query: str):
        log.step(f'Ввести "{query}" в поиск мультиселекта', where='IVA ONE WEB Клиент')
        search_input = self.get_object(self.L_MULTISELECT_SEARCH_INPUT())
        search_input.clear()  # сменить запрос (выбранные остаются чипами)
        time.sleep(2)  # без паузы поиск часто не фильтрует (как в search_user)
        search_input.send_keys(query)

    def assert_contact_chip(self, name: str):
        self.assert_presence(
            self.L_CHIP(name),
            f'Выбранный контакт "{name}" сохранён в плашке мультиселекта (чип)',
        )

    def click_bulk_write(self):
        log.step('Нажать "Написать" в плашке мультиселекта', where='IVA ONE WEB Клиент')
        self.get_object(self.L_BULK_ACTION_WRITE()).click()

    def open_mcu_conference_form(self):
        """Открыть форму ВКС-встречи из мультиселекта: кнопка «Событие» в плашке → пункт
        «ВКС-встреча» в меню {ВКС-встреча, Событие}."""
        log.step('Нажать "Событие" в плашке мультиселекта', where='IVA ONE WEB Клиент')
        self.get_object(self.L_BULK_ACTION_EVENT_TRIGGER()).click()
        log.step('Выбрать "ВКС-встреча" в меню мультиселекта', where='IVA ONE WEB Клиент')
        self.get_object(LContactCard.L_I18N_MENU_ITEM('contact_card_menu_mcu', self.lang)).click()

    def open_event_form(self):
        """Открыть форму оффлайн-события из мультиселекта: кнопка «Событие» в плашке → пункт
        «Событие» в меню {ВКС-встреча, Событие}. ВКС и Событие живут в одном меню кнопки-триггера.
        Разделителя нет, если все выбранные имеют cans event.offline (личный + корпоративный) —
        форма сразу."""
        log.step('Нажать "Событие" в плашке мультиселекта', where='IVA ONE WEB Клиент')
        self.get_object(self.L_BULK_ACTION_EVENT_TRIGGER()).click()
        log.step('Выбрать "Событие" в меню мультиселекта', where='IVA ONE WEB Клиент')
        self.get_object(LContactCard.L_I18N_MENU_ITEM('contact_card_menu_event', self.lang)).click()

    def reset_multiselect(self):
        log.step('Нажать "Сбросить" в плашке мультиселекта', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_BULK_RESET_BTN(self.lang)).click()

    def assert_multiselect_inactive(self, message='Плашка мультиселекта закрылась (мультиселект деактивирован)'):
        assert_fn(
            lambda: self.wait_absence(self.L_BULK_BAR()),
            message,
        )

    def assert_create_chat_dialog(self):
        self.assert_presence(
            self.L_I18N_ACTION_DIVIDER('contacts_create_chat_dialog_title', self.lang),
            'Открыт диалог "Создать чат"',
        )

    def assert_create_chat_unavailable_info(self):
        self.assert_presence(
            self.L_I18N_ACTION_DIVIDER_INFO('contacts_create_chat_dialog_title', 'contacts_create_chat_unavailable_text', self.lang),
            'В диалоге "Создать чат" есть текст о недоступности чата для части контактов',
        )

    def assert_contact_unavailable_in_create_chat(self, name: str):
        self.assert_presence(
            self.L_I18N_ACTION_DIVIDER_CONTACT_UNAVAILABLE('contacts_create_chat_dialog_title', name, self.lang),
            f'Контакт "{name}" помечен недоступным для чата в диалоге',
        )

    def assert_contact_available_in_create_chat(self, name: str):
        self.assert_presence(
            self.L_I18N_ACTION_DIVIDER_CONTACT_AVAILABLE('contacts_create_chat_dialog_title', name, self.lang),
            f'Контакт "{name}" доступен для чата в диалоге',
        )

    def cancel_create_chat(self):
        log.step('Нажать "Отмена" в диалоге "Создать чат"', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_ACTION_DIVIDER_CANCEL('contacts_create_chat_dialog_title', self.lang)).click()

    def bulk_move_select_book(self, book_name: str):
        """Mixed-перемещение из мультиселекта: «Ещё» → «Переместить» → move-picker → выбор книги.
        Если в выборке есть недоступные — после выбора книги откроется разделитель «Перемещение»."""
        log.step('Открыть "Ещё" в плашке мультиселекта', where='IVA ONE WEB Клиент')
        self.get_object(self.L_BULK_ACTION_MORE()).click()
        log.step('Выбрать "Переместить" в меню мультиселекта', where='IVA ONE WEB Клиент')
        menu_item = LContactCard.L_I18N_MENU_ITEM('contact_card_menu_move', self.lang)
        self.get_object(menu_item).click()
        if not self.wait_presence(LContactCard.L_MOVE_MENU(), timeout=3, mode='return'):
            self.get_object(menu_item).click()  # submenu иногда раскрывается со второго клика
            self.wait_presence(LContactCard.L_MOVE_MENU(), timeout=5)
        log.step(f'Выбрать книгу "{book_name}" в picker перемещения', where='IVA ONE WEB Клиент')
        self.get_object(LContactCard.L_MOVE_MENU_BOOK_NODE(book_name)).click()

    def assert_move_divider_dialog(self):
        self.assert_presence(
            self.L_I18N_ACTION_DIVIDER('contacts_move_dialog_title', self.lang),
            'Открыт экран-разделитель "Перемещение"',
        )

    def assert_move_divider_unavailable_info(self):
        self.assert_presence(
            self.L_I18N_ACTION_DIVIDER_INFO('contacts_move_dialog_title', 'contacts_move_unavailable_text', self.lang),
            'В разделителе "Перемещение" есть текст о недоступности перемещения для части контактов',
        )

    def assert_contact_unavailable_in_move_divider(self, name: str):
        self.assert_presence(
            self.L_I18N_ACTION_DIVIDER_CONTACT_UNAVAILABLE('contacts_move_dialog_title', name, self.lang),
            f'Контакт "{name}" помечен недоступным для перемещения в разделителе',
        )

    def assert_contact_available_in_move_divider(self, name: str):
        self.assert_presence(
            self.L_I18N_ACTION_DIVIDER_CONTACT_AVAILABLE('contacts_move_dialog_title', name, self.lang),
            f'Контакт "{name}" доступен для перемещения в разделителе',
        )

    def confirm_move_available(self):
        log.step('Нажать "Переместить доступных" в разделителе', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_ACTION_DIVIDER_CONFIRM('contacts_move_dialog_title', 'contacts_move_confirm_button', self.lang)).click()

    def bulk_delete(self):
        """Mixed-удаление из мультиселекта: «Ещё» → «Удалить». Если в выборке есть
        недоступные (корп) — разделитель «Удалить контакты?» открывается сразу
        (без picker, в отличие от Move)."""
        log.step('Открыть "Ещё" в плашке мультиселекта', where='IVA ONE WEB Клиент')
        self.get_object(self.L_BULK_ACTION_MORE()).click()
        log.step('Выбрать "Удалить" в меню мультиселекта', where='IVA ONE WEB Клиент')
        self.get_object(LContactCard.L_I18N_MENU_ITEM('contact_card_menu_delete', self.lang)).click()

    def assert_delete_divider_dialog(self):
        self.assert_presence(
            self.L_I18N_ACTION_DIVIDER('contacts_delete_dialog_title', self.lang),
            'Открыт экран-разделитель "Удалить контакты?"',
        )

    def assert_delete_divider_unavailable_info(self):
        self.assert_presence(
            self.L_I18N_ACTION_DIVIDER_INFO('contacts_delete_dialog_title', 'contacts_delete_unavailable_text', self.lang),
            'В разделителе "Удалить контакты?" есть текст о недоступности удаления для части контактов',
        )

    def assert_contact_unavailable_in_delete_divider(self, name: str):
        self.assert_presence(
            self.L_I18N_ACTION_DIVIDER_CONTACT_UNAVAILABLE('contacts_delete_dialog_title', name, self.lang),
            f'Контакт "{name}" помечен недоступным для удаления в разделителе',
        )

    def assert_contact_available_in_delete_divider(self, name: str):
        self.assert_presence(
            self.L_I18N_ACTION_DIVIDER_CONTACT_AVAILABLE('contacts_delete_dialog_title', name, self.lang),
            f'Контакт "{name}" доступен для удаления в разделителе',
        )

    def confirm_delete_available(self):
        log.step('Нажать "Удалить доступных" в разделителе', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_ACTION_DIVIDER_CONFIRM('contacts_delete_dialog_title', 'contacts_delete_confirm_button', self.lang)).click()

    def assert_contact_absent_in_list(self, full_name: str):
        assert_fn(
            lambda: self.wait_absence(self.L_CONTACT_ROW_NAME(full_name)),
            f'Контакт "{full_name}" отсутствует в списке',
        )

    def click_user_row_name(self, user_data: dict):
        log.step(f'Открыть профиль пользователя "{user_data["username"]}" кликом по ФИ', where='IVA ONE WEB Клиент')
        # Safari падает на обычном клике по контейнеру ФИ — клик через JS.
        full_name = user_data["last_name"] + ' ' + user_data["first_name"]
        page_helpers.retry_on_rerender(
            lambda: page_helpers.click_via_js(self.driver, self.get_object(self.L_CONTACT_ROW_NAME(full_name))))
        return chunks.get_chunk(self.version, 'user_profile')(driver=self.driver, lang=self.lang)

    def assert_row_highlight_on_hover(self, user_data: dict):
        """Подсветка строки — чистый CSS :hover (классов нет): сравниваем computed
        background строки с var(--iva-color-bg-primary-hovered) через probe-нормализацию
        (сырой токен и computed bg различаются по alpha — как в assert_row_selected).
        Наводить на ФИ (hover над ds-checkbox гасит подсветку); фильтрация пересоздаёт
        ноды — отсюда ретрай."""
        full_name = f'{user_data["last_name"]} {user_data["first_name"]}'
        log.step(f'Навести курсор на ФИ пользователя "{full_name}"', where='IVA ONE WEB Клиент')
        if self.driver.name.lower() == 'safari':
            # safaridriver не применяет :hover от синтетического указателя — проверяем
            # только наличие :hover-правила в CSS.
            rule_exists = self.driver.execute_script(
                "return [...document.styleSheets].some(sh => {"
                "  try { return [...sh.cssRules].some(r => r.selectorText"
                "    && r.selectorText.includes('.table-row') && r.selectorText.includes(':hover')"
                "    && (r.style.background || r.style.backgroundColor)); }"
                "  catch (e) { return false; }"
                "});")
            assert_fn(lambda: rule_exists,
                      'CSS-правило подсветки строки при наведении задано (Safari: :hover из WebDriver недостижим)')
            return
        def _hover_applied():
            for _ in range(10):
                try:
                    ActionChains(self.driver).move_to_element(
                        self.get_object(self.L_CONTACT_ROW_NAME(full_name))).perform()
                    if page_helpers.element_bg_matches_token(
                            self.driver, self.get_object(self.L_ADDRESS_BOOK_ITEM(full_name)),
                            '--iva-color-bg-primary-hovered'):
                        return True
                except (NoSuchElementException, StaleElementReferenceException):
                    # NoSuchElement — вторая маска той же гонки: узел детачится между
                    # presence-wait и find_element внутри get_object.
                    log.debug('Нода строки пересоздана (re-render списка) — повтор hover по свежему элементу')
                time.sleep(0.5)
            return False

        assert_fn(_hover_applied, 'Строка пользователя подсвечена при наведении на ФИ')

    def assert_row_selected(self, user_data: dict):
        """Выбранная строка: класс _sidebar-active + фон var(--iva-color-bg-item-selected).
        Цвет валиден без hover на строке (hover перекрывает серым bg-primary-hovered);
        здесь курсор на строку не наводится — клик по ФИ идёт через JS. Строка может
        пересоздаваться (re-render списка при выборе) — отсюда ретрай по stale."""
        full_name = f'{user_data["last_name"]} {user_data["first_name"]}'
        self.assert_presence(self.L_ROW_SELECTED(full_name), f'Строка контакта "{full_name}" выделена в списке')

        def _selected_highlighted():
            for _ in range(10):
                try:
                    if page_helpers.element_bg_matches_token(
                            self.driver, self.get_object(self.L_ROW_SELECTED(full_name)),
                            '--iva-color-bg-item-selected'):
                        return True
                except StaleElementReferenceException:
                    log.debug('Нода выбранной строки пересоздана (re-render) — повтор замера')
                time.sleep(0.5)
            return False

        assert_fn(_selected_highlighted, 'Выбранная строка подсвечена цветом выделения (bg-item-selected)')

    def open_book_node(self, node_name: str):
        """Открыть узел дерева книг по видимому имени. Для серверных групп («Корпоративные»
        и т.п.) — имя приходит с бэка, не через i18n."""
        log.step(f'Открыть группу "{node_name}" в адресной книге', where='IVA ONE WEB Клиент')
        book_link = self.L_TREE_BOOK_NODE_LINK(node_name)
        page_helpers.wait_clickable_via_js(self.driver, lambda: self.get_object(book_link), timeout=5)
        page_helpers.click_via_js(self.driver, self.get_object(book_link))

    def assert_all_contacts_selected(self):
        text = i18n.get_str('contact_tree_all_contacts', self.lang)
        self.assert_presence(self.L_TREE_NODE_SELECTED(text),
                             'Группа "Все контакты" выбрана по умолчанию (выделена в дереве)')

    def assert_book_selected(self, book_name: str):
        self.assert_presence(self.L_TREE_NODE_SELECTED(book_name), f'Книга "{book_name}" выделена в дереве')

    def assert_contacts_count_max(self, limit: int):
        rows = self.get_object(self.L_ADDRESS_BOOK_ITEMS(), multiple=True)
        log.info(f'Строк контактов в списке: {len(rows)}')
        assert_fn(lambda: 0 < len(rows) <= limit, f'Список контактов загружен, записей не более {limit}')

    def assert_contacts_sorted_by_name(self):
        names = [el.text.strip() for el in self.get_object(self.L_ROW_NAMES(), multiple=True)]
        log.info(f'Имена контактов в списке: {names}')

        def sort_key(name):
            lowered = name.lower()
            is_cyrillic = bool(lowered) and (lowered[0] == 'ё' or 'а' <= lowered[0] <= 'я')
            # Кириллица в списке идёт перед латиницей (порядок стенда).
            return (0 if is_cyrillic else 1, lowered)

        assert_fn(lambda: names == sorted(names, key=sort_key), 'Список контактов отсортирован по ФИО')

    def assert_alphabet_divider(self, letter: str):
        self.assert_presence(self.L_ALPHABET_ROW(letter), f'Отображается буквенный разделитель "{letter}"')

    def _contacts_rows_count(self) -> int:
        return len(self.get_object(self.L_ADDRESS_BOOK_ITEMS(), multiple=True, multiple_no_wait=True))

    def assert_contacts_count(self, n: int, timeout: float = 15):
        """Строк ровно n (страница пагинации загружена целиком). Поллинг: строки рендерятся после XHR."""
        end = time.time() + timeout
        count = self._contacts_rows_count()
        while count != n and time.time() < end:
            time.sleep(0.5)
            count = self._contacts_rows_count()
        log.info(f'Строк контактов в списке: {count}')
        assert_fn(lambda: count == n, f'Список контактов загружен, строк ровно {n}')

    def scroll_contacts_until_count_above(self, n: int, retries: int = 4, page_timeout: float = 15):
        """Прокрутить список вниз и дождаться догрузки строк (>n). Скролл повторяется:
        одиночный прыжок к низу может разминуться с IntersectionObserver-триггером
        догрузки (лайаут дорисовывается после загрузки страницы, низ списка уезжает)."""
        log.step('Прокрутить список контактов вниз', where='IVA ONE WEB Клиент')
        count = self._contacts_rows_count()
        for _ in range(retries):
            page_helpers.scroll_element_to_bottom_via_js(
                self.driver, self.get_object(self.L_CONTACTS_SCROLL_CONTAINER()))
            end = time.time() + page_timeout
            while count <= n and time.time() < end:
                time.sleep(0.5)
                count = self._contacts_rows_count()
            if count > n:
                break
        log.info(f'Строк контактов после докрутки: {count}')
        assert_fn(lambda: count > n, f'Догрузка произошла: строк в списке больше {n}')

    def assert_load_trigger_active(self):
        # iva-билд: <iva-spinner> в msg-load-trigger рендерится только во время активной
        # подгрузки (isLoading, триггер в зоне видимости); после загрузки страницы
        # canLoadMore=true, но спиннера нет (транзиентный). Значимый инвариант
        # «есть следующая страница» — триггер активен (без класса hidden).
        self.assert_presence(self.L_LOAD_TRIGGER_ACTIVE(),
                             'Триггер догрузки активен (без класса hidden) — есть следующая страница')

    def scroll_contacts_until_all_loaded(self, max_pages: int = 5, page_timeout: float = 15):
        """Скроллить вниз, пока догрузка не остановится (триггер получил класс hidden).
        max_pages — потолок страниц по 100: защита от параллельных прогонов, досеивающих юзеров."""
        log.step('Доскроллить список контактов до конца (догрузка всех страниц)', where='IVA ONE WEB Клиент')
        for _ in range(max_pages):
            if self._load_trigger_hidden():
                return
            before = self._contacts_rows_count()
            page_helpers.scroll_element_to_bottom_via_js(
                self.driver, self.get_object(self.L_CONTACTS_SCROLL_CONTAINER()))
            end = time.time() + page_timeout
            while time.time() < end:
                if self._load_trigger_hidden() or self._contacts_rows_count() > before:
                    break
                time.sleep(0.5)

    def _load_trigger_hidden(self) -> bool:
        # .hidden = display:none → wait_presence (visibility на Chromium/FF) неприменим;
        # проверяем присутствие узла в DOM напрямую.
        return bool(self.get_object(self.L_LOAD_TRIGGER_HIDDEN(), multiple=True, multiple_no_wait=True))

    def assert_load_trigger_hidden(self, timeout: float = 15):
        def _hidden():
            end = time.time() + timeout
            while time.time() < end:
                if self._load_trigger_hidden():
                    return True
                time.sleep(0.5)
            return False
        assert_fn(_hidden, 'Догрузка остановилась: триггер списка скрыт (canLoadMore=false)')
        assert_fn(lambda: self.wait_absence(self.L_LOAD_TRIGGER_SPINNER(), timeout=5),
                  'Лоудер (iva-spinner) в триггере догрузки исчез')

    def open_chat_from_row(self, user_data: dict):
        full_name = f'{user_data["last_name"]} {user_data["first_name"]}'
        log.step(f'Открыть меню действий (кебаб) у контакта "{full_name}"', where='IVA ONE WEB Клиент')
        # Кебаб — реальный <button> (cdk-menu-trigger): JS-клик CDK-меню НЕ открывает
        # (проверено 2026-07-02), обычный клик открывает. Старый JS-обход относился
        # к убранной прямой кнопке чата.
        # Перерисовка строки (после поиска/догрузки) детачит cdk-триггер — клик уходит
        # в отвязанный узел и меню не открывается либо схлопывается сразу после появления.
        # Ретраим связку «клик по кебабу → клик по пункту» целиком.
        log.step('Выбрать пункт "Написать" в меню действий контакта', where='IVA ONE WEB Клиент')
        for _ in range(3):
            try:
                self.get_object(self.L_ROW_CHAT_BTN(full_name)).click()
                if not self.wait_presence(self.L_ROW_MENU_WRITE_ITEM(), 5, mode='return'):
                    continue  # меню не открылось — клик пришёлся в перерисовку
                self.get_object(self.L_ROW_MENU_WRITE_ITEM()).click()
                break
            except NoSuchElementException:
                continue  # узел (кебаб/пункт меню) детачился между wait и find — заход заново
        else:
            raise NoSuchElementException(f'Меню действий контакта "{full_name}" не открылось за 3 попытки')
        chat = pages.get_page(self.version, 'chat')(driver=self.driver, lang=self.lang, open_page=False)
        chat.wait_presence(chat.L_CHAT_INPUT(), 15)
        return chat

    def assert_multiselect_closed(self):
        assert_fn(
            lambda: self.wait_absence(self.L_BULK_BAR()),
            'Режим мультиселекта закрыт (плашка выбора исчезла)',
        )

    def assert_contact_checkbox_selected(self, name: str):
        assert_fn(
            lambda: self.get_object(self.L_ROW_CHECKBOX_INPUT(name)).is_selected(),
            f'Чекбокс контакта "{name}" отмечен (выбор сохранён)',
        )

    def assert_contact_checkbox_not_selected(self, name: str):
        assert_fn(
            lambda: not self.get_object(self.L_ROW_CHECKBOX_INPUT(name)).is_selected(),
            f'Чекбокс контакта "{name}" снят (выбор сброшен)',
        )

    def remove_chip(self, name: str):
        """Убрать контакт из выборки крестиком его чипа. Крестик (iva-icon-circle-x-fill)
        виден только по hover на чип, поэтому наводим курсор и ждём кликабельности.
        Safari не применяет :hover из WebDriver — там кликаем крестик через JS."""
        log.step(f'Удалить контакт "{name}" из выбранных крестиком чипа', where='IVA ONE WEB Клиент')
        if self.driver.name.lower() == 'safari':
            page_helpers.click_via_js(self.driver, self.get_object(self.L_CHIP_REMOVE_BTN(name)))
            return
        ActionChains(self.driver).move_to_element(self.get_object(self.L_CHIP(name))).perform()
        page_helpers.wait_clickable_via_js(self.driver, lambda: self.get_object(self.L_CHIP_REMOVE_BTN(name)), timeout=5)
        self.get_object(self.L_CHIP_REMOVE_BTN(name)).click()

    def assert_contact_chip_absent(self, name: str):
        assert_fn(
            lambda: self.wait_absence(self.L_CHIP(name)),
            f'Чип контакта "{name}" убран из плашки мультиселекта',
        )

    def click_bulk_call(self):
        log.step('Нажать "Позвонить" в плашке мультиселекта', where='IVA ONE WEB Клиент')
        self.get_object(self.L_BULK_ACTION_CALL()).click()

    def assert_call_divider_dialog(self):
        self.assert_presence(
            self.L_I18N_ACTION_DIVIDER('address_book_call_unavailability_screen_title', self.lang),
            'Открыт экран-разделитель "Начать звонок"',
        )

    def assert_call_divider_unavailable_info(self):
        self.assert_presence(
            self.L_I18N_ACTION_DIVIDER_INFO('address_book_call_unavailability_screen_title', 'address_book_call_unavailability_screen_text_invariant', self.lang),
            'В разделителе "Начать звонок" есть текст о недоступности звонка для части контактов',
        )

    def assert_contact_unavailable_in_call_divider(self, name: str):
        self.assert_presence(
            self.L_I18N_ACTION_DIVIDER_CONTACT_UNAVAILABLE('address_book_call_unavailability_screen_title', name, self.lang),
            f'Контакт "{name}" помечен недоступным для звонка в разделителе',
        )

    def assert_contact_available_in_call_divider(self, name: str):
        self.assert_presence(
            self.L_I18N_ACTION_DIVIDER_CONTACT_AVAILABLE('address_book_call_unavailability_screen_title', name, self.lang),
            f'Контакт "{name}" доступен для звонка в разделителе',
        )

    def confirm_call_available(self):
        log.step('Нажать "Позвонить доступным" в разделителе', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_ACTION_DIVIDER_CONFIRM('address_book_call_unavailability_screen_title', 'address_book_call_unavailability_screen_action_button', self.lang)).click()

    def assert_call_divider_closed(self):
        assert_fn(
            lambda: self.wait_absence(self.L_I18N_ACTION_DIVIDER('address_book_call_unavailability_screen_title', self.lang)),
            'Экран-разделитель "Начать звонок" исчез',
        )

    # --- Книги (папки): контекстное меню узла дерева + редактирование ---

    def open_create_book_dialog(self):
        """Открыть диалог создания книги кнопкой-узлом «Новая книга» в дереве групп.
        Узел — дочерний к «Личные»; у юзера без книг «Личные» свёрнут, поэтому при
        необходимости раскрываем её перед кликом (см. ниже)."""
        log.step('Нажать "Новая книга"', where='IVA ONE WEB Клиент')
        # Узел «Новая книга» — дочерний к «Личные» в дереве групп. У юзера без книг «Личные»
        # свёрнут → узел рендерится display:none (Selenium не считает его visible). Раскрываем
        # «Личные» кликом по её узлу (отдельного chevron у пустой «Личные» нет), если узел
        # создания ещё не виден. Дерево групп грузится async — ждём корень «Личные» сначала.
        self.wait_presence(self.L_I18N_TREE_PERSONAL_ROOT(self.lang), 15)
        if not self.wait_presence(self.L_TREE_CREATE_BOOK_BTN(), 3, mode='return'):
            page_helpers.click_via_js(self.driver, self.get_object(self.L_I18N_TREE_PERSONAL_ROOT_LINK(self.lang)))
        self.wait_presence(self.L_TREE_CREATE_BOOK_BTN(), 10)
        # Узел дерева: на Safari плоский .click() даёт ElementNotInteractable → JS-клик
        # (как для прочих узлов дерева, см. open_personal_book).
        page_helpers.click_via_js(self.driver, self.get_object(self.L_TREE_CREATE_BOOK_BTN()))
        self.wait_presence(self.L_EDIT_BOOK_DIALOG(), 5)

    def assert_create_book_dialog_open(self):
        self.assert_presence(self.L_I18N_CREATE_BOOK_DIALOG_TITLE(self.lang), 'Открыт диалог "Создать книгу"')

    def confirm_create_book(self):
        log.step('Нажать "Создать" в диалоге создания книги', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_CREATE_BOOK_BTN(self.lang)).click()

    def open_create_contact_form(self):
        """Открыть форму создания контакта кнопкой «+» («Создать контакт») в шапке раздела.
        Возвращает chunk формы (его __init__ дожидается появления формы-сайдбара)."""
        log.step('Нажать "Создать контакт"', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_CREATE_CONTACT_BTN(self.lang)).click()
        return chunks.get_chunk(self.version, 'contact_form')(driver=self.driver, lang=self.lang)

    def open_book_context_menu(self, book_name: str):
        """Вызвать контекстное меню узла книги правым кликом. Меню (CDK-overlay role=menu)
        открывается ТОЛЬКО событием contextmenu по ссылке узла личной книги."""
        log.step(f'Вызвать контекстное меню книги "{book_name}" правым кликом', where='IVA ONE WEB Клиент')
        self.click_right(self.L_TREE_BOOK_NODE_LINK(book_name))
        self.wait_presence(self.L_TREE_CONTEXT_MENU(), 5)

    def assert_book_context_menu_items(self):
        self.assert_presence(self.L_I18N_TREE_CTX_EDIT_BOOK(self.lang),
                             'В контекстном меню книги есть пункт "Редактировать книгу"')
        self.assert_presence(self.L_I18N_TREE_CTX_DELETE_BOOK(self.lang),
                             'В контекстном меню книги есть пункт "Удалить"')

    def open_edit_book_dialog(self):
        log.step('Выбрать "Редактировать книгу" в контекстном меню', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_TREE_CTX_EDIT_BOOK(self.lang)).click()
        self.wait_presence(self.L_EDIT_BOOK_DIALOG(), 5)

    def assert_edit_book_dialog_open(self):
        self.assert_presence(self.L_I18N_EDIT_BOOK_DIALOG_TITLE(self.lang), 'Открыт диалог "Редактировать книгу"')

    def set_book_name(self, name: str):
        log.step(f'Ввести название книги "{name}"', where='IVA ONE WEB Клиент')
        name_input = self.get_object(self.L_EDIT_BOOK_NAME_INPUT())
        name_input.clear()
        name_input.send_keys(name)

    def select_book_icon_crown(self):
        log.step('Выбрать иконку "Корона"', where='IVA ONE WEB Клиент')
        self.get_object(self.L_EDIT_BOOK_ICON_BUTTON(enums.AddressBookGroupIcon.CROWN)).click()

    def assert_book_icon_crown_selected(self):
        self.assert_presence(self.L_EDIT_BOOK_ICON_BUTTON_SELECTED(enums.AddressBookGroupIcon.CROWN),
                             'Иконка "Корона" отмечена выбранной в пикере')

    def save_book_edit(self):
        log.step('Нажать "Сохранить" в диалоге редактирования книги', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_EDIT_BOOK_SAVE_BTN(self.lang)).click()

    def assert_book_renamed(self, book_name: str):
        self.assert_presence(self.L_TREE_BOOK_NODE(book_name),
                             f'Книга "{book_name}" отображается в дереве с новым именем')

    def assert_book_icon(self, book_name: str, icon: enums.AddressBookGroupIcon = enums.AddressBookGroupIcon.CROWN):
        self.assert_presence(self.L_TREE_BOOK_NODE_ICON(book_name, icon),
                             f'У книги "{book_name}" в дереве иконка "{icon}"')

    def assert_book_name_truncated(self):
        """Поле имени книги обрезало ввод до своего maxlength (символы сверх лимита не вводятся)."""
        el = self.get_object(self.L_EDIT_BOOK_NAME_INPUT())
        max_len = int(el.get_attribute('maxlength'))
        # get_attribute('value') на Safari/FF возвращает None (W3C-драйверы отдают HTML-атрибут,
        # а не live-property) — читаем value как в login.py: get_attribute, иначе через JS.
        value = el.get_attribute('value') or self.driver.execute_script('return arguments[0].value;', el) or ''
        log.info(f'Длина значения поля имени: {len(value)}, maxlength={max_len}')
        assert_fn(lambda: len(value) == max_len,
                  f'Поле имени книги обрезало ввод до лимита ({max_len} символов)')

    def assert_book_edit_dialog_closed(self):
        assert_fn(lambda: self.wait_absence(self.L_EDIT_BOOK_DIALOG()),
                  'Диалог редактирования книги закрылся (сохранение прошло)')

    def open_delete_book_dialog(self):
        log.step('Выбрать "Удалить" в контекстном меню книги', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_TREE_CTX_DELETE_BOOK(self.lang)).click()
        self.wait_presence(self.L_I18N_DELETE_BOOK_DIALOG(self.lang), 5)

    def assert_delete_book_dialog(self):
        self.assert_presence(self.L_I18N_DELETE_BOOK_DIALOG(self.lang),
                             'Открыто окно подтверждения "Удалить адресную книгу?"')

    def confirm_delete_book(self):
        log.step('Нажать "Удалить" в окне подтверждения', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_DELETE_BOOK_CONFIRM_BTN(self.lang)).click()

    def assert_book_absent(self, book_name: str):
        assert_fn(lambda: self.wait_absence(self.L_TREE_BOOK_NODE(book_name)),
                  f'Книга "{book_name}" удалена из дерева')

    def assert_personal_root_selected(self):
        text = i18n.get_str('contact_tree_personal_root', self.lang)
        self.assert_presence(self.L_TREE_NODE_SELECTED(text), 'Группа "Личные" выбрана в дереве')

    def cancel_delete_book(self):
        log.step('Нажать "Отмена" в окне подтверждения удаления книги', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_DELETE_BOOK_CANCEL_BTN(self.lang)).click()

    def assert_delete_book_dialog_closed(self):
        assert_fn(lambda: self.wait_absence(self.L_I18N_DELETE_BOOK_DIALOG(self.lang)),
                  'Окно подтверждения удаления книги закрылось')

    def assert_book_present(self, book_name: str):
        self.assert_presence(self.L_TREE_BOOK_NODE(book_name),
                             f'Книга "{book_name}" осталась в дереве (не удалена)')

    def assert_delete_book_cascade_warning(self, book_name: str):
        self.assert_presence(self.L_DELETE_BOOK_DIALOG_BODY(book_name, self.lang),
                             f'Поп-ап предупреждает об удалении книги "{book_name}" и её контактов')

    def assert_book_cascade_deleted(self, token: str, book_id: str):
        """Каскад: после удаления книги её контакты тоже удалены — запрос контактов удалённой
        книги отвечает 404 (книга и контакты удалены на бэке). REST-проверка ground-truth."""
        def _gone():
            try:
                iva_one.get_contacts(token, group_id=book_id)
                return False
            except requests.HTTPError as e:
                return e.response.status_code == 404
        assert_fn(_gone, 'Книга и её контакты удалены на бэке (запрос контактов книги — 404)')


class CVersion2AddressBook(_CAddressBook, Version2Locators.LAddressBook):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.version = 'Version2'
