from typing import TYPE_CHECKING

from autocore.base.web.base_page import PBase
from autocore.test.logger import get_log
from autocore.test.assertions import assert_fn
from autocore.clients.rest.enums import ChatTypes

from tools import i18n
from tools.helpers.page_helpers import wait_api_idle
from tests.pages.locators.Version2.chunks import chats_list as Version2Locators

if TYPE_CHECKING:
    from tests.pages.locators.Version2.chunks.chats_list import (
        LChatsList as _LocatorsTypingBase,
    )
else:
    class _LocatorsTypingBase:
        pass

log = get_log()


class _CChatsList(PBase, _LocatorsTypingBase):
    """Chunk левой панели списка чатов (`<chat-chats-header>` / `<chat-chats-list>` /
    `<chat-chat-list-item>`): открытие чата кликом, поиск, меню создания, контекст-меню
    чата (pin/delete), бейджи unread/mention.

    Verify «комната открыта» намеренно НЕ здесь — это домен chat-room (топбар комнаты);
    тесты дополняют open_* проверкой `chat.assert_chat_with_chat_name_opened`. Инстанс
    создаётся после `left_menu.open_chats()` (раздел чатов уже открыт), поэтому
    `check_primary_element` (по умолчанию) ждёт шапку списка как барьер; `open_page=False`
    — раздел открыт кликом, URL не грузим.
    """

    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_I18N_HEADER(self.lang)
        self.page_path = ''
        kwargs['open_page'] = False
        super().__init__(*args, **kwargs)

    def open_chat(self, chat_name: str):
        log.step(f'Открыть чат "{chat_name}"', where='IVA ONE WEB Клиент')
        self.get_object(self.L_CHAT_ITEM_NAME(chat_name)).click()

    def click_create_chat_btn(self):
        log.step('Нажать кнопку "+" для создания чата', where='IVA ONE WEB Клиент')
        self.get_object(self.L_CREATE_CHAT_BTN()).click()
        self.wait_presence(self.L_CREATE_CHAT_TYPE_MENU())

    def select_chat_type(self, chat_type: ChatTypes):
        if chat_type == ChatTypes.GROUP:
            type_name = i18n.get_str('create_chat_menu_group_title', self.lang)
            locator = self.L_I18N_CREATE_CHAT_MENU_GROUP_BTN(self.lang)
        elif chat_type == ChatTypes.CHANNEL:
            type_name = i18n.get_str('create_chat_menu_channel_title', self.lang)
            locator = self.L_I18N_CREATE_CHAT_MENU_CHANNEL_BTN(self.lang)
        else:
            raise ValueError(f'Unsupported chat type for create wizard: {chat_type}')
        log.step(f'Выбрать тип чата "{type_name}" в меню создания', where='IVA ONE WEB Клиент')
        self.get_object(locator).click()
        self.wait_absence(self.L_CREATE_CHAT_TYPE_MENU())

    def search_chat(self, channel_name: str):
        log.step(f'Найти чат или канал "{channel_name}" в списке чатов', where='IVA ONE WEB Клиент')
        self.get_object(self.L_CHATS_LIST_SEARCH_BTN()).click()
        search_input_locator = self.L_I18N_CHATS_LIST_SEARCH_INPUT(self.lang)
        search_input = self.get_object(search_input_locator)
        search_input.click()
        self.clear_input(search_input_locator)
        search_input.send_keys(channel_name)
        self.wait_presence(self.L_CHAT_SEARCH_RESULT_CHANNEL(channel_name), 5)

    def assert_chat_search_result_visible(self, channel_name: str):
        self.assert_presence(self.L_CHAT_SEARCH_RESULT_CHANNEL(channel_name),
                             f'Публичный канал "{channel_name}" найден в результатах поиска')

    def open_chat_from_search(self, channel_name: str):
        log.step(f'Открыть найденный публичный канал "{channel_name}"', where='IVA ONE WEB Клиент')
        self.assert_chat_search_result_visible(channel_name)
        self.get_object(self.L_CHAT_SEARCH_RESULT_CHANNEL(channel_name)).click()

    def open_found_user_dialog(self, full_name: str):
        # Результат поиска по человеку без чата — тот же узел, что у чата/канала
        # (L_CHAT_SEARCH_RESULT_CHANNEL); открывает пустой p2p-диалог.
        log.step(f'Открыть диалог с пользователем "{full_name}" из результатов поиска',
                 where='IVA ONE WEB Клиент')
        self.get_object(self.L_CHAT_SEARCH_RESULT_CHANNEL(full_name)).click()

    def open_chat_context_menu(self, chat_name: str):
        log.step(f'Открыть контекстное меню чата "{chat_name}" (ПКМ по чату в списке)',
                 where='IVA ONE WEB Клиент')
        self.click_right(self.L_CHAT_LIST_ITEM(chat_name))
        self.wait_presence(self.L_CHAT_LIST_CONTEXT_MENU())

    def click_pin_in_chat_context_menu(self):
        pin_btn_name = i18n.get_str('chats_context_menu_item_pin', self.lang)
        log.step(f'Нажать кнопку "{pin_btn_name}" в контекстном меню чата', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_CHAT_LIST_PIN_BTN(self.lang)).click()
        self.wait_absence(self.L_CHAT_LIST_CONTEXT_MENU())

    def assert_chat_pinned(self, chat_name: str):
        # Закрепление асинхронно (~1.5-2s: REST changeChatPinnedState + ре-рендер списка);
        # assert_presence ждёт до 15s — этого достаточно.
        self.assert_presence(self.L_CHAT_ITEM_PINNED_ICON(chat_name),
                             f'Чат "{chat_name}" закреплён')

    def click_delete_in_chat_context_menu(self):
        delete_btn_name = i18n.get_str('chats_context_menu_item_delete', self.lang)
        log.step(f'Нажать кнопку "{delete_btn_name}" в контекстном меню чата', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_CHAT_LIST_DELETE_BTN(self.lang)).click()
        self.wait_absence(self.L_CHAT_LIST_CONTEXT_MENU())
        self.wait_presence(self.L_I18N_CHAT_DELETE_CONFIRM_DIALOG(self.lang))

    def confirm_delete_chat(self):
        log.step('Подтвердить удаление чата в диалоге', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_CHAT_DELETE_CONFIRM_BTN(self.lang)).click()
        self.wait_absence(self.L_I18N_CHAT_DELETE_CONFIRM_DIALOG(self.lang))
        # Удаление чата из списка идёт после delete-REST (асинхронно, иногда >5s) —
        # дождаться тишины по /api/v1, чтобы последующая проверка списка не гонилась.
        wait_api_idle(self.driver)

    def assert_chat_not_in_list(self, chat_name: str):
        assert_fn(lambda: self.wait_absence(self.L_CHAT_ITEM_NAME(chat_name)),
                  f'Чат "{chat_name}" отсутствует в списке чатов')

    def assert_mention_badge_visible(self, chat_name: str):
        self.assert_presence(self.L_CHAT_ITEM_MENTION_BADGE(chat_name),
                             f'Счётчик упоминания отображается для чата "{chat_name}"')

    def assert_unread_badge_visible(self, chat_name: str):
        self.assert_presence(self.L_CHAT_ITEM_UNREAD_BADGE(chat_name),
                             f'Иконка о новом сообщении отображается для чата "{chat_name}"')

    def assert_unread_badge_absent(self, chat_name: str):
        # Снятие бейджа приходит асинхронно (read-ack бэка) — окно шире дефолтных 5s.
        assert_fn(lambda: self.wait_absence(self.L_CHAT_ITEM_UNREAD_BADGE(chat_name), 15),
                  f'Иконка о новом сообщении отсутствует для чата "{chat_name}"')


class CVersion2ChatsList(_CChatsList, Version2Locators.LChatsList):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.version = 'Version2'
