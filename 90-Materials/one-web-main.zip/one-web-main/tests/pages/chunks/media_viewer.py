from typing import TYPE_CHECKING

from autocore.base.web.base_page import PBase
from autocore.test.logger import get_log
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys

from tests.pages.locators.Version2.chunks import media_viewer as Version2Locators

if TYPE_CHECKING:
    from tests.pages.locators.Version2.chunks.media_viewer import (
        LMediaViewer as _LocatorsTypingBase,
    )
else:
    class _LocatorsTypingBase:
        pass

log = get_log()


class _CMediaViewer(PBase, _LocatorsTypingBase):
    """Chunk для fullscreen media viewer (`<lib-media-viewer>` в `<cdk-dialog-container>`).

    Открывается кликом на медиа в галерее (`chat_attachments`) или в сообщении.
    Корень общий для image и video, distinguishing — `L_IMAGE_CONTENT_SLIDE` /
    `L_VIDEO_CONTENT_SLIDE` внутри.
    """

    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_ROOT()
        self.page_path = ''
        kwargs['open_page'] = False
        super().__init__(*args, **kwargs)

    def assert_image_viewer_open(self):
        self.assert_presence(self.L_IMAGE_CONTENT_SLIDE(),
                             'Открыт fullscreen viewer с изображением')

    def assert_video_viewer_open(self):
        self.assert_presence(self.L_VIDEO_CONTENT_SLIDE(),
                             'Открыт fullscreen viewer с видео')

    def close_via_esc(self):
        log.step('Нажать клавишу Esc для выхода из fullscreen-просмотра', where='IVA ONE WEB Клиент')
        ActionChains(self.driver).send_keys(Keys.ESCAPE).perform()
        self.wait_absence(self.L_ROOT())

    def assert_closed(self):
        self.wait_absence(self.L_ROOT())


class CVersion2MediaViewer(_CMediaViewer, Version2Locators.LMediaViewer):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.version = 'Version2'
