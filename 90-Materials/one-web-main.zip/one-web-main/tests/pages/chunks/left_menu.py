from typing import TYPE_CHECKING

from autocore.base.web.base_page import PBase
from tests.pages.locators.Version2.chunks import left_menu as Version2Locators
from autocore.test.logger import get_log
from tests import pages
from tests.pages import chunks

if TYPE_CHECKING:
    from tests.pages.locators.Version2.chunks.left_menu import (
        LLeftMenu as _LocatorsTypingBase,
    )
else:
    class _LocatorsTypingBase:
        pass

log = get_log()


class _CLeftMenu(PBase, _LocatorsTypingBase):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_ROOT()
        self.page_path = ''
        kwargs['open_page'] = False
        super().__init__(*args, **kwargs)

    def open_profile(self):
        log.step('Открыть профиль авторизованного пользователя', where='IVA ONE WEB Клиент')
        self.get_object(self.L_USER_PROFILE_BTN()).click()
        _ = pages.get_page(self.version, 'profile_popup')(self.driver, lang=self.lang, open_page=False)

    def open_chats(self):
        log.step('Открыть "Чаты"', where='IVA ONE WEB Клиент')
        self.get_object(self.L_CHATS()).click()
        # Раздел "Чаты" открывает список чатов (chats_list chunk), а не комнату (chat page).
        # Инстанс служит барьером: ждёт шапку списка (primary_element) после клика.
        _ = chunks.get_chunk(self.version, 'chats_list')(self.driver, lang=self.lang)

    def open_address_book(self):
        log.step('Открыть "Адресную книгу"', where='IVA ONE WEB Клиент')
        self.get_object(self.L_ADDRESS_BOOK()).click()
        _ = chunks.get_chunk(self.version, 'address_book')(self.driver, lang=self.lang, check_primary_element=False)

    def open_calendar(self):
        log.step('Открыть "Календарь"', where='IVA ONE WEB Клиент')
        self.get_object(self.L_CALENDAR()).click()
        _ = chunks.get_chunk(self.version, 'calendar')(self.driver, lang=self.lang)

    def assert_section_active(self, href_part: str, message: str):
        self.assert_presence(self.L_NAV_ACTIVE(href_part), message)

    def assert_img_avatar_exist(self):
        self.assert_presence(self.L_USER_DS_AVATAR_IMG(), 'В левом меню отображается аватар-изображение')


class CVersion2LeftMenu(_CLeftMenu, Version2Locators.LLeftMenu):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.version = 'Version2'
