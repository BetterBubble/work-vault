import re
from typing import TYPE_CHECKING

from autocore.base.web.base_page import PBase
from autocore.test.logger import get_log

from tools.helpers.page_helpers import wait_clickable_via_js
from tests.pages.locators.Version2.chunks import offline_event as Version2Locators

if TYPE_CHECKING:
    from tests.pages.locators.Version2.chunks.offline_event import (
        LOfflineEvent as _LocatorsTypingBase,
    )
else:
    class _LocatorsTypingBase:
        pass

log = get_log()


class _COfflineEvent(PBase, _LocatorsTypingBase):
    """Sidebar оффлайн-события: форма создания `(sidebar:event/create/jump)` и карточка
    созданного события `(sidebar:event/jump/{uid})`.

    Открывается из карточки контакта («Ещё» → «Событие»). Требует доступа к imail —
    форма грузит данные через imail-сессию; у пользователя без почты зависает. Создание
    идёт через imail (jump-протокол, метод `calObjPublish`); удаление — `calObjCancel`.
    """

    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_FORM_ROOT()
        self.page_path = ''
        kwargs['open_page'] = False
        kwargs['check_primary_element'] = False
        super().__init__(*args, **kwargs)

    def assert_form_loaded(self):
        # Поле темы появляется только когда форма догрузила данные из imail. У юзера без
        # почты форма зависает на спиннере — этот ассерт тогда красный (нет доступа к imail).
        # Под параллельной нагрузкой (-n 4) imail отдаёт форму дольше дефолтных 15s
        # ассерта — дожидаемся до 60s, ассерт затем фиксирует итог.
        self.wait_presence(self.L_I18N_THEME_INPUT(self.lang), timeout=60, mode='return')
        self.assert_presence(
            self.L_I18N_THEME_INPUT(self.lang),
            'Форма события загрузилась (поле темы доступно)',
        )

    def fill_theme(self, theme: str):
        log.step(f'Ввести тему события "{theme}"', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_THEME_INPUT(self.lang)).send_keys(theme)

    def create_event(self):
        log.step('Нажать "Создать событие"', where='IVA ONE WEB Клиент')
        wait_clickable_via_js(self.driver, lambda: self.get_object(self.L_I18N_CREATE_BTN(self.lang)))
        self.get_object(self.L_I18N_CREATE_BTN(self.lang)).click()

    def assert_event_created(self):
        self.assert_presence(
            self.L_PARTICIPANTS_LIST(),
            'Открыта карточка созданного события (список участников отображается)',
        )

    def get_event_uid(self):
        """Числовой uid события из URL карточки `(sidebar:event/jump/{uid})`."""
        self.wait_presence(self.L_PARTICIPANTS_LIST(), timeout=10)
        match = re.search(r'event/jump/(\d+)', self.driver.current_url)
        return int(match.group(1)) if match else None

    def assert_participant_by_name(self, full_name: str):
        self.assert_presence(
            self.L_PARTICIPANT_BY_TEXT(full_name),
            f'Участник "{full_name}" отображается в участниках события',
        )

    def assert_create_participant_by_name(self, full_name: str):
        # Участник, предзаполненный в ФОРМЕ создания (calendar-event-create-edit-participants-list).
        self.assert_presence(
            self.L_CREATE_PARTICIPANT_BY_TEXT(full_name),
            f'Участник "{full_name}" предзаполнен в форме создания события',
        )

    def assert_participant_by_email(self, email: str):
        self.assert_presence(
            self.L_PARTICIPANT_BY_TEXT(email),
            f'Контакт ({email}) отображается в участниках события',
        )

    def assert_participant_avatar(self, full_name: str):
        self.assert_presence(
            self.L_PARTICIPANT_AVATAR_BY_TEXT(full_name),
            f'У участника "{full_name}" загружен аватар контакта',
        )

    def click_edit_btn(self):
        log.step('Открыть меню "Ещё" → "Изменить" (редактировать событие)', where='IVA ONE WEB Клиент')
        self.get_object(self.L_VIEW_MORE_MENU_BTN()).click()
        self.wait_presence(self.L_I18N_VIEW_EDIT_MENU_ITEM(self.lang))
        self.get_object(self.L_I18N_VIEW_EDIT_MENU_ITEM(self.lang)).click()

    def assert_participant_with_position(self, full_name: str, position: str):
        self.assert_presence(
            self.L_PARTICIPANT_POSITION_BY_TEXT(full_name, position),
            f'Участник "{full_name}" отображается в карточке с должностью "{position}"',
        )

    # --- Карточка Событие глазами приглашённого: ответ на приглашение (TC-52479) ---
    # Зеркало методов приглашения LMcuConferenceSidebar (TC-1427) под Событие-корни.
    def assert_invitation_actions_available(self):
        self.assert_presence(
            self.L_INVITATION_RESPONSE_BLOCK(),
            'В карточке доступно приглашение с вариантами ответа Принять/Возможно/Отклонить',
        )
        self.assert_presence(
            self.L_I18N_INVITATION_ACCEPT_BTN(self.lang),
            'Доступна кнопка ответа "Принять"',
        )
        self.assert_presence(
            self.L_I18N_INVITATION_MAYBE_BTN(self.lang),
            'Доступна кнопка ответа "Возможно"',
        )
        self.assert_presence(
            self.L_I18N_INVITATION_DECLINE_BTN(self.lang),
            'Доступна кнопка ответа "Отклонить"',
        )

    def assert_invitation_response_visible(self, full_name: str):
        self.assert_presence(
            self.L_PARTICIPANT_STATUS_CIRCLE(full_name),
            f'Отображается ответ участника "{full_name}" на приглашение',
        )

    def open_view_fullscreen(self):
        log.step('Открыть полноэкранный просмотр события', where='IVA ONE WEB Клиент')
        self.get_object(self.L_VIEW_MAXIMIZE_BTN()).click()
        self.wait_presence(self.L_FULLSCREEN_ROOT())

    def assert_fullscreen_invitation_actions_available(self):
        self.assert_presence(
            self.L_FULLSCREEN_INVITATION_RESPONSE_BLOCK(),
            'В полноэкранном просмотре доступно приглашение с возможностью ответа',
        )
        self.assert_presence(
            self.L_I18N_FULLSCREEN_INVITATION_ACCEPT_BTN(self.lang),
            'В полноэкранном просмотре доступна кнопка ответа "Принять"',
        )

    def assert_attachments_section_visible(self):
        self.assert_presence(
            self.L_I18N_FULLSCREEN_ATTACHMENTS_SECTION(self.lang),
            'В полноэкранном просмотре доступна секция "Вложения"',
        )
        self.assert_presence(
            self.L_I18N_FULLSCREEN_ATTACHMENTS_LABEL(self.lang),
            'В полноэкранном просмотре отображается заголовок секции "Вложения"',
        )

    def accept_invitation_fullscreen(self):
        log.step('Выбрать пункт "Принять"', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_FULLSCREEN_INVITATION_ACCEPT_BTN(self.lang)).click()

    def assert_invitation_accepted_mark(self, full_name: str):
        self.assert_presence(
            self.L_PARTICIPANT_ACCEPTED_MARK(full_name),
            f'Рядом с ФИ "{full_name}" отображается зелёная галочка принятого приглашения',
        )

    def start_imail_session_capture(self):
        """Перехватить id imail-сессии. Приложение авторизует jump-запросы заголовком
        `X-Session-State-Id` (не куки/storage — добавляется HTTP-интерсептором). Снифер
        XHR ловит его в `window.__imailSid`, чтобы `cancel_event_via_jump` мог удалить
        событие тем же запросом, что делает UI. Вызывать ДО загрузки формы события."""
        self.driver.execute_script(
            """
            if (window.__imailCap) return;
            window.__imailCap = true;
            window.__imailSid = null;
            const orig = XMLHttpRequest.prototype.setRequestHeader;
            XMLHttpRequest.prototype.setRequestHeader = function(k, v) {
                if (k === 'X-Session-State-Id') window.__imailSid = v;
                return orig.apply(this, arguments);
            };
            """
        )

    def cancel_event_via_jump(self, uid):
        """Удалить событие через imail jump-протокол (`calObjCancel`) — non-UI очистка
        артефакта. Шлёт тот же запрос, что UI: POST imail/session с заголовком
        `X-Session-State-Id` (из `start_imail_session_capture`) и куками сессии."""
        if uid is None:
            return None
        log.step(f'Удалить событие (uid={uid}) через imail (calObjCancel)', where='IVA ONE WEB Клиент')
        return self.driver.execute_async_script(
            """
            const uid = arguments[0];
            const done = arguments[arguments.length - 1];
            const sid = window.__imailSid;
            const imail = location.origin.replace('-one.', '-imail.');
            fetch(imail + '/session', {
                method: 'POST', credentials: 'include',
                headers: {'Content-Type': 'application/json', 'X-Session-State-Id': sid},
                body: JSON.stringify([{method: 'calObjCancel',
                                       payload: {view: 'Календарь-view', uid: uid},
                                       id: 'calObjCancel'}])
            }).then(r => done(r.status)).catch(e => done('error: ' + e));
            """,
            int(uid),
        )


class CVersion2OfflineEvent(_COfflineEvent, Version2Locators.LOfflineEvent):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.version = 'Version2'
