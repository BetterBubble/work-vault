import os
from typing import TYPE_CHECKING

from tests.pages.profile_popup import PVersion2ProfilePopup
from tests.pages.locators.Version2.chunks import profile_popup_account as Version2Locators
from tests.pages import chunks
from autocore.test.logger import get_log
from autocore.test.assertions import assert_fn
from autocore.consts import TEST_DATA_DIR
from tools import i18n, enums
from tools.helpers.page_helpers import upload_avatar_via_lazy_picker, wait_api_idle

if TYPE_CHECKING:
    from tests.pages.locators.Version2.chunks.profile_popup_account import (
        LProfilePopupAccount as _LocatorsTypingBase,
    )
else:
    class _LocatorsTypingBase:
        pass

log = get_log()


class _CProfilePopupAccount(PVersion2ProfilePopup, _LocatorsTypingBase):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_ROOT()
        self.page_path = ''
        kwargs['open_page'] = False
        super().__init__(*args, **kwargs)

    def assert_correct_account(self, user_data: dict):
        expected_name = f'{user_data["first_name"]} {user_data["last_name"]}'
        display_name = " ".join(self.get_object(self.L_I18N_USER_INFO(self.lang)).text.split())
        assert_fn(lambda: expected_name in display_name,
                  f'Открыт правильный аккаунт пользователя. Ожидается: "{expected_name}". Отображается "{display_name}"')

    def logout(self):
        logout_button_text = i18n.get_str('profile_popup_account_logout_button', self.lang)
        log.step(f'Нажать кнопку "{logout_button_text}"')
        self.get_object(self.L_I18N_BTN_LOGOUT(self.lang)).click()

    def upload_avatar(self, file_name):
        log.step(f'Загрузить аватар "{file_name}"', where='IVA ONE WEB Клиент')
        local_path = os.path.join(TEST_DATA_DIR, file_name)
        # Дождаться окна тишины по /api/v1 — без этого upload иногда стартует поверх
        # фоновых запросов (инициализация чатов), и бэк теряет ассоциацию user→avatar.
        wait_api_idle(self.driver, idle_window_ms=500, timeout=5)
        upload_avatar_via_lazy_picker(self.driver, self.get_object(self.L_AVATAR_EDIT_HOST()), local_path)

    def assert_avatar_uploaded(self):
        self.assert_presence(self.L_AVATAR_IMAGE(), 'Аватар загружен')

    def assert_save_cancel_btns_exists(self):
        assert_fn(lambda: self.get_object(self.L_I18N_SAVE_BTN(self.lang)) and self.get_object(self.L_I18N_CANCEL_BTN(self.lang)),
                  'Кнопки Сохранить и Отмена появились')

    def click_edit_action_btn(self, action: enums.ProfilePopupEditActions):
        actions = {
                enums.ProfilePopupEditActions.SAVE: {
                        'locator': self.L_I18N_SAVE_BTN(self.lang),
                        'name': i18n.get_str('profile_popup_account_save_btn', self.lang)
                    },
                enums.ProfilePopupEditActions.CANCEL: {
                        'locator': self.L_I18N_CANCEL_BTN(self.lang),
                        'name': i18n.get_str('profile_popup_account_cancel_btn', self.lang)
                    }
            }
        log.step(f'Нажать кнопку "{actions[action].get('name')}"', where='IVA ONE WEB Клиент')
        self.get_object(actions[action].get('locator')).click()
        if not self.wait_absence(self.L_FOOTER()):
            assert_fn(lambda: False, f'Кнопки "Сохранить" и "Отмена" исчезли после нажатия кнопки "{actions[action].get('name')}"')

    def assert_changes_saved_toast_exist(self):
        self.toast.assert_i18n_visible(
            'profile_popup_changes_saved_toast',
            'Отображается тост-уведомление "Изменения сохранены"',
        )

    def assert_avatar_success_uploaded_toast_exist(self):
        self.toast.assert_i18n_visible(
            'profile_popup_avatar_success_uploaded_toast',
            'Отображается тост-уведомление "Изображение загружено успешно, обновление появится после проверки безопасности"',
        )

    def assert_avatar_was_saved(self, toasts_check=True, close_popup=False):
        if toasts_check:
            self.assert_changes_saved_toast_exist()
            self.assert_avatar_success_uploaded_toast_exist()
        self.assert_avatar_uploaded()
        self.assert_img_avatar_exist()
        if close_popup:
            self.close_popup()


class CVersion2ProfilePopupAccount(_CProfilePopupAccount, Version2Locators.LProfilePopupAccount):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.version = 'Version2'
        self.toast = chunks.get_chunk(self.version, 'toast')(driver=self.driver, lang=self.lang)

