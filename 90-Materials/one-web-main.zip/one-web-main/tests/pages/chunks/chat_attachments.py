import time
from typing import TYPE_CHECKING

from autocore.base.web.base_page import PBase
from autocore.test.assertions import assert_fn
from autocore.test.logger import get_log
from selenium.common.exceptions import TimeoutException

from tests.pages.locators.Version2.chunks import chat_attachments as Version2Locators
from tools import i18n

if TYPE_CHECKING:
    from tests.pages.locators.Version2.chunks.chat_attachments import (
        LChatAttachments as _LocatorsTypingBase,
    )
else:
    class _LocatorsTypingBase:
        pass

log = get_log()


class _CChatAttachments(PBase, _LocatorsTypingBase):
    """Chunk для gallery-view sidebar'а `(sidebar:chat/<id>/attachments/<category>)`.

    Получается через `get_chunk(version, 'chat_attachments')(driver=..., lang=...)`.
    Открывается из карточки чата по клику на категорию галереи
    (см. `_CChatProfileBase.click_gallery_category`).
    """

    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_ROOT()
        self.page_path = ''
        kwargs['open_page'] = False
        super().__init__(*args, **kwargs)

    def assert_video_visible(self, filename: str, message: str = None):
        msg = message or f'Видео "{filename}" отображается в списке галереи'
        self.assert_presence(self.L_VIDEO_ITEM_BY_NAME(filename), msg)

    def assert_image_visible(self, filename: str, message: str = None):
        msg = message or f'Изображение "{filename}" отображается в списке галереи'
        self.assert_presence(self.L_IMAGE_ITEM_BY_NAME(filename), msg)

    def assert_audio_visible(self, filename: str, message: str = None):
        msg = message or f'Аудиофайл "{filename}" отображается в списке галереи'
        self.assert_presence(self.L_AUDIO_ITEM_BY_NAME(filename), msg)

    def click_image(self, filename: str):
        log.step(f'Нажать на изображение "{filename}" в галерее', where='IVA ONE WEB Клиент')
        self.wait_presence(self.L_IMAGE_ITEM_BY_NAME(filename))
        self.get_object(self.L_IMAGE_ITEM_BY_NAME(filename)).click()

    def click_video(self, filename: str):
        log.step(f'Нажать на видео "{filename}" в галерее', where='IVA ONE WEB Клиент')
        self.wait_presence(self.L_VIDEO_ITEM_BY_NAME(filename))
        self.get_object(self.L_VIDEO_ITEM_BY_NAME(filename)).click()

    def right_click_video(self, filename: str):
        # Selenoid + custom-overlay меню: на Safari/Firefox/Edge первый right-click
        # иногда не открывает popup — retry до 3 раз с проверкой L_CONTEXT_MENU.
        if self.driver.name in ['Safari', 'firefox', 'MicrosoftEdge']:
            time.sleep(3)
        log.step(f'Открыть контекстное меню видео "{filename}" по ПКМ', where='IVA ONE WEB Клиент')
        self.wait_presence(self.L_VIDEO_ITEM_BY_NAME(filename))
        for attempt in range(3):
            self.click_right(self.L_VIDEO_ITEM_BY_NAME(filename), 5)
            try:
                self.wait_presence(self.L_CONTEXT_MENU(), 5)
                return
            except TimeoutException:
                if attempt == 2:
                    raise
                log.warning(
                    f'Контекстное меню видео не открылось, повторяем right-click (попытка {attempt + 2}/3)'
                )

    def click_context_menu_download(self):
        log.step('Нажать "Скачать" в контекстном меню видео', where='IVA ONE WEB Клиент')
        self.get_object(self.L_CONTEXT_MENU_DOWNLOAD_BTN()).click()
        # Safari при скачивании через blob URL показывает native alert
        # «сайт пытается скачать несколько файлов — разрешить?» — accept'им.
        if self.driver.name == 'Safari':
            time.sleep(1)
            try:
                self.driver.switch_to.alert.accept()
            except Exception:
                pass
        self.wait_absence(self.L_CONTEXT_MENU())

    def click_context_menu_go_to_message(self):
        log.step('Нажать "Перейти к сообщению" в контекстном меню видео', where='IVA ONE WEB Клиент')
        self.get_object(self.L_CONTEXT_MENU_GO_TO_MESSAGE_BTN()).click()
        self.wait_absence(self.L_CONTEXT_MENU())

    def assert_gallery_open(self):
        self.assert_presence(self.L_ROOT(), 'Отображается сайдбар галереи')

    def switch_to_tab(self, i18n_key: str):
        """Переключить вкладку галереи (Изображения/Видео/Аудио) кликом по <iva-tab>.
        i18n_key — ключ лейбла: 'media_header_pictures' | 'media_header_video' | 'media_header_audio'."""
        tab_name = i18n.get_str(i18n_key, self.lang)
        log.step(f'Переключиться на вкладку галереи "{tab_name}"', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_GALLERY_TAB(i18n_key, self.lang)).click()

    def assert_download_initiated(self, timeout: float = 5.0):
        """Verify, что после клика "Скачать" IVA инициировало XHR на /api/v1/uploads/{id}/download.
        IVA скачивает медиа через `fetch → blob → URL.createObjectURL + a[download].click()`,
        поэтому browser не сохраняет файл в стандартный download-folder selenoid'а
        и `selenoid:/download/{sessionId}/{file}` не работает. Зато XHR виден в performance API."""
        def _has_download_xhr() -> bool:
            return bool(self.driver.execute_script(
                "return (window.performance.getEntries() || [])"
                ".some(e => e.name.indexOf('/api/v1/uploads/') !== -1"
                " && e.name.indexOf('/download') !== -1"
                " && (e.initiatorType === 'xmlhttprequest' || e.initiatorType === 'fetch'));"
            ))
        end_time = time.time() + timeout
        while time.time() < end_time:
            if _has_download_xhr():
                break
            time.sleep(0.2)
        assert_fn(_has_download_xhr,
                  'IVA отправило XHR на /api/v1/uploads/{id}/download — загрузка началась')


class CVersion2ChatAttachments(_CChatAttachments, Version2Locators.LChatAttachments):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.version = 'Version2'
