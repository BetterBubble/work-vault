from typing import TYPE_CHECKING

from autocore.base.web.base_page import PBase
from autocore.test.logger import get_log

from tools import i18n
from tools.helpers.page_helpers import wait_clickable_via_js
from tests.pages.locators.Version2.chunks import mcu_conference_sidebar as Version2Locators

if TYPE_CHECKING:
    from tests.pages.locators.Version2.chunks.mcu_conference_sidebar import (
        LMcuConferenceSidebar as _LocatorsTypingBase,
    )
else:
    class _LocatorsTypingBase:
        pass

log = get_log()


class _CMcuConferenceSidebar(PBase, _LocatorsTypingBase):
    """Sidebar ВКС-конференции: компактная форма создания (`(sidebar:event/create/mcu)`)
    и карточка созданной встречи (`(sidebar:event/mcu/{id})`).

    Открывается из карточки контакта («Ещё» → «ВКС-встреча»). Форма — планировщик
    (тема + предзаполненные дата/время), по сабмиту («Сохранить» — sidebar-текст даже
    при создании) уходит POST conferences и UI переходит на карточку созданной встречи
    со списком участников (вкладка «Участники N»). Редиректа в живую комнату ВКС нет —
    это запланированная встреча.
    """

    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_CREATE_FORM_ROOT()
        self.page_path = ''
        kwargs['open_page'] = False
        kwargs['check_primary_element'] = False
        super().__init__(*args, **kwargs)

    def fill_theme(self, theme: str):
        log.step(f'Ввести тему встречи "{theme}"', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_THEME_INPUT(self.lang)).send_keys(theme)

    def create_conference(self):
        # 2.1.0: сабмит sidebar-формы — «Сохранить» (даже при создании встречи).
        text = i18n.get_str('calendar_conference_edit_save_btn', self.lang)
        log.step(f'Нажать "{text}"', where='IVA ONE WEB Клиент')
        # Кнопка disabled пока тема пустая — дожидаемся реальной кликабельности.
        wait_clickable_via_js(self.driver, lambda: self.get_object(self.L_I18N_CREATE_BTN(self.lang)))
        self.get_object(self.L_I18N_CREATE_BTN(self.lang)).click()

    def assert_conference_created(self, theme: str):
        self.assert_presence(
            self.L_DETAILS_TITLE(theme),
            f'Открыта карточка созданной ВКС-встречи "{theme}"',
        )

    def assert_guest_link_available(self):
        self.assert_presence(
            self.L_GUEST_LINK(),
            'Для организатора доступна гостевая ссылка',
        )

    def assert_extra_links_available(self):
        self.assert_presence(
            self.L_I18N_EXTRA_LINKS_BTN(self.lang),
            'Доступно меню дополнительных ссылок',
        )

    def assert_participants_count(self, count: int):
        self.assert_presence(
            self.L_I18N_PARTICIPANTS_COUNT(count, self.lang),
            f'Во вкладке участников встречи счётчик "{count}"',
        )

    def assert_participant_by_name(self, full_name: str):
        self.assert_presence(
            self.L_PARTICIPANT_BY_NAME(full_name),
            f'Участник "{full_name}" отображается в списке участников встречи',
        )

    def assert_participant_avatar(self, full_name: str):
        self.assert_presence(
            self.L_PARTICIPANT_AVATAR_BY_NAME(full_name),
            f'У участника "{full_name}" загружен аватар контакта',
        )

    def click_edit_btn(self):
        log.step('Открыть меню "Ещё" → "Изменить" (редактировать встречу)', where='IVA ONE WEB Клиент')
        self.get_object(self.L_VIEW_MORE_MENU_BTN()).click()
        self.wait_presence(self.L_I18N_MORE_MENU_EDIT_ITEM(self.lang))
        self.get_object(self.L_I18N_MORE_MENU_EDIT_ITEM(self.lang)).click()

    def assert_participant_with_position(self, full_name: str, position: str):
        self.assert_presence(
            self.L_PARTICIPANT_POSITION_BY_NAME(full_name, position),
            f'Участник "{full_name}" отображается в карточке с должностью "{position}"',
        )

    # --- Карточка глазами приглашённого: ответ на приглашение ---
    def assert_invitation_actions_available(self):
        self.assert_presence(
            self.L_INVITATION_RESPONSE_BLOCK(),
            'В карточке доступно приглашение с вариантами ответа Принять/Возможно/Отклонить',
        )
        self.assert_presence(
            self.L_I18N_INVITATION_ACCEPT_BTN(self.lang),
            'Доступна кнопка ответа "Принять"',
        )
        self.assert_presence(
            self.L_I18N_INVITATION_MAYBE_BTN(self.lang),
            'Доступна кнопка ответа "Возможно"',
        )
        self.assert_presence(
            self.L_I18N_INVITATION_DECLINE_BTN(self.lang),
            'Доступна кнопка ответа "Отклонить"',
        )

    def assert_invitation_response_visible(self, full_name: str):
        self.assert_presence(
            self.L_PARTICIPANT_STATUS_CIRCLE(full_name),
            f'Отображается ответ участника "{full_name}" на приглашение',
        )

    def open_view_fullscreen(self):
        log.step('Открыть полноэкранный просмотр встречи', where='IVA ONE WEB Клиент')
        self.get_object(self.L_VIEW_MAXIMIZE_BTN()).click()
        self.wait_presence(self.L_FULLSCREEN_ROOT())

    def assert_fullscreen_invitation_actions_available(self):
        self.assert_presence(
            self.L_FULLSCREEN_INVITATION_RESPONSE_BLOCK(),
            'В полноэкранном просмотре доступно приглашение с возможностью ответа',
        )
        self.assert_presence(
            self.L_I18N_FULLSCREEN_INVITATION_ACCEPT_BTN(self.lang),
            'В полноэкранном просмотре доступна кнопка ответа "Принять"',
        )

    def assert_attachments_section_visible(self):
        self.assert_presence(
            self.L_FULLSCREEN_ATTACHMENTS_SECTION(),
            'В полноэкранном просмотре доступна секция "Вложения"',
        )
        self.assert_presence(
            self.L_I18N_FULLSCREEN_ATTACHMENTS_LABEL(self.lang),
            'В полноэкранном просмотре отображается заголовок секции "Вложения"',
        )

    def assert_fullscreen_participant_with_position(self, full_name: str, position: str):
        self.assert_presence(
            self.L_FULLSCREEN_PARTICIPANT_POSITION_BY_NAME(full_name, position),
            f'Участник "{full_name}" в полноэкранном просмотре с должностью "{position}"',
        )

    def accept_invitation_fullscreen(self):
        log.step('Выбрать пункт "Принять"', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_FULLSCREEN_INVITATION_ACCEPT_BTN(self.lang)).click()

    def assert_fullscreen_invitation_accepted_mark(self, full_name: str):
        self.assert_presence(
            self.L_FULLSCREEN_PARTICIPANT_ACCEPTED_MARK(full_name),
            f'Рядом с ФИ "{full_name}" отображается зелёная галочка принятого приглашения',
        )


class CVersion2McuConferenceSidebar(_CMcuConferenceSidebar, Version2Locators.LMcuConferenceSidebar):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.version = 'Version2'
