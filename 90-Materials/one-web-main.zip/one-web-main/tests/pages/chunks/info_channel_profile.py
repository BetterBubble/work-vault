from typing import TYPE_CHECKING

from tests.pages.locators.Version2.chunks import info_channel_profile as Version2Locators
from autocore.test.logger import get_log
from tests.pages import chunks
from tests.pages.chunks.chat_profile_base import _CChatProfileBase

if TYPE_CHECKING:
    from tests.pages.locators.Version2.chunks.info_channel_profile import (
        LInfoChannelProfile as _LocatorsTypingBase,
    )
else:
    class _LocatorsTypingBase:
        pass

log = get_log()


class _CInfoChannelProfile(_CChatProfileBase, _LocatorsTypingBase):
    pass


class CVersion2InfoChannelProfile(_CInfoChannelProfile, Version2Locators.LInfoChannelProfile):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.version = 'Version2'
        self.toast = chunks.get_chunk(self.version, 'toast')(driver=self.driver, lang=self.lang)
