from typing import TYPE_CHECKING

from tests.pages.profile_popup import PVersion2ProfilePopup
from tests.pages.locators.Version2.chunks import profile_popup_sessions as Version2Locators
from autocore.test.logger import get_log
from autocore.test.assertions import assert_fn

if TYPE_CHECKING:
    from tests.pages.locators.Version2.chunks.profile_popup_sessions import (
        LProfilePopupSessions as _LocatorsTypingBase,
    )
else:
    class _LocatorsTypingBase:
        pass

log = get_log()


class _CProfilePopupSessions(PVersion2ProfilePopup, _LocatorsTypingBase):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_ROOT()
        self.page_path = ''
        kwargs['open_page'] = False
        super().__init__(*args, **kwargs)

    def assert_current_session_present(self):
        self.assert_presence(self.L_I18N_CURRENT_SESSION_HEADER(self.lang),
                             'Отображается раздел "Текущий сеанс" со списком активных сессий')

    def terminate_current_session(self):
        log.step('Нажать "Завершить" в разделе "Текущий сеанс"', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_CURRENT_SESSION_TERMINATE_BTN(self.lang)).click()
        log.step('Подтвердить завершение в диалоге "Завершить выбранный сеанс?"', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_TERMINATE_SESSION_DIALOG_CONFIRM_BTN(self.lang)).click()

    def assert_other_sessions_present(self):
        self.assert_presence(self.L_I18N_OTHER_SESSIONS_HEADER(self.lang),
                             'Отображается раздел "Другие сеансы" (есть вторая активная сессия)')

    def click_terminate_other_sessions(self):
        log.step('Нажать "Завершить другие сеансы"', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_TERMINATE_OTHER_SESSIONS_BTN(self.lang)).click()

    def assert_terminate_other_sessions_dialog_shown(self):
        self.assert_presence(self.L_I18N_TERMINATE_OTHER_SESSIONS_DIALOG(self.lang),
                             'Отображается окно подтверждения завершения других сеансов')

    def confirm_terminate_other_sessions(self):
        log.step('Подтвердить завершение в диалоге "Завершить другие сеансы?"', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_TERMINATE_OTHER_SESSIONS_DIALOG_CONFIRM_BTN(self.lang)).click()

    def assert_other_sessions_terminated(self):
        # Наблюдаемый сигнал на текущем драйвере: компонент чистит otherSessions →
        # раздел "Другие сеансы" исчезает (footer-кнопка тоже). wait_absence возвращает
        # bool (не кидает) — оборачиваем в assert_fn, иначе неисчезновение = ложный зелёный.
        assert_fn(lambda: self.wait_absence(self.L_I18N_OTHER_SESSIONS_HEADER(self.lang)),
                  'Раздел "Другие сеансы" отсутствует — другие сеансы завершены')


class CVersion2ProfilePopupSessions(_CProfilePopupSessions, Version2Locators.LProfilePopupSessions):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.version = 'Version2'
