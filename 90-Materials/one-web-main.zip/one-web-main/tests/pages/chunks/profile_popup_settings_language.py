from typing import TYPE_CHECKING

from tests.pages.profile_popup import PVersion2ProfilePopup
from tests.pages.locators.Version2.chunks import profile_popup_settings_language as Version2Locators
from autocore import consts
from autocore.test.logger import get_log
from tools import i18n
from tools.enums import ProfileLanguage

if TYPE_CHECKING:
    from tests.pages.locators.Version2.chunks.profile_popup_settings_language import (
        LProfilePopupSettingsLanguage as _LocatorsTypingBase,
    )
else:
    class _LocatorsTypingBase:
        pass

log = get_log()


class _CProfilePopupSettingsLanguage(PVersion2ProfilePopup, _LocatorsTypingBase):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_ROOT()
        self.page_path = ''
        kwargs['open_page'] = False
        super().__init__(*args, **kwargs)

    def assert_current_language(self, language_key: ProfileLanguage):
        language_name = i18n.get_str(language_key.value, self.lang)
        self.assert_presence(self.L_I18N_LANGUAGE_SELECT_VALUE(language_key.value, self.lang),
                             f'Текущий язык интерфейса — {language_name}')

    def open_language_dropdown(self):
        log.step('Открыть выпадающий список выбора языка', where='IVA ONE WEB Клиент')
        self.get_object(self.L_LANGUAGE_SELECT()).click()

    def select_language(self, language: ProfileLanguage):
        # Текст опции языко-независим («Русский»/«English» одинаковы в RU и EN),
        # поэтому локатор работает и когда UI уже переключён на английский.
        language_name = i18n.get_str(language.value, self.lang)
        log.step(f'Выбрать язык "{language_name}"', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_LANGUAGE_OPTION(language.value, self.lang)).click()

    def assert_ui_language_english(self):
        # После смены языка self.lang остаётся RU — ассерт факта перевода ведём по EN-тексту
        # заголовка секции («Язык» → «Language»).
        self.assert_presence(self.L_I18N_LANGUAGE_SECTION_TITLE(consts.LANG_EN),
                             'Заголовок секции отображается на английском — "Language"')


class CVersion2ProfilePopupSettingsLanguage(_CProfilePopupSettingsLanguage, Version2Locators.LProfilePopupSettingsLanguage):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.version = 'Version2'
