from typing import TYPE_CHECKING

from tests.pages.profile_popup import PVersion2ProfilePopup
from tests.pages.locators.Version2.chunks import profile_popup_settings_equipment as Version2Locators
from autocore.test.logger import get_log
from tools import i18n
from tools.enums import ProfileEquipmentSection

if TYPE_CHECKING:
    from tests.pages.locators.Version2.chunks.profile_popup_settings_equipment import (
        LProfilePopupSettingsEquipment as _LocatorsTypingBase,
    )
else:
    class _LocatorsTypingBase:
        pass

log = get_log()


class _CProfilePopupSettingsEquipment(PVersion2ProfilePopup, _LocatorsTypingBase):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_ROOT()
        self.page_path = ''
        kwargs['open_page'] = False
        super().__init__(*args, **kwargs)

    def assert_section_device_radio(self, section: ProfileEquipmentSection):
        section_name = i18n.get_str(section.value, self.lang)
        self.assert_presence(self.L_I18N_SECTION_DEVICE_RADIO(section.value, self.lang),
                             f'В разделе «{section_name}» отображается radiobutton устройства')

    def assert_microphone_sensitivity_slider(self):
        self.assert_presence(
            self.L_I18N_SECTION_SLIDER_LABEL(
                ProfileEquipmentSection.MICROPHONE.value, 'profile_media_settings_sensitivity_label', self.lang),
            'В разделе «Микрофон» отображается ползунок чувствительности')

    def assert_speakers_volume_slider(self):
        self.assert_presence(
            self.L_I18N_SECTION_SLIDER_LABEL(
                ProfileEquipmentSection.SPEAKERS.value, 'profile_media_settings_volume_label', self.lang),
            'В разделе «Динамики» отображается ползунок громкости')


class CVersion2ProfilePopupSettingsEquipment(_CProfilePopupSettingsEquipment,
                                             Version2Locators.LProfilePopupSettingsEquipment):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.version = 'Version2'
