from typing import TYPE_CHECKING

from tests.pages.profile_popup import PVersion2ProfilePopup
from tests.pages.locators.Version2.chunks import profile_popup_about as Version2Locators
from tests.pages import chunks
from autocore.test.logger import get_log
from tools import i18n

if TYPE_CHECKING:
    from tests.pages.locators.Version2.chunks.profile_popup_about import (
        LProfilePopupAbout as _LocatorsTypingBase,
    )
else:
    class _LocatorsTypingBase:
        pass

log = get_log()


class _CProfilePopupAbout(PVersion2ProfilePopup, _LocatorsTypingBase):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_ROOT()
        self.page_path = ''
        kwargs['open_page'] = False
        super().__init__(*args, **kwargs)

    def assert_about_info_visible(self):
        self.assert_presence(self.L_PRODUCT_VERSION(), 'В разделе "О приложении" отображается версия приложения')
        self.assert_presence(self.L_I18N_BUILD_VERSION_BTN(self.lang),
                             'В разделе "О приложении" отображается версия сборки')

    def click_build_version_times(self, times):
        build_label = i18n.get_str('profile_about_label_build', self.lang)
        log.step(f'Нажать "{build_label}" {times} раз', where='IVA ONE WEB Клиент')
        build_version_btn = self.get_object(self.L_I18N_BUILD_VERSION_BTN(self.lang))
        for _ in range(times):
            build_version_btn.click()

    def click_build_version(self, times=10):
        self.click_build_version_times(times)

    def assert_develop_enable_hint_visible(self):
        hint_key = 'profile_support_develop_enable_hint_after_6_clicks'
        hint_text = i18n.get_str(hint_key, self.lang)
        self.toast.assert_i18n_visible(hint_key, f'Отображается hint-тост "{hint_text}"')

    def assert_develop_disable_hint_visible(self):
        hint_key = 'profile_support_develop_disable_hint_after_6_clicks'
        hint_text = i18n.get_str(hint_key, self.lang)
        self.toast.assert_i18n_visible(hint_key, f'Отображается hint-тост "{hint_text}"')

    def assert_develop_enabled_toast_visible(self):
        toast_key = 'profile_support_develop_enabled_toast'
        toast_text = i18n.get_str(toast_key, self.lang)
        self.toast.assert_i18n_visible(toast_key, f'Отображается тост "{toast_text}"')

    def assert_develop_disabled_toast_visible(self):
        toast_key = 'profile_support_develop_disabled_toast'
        toast_text = i18n.get_str(toast_key, self.lang)
        self.toast.assert_i18n_visible(toast_key, f'Отображается тост "{toast_text}"')

    def enable_develop_mode(self):
        self.click_build_version_times(10)
        self.assert_develop_enabled_toast_visible()


class CVersion2ProfilePopupAbout(_CProfilePopupAbout, Version2Locators.LProfilePopupAbout):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.version = 'Version2'
        self.toast = chunks.get_chunk(self.version, 'toast')(driver=self.driver, lang=self.lang)
