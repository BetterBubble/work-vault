from typing import TYPE_CHECKING

from autocore.base.web.base_page import PBase
from autocore.test.assertions import assert_fn
from autocore.test.logger import get_log
from tests.pages.locators.Version2.chunks import chat_pinned_messages_room as Version2Locators

if TYPE_CHECKING:
    from tests.pages.locators.Version2.chunks.chat_pinned_messages_room import (
        LChatPinnedMessagesRoom as _LocatorsTypingBase,
    )
else:
    class _LocatorsTypingBase:
        pass

log = get_log()


class _CChatPinnedMessagesRoom(PBase, _LocatorsTypingBase):
    """Chunk экрана со списком закреплённых сообщений чата (URL `/chat/<id>/pin`).

    Получается через
    `get_chunk(setup_aut['ver'], 'chat_pinned_messages_room')(driver=..., lang=...)`
    уже после клика по кнопке открытия списка — конструктор сам ждёт `<chat-pinned-room>`.
    """

    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_ROOT()
        self.page_path = ''
        kwargs['open_page'] = False
        super().__init__(*args, **kwargs)

    def assert_message_visible(self, text: str):
        self.assert_presence(self.L_MESSAGE_WITH_TEXT(text),
                             f'Закреплённое сообщение "{text}" присутствует в списке')

    def assert_input_absent(self):
        assert_fn(lambda: self.wait_absence(self.L_INPUT_EDITOR()),
                  'На экране списка закреплённых сообщений отсутствует поле ввода')


class CVersion2ChatPinnedMessagesRoom(_CChatPinnedMessagesRoom, Version2Locators.LChatPinnedMessagesRoom):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.version = 'Version2'
