from typing import TYPE_CHECKING

from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import TimeoutException

from autocore.base.web.base_page import PBase
from autocore.test.logger import get_log
from autocore.test.assertions import assert_fn
from tests.pages.locators.Version2.chunks import contact_form as Version2Locators
from tools.helpers import page_helpers

if TYPE_CHECKING:
    from tests.pages.locators.Version2.chunks.contact_form import (
        LContactForm as _LocatorsTypingBase,
    )
else:
    class _LocatorsTypingBase:
        pass

log = get_log()


class _CContactForm(PBase, _LocatorsTypingBase):
    """Форма создания/редактирования личного контакта (sidebar `(sidebar:contact/create|.../edit)`).

    Открывается из адресной книги («+ Создать контакт» в шапке или «Редактировать» в меню
    карточки). Поля — `iva-form-field` + native `input[formcontrolname]`; «Основной» телефон/
    почта — отдельные поля (`primaryPhone`/`primaryEmail`), дополнительные — FormArray
    `additionalPhones`/`additionalEmails`. Один компонент для create и edit (различие — текст
    кнопки сохранения и предзаполнение).
    """

    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_ROOT()
        self.page_path = ''
        kwargs['open_page'] = False
        super().__init__(*args, **kwargs)

    def _set_field(self, control_name: str, value: str):
        # field.clear()+send_keys, НЕ PBase.clear_input: его клавиатурный clear (Ctrl/Cmd+A →
        # Delete) на этих iva-form-field reactive-инпутах интермиттентно рассинхронит Angular
        # FormControl (input.value в DOM стоит, но форма остаётся invalid → submit disabled,
        # флак подтверждён на lin). Нативный clear() держит Angular в синхроне.
        field = self.get_object(self.L_FIELD(control_name))
        field.clear()
        field.send_keys(value)

    def set_first_name(self, value: str):
        log.step(f'Ввести имя "{value}"', where='IVA ONE WEB Клиент')
        self._set_field('firstName', value)

    def set_primary_phone(self, value: str):
        log.step(f'Ввести основной телефон "{value}"', where='IVA ONE WEB Клиент')
        self._set_field('primaryPhone', value)

    def set_primary_email(self, value: str):
        log.step(f'Ввести основной email "{value}"', where='IVA ONE WEB Клиент')
        self._set_field('primaryEmail', value)

    def add_additional_phone(self, value: str):
        log.step(f'Добавить дополнительный телефон "{value}"', where='IVA ONE WEB Клиент')
        # Поле доп. телефона создаётся кликом «Добавить телефон» (FormArray пуст по умолчанию).
        # Считаем уже добавленные → заполняем следующее по индексу (метод переиспользуем для
        # нескольких добавлений, см. TC-47001 лимит).
        existing = len(self.get_object(self.L_ADDITIONAL_PHONE_ALL(), multiple=True, multiple_no_wait=True))
        self.get_object(self.L_I18N_ADD_PHONE_BTN(self.lang)).click()
        new_index = existing + 1
        self.wait_presence(self.L_ADDITIONAL_PHONE(new_index), 5)
        field = self.get_object(self.L_ADDITIONAL_PHONE(new_index))
        field.send_keys(value)
        # Form-level ошибка «доп. без основного» отрисовывается по touched/dirty — снимаем
        # фокус (blur), чтобы валидация отобразилась (разведка: ошибка появляется после blur).
        field.send_keys(Keys.TAB)

    def _wait_field_value(self, locator, value, timeout=10):
        # Поллит значение инпута до совпадения с value (или таймаут → False). Читаем именно
        # DOM-property `value` (get_property), а НЕ атрибут: Angular ставит значение как
        # property, и get_attribute('value') на geckodriver/firefox возвращает None (атрибута
        # нет), тогда как Chrome конфлейтит property+attribute. get_property — кросс-браузерно.
        try:
            WebDriverWait(self.driver, timeout).until(
                lambda _: (self.get_object(locator).get_property('value') or '') == value)
            return True
        except TimeoutException:
            return False

    def assert_primary_phone_prefilled(self, value: str):
        # В режиме edit основной телефон/почта предзаполняются сервером АСИНХРОННО (после
        # GET /contacts/{id}); Имя/Фамилия — НЕТ (сервер их не эхоит, только displayName).
        # Поллим значение телефона: это и проверка «форма edit открыта с данными контакта»,
        # и гейт против гонки — ввод Имени до оседания гидрации patchForm мог бы быть затёрт
        # ответом GET.
        assert_fn(lambda: self._wait_field_value(self.L_FIELD('primaryPhone'), value),
                  f'В форме редактирования предзаполнен основной телефон "{value}"')

    def assert_book_preselected(self, book_name: str):
        self.assert_presence(self.L_GROUP_SELECT_VALUE(book_name),
                             f'В поле «Адресная книга» предвыбрана книга "{book_name}"')

    def assert_primary_phone_required_error(self):
        self.assert_presence(self.L_I18N_PRIMARY_PHONE_REQUIRED_ERROR(self.lang),
                             'Отображается ошибка "Сначала укажите основной телефон"')

    def assert_submit_disabled(self):
        btn = self.get_object(self.L_I18N_SUBMIT_CREATE_BTN(self.lang))
        assert_fn(lambda: btn.get_attribute('disabled') is not None,
                  'Кнопка "Создать контакт" недоступна')

    def assert_add_phone_disabled(self):
        btn = self.get_object(self.L_I18N_ADD_PHONE_BTN(self.lang))
        assert_fn(lambda: btn.get_attribute('disabled') is not None,
                  'Кнопка "Добавить телефон" недоступна — достигнут лимит доп. телефонов')

    def submit_create(self):
        log.step('Нажать "Создать контакт"', where='IVA ONE WEB Клиент')
        # Кнопка disabled, пока форма невалидна; валидация после ввода может отработать с
        # задержкой → ждём «реально кликабельна (не disabled)», затем кликаем.
        # NB Safari (отложен — TODO 018): нативный .click() давал ElementNotInteractable, а
        # синтетический click WebKit не транслирует в submit-формы; разрулить при возврате Safari.
        submit_btn = self.L_I18N_SUBMIT_CREATE_BTN(self.lang)
        page_helpers.wait_clickable_via_js(self.driver, lambda: self.get_object(submit_btn), timeout=10)
        self.get_object(submit_btn).click()

    def submit_save(self):
        log.step('Нажать "Сохранить"', where='IVA ONE WEB Клиент')
        # Edit-режим: кнопка «Сохранить» disabled, пока форма невалидна (поле Имя required и
        # при открытии пусто). Ждём «реально кликабельна (не disabled)», затем кликаем —
        # как submit_create, но с save-локатором.
        submit_btn = self.L_I18N_SUBMIT_SAVE_BTN(self.lang)
        page_helpers.wait_clickable_via_js(self.driver, lambda: self.get_object(submit_btn), timeout=10)
        self.get_object(submit_btn).click()

    def assert_form_closed(self):
        assert_fn(lambda: self.wait_absence(self.L_ROOT()),
                  'Форма контакта закрылась после сохранения')


class CVersion2ContactForm(_CContactForm, Version2Locators.LContactForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.version = 'Version2'
