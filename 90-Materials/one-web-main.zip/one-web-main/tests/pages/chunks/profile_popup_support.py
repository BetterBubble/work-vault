import csv
from datetime import datetime, timezone
from io import StringIO
import time
from typing import TYPE_CHECKING

from autocore.test.assertions import assert_fn
from autocore.test.logger import get_log
from tests.pages import chunks
from tests.pages.locators.Version2.chunks import profile_popup_support as Version2Locators
from tests.pages.profile_popup import PVersion2ProfilePopup
from tools import i18n
from tools.helpers import page_helpers

if TYPE_CHECKING:
    from tests.pages.locators.Version2.chunks.profile_popup_support import (
        LProfilePopupSupport as _LocatorsTypingBase,
    )
else:
    class _LocatorsTypingBase:
        pass

log = get_log()
LOGS_DOWNLOAD_CAPTURE = '__profile_logs_download_capture__'


class _CProfilePopupSupport(PVersion2ProfilePopup, _LocatorsTypingBase):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_ROOT()
        self.page_path = ''
        kwargs['open_page'] = False
        super().__init__(*args, **kwargs)

    def assert_logging_actions_available(self):
        self.assert_presence(self.L_LOGGING_BLOCK(), 'В разделе "Поддержка" отображается блок логирования')
        self.assert_presence(self.L_I18N_LOGGING_TITLE(self.lang), 'В блоке логирования отображается заголовок')
        export_button_name = i18n.get_str('profile_support_logging_button_export', self.lang)
        clear_button_name = i18n.get_str('profile_support_logging_button_clear', self.lang)
        assert_fn(lambda: self.get_object(self.L_I18N_EXPORT_LOGS_BUTTON(self.lang)).is_enabled(),
                  f'Кнопка "{export_button_name}" доступна')
        assert_fn(lambda: self.get_object(self.L_I18N_CLEAR_LOGS_BUTTON(self.lang)).is_enabled(),
                  f'Кнопка "{clear_button_name}" доступна')

    def assert_standard_logging_view(self):
        self.assert_logging_actions_available()
        assert_fn(lambda: self.wait_absence(self.L_DEVELOP_LOGGING_OPTIONS(), timeout=2),
                  'Расширенный блок develop-логирования отсутствует')
        assert_fn(lambda: self.wait_absence(self.L_I18N_DEVELOP_LOGGING_ENABLED_TOGGLE(self.lang), timeout=2),
                  'Переключатель "Включить логирование" отсутствует')

    def assert_develop_logging_options_visible(self):
        self.assert_logging_actions_available()
        self.assert_presence(self.L_DEVELOP_LOGGING_OPTIONS(), 'Отображается расширенный блок develop-логирования')
        self.assert_presence(self.L_I18N_DEVELOP_LOGGING_ENABLED_TOGGLE(self.lang),
                             'Отображается переключатель "Включить логирование"')
        self.assert_presence(self.L_I18N_DEVELOP_CONSOLE_PROXY_TOGGLE(self.lang),
                             'Отображается переключатель "Проксировать консоль"')
        self.assert_presence(self.L_I18N_DEVELOP_CONSOLE_TITLE(self.lang),
                             'Отображается секция настроек вывода в консоль')
        self.assert_presence(self.L_I18N_DEVELOP_IDB_TITLE(self.lang),
                             'Отображается секция настроек хранения логов')
        self.assert_presence(self.L_I18N_DEVELOP_SENTRY_TITLE(self.lang),
                             'Отображается секция настроек Sentry')
        self.assert_presence(self.L_I18N_DEVELOP_LOG_LEVELS_TITLE(self.lang),
                             'Отображается секция уровней логирования')

    def install_logs_download_capture(self):
        page_helpers.install_blob_download_capture(self.driver, LOGS_DOWNLOAD_CAPTURE)

    def export_logs(self):
        button_name = i18n.get_str('profile_support_logging_button_export', self.lang)
        log.step(f'Нажать кнопку "{button_name}"', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_EXPORT_LOGS_BUTTON(self.lang)).click()

    def clear_logs(self):
        button_name = i18n.get_str('profile_support_logging_button_clear', self.lang)
        log.step(f'Нажать кнопку "{button_name}"', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_CLEAR_LOGS_BUTTON(self.lang)).click()

    def get_browser_timestamp_ms(self) -> int:
        return page_helpers.get_browser_timestamp_ms(self.driver)

    def assert_logs_exported(self):
        toast_text = i18n.get_str('notification_logs_export', self.lang)
        self.toast.assert_i18n_visible('notification_logs_export', f'Отображается тост "{toast_text}"')

    def assert_logs_deleted(self):
        toast_text = i18n.get_str('notification_logs_deleted', self.lang)
        self.toast.assert_i18n_visible('notification_logs_deleted', f'Отображается тост "{toast_text}"')

    def assert_exported_logs_file(self):
        capture = self._wait_logs_download_capture()
        filename = capture.get('filename') or ''
        text = capture.get('text')
        assert_fn(lambda: self._is_logs_filename(filename) and text is not None,
                  f'Скачан CSV-файл логов logs_*.csv, фактически "{filename}"')

    def assert_no_exported_logs_before(self, timestamp_ms: int):
        capture = self._wait_logs_download_capture()
        filename = capture.get('filename') or ''
        text = capture.get('text')
        old_rows = self._log_rows_before(text or '', timestamp_ms)
        assert_fn(
            lambda: self._is_logs_filename(filename) and text is not None and not old_rows,
            f'В экспортированном CSV нет логов старше момента очистки; найдено старых строк: {old_rows}',
        )

    def _wait_logs_download_capture(self, timeout: float = 5.0) -> dict:
        end_time = time.time() + timeout
        while time.time() < end_time:
            capture = self._get_logs_download_capture()
            if capture.get('filename') and capture.get('text') is not None:
                return capture
            time.sleep(0.2)
        return self._get_logs_download_capture()

    def _get_logs_download_capture(self) -> dict:
        return page_helpers.get_blob_download_capture(self.driver, LOGS_DOWNLOAD_CAPTURE)

    @staticmethod
    def _is_logs_filename(filename: str) -> bool:
        return filename.startswith('logs_') and filename.endswith('.csv') and len(filename) > len('logs_.csv')

    @staticmethod
    def _log_rows_before(text: str, timestamp_ms: int) -> list:
        clean_text = text.lstrip('\ufeff').strip()
        if not clean_text:
            return []

        rows = list(csv.reader(StringIO(clean_text), delimiter=';'))
        if len(rows) <= 1:
            return []

        old_rows = []
        for row in rows[1:]:
            if not row or not row[0].strip():
                continue
            try:
                row_dt = datetime.fromisoformat(row[0].replace('Z', '+00:00'))
            except ValueError:
                old_rows.append(row[:4])
                continue
            if row_dt.tzinfo is None:
                row_dt = row_dt.replace(tzinfo=timezone.utc)
            if row_dt.timestamp() * 1000 < timestamp_ms:
                old_rows.append(row[:4])
        return old_rows


class CVersion2ProfilePopupSupport(_CProfilePopupSupport, Version2Locators.LProfilePopupSupport):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.version = 'Version2'
        self.toast = chunks.get_chunk(self.version, 'toast')(driver=self.driver, lang=self.lang)
