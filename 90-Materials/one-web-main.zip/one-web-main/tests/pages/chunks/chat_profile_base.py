import os
import time
from typing import TYPE_CHECKING

from autocore.base.web.base_page import PBase
from autocore.consts import TEST_DATA_DIR
from autocore.test.assertions import assert_fn
from selenium.common.exceptions import TimeoutException
from tests.pages.locators.Version2.chunks import chat_profile_base as Version2Locators
from autocore.test.logger import get_log
from tools import i18n
from tools.helpers.page_helpers import (
    upload_avatar_via_lazy_picker,
    wait_clickable_via_js,
    with_clipboard_capture,
)
from tests import pages
from tests.pages import chunks

if TYPE_CHECKING:
    from tests.pages.locators.Version2.chunks.chat_profile_base import (
        LChatProfileBase as _LocatorsTypingBase,
    )
else:
    class _LocatorsTypingBase:
        pass

log = get_log()


class _CChatProfileBase(PBase, _LocatorsTypingBase):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_ROOT()
        self.page_path = ''
        kwargs['open_page'] = False
        super().__init__(*args, **kwargs)

    def open_user_profile(self, username):
        log.step(f'Открыть профиль пользователя "{username}" из карточки чата', where='IVA ONE WEB Клиент')
        self.get_object(self.L_USER_ITEM_WITH_NAME(username)).click()
        _ = chunks.get_chunk(self.version, 'user_profile')(driver=self.driver, lang=self.lang)

    def open_member_context_menu(self, username):
        if self.driver.name in ['Safari', 'firefox', 'MicrosoftEdge']:
            time.sleep(3)
        log.step(f'Открыть контекстное меню участника "{username}"', where='IVA ONE WEB Клиент')
        self._wait_clickable(self.L_USER_ITEM_WITH_NAME(username))
        for attempt in range(3):
            self.click_right(self.L_USER_ITEM_WITH_NAME(username), 5)
            try:
                self.wait_presence(self.L_MEMBER_CONTEXT_MENU(), 5)
                return
            except TimeoutException:
                if attempt == 2:
                    raise
                log.warning(
                    f'Контекстное меню участника не открылось, повторяем right-click (попытка {attempt + 2}/3)'
                )

    def click_kick_member_in_context_menu(self):
        kick_btn_name = i18n.get_str('group_chat_profile_kick_member_btn', self.lang)
        log.step(f'Нажать кнопку "{kick_btn_name}" в контекстном меню участника', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_MEMBER_CONTEXT_MENU_KICK_BTN(self.lang)).click()
        self.wait_absence(self.L_MEMBER_CONTEXT_MENU())

    def assert_user_not_in_profile_list(self, username):
        assert_fn(lambda: self.wait_absence(self.L_USER_ITEM_WITH_NAME(username)),
                  f'Участник "{username}" отсутствует в списке участников чата')

    def assert_user_in_profile_list(self, username):
        self.assert_presence(self.L_USER_ITEM_WITH_NAME(username),
                             f'Участник "{username}" в списке участников чата')

    def click_add_user_btn(self):
        log.step('Нажать кнопку "Добавить пользователя" в карточке чата',
                 where='IVA ONE WEB Клиент')
        self.get_object(self.L_ADD_USER_BTN()).click()
        self.wait_presence(self.L_I18N_ADD_MEMBERS_DIALOG(self.lang))

    def search_and_select_member_in_add_popup(self, full_name):
        log.step(f'Найти и выбрать участника "{full_name}" в диалоге добавления',
                 where='IVA ONE WEB Клиент')
        search_input = self.get_object(self.L_I18N_ADD_MEMBERS_DIALOG_SEARCH_INPUT(self.lang))
        search_input.clear()
        search_input.send_keys(full_name)
        self.wait_presence(self.L_I18N_ADD_MEMBERS_DIALOG_CONTACT_ROW(full_name, self.lang))
        self.get_object(self.L_I18N_ADD_MEMBERS_DIALOG_CONTACT_ROW(full_name, self.lang)).click()

    def click_add_in_popup(self):
        add_btn_name = i18n.get_str('chat_profile_add_members_dialog_confirm_btn', self.lang)
        log.step(f'Нажать кнопку "{add_btn_name}" в диалоге добавления',
                 where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_ADD_MEMBERS_DIALOG_CONFIRM_BTN(self.lang)).click()
        self.wait_absence(self.L_I18N_ADD_MEMBERS_DIALOG(self.lang))

    def click_make_admin_in_context_menu(self):
        make_admin_btn_name = i18n.get_str('group_chat_profile_make_admin_btn', self.lang)
        log.step(f'Нажать кнопку "{make_admin_btn_name}" в контекстном меню участника', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_MEMBER_CONTEXT_MENU_MAKE_ADMIN_BTN(self.lang)).click()
        self.wait_absence(self.L_MEMBER_CONTEXT_MENU())

    def assert_user_is_admin(self, username):
        self.assert_presence(self.L_I18N_USER_ITEM_ADMIN_ROLE(username, self.lang),
                             f'Участник "{username}" назначен администратором')

    def click_transfer_owner_in_context_menu(self):
        transfer_owner_btn_name = i18n.get_str('group_chat_profile_transfer_owner_btn', self.lang)
        log.step(f'Нажать кнопку "{transfer_owner_btn_name}" в контекстном меню участника', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_MEMBER_CONTEXT_MENU_TRANSFER_OWNER_BTN(self.lang)).click()
        self.wait_absence(self.L_MEMBER_CONTEXT_MENU())
        self.wait_presence(self.L_TRANSFER_OWNER_CONFIRM_DIALOG())

    def confirm_transfer_owner(self):
        log.step('Подтвердить передачу прав владельца в диалоге', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_TRANSFER_OWNER_CONFIRM_BTN(self.lang)).click()
        self.wait_absence(self.L_TRANSFER_OWNER_CONFIRM_DIALOG())

    def assert_user_is_owner(self, username):
        self.assert_presence(self.L_I18N_USER_ITEM_OWNER_ROLE(username, self.lang),
                             f'Участник "{username}" назначен владельцем')

    def _wait_input_value(self, locator, expected_value: str, timeout: float = 3.0) -> bool:
        end_time = time.time() + timeout
        while time.time() < end_time:
            input_el = self.get_object(locator)
            current_value = input_el.get_attribute('value') or ''
            if current_value == expected_value:
                return True
            js_value = self.driver.execute_script('return arguments[0].value;', input_el) or ''
            if js_value == expected_value:
                return True
            time.sleep(0.1)
        return False

    def _wait_description_counter(self, expected_counter: str, timeout: float = 3.0) -> bool:
        end_time = time.time() + timeout
        while time.time() < end_time:
            counter_text = ''.join(self.get_object(self.L_DESCRIPTION_COUNTER()).text.split())
            if expected_counter in counter_text:
                return True
            time.sleep(0.1)
        return False

    def _wait_clickable(self, locator, timeout: float = 10.0) -> bool:
        if self.driver.name == 'Safari':
            return wait_clickable_via_js(self.driver, lambda: self.get_object(locator), timeout)

        end_time = time.time() + timeout
        while time.time() < end_time:
            element = self.get_object(locator)
            if element.is_displayed() and element.is_enabled():
                return True
            time.sleep(0.1)
        return False

    def click_edit_chat(self):
        edit_btn_name = i18n.get_str('group_chat_profile_edit_btn', self.lang)
        log.step(f'Нажать кнопку "{edit_btn_name}" в карточке чата', where='IVA ONE WEB Клиент')
        self.get_object(self.L_EDIT_CHAT_BTN()).click()
        self.wait_presence(self.L_EDIT_FORM())

    def assert_edit_form_opened(self):
        self.assert_presence(self.L_EDIT_FORM(), 'Открыта форма редактирования карточки чата')

    def upload_avatar(self, file_name: str):
        log.step(f'Загрузить фото чата "{file_name}"', where='IVA ONE WEB Клиент')
        local_path = os.path.join(TEST_DATA_DIR, file_name)
        upload_avatar_via_lazy_picker(self.driver, self.get_object(self.L_AVATAR_EDIT_HOST()), local_path)

    def assert_avatar_uploaded(self):
        self.assert_presence(self.L_AVATAR_PREVIEW_IMAGE(), 'Фото чата загружено')

    def click_clear_chat_name_btn(self):
        log.step('Нажать кнопку очистки поля названия чата', where='IVA ONE WEB Клиент')
        self.wait_presence(self.L_CHAT_NAME_CLEAR_BTN())
        self.get_object(self.L_CHAT_NAME_CLEAR_BTN()).click()
        self.wait_absence(self.L_CHAT_NAME_CLEAR_BTN())

    def assert_chat_name_input_empty(self):
        locator = self.L_CHAT_NAME_INPUT()
        assert_fn(
            lambda: self._wait_input_value(locator, ''),
            'Поле "Название чата" пустое',
        )

    def type_chat_name(self, name: str, check_value=True):
        locator = self.L_CHAT_NAME_INPUT()
        log.step(f'Ввести название "{name}" в поле названия чата', where='IVA ONE WEB Клиент')
        self.get_object(locator).send_keys(name)
        if check_value:
            assert_fn(lambda: self._wait_input_value(locator, name),
                      f'В поле "Название чата" отображается введённое значение "{name}"')

    def type_description(self, description: str, check_value=True):
        description_label = i18n.get_str('group_chat_profile_description_label', self.lang)
        locator = self.L_DESCRIPTION_TEXTAREA()
        log.step(f'Ввести описание "{description}" в поле "{description_label}"', where='IVA ONE WEB Клиент')
        self.clear_input(locator)
        self.get_object(locator).send_keys(description)
        if check_value:
            assert_fn(lambda: self._wait_input_value(locator, description),
                      f'В поле "{description_label}" отображается введённое значение "{description}"')

    def assert_description_counter(self, description: str):
        expected_counter = f'{len(description)}/500'
        assert_fn(lambda: self._wait_description_counter(expected_counter),
                  f'Счётчик описания отображает значение "{expected_counter}"')

    def save_changes(self):
        save_btn_name = i18n.get_str('group_chat_profile_save_btn', self.lang)
        log.step(f'Нажать кнопку "{save_btn_name}" на форме редактирования карточки чата', where='IVA ONE WEB Клиент')
        assert_fn(lambda: self.wait_absence(self.L_AVATAR_LOADING()) and
                  self._wait_clickable(self.L_I18N_SAVE_CHANGES_BTN(self.lang)),
                  f'Кнопка "{save_btn_name}" доступна на форме редактирования карточки чата')
        self.get_object(self.L_I18N_SAVE_CHANGES_BTN(self.lang)).click()
        self.wait_absence(self.L_EDIT_FORM())

    def assert_description_visible(self, description: str):
        self.assert_presence(self.L_DESCRIPTION_TEXT(description),
                             f'В карточке чата отображается описание "{description}"')

    def _activate_toggle(self, toggle_key, switch_locator, checkbox_locator):
        toggle_label = i18n.get_str(toggle_key, self.lang)
        log.step(f'Активировать тогл "{toggle_label}"', where='IVA ONE WEB Клиент')
        if self.get_object(checkbox_locator).is_selected():
            return
        self.get_object(switch_locator).click()
        self._assert_toggle_active(toggle_key, checkbox_locator)

    def _assert_toggle_active(self, toggle_key, checkbox_locator):
        toggle_label = i18n.get_str(toggle_key, self.lang)
        assert_fn(
            lambda: self.get_object(checkbox_locator).is_selected(),
            f'Тогл "{toggle_label}" в активном состоянии',
        )

    def toggle_chat_public(self):
        self._activate_toggle(
            self._PUBLIC_TOGGLE_KEY,
            self.L_I18N_PUBLIC_TOGGLE_SWITCH(self.lang),
            self.L_I18N_PUBLIC_TOGGLE_CHECKBOX(self.lang),
        )

    def assert_chat_public_toggle_active(self):
        self._assert_toggle_active(self._PUBLIC_TOGGLE_KEY, self.L_I18N_PUBLIC_TOGGLE_CHECKBOX(self.lang))

    def assert_chat_is_public(self):
        public_label = i18n.get_str(self._PUBLIC_CHAT_LABEL_KEY, self.lang)
        self.assert_presence(
            self.L_I18N_PUBLIC_CHAT_LABEL(self.lang),
            f'В карточке отображается метка "{public_label}"',
        )

    def toggle_reactions(self):
        self._activate_toggle(
            self._REACTIONS_TOGGLE_KEY,
            self.L_I18N_REACTIONS_TOGGLE_SWITCH(self.lang),
            self.L_I18N_REACTIONS_TOGGLE_CHECKBOX(self.lang),
        )

    def assert_reactions_toggle_active(self):
        self._assert_toggle_active(self._REACTIONS_TOGGLE_KEY, self.L_I18N_REACTIONS_TOGGLE_CHECKBOX(self.lang))

    def toggle_threads(self):
        self._activate_toggle(
            self._THREADS_TOGGLE_KEY,
            self.L_I18N_THREADS_TOGGLE_SWITCH(self.lang),
            self.L_I18N_THREADS_TOGGLE_CHECKBOX(self.lang),
        )

    def assert_threads_toggle_active(self):
        self._assert_toggle_active(self._THREADS_TOGGLE_KEY, self.L_I18N_THREADS_TOGGLE_CHECKBOX(self.lang))

    def assert_avatar_visible(self):
        self.assert_presence(self.L_AVATAR_IMAGE(), 'Фото чата отображается в карточке чата')

    def copy_chat_link(self) -> str:
        log.step('Скопировать ссылку', where='IVA ONE WEB Клиент')

        def _click_and_wait_toast():
            self.get_object(self.L_I18N_COPY_LINK_BTN(self.lang)).click()
            # Дождёмся тоста — гарантия, что app завершил copy-flow и положил в буфер.
            self.toast.wait_i18n_visible('group_chat_profile_copy_link_toast')

        return with_clipboard_capture(self.driver, _click_and_wait_toast, timeout=1.0)

    def toggle_notifications(self):
        log.step('Переключить уведомления в карточке чата', where='IVA ONE WEB Клиент')
        self.get_object(self.L_NOTIFICATIONS_TOGGLE_BTN()).click()

    def assert_notifications_muted_toast_visible(self):
        self.toast.assert_i18n_visible(
            'group_chat_profile_notifications_muted_toast',
            'Отображается тост "Уведомления отключены"',
        )

    def assert_notifications_unmuted_toast_visible(self):
        self.toast.assert_i18n_visible(
            'group_chat_profile_notifications_unmuted_toast',
            'Отображается тост "Уведомления включены"',
        )

    def assert_copy_link_toast_visible(self):
        self.toast.assert_i18n_visible(
            'group_chat_profile_copy_link_toast',
            'Отображается тост "Ссылка скопирована"',
        )

    def click_more_menu_btn(self):
        more_btn_name = i18n.get_str('group_chat_profile_more_btn', self.lang)
        log.step(f'Нажать кнопку "{more_btn_name}" в карточке чата', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_MORE_MENU_BTN(self.lang)).click()
        self.wait_presence(self.L_MORE_MENU())

    def click_delete_chat_btn(self):
        delete_btn_name = i18n.get_str('group_chat_profile_delete_chat_btn', self.lang)
        log.step(f'Нажать кнопку "{delete_btn_name}" в меню "Ещё"', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_DELETE_CHAT_MENU_ITEM(self.lang)).click()
        self.wait_absence(self.L_MORE_MENU())
        self.wait_presence(self.L_I18N_DELETE_CONFIRM_DIALOG(self.lang))

    def confirm_delete_chat(self):
        log.step('Подтвердить удаление в диалоге', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_DELETE_CONFIRM_BTN(self.lang)).click()
        self.wait_absence(self.L_I18N_DELETE_CONFIRM_DIALOG(self.lang))

    def click_gallery_category(self, category_key: str):
        """Кликнуть на кнопку категории в галерее карточки чата.
        category_key — i18n ключ, например 'chat_profile_gallery_category_video'."""
        category_name = i18n.get_str(category_key, self.lang)
        log.step(f'Нажать кнопку "{category_name}" в галерее карточки чата', where='IVA ONE WEB Клиент')
        self.wait_presence(self.L_I18N_GALLERY_CATEGORY_BTN(category_key, self.lang))
        self.get_object(self.L_I18N_GALLERY_CATEGORY_BTN(category_key, self.lang)).click()
