from typing import TYPE_CHECKING

from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys

from autocore.base.web.base_page import PBase
from tests.pages.locators.Version2.chunks import user_profile as Version2Locators
from tests.pages.locators.Version2.chunks.address_book import LAddressBook
from autocore.test.logger import get_log
from autocore.test.assertions import assert_fn
from tests import pages
from tests.pages import chunks
from tools.helpers import page_helpers

if TYPE_CHECKING:
    from tests.pages.locators.Version2.chunks.user_profile import (
        LUserProfile as _LocatorsTypingBase,
    )
else:
    class _LocatorsTypingBase:
        pass

log = get_log()


class _CUserProfile(PBase, _LocatorsTypingBase):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_ROOT()
        self.page_path = ''
        kwargs['open_page'] = False
        super().__init__(*args, **kwargs)

    def open_chat(self):
        # Дрейф 2026-07-02: прямой кнопки «Написать» в карточке больше нет — продукт
        # перенёс её в меню «Ещё»; чат открывается через пункт этого меню.
        log.step('Открыть меню "Ещё" в карточке контакта', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_ACTION_BTN('contact_profile_button_more', self.lang)).click()
        log.step('Выбрать пункт "Написать" в меню "Ещё"', where='IVA ONE WEB Клиент')
        self.wait_presence(LAddressBook.L_ROW_MENU_WRITE_ITEM(), 5)
        self.get_object(LAddressBook.L_ROW_MENU_WRITE_ITEM()).click()
        chat = pages.get_page(self.version, 'chat')(driver=self.driver, lang=self.lang, open_page=False)
        chat.wait_presence(chat.L_CHAT_TOPBAR(), 15)
        chat.wait_presence(chat.L_CHAT_INPUT(), 15)

    def assert_profile_sidebar_with_name_opened(self, user_data: dict):
        expected_name = f'{user_data["last_name"]} {user_data["first_name"]}'
        actual_name = self.get_object(self.L_SIDEBAR_USER_FULL_NAME_RENDER()).text
        assert_fn(lambda: actual_name == expected_name, f'Открыт профиль пользователя "{actual_name}", ожидается "{expected_name}"')

    def assert_avatar_displayed(self):
        self.assert_presence(self.L_SIDEBAR_USER_AVATAR_RENDER(), 'В карточке профиля отображается аватар')

    def assert_profile_field(self, title_key: str, value: str, message: str):
        self.assert_presence(self.L_I18N_PROFILE_FIELD(title_key, value, self.lang), message)

    def assert_action_button(self, key: str, message: str):
        self.assert_presence(self.L_I18N_ACTION_BTN(key, self.lang), message)

    def assert_write_in_more_menu(self):
        """«Написать» проверяется как пункт меню «Ещё»: прямую кнопку из карточки продукт
        убрал 2026-07-02. Пункт меню — тот же overlay-локатор, что у кебаба строки
        (LAddressBook.L_ROW_MENU_WRITE_ITEM). После проверки меню закрывается по Esc,
        чтобы overlay не перекрывал дальнейшие клики по карточке."""
        log.step('Открыть меню "Ещё" в карточке контакта', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_ACTION_BTN('contact_profile_button_more', self.lang)).click()
        self.assert_presence(LAddressBook.L_ROW_MENU_WRITE_ITEM(),
                             'Пункт "Написать" отображается в меню "Ещё" карточки')
        ActionChains(self.driver).send_keys(Keys.ESCAPE).perform()
        self.wait_absence(LAddressBook.L_ROW_MENU_WRITE_ITEM())

    def open_org_structure(self):
        log.step('Открыть орг-структуру из строки "Должность" карточки', where='IVA ONE WEB Клиент')
        # Safari кидает WebDriverException на обычном клике по chevron-кнопке — клик через JS.
        page_helpers.click_via_js(self.driver, self.get_object(self.L_ORG_STRUCTURE_BTN()))
        return chunks.get_chunk(self.version, 'org_structure_sidebar')(driver=self.driver, lang=self.lang)


class CVersion2UserProfile(_CUserProfile, Version2Locators.LUserProfile):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.version = 'Version2'
