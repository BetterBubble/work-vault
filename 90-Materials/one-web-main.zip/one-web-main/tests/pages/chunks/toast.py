from typing import TYPE_CHECKING

from autocore.base.web.base_page import PBase
from autocore.test.logger import get_log
from tests.pages.locators.Version2.chunks import toast as Version2Locators
from tools import i18n
from tools.helpers import page_helpers

if TYPE_CHECKING:
    from tests.pages.locators.Version2.chunks.toast import (
        LToast as _LocatorsTypingBase,
    )
else:
    class _LocatorsTypingBase:
        pass

log = get_log()


class _CToast(PBase, _LocatorsTypingBase):
    """Глобальный chunk для проверок тоста `<ds-toast-wrapper>`.

    Получается через `get_chunk(setup_aut['ver'], 'toast')(driver=..., lang=...)`.
    Покрывает три типовых сценария:
        - assert/wait, что тост с конкретным текстом отображается;
        - то же, но по i18n-ключу;
        - дождаться, что тост исчез (например, перед повторным кликом).

    `check_primary_element=False` — тоста может не быть на странице в момент
    создания chunk'а, ждать его в конструкторе нельзя.
    """

    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_ROOT()
        self.page_path = ''
        kwargs['open_page'] = False
        kwargs['check_primary_element'] = False
        super().__init__(*args, **kwargs)

    def assert_visible_by_text(self, text: str, message: str = None):
        msg = message or f'Отображается тост "{text}"'
        self.assert_presence(self.L_TOAST_BY_TEXT(text), msg)

    def assert_i18n_visible(self, key: str, message: str = None):
        text = i18n.get_str(key, self.lang)
        self.assert_visible_by_text(text, message)

    def wait_visible_by_text(self, text: str, timeout: int = 5):
        self.wait_presence(self.L_TOAST_BY_TEXT(text), timeout)

    def wait_i18n_visible(self, key: str, timeout: int = 5):
        text = i18n.get_str(key, self.lang)
        self.wait_visible_by_text(text, timeout)

    def wait_disappear(self, timeout: int = 10):
        """Дождаться исчезновения тоста (любого, по корневому `<ds-toast-wrapper>`).

        Используется перед операциями, которые могут быть перехвачены живым тостом
        (например, повторный клик по кнопке `Отправить` в чате).
        """
        self.wait_absence(self.L_ROOT(), timeout)

    def assert_success_visible(self, message: str = 'Отображается success-тост'):
        """Проверить, что показан SUCCESS-тост (по success-иконке ds-icon-circle-check-line),
        без привязки к тексту. error/warning-тосты НЕ матчатся."""
        self.assert_presence(self.L_TOAST_SUCCESS(), message)

    def assert_i18n_contains(self, key: str, message: str = None):
        """Как assert_i18n_visible, но текст ищется по всему <ds-toast> (а не в div.content) —
        для тостов с проецируемым контентом (entity-created-toast)."""
        text = i18n.get_str(key, self.lang)
        msg = message or f'Отображается тост "{text}"'
        self.assert_presence(self.L_TOAST_CONTAINS(text), msg)

    def assert_go_to_button_visible(self):
        self.assert_presence(self.L_I18N_GO_TO_BTN(self.lang),
                             'В тосте есть кнопка "Перейти"')

    def click_go_to(self):
        log.step('Нажать "Перейти" в тосте', where='IVA ONE WEB Клиент')
        btn = self.get_object(self.L_I18N_GO_TO_BTN(self.lang))
        if self.driver.name.lower() == 'safari':
            # Safari: <a class="toast-link"> кидает ElementNotInteractableException на
            # обычном клике — клик через JS.
            page_helpers.click_via_js(self.driver, btn)
        else:
            btn.click()


class CVersion2Toast(_CToast, Version2Locators.LToast):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.version = 'Version2'
