from typing import TYPE_CHECKING

from autocore.base.web.base_page import PBase
from autocore.test.assertions import assert_fn
from autocore.test.logger import get_log
from tests.pages.locators.Version2.chunks import p2p_chat_profile as Version2Locators
from tests.pages import chunks
from tools import i18n

if TYPE_CHECKING:
    from tests.pages.locators.Version2.chunks.p2p_chat_profile import (
        LP2pChatProfile as _LocatorsTypingBase,
    )
else:
    class _LocatorsTypingBase:
        pass

log = get_log()


class _CP2pChatProfile(PBase, _LocatorsTypingBase):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_ROOT()
        self.page_path = ''
        kwargs['open_page'] = False
        super().__init__(*args, **kwargs)

    def click_more_menu_btn(self):
        more_btn_name = i18n.get_str('p2p_chat_profile_more_btn', self.lang)
        log.step(f'Нажать кнопку "{more_btn_name}" в карточке личного чата', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_MORE_MENU_BTN(self.lang)).click()
        self.wait_presence(self.L_MORE_MENU())

    def click_mute_notifications(self):
        mute_btn_name = i18n.get_str('p2p_chat_profile_mute_menu_item', self.lang)
        log.step(f'Нажать кнопку "{mute_btn_name}" в меню "Ещё"', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_MUTE_MENU_ITEM(self.lang)).click()
        self.wait_absence(self.L_MORE_MENU())

    def assert_notifications_muted_toast_visible(self):
        self.toast.assert_i18n_visible(
            'p2p_chat_profile_notifications_muted_toast',
            'Отображается тост "Уведомления отключены"',
        )

    def click_gallery_category(self, category_key: str):
        """Кликнуть на кнопку категории в галерее карточки p2p-чата.
        category_key — i18n ключ, например 'chat_profile_gallery_category_audio'."""
        category_name = i18n.get_str(category_key, self.lang)
        log.step(f'Нажать кнопку "{category_name}" в галерее карточки чата', where='IVA ONE WEB Клиент')
        self.wait_presence(self.L_I18N_GALLERY_CATEGORY_BTN(category_key, self.lang))
        self.get_object(self.L_I18N_GALLERY_CATEGORY_BTN(category_key, self.lang)).click()

    def assert_gallery_category_count(self, category_key: str, expected_count: int):
        """Проверить, что счётчик в кнопке категории галереи равен expected_count.
        category_key — i18n ключ, например 'chat_profile_gallery_category_audio'."""
        category_name = i18n.get_str(category_key, self.lang)
        counter_locator = self.L_I18N_GALLERY_CATEGORY_BTN_COUNT(category_key, self.lang)
        self.wait_presence(counter_locator)
        actual_text = self.get_object(counter_locator).text.strip()
        assert_fn(lambda: actual_text == str(expected_count),
                  f'Счётчик категории "{category_name}" = {expected_count} '
                  f'(фактически "{actual_text}")')


class CVersion2P2pChatProfile(_CP2pChatProfile, Version2Locators.LP2pChatProfile):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.version = 'Version2'
        self.toast = chunks.get_chunk(self.version, 'toast')(driver=self.driver, lang=self.lang)
