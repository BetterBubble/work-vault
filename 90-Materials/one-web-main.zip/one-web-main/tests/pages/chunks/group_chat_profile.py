from typing import TYPE_CHECKING

from tests.pages.locators.Version2.chunks import group_chat_profile as Version2Locators
from autocore.test.logger import get_log
from tests.pages import chunks
from tests.pages.chunks.chat_profile_base import _CChatProfileBase

if TYPE_CHECKING:
    from tests.pages.locators.Version2.chunks.group_chat_profile import (
        LGroupChatProfile as _LocatorsTypingBase,
    )
else:
    class _LocatorsTypingBase:
        pass

log = get_log()


class _CGroupChatProfile(_CChatProfileBase, _LocatorsTypingBase):
    pass


class CVersion2GroupChatProfile(_CGroupChatProfile, Version2Locators.LGroupChatProfile):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.version = 'Version2'
        self.toast = chunks.get_chunk(self.version, 'toast')(driver=self.driver, lang=self.lang)
