from typing import TYPE_CHECKING

from autocore.base.web.base_page import PBase
from autocore.test.logger import get_log

from tools import i18n
from tools.enums import CalendarMeetingType
from tools.helpers.page_helpers import wait_clickable_via_js
from tests.pages import chunks
from tests.pages.locators.Version2.chunks import calendar as Version2Locators

if TYPE_CHECKING:
    from tests.pages.locators.Version2.chunks.calendar import (
        LCalendar as _LocatorsTypingBase,
    )
else:
    class _LocatorsTypingBase:
        pass

log = get_log()


class _CCalendar(PBase, _LocatorsTypingBase):
    """Раздел «Календарь»: вью <lib-calendar> с сеткой событий по часам и общий флоу
    создания мероприятия («+» → тип → форма в <calendar-event-sidebar-wrapper>).
    Открывается из leftbar (left_menu.open_calendar). Поля формы (имя/участники/fullscreen/
    submit) шарятся между Событие и ВКС; type-специфика и карточка созданного — в chunk'ах
    offline_event / mcu_conference_sidebar."""

    # Текст submit-кнопки зависит от типа мероприятия и режима формы (переиспользуем
    # существующие ключи); база по типу здесь, sidebar-ВКС переопределяется в submit_create.
    _CREATE_BTN_I18N_KEY = {
        CalendarMeetingType.VKS: 'mcu_conference_create_button',
        CalendarMeetingType.EVENT: 'offline_event_create_button',
    }

    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_VIEW_ROOT()
        self.page_path = ''
        self._meeting_type = None
        self._is_fullscreen = False
        kwargs['open_page'] = False
        super().__init__(*args, **kwargs)

    def _wait_grid_loaded(self, timeout=60):
        # Пока данные календаря грузятся, в сетке только спиннер (событий нет вовсе) —
        # поиск события при живом спиннере валится по timeout get_object (TC-1427:
        # на прогоне стенд отдавал календарь приглашённого дольше 15s).
        self.wait_absence(self.L_GRID_LOADER(), timeout=timeout)

    def assert_event_in_grid(self, name: str):
        self._wait_grid_loaded()
        self.assert_presence(
            self.L_EVENT_IN_GRID_BY_NAME(name),
            f'Событие "{name}" отображается в календаре',
        )

    # --- Создание мероприятия ---
    def click_create_btn(self):
        log.step('Нажать кнопку "+" (создать мероприятие)', where='IVA ONE WEB Клиент')
        self.get_object(self.L_CREATE_BTN()).click()

    def select_meeting_type(self, meeting_type: CalendarMeetingType):
        self._meeting_type = meeting_type
        self._is_fullscreen = False  # начало нового флоу создания — форма открывается в sidebar
        type_name = i18n.get_str(meeting_type.value, self.lang)
        log.step(f'Выбрать тип мероприятия "{type_name}"', where='IVA ONE WEB Клиент')
        self.wait_presence(self.L_CREATE_TYPE_MENU())
        self.get_object(self.L_I18N_CREATE_TYPE_MENU_ITEM(meeting_type.value, self.lang)).click()

    def fill_name(self, name: str):
        log.step(f'Ввести название мероприятия "{name}"', where='IVA ONE WEB Клиент')
        self.get_object(self.L_NAME_INPUT()).send_keys(name)

    def open_add_required_participants(self):
        log.step('Нажать "Добавить" (обязательные участники)', where='IVA ONE WEB Клиент')
        self.get_object(self.L_I18N_ADD_REQUIRED_PARTICIPANT_BTN(self.lang)).click()
        return chunks.get_chunk(self.version, 'add_participants_dialog')(driver=self.driver, lang=self.lang)

    def assert_form_participant_with_position(self, full_name: str, position: str):
        self.assert_presence(
            self.L_FORM_PARTICIPANT_POSITION(full_name, position),
            f'Участник "{full_name}" добавлен в форму с должностью "{position}"',
        )

    def open_fullscreen(self):
        log.step('Перейти в полноэкранный режим формы', where='IVA ONE WEB Клиент')
        self.get_object(self.L_FULLSCREEN_BTN()).click()
        self._is_fullscreen = True

    def assert_fullscreen_slots_visible(self):
        self.assert_presence(
            self.L_SLOTS_BLOCK(),
            'В полноэкранном режиме доступен блок планировщика "Свободные слоты"',
        )

    def submit_create(self):
        key = self._CREATE_BTN_I18N_KEY[self._meeting_type]
        if self._meeting_type is CalendarMeetingType.VKS and not self._is_fullscreen:
            # 2.1.0: sidebar-сабмит ВКС переименован в «Сохранить» (даже при создании);
            # в fullscreen текст остался «Создать встречу».
            key = 'calendar_conference_edit_save_btn'
        text = i18n.get_str(key, self.lang)
        log.step(f'Нажать "{text}"', where='IVA ONE WEB Клиент')
        # Кнопка disabled пока имя пустое — дожидаемся реальной кликабельности.
        wait_clickable_via_js(self.driver, lambda: self.get_object(self.L_I18N_SUBMIT_BTN(text)))
        self.get_object(self.L_I18N_SUBMIT_BTN(text)).click()

    def open_event_in_grid(self, name: str):
        log.step(f'Выбрать мероприятие "{name}" в сетке календаря', where='IVA ONE WEB Клиент')
        self._wait_grid_loaded()
        self.get_object(self.L_EVENT_CARD_CLICKABLE_BY_NAME(name)).click()

    def submit_edit(self):
        # Сохранение изменений ВКС-встречи («Сохранить» — на 2.1.0 тот же текст, что у
        # sidebar-создания). Кнопка в той же обёртке calendar-event-sidebar-wrapper → reuse L_I18N_SUBMIT_BTN.
        text = i18n.get_str('calendar_conference_edit_save_btn', self.lang)
        log.step(f'Нажать "{text}"', where='IVA ONE WEB Клиент')
        wait_clickable_via_js(self.driver, lambda: self.get_object(self.L_I18N_SUBMIT_BTN(text)))
        self.get_object(self.L_I18N_SUBMIT_BTN(text)).click()


class CVersion2Calendar(_CCalendar, Version2Locators.LCalendar):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.version = 'Version2'
