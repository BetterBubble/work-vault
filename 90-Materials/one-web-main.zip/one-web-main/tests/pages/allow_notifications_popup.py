from typing import TYPE_CHECKING

from autocore.base.web.base_page import PBase
from .locators import Version2 as Version2Locators
from autocore.test.logger import get_log

if TYPE_CHECKING:
    from .locators.Version2.allow_notifications_popup import (
        LAllowNotificationsPopup as _LocatorsTypingBase,
    )
else:
    class _LocatorsTypingBase:
        pass

log = get_log()


class _PVersionAllowNotificationsPopup(PBase, _LocatorsTypingBase):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_I18N_HEADER(self.lang)
        self.page_path = ''
        kwargs['open_page'] = False
        super().__init__(*args, **kwargs)

    def allow(self):
        log.step(f'Разрешить браузеру отправку push-уведомлений', where='IVA ONE WEB Клиент')
        allow_button_locator = self.L_I18N_BTN_OK(self.lang)
        allow_button = self.get_object(allow_button_locator)
        allow_button.click()
        self.wait_absence(allow_button_locator)


class PVersion2AllowNotificationsPopup(_PVersionAllowNotificationsPopup, Version2Locators.LAllowNotificationsPopup):
    pass
