import time
from typing import TYPE_CHECKING

from selenium.common.exceptions import TimeoutException

from .locators import Version2 as Version2Locators
from autocore.test.logger import get_log
from autocore.base.web.base_page import PBase
from autocore.test.assertions import assert_fn
from tests import pages
from tools import i18n

if TYPE_CHECKING:
    from .locators.Version2.login import LLogin as _LocatorsTypingBase
else:
    class _LocatorsTypingBase:
        pass

log = get_log()


class _PVersionLogin(PBase, _LocatorsTypingBase):
    def __init__(self, *args, **kwargs):
        self.lang = kwargs['lang']
        self.primary_element = self.L_HEADER()
        self.page_path = ''
        super().__init__(*args, **kwargs)

    def _input(self, locator, input_text: str):
        self.get_object(locator).send_keys(input_text)

    def _wait_input_value(self, locator, expected_value: str, timeout: float = 3.0) -> bool:
        end_time = time.time() + timeout
        while time.time() < end_time:
            input_el = self.get_object(locator)
            current_value = input_el.get_attribute('value') or ''
            if current_value == expected_value:
                return True
            # Браузеры иногда позже синхронизируют value в webdriver, читаем через JS как fallback.
            js_value = self.driver.execute_script('return arguments[0].value;', input_el) or ''
            if js_value == expected_value:
                return True
            time.sleep(0.1)
        return False

    def _show_password(self):
        log.step('Показать пароль', where='IVA ONE WEB Клиент')
        self.get_object(self.L_SHOW_HIDE_PWD()).click()

    def input_login(self, username: str, check_value=False):
        locator = self.L_INPUT_LOGIN()
        log.step(f'Ввести логин "{username}"', where='IVA ONE WEB Клиент')
        self._input(locator, username)
        if check_value:
            assert_fn(lambda: self._wait_input_value(locator, username),
                      f'В поле "Имя пользователя или E-mail" отображается введённое значение "{username}"')

    def input_password(self, password: str, check_value=False):
        locator = self.L_INPUT_PASSWORD()
        log.step(f'Ввести пароль "{password}"', where='IVA ONE WEB Клиент')
        self._input(locator, password)
        if check_value:
            self._show_password()  # Можем получить value без открытия пароля на глазик. Это ок?
            assert_fn(lambda: self._wait_input_value(locator, password),
                      f'В поле "Пароль" отображается введённое значение "{password}"')

    def _submit(self):
        log.step('Нажать кнопку "Вход"', where='IVA ONE WEB Клиент')
        self.get_object(self.L_BTN_SUBMIT()).click()

    def _is_stale_login_form_visible(self) -> bool:
        """После logout keycloak иногда отрисовывает свежую форму поверх старой (новый auth-flow-id), и submit по «несвежей» форме молча возвращает нас на пустую login-форму. Признак — input логина снова видим и пустой; при реальной ошибке авторизации keycloak сохраняет введённый логин в поле, и эта функция вернёт False."""
        if not self.wait_presence(self.L_INPUT_LOGIN(), timeout=3, mode='return'):
            return False
        # Форма может исчезнуть между presence-проверкой и чтением value (успешный логин
        # завершился в этот момент) — исчезла значит не «несвежая», повторный логин не нужен.
        try:
            value = self.get_object(self.L_INPUT_LOGIN()).get_attribute('value') or ''
        except TimeoutException:
            return False
        return value == ''

    def login(self, username: str, password: str, check_values=False, allow_notifications=True):
        log.step(f'Авторизоваться пользователем "{username}"', where='IVA ONE WEB Клиент')
        self.input_login(username, check_values)
        self.input_password(password, check_values)
        self._submit()
        if self._is_stale_login_form_visible():
            log.warning('После submit login-форма всё ещё видна с пустым полем логина — повторяем логин')
            self.input_login(username, check_values)
            self.input_password(password, check_values)
            self._submit()
        if allow_notifications and self.driver.name != 'Safari':
            allow_notifications_popup = pages.get_page(self.version, 'allow_notifications_popup')(self.driver, lang=self.lang, check_primary_element=False)
            allow_notifications_popup.allow()

    def check_wrong_auth_text(self):
        wrong_auth_text = i18n.get_str('wrong_auth_text', self.lang)
        self.wait_presence(locator=self.L_I18N_WRONG_AUTH_TEXT(self.lang),
                           message=f'Под полем Логин отображается текст "{wrong_auth_text}". Авторизация не успешна')

    def assert_authorization_page_opened(self):
        self.assert_presence(self.L_HEADER(), 'Произошёл переход на экран авторизации')


class PVersion2Login(_PVersionLogin, Version2Locators.LLogin):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.version = 'Version2'

