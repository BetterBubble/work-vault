import allure
import pytest

from autocore import driver_sessions
from autocore.test.logger import get_log
from tools.helpers.session import web_preamble
from tests import pages
from tests.pages import chunks
from tools import enums


log = get_log()


@allure.id("294")
@allure.title("Просмотр информации об аккаунте")
@allure.label("owner", "Simon")
@allure.tag("web", "RFA")
@allure.story("Аккаунт")
@allure.feature("Личный профиль")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_view_account_info(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]

    log.tc('294')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data.get('username'), user_data.get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_profile()
    profile_popup = pages.get_page(version, 'profile_popup')(driver, lang=lang, open_page=False)
    profile_popup.open_account_chunk()
    profile_popup_account = chunks.get_chunk(version, 'profile_popup_account')(driver, lang=lang)
    profile_popup_account.assert_correct_account(user_data)


@allure.id("1391")
@allure.title("Загрузить аватар профиля")
@allure.label("owner", "Simon")
@allure.tag("web", "RFA")
@allure.story("Аккаунт")
@allure.label("IVAQA", "IVAONE-7954", "IVAONE-8373", "IVAONE-8402")
@allure.feature("Личный профиль")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_upload_profile_avatar(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]
    avatar_filename = 'test_image_sample.jpeg'

    log.tc('1391')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data.get('username'), user_data.get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_profile()
    profile_popup = pages.get_page(version, 'profile_popup')(driver, lang=lang, open_page=False)
    profile_popup.open_account_chunk()
    profile_popup_account = chunks.get_chunk(version, 'profile_popup_account')(driver, lang=lang)
    profile_popup_account.upload_avatar(avatar_filename)
    profile_popup_account.assert_avatar_uploaded()
    profile_popup_account.assert_save_cancel_btns_exists()
    profile_popup_account.click_edit_action_btn(enums.ProfilePopupEditActions.SAVE)
    profile_popup_account.assert_avatar_was_saved(close_popup=True)
    left_menu.assert_img_avatar_exist()


@allure.id("295")
@allure.title("Выйти из аккаунта")
@allure.label("owner", "Vitaly")
@allure.tag("web", "RFA")
@allure.story("Аккаунт")
@allure.feature("Личный профиль")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_account_logout(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]

    log.tc('295')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data.get('username'), user_data.get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_profile()
    profile_popup = pages.get_page(version, 'profile_popup')(driver, lang=lang, open_page=False)
    profile_popup.open_account_chunk()
    profile_popup_account = chunks.get_chunk(version, 'profile_popup_account')(driver, lang=lang)
    profile_popup_account.logout()
    login_page.assert_authorization_page_opened()


@allure.id("464")
@allure.title("Завершение сеанса. Завершить текущий сеанс")
@allure.label("owner", "Simon")
@allure.tag("web", "RFA")
@allure.story("Мои сеансы")
@allure.label("IVAQA", "IVAONE-7767", "IVAONE-8724")
@allure.feature("Личный профиль")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.xfail(reason='IVAONE-12575 [Back] Ручка /api/v1/me/sessions отдает 500')
def test_terminate_current_session(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]

    log.tc('464')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data.get('username'), user_data.get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_profile()
    profile_popup = pages.get_page(version, 'profile_popup')(driver, lang=lang, open_page=False)
    profile_popup.open_sessions_chunk()
    sessions = chunks.get_chunk(version, 'profile_popup_sessions')(driver, lang=lang)
    sessions.assert_current_session_present()
    sessions.terminate_current_session()
    login_page.assert_authorization_page_opened()


@allure.id("296")
@allure.title("Завершение сеанса. Завершить другие сеансы")
@allure.label("owner", "Vitaly")
@allure.tag("web", "RFA")
@allure.story("Мои сеансы")
@allure.feature("Личный профиль")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.xfail(reason='IVAONE-12575 [Back] Ручка /api/v1/me/sessions отдает 500')
def test_terminate_other_sessions(setup_multiple_auts, users_factory, teardown):
    auts = setup_multiple_auts(2)
    lang = auts['setup']['cmd']['lang']
    version = auts['setup']['cmd']['ver']
    user_data = users_factory[0]
    driver_1, driver_2 = auts['driver']
    teardown.append((lambda el: el.quit(), driver_1))
    teardown.append((lambda el: el.quit(), driver_2))

    log.tc('296')

    # Вторая сессия того же юзера (driver_2) — поднять первой, чтобы она стала "другой" для driver_1.
    driver_sessions.set_active(driver_2)
    login_page_2 = pages.get_page(version, 'login')(driver_2, lang=lang)
    login_page_2.login(user_data.get('username'), user_data.get('password'))
    chunks.get_chunk(version, 'left_menu')(driver_2, lang=lang)  # барьер: сессия driver_2 поднята

    # Текущая сессия (driver_1) — из неё завершаем другие.
    driver_sessions.set_active(driver_1)
    login_page_1 = pages.get_page(version, 'login')(driver_1, lang=lang)
    login_page_1.login(user_data.get('username'), user_data.get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver_1, lang=lang)
    left_menu.open_profile()
    profile_popup = pages.get_page(version, 'profile_popup')(driver_1, lang=lang, open_page=False)
    profile_popup.open_sessions_chunk()
    sessions = chunks.get_chunk(version, 'profile_popup_sessions')(driver_1, lang=lang)
    sessions.assert_other_sessions_present()
    sessions.click_terminate_other_sessions()
    sessions.assert_terminate_other_sessions_dialog_shown()
    sessions.confirm_terminate_other_sessions()
    sessions.assert_other_sessions_terminated()  # раздел "Другие сеансы" исчез на driver_1

    # Наблюдаемый сигнал на driver_2: сессия завершена сервером → refresh форсирует
    # проверку токена → редирект на страницу авторизации Keycloak.
    driver_sessions.set_active(driver_2)
    driver_2.refresh()
    login_page_2.assert_authorization_page_opened()


@allure.id("465")
@allure.title("Настройки. Язык. Смена на английский")
@allure.label("owner", "Simon")
@allure.tag("web", "RFA")
@allure.story("Настройки")
@allure.feature("Личный профиль")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_change_interface_language_to_english(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]

    log.tc('465')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data.get('username'), user_data.get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_profile()
    profile_popup = pages.get_page(version, 'profile_popup')(driver, lang=lang, open_page=False)
    profile_popup.open_settings_language_chunk()
    settings_language = chunks.get_chunk(version, 'profile_popup_settings_language')(driver, lang=lang)
    settings_language.assert_current_language(enums.ProfileLanguage.RUSSIAN)
    settings_language.open_language_dropdown()
    settings_language.select_language(enums.ProfileLanguage.ENGLISH)
    settings_language.assert_ui_language_english()
    # Вернуть язык на русский — не оставлять UI в английском для соседних тестов
    settings_language.open_language_dropdown()
    settings_language.select_language(enums.ProfileLanguage.RUSSIAN)


@allure.id("46822")
@allure.title("Настройки оборудования")
@allure.label("owner", "Simon")
@allure.tag("RFA")
@allure.story("Настройки")
@allure.feature("Личный профиль")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_view_equipment_settings(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]

    log.tc('46822')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data.get('username'), user_data.get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_profile()
    profile_popup = pages.get_page(version, 'profile_popup')(driver, lang=lang, open_page=False)
    profile_popup.open_settings_equipment_chunk()
    settings_equipment = chunks.get_chunk(version, 'profile_popup_settings_equipment')(driver, lang=lang)
    settings_equipment.assert_section_device_radio(enums.ProfileEquipmentSection.MICROPHONE)
    settings_equipment.assert_section_device_radio(enums.ProfileEquipmentSection.SPEAKERS)
    settings_equipment.assert_section_device_radio(enums.ProfileEquipmentSection.VIDEO)
    settings_equipment.assert_microphone_sensitivity_slider()
    settings_equipment.assert_speakers_volume_slider()


@allure.id("919")
@allure.title("DEV OFF. Экспортировать логи в файл")
@allure.label("owner", "Simon")
@allure.tag("web", "RFA")
@allure.story("Поддержка")
@allure.feature("Личный профиль")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_support_export_logs_file(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]

    log.tc('919')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data.get('username'), user_data.get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_profile()
    profile_popup = pages.get_page(version, 'profile_popup')(driver, lang=lang, open_page=False)
    profile_popup.open_support_chunk()
    support = chunks.get_chunk(version, 'profile_popup_support')(driver, lang=lang)
    support.assert_logging_actions_available()
    support.install_logs_download_capture()
    support.export_logs()
    support.assert_logs_exported()
    support.assert_exported_logs_file()


@allure.id("920")
@allure.title("DEV OFF. Очистить логи")
@allure.label("owner", "Simon")
@allure.tag("web", "RFA")
@allure.story("Поддержка")
@allure.feature("Личный профиль")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_support_clear_logs(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]

    log.tc('920')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data.get('username'), user_data.get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_profile()
    profile_popup = pages.get_page(version, 'profile_popup')(driver, lang=lang, open_page=False)
    profile_popup.open_support_chunk()
    support = chunks.get_chunk(version, 'profile_popup_support')(driver, lang=lang)
    support.assert_logging_actions_available()
    clear_started_at = support.get_browser_timestamp_ms()
    support.clear_logs()
    support.assert_logs_deleted()
    support.install_logs_download_capture()
    support.export_logs()
    support.assert_logs_exported()
    support.assert_exported_logs_file()
    support.assert_no_exported_logs_before(clear_started_at)


@allure.id("462")
@allure.title("Активировать develop режим")
@allure.label("owner", "Simon")
@allure.tag("RFA", "web")
@allure.story("О приложении")
@allure.feature("Личный профиль")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.xfail(reason='IVAONE-12561 [Web] Личный профиль. При активации режима разработчика перепутаны подсказки в тост-уведомлении')
def test_activate_develop_mode(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]

    log.tc('462')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data.get('username'), user_data.get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.assert_section_active('chat', 'Открыта главная страница на вкладке "Чаты"')
    left_menu.open_profile()
    profile_popup = pages.get_page(version, 'profile_popup')(driver, lang=lang, open_page=False)
    profile_popup.open_account_chunk()
    profile_popup_account = chunks.get_chunk(version, 'profile_popup_account')(driver, lang=lang)
    profile_popup_account.assert_correct_account(user_data)
    profile_popup.open_about_chunk()
    profile_popup_about = chunks.get_chunk(version, 'profile_popup_about')(driver, lang=lang)
    profile_popup_about.assert_about_info_visible()
    profile_popup_about.click_build_version_times(6)
    profile_popup_about.assert_develop_enable_hint_visible()
    profile_popup_about.click_build_version_times(4)
    profile_popup_about.assert_develop_enabled_toast_visible()
    profile_popup.open_support_chunk()
    profile_popup_support = chunks.get_chunk(version, 'profile_popup_support')(driver, lang=lang)
    profile_popup_support.assert_develop_logging_options_visible()


@allure.id("921")
@allure.title("Де-активировать develop режим")
@allure.label("owner", "Simon")
@allure.tag("RFA", "web")
@allure.story("О приложении")
@allure.feature("Личный профиль")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.xfail(reason='IVAONE-12561 [Web] Личный профиль. При активации режима разработчика перепутаны подсказки в тост-уведомлении')
def test_deactivate_develop_mode(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]

    log.tc('921')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data.get('username'), user_data.get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.assert_section_active('chat', 'Открыта главная страница на вкладке "Чаты"')
    left_menu.open_profile()
    profile_popup = pages.get_page(version, 'profile_popup')(driver, lang=lang, open_page=False)
    profile_popup.open_about_chunk()
    profile_popup_about = chunks.get_chunk(version, 'profile_popup_about')(driver, lang=lang)
    profile_popup_about.enable_develop_mode()
    profile_popup.open_account_chunk()
    profile_popup_account = chunks.get_chunk(version, 'profile_popup_account')(driver, lang=lang)
    profile_popup_account.assert_correct_account(user_data)
    profile_popup.open_about_chunk()
    profile_popup_about.assert_about_info_visible()
    profile_popup_about.click_build_version_times(6)
    profile_popup_about.assert_develop_disable_hint_visible()
    profile_popup_about.click_build_version_times(4)
    profile_popup_about.assert_develop_disabled_toast_visible()
    profile_popup.open_support_chunk()
    profile_popup_support = chunks.get_chunk(version, 'profile_popup_support')(driver, lang=lang)
    profile_popup_support.assert_standard_logging_view()
