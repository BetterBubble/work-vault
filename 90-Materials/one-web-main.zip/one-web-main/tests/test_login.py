import allure
import pytest

from autocore.test.logger import get_log
from tools.helpers.session import web_preamble
from tests import pages
from tests.pages import chunks


log = get_log()


@allure.id("36760")
@allure.title("Авторизация за пользователя. Успешная авторизация")
@allure.label("owner", "Simon")
@allure.feature("Авторизация")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.qaauto_smoke
def test_login_success_auth(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]

    log.tc('36760')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data.get('username'), user_data.get('password'), check_values=True)
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_profile()
    profile_popup = pages.get_page(version, 'profile_popup')(driver, lang=lang, open_page=False)
    profile_popup.open_account_chunk()
    profile_popup_account = chunks.get_chunk(version, 'profile_popup_account')(driver, lang=lang)
    profile_popup_account.assert_correct_account(user_data)


@allure.id("36761")
@allure.title("Авторизация за пользователя. Неправильный логин")
@allure.label("owner", "Simon")
@allure.feature("Авторизация")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_login_wrong_username_auth(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]

    log.tc('36761')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login('wrong_username', user_data.get('password'), check_values=True, allow_notifications=False)
    login_page.check_wrong_auth_text()


@allure.id("36762")
@allure.title("Авторизация за пользователя. Неправильный пароль")
@allure.label("owner", "Simon")
@allure.feature("Авторизация")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_login_wrong_password_auth(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]

    log.tc('36762')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data.get('username'), 'wrong_password', check_values=True, allow_notifications=False)
    login_page.check_wrong_auth_text()


@allure.id("36765")
@allure.title("Авторизация за пользователя. Успешная авторизация-логаут-авторизация")
@allure.label("owner", "Simon")
@allure.feature("Авторизация")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_login_relogin(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]

    log.tc('36765')

    allow_notifications = True
    for i in range(2):
        login_page = pages.get_page(version, 'login')(driver, lang=lang)
        login_page.login(user_data.get('username'), user_data.get('password'), allow_notifications=allow_notifications)
        left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
        left_menu.open_profile()
        profile_popup = pages.get_page(version, 'profile_popup')(driver, lang=lang, open_page=False)
        profile_popup.open_account_chunk()
        profile_popup_account = chunks.get_chunk(version, 'profile_popup_account')(driver, lang=lang)
        profile_popup_account.assert_correct_account(user_data)
        if i == 0:
            profile_popup_account.logout()
            allow_notifications = False


@allure.id("36766")
@allure.title("Авторизация за пользователя. Успешная авторизация-логаут-авторизация за пользователя 2")
@allure.label("owner", "Simon")
@allure.feature("Авторизация")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_login_two_users(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory

    log.tc('36766')

    allow_notifications = True
    for i, user in enumerate(users_data):
        login_page = pages.get_page(version, 'login')(driver, lang=lang)
        login_page.login(users_data[i].get('username'), users_data[i].get('password'), allow_notifications=allow_notifications)
        left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
        left_menu.open_profile()
        profile_popup = pages.get_page(version, 'profile_popup')(driver, lang=lang, open_page=False)
        profile_popup.open_account_chunk()
        profile_popup_account = chunks.get_chunk(version, 'profile_popup_account')(driver, lang=lang)
        profile_popup_account.assert_correct_account(users_data[i])
        if i == 0:
            profile_popup_account.logout()
            allow_notifications = False


@allure.id("36767")
@allure.title("Авторизация за пользователя. Пустые поля")
@allure.label("owner", "Simon")
@allure.feature("Авторизация")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_login_empty_inputs_auth(setup_aut, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)

    log.tc('36767')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login('', '', allow_notifications=False)
    login_page.check_wrong_auth_text()

