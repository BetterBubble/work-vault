import time
from autocore.test.logger import get_log
from autocore import driver_sessions
from autocore.selenoid.tools.recognize import check_video
from autocore.test.generate_data import get_random_string, generate_email
from autocore.selenoid import Selenoid
from autocore.clients import rest
from autocore.clients.rest import iva_one
from autocore.clients.postgres import toggle_webrtc_simulcast
from conftest import BROWSER_DATA_DIR
from consts import IVA_MCU_CLIENT_SECRET


log = get_log()


def test_basic_video(setup_multiple_auts, teardown):
    aut_init_list = [
        {'fake_video_file_path': f'{BROWSER_DATA_DIR}/video_user_1.mjpeg'},
        {'fake_video_file_path': f'{BROWSER_DATA_DIR}/video_user_2.mjpeg'}
    ]

    auts = setup_multiple_auts(2, aut_init_list)
    iva_one_config = auts['setup']['config']
    iva_one_web_realm = iva_one_config['web-realm']
    iva_one_admin_creds = iva_one_config['credentials']['admin']
    mcu_config = auts['setup']['config']['integrated-services']['mcu']
    mcu_url = mcu_config['web_url']
    mcu_db_conf = mcu_config['credentials']['db']

    log.tc('test_basic_video')
    toggle_webrtc_simulcast(enabled=False, db=mcu_db_conf)  # TODO: VCSAT-859
    log.step(f"Создадим пользователя", where="IVA ONE REST API")
    iva_one_user = get_random_string()
    iva_one_user_email = generate_email()
    iva_one_user_password = '1'

    admin_token = iva_one.login(**iva_one_admin_creds)
    iva_one.create_user(admin_token, iva_one_web_realm, iva_one_user, iva_one_user_email)
    iva_one.set_user_password(admin_token, iva_one_web_realm, iva_one_user, iva_one_user_password)

    teardown.append(lambda: iva_one.delete_user(realm=iva_one_web_realm, username=iva_one_user))

    log.step(f"Создадим мероприятие", where="REST API")
    user_token = iva_one.login(username=iva_one_user, password=iva_one_user_password,
                               realm='IVA', client_id='iva-mcu', client_secret=IVA_MCU_CLIENT_SECRET)
    meeting_response = rest.create_meeting(iva_one_user, start=0, get_conf_number=False,
                                           token=user_token, url=mcu_url, db=mcu_db_conf)

    conf_id = meeting_response['conferenceId']
    meeting_id = meeting_response['conferenceNumber']

    driver1, driver2 = auts['driver']
    teardown.append(lambda: driver1.quit())
    teardown.append(lambda: driver2.quit())
    teardown.append(lambda: rest.delete_meeting(iva_one_user, conf_id, mcu_url, user_token))

    log.step(f"Подключимся к мероприятию", where="IVA WEB Клиент")

    selenoid = Selenoid(driver1)
    selenoid.open_url(mcu_url)
    selenoid.login_by_id(meeting_id)
    selenoid.click_video_button()

    selenoid2 = Selenoid(driver2)
    driver_sessions.set_active(driver2)
    selenoid2.open_url(mcu_url)
    selenoid2.login_by_id(meeting_id)
    selenoid2.click_video_button()
    driver_sessions.set_active(driver1)

    time.sleep(5)
    log.step(f"Проверка отображения видео", where="IVA WEB Клиент")
    check_video([driver1, driver2])
