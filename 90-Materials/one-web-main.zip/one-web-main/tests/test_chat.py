import os

import allure
import pytest

from autocore.test.logger import get_log
from autocore.test.generate_data import get_random_string
from autocore import driver_sessions
from autocore.clients.rest import iva_one
from autocore.consts import TEST_DATA_DIR
from tools import i18n
from tools.helpers import build_chat_link
from tools.helpers import network
from tools.helpers import media_chat
from tools.helpers.centrifugo import CentrifugoListener
from tools.helpers.chat_setup import wait_favorites_chat_materialized, wait_group_chat_materialized
from tools.helpers.session import web_preamble, iva_one_web_login, relogin_session
from tests import pages
from tests.pages import chunks
from conftest import BROWSER_DATA_DIR

log = get_log()


@allure.id("2393")
@allure.title("Написать сообщение в личный чат")
@allure.label("owner", "Simon")
@allure.tag("web")
@allure.story("Личный чат")
@allure.label("IVAQA", "IVAONE-8981", "IVAONE-9913")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_chat_send_receive_message(setup_multiple_auts, users_factory, teardown):
    auts = setup_multiple_auts(2)
    lang = auts['setup']['cmd']['lang']
    version = auts['setup']['cmd']['ver']
    users_data = users_factory
    usernames = [creds['username'] for creds in users_data]
    token = iva_one_web_login(auts, users_data[0])
    iva_one.create_p2p_chat(token, usernames[1])
    message = get_random_string(10)
    driver, driver_2 = auts['driver']
    teardown.append((lambda el: el.quit(), driver))
    teardown.append((lambda el: el.quit(), driver_2))

    log.tc('2393')

    driver_sessions.set_active(driver)
    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(usernames[0], users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    user1_chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    user1_chats = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    user1_chats_list.open_chat(users_data[1]['last_name'])
    user1_chats.assert_chat_with_chat_name_opened(users_data[1]['last_name'])

    driver_sessions.set_active(driver_2)
    login_page = pages.get_page(version, 'login')(driver_2, lang=lang)
    login_page.login(usernames[1], users_data[1].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver_2, lang=lang)
    left_menu.open_chats()
    user2_chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver_2, lang=lang)
    user2_chats = pages.get_page(version, 'chat')(driver_2, lang=lang, open_page=False)
    user2_chats_list.open_chat(users_data[0]['last_name'])

    user2_chats.send_text_message(message)
    user2_chats.assert_sent_message_exists(message)

    driver_sessions.set_active(driver)
    user1_chats.assert_sent_message_exists(message)


@allure.id("418")
@allure.title("Профиль пользователя. Переход в личный чат с пользователем")
@allure.label("owner", "Simon")
@allure.tag("web")
@allure.feature("Адресная книга")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_chat_open_chat_from_contacts(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[1]
    contact_data = users_factory[0]
    message = get_random_string(10)

    log.tc('418')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data.get('username'), user_data.get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_address_book()
    address_book = chunks.get_chunk(version, 'address_book')(driver, lang=lang, check_primary_element=False)
    address_book.open_user_profile(contact_data)
    user_profile = chunks.get_chunk(version, 'user_profile')(driver, lang=lang)
    user_profile.open_chat()
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chat.send_text_message(message)
    chat.assert_sent_message_exists(message)


@allure.id("2299")
@allure.title("Список участников чата. Свой профиль")
@allure.label("owner", "Simon")
@allure.tag("web")
@allure.story("Групповой чат")
@allure.label("IVAQA", "IVAONE-8789")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_chat_open_personal_profile_from_group_profile(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    group_chat_name = get_random_string(10)
    token = iva_one_web_login(setup_aut, users_data[0])
    chat_id = iva_one.create_chat(token, group_chat_name, [user['username'] for user in users_data])
    wait_group_chat_materialized(token, chat_id, min_members=len(users_data))

    log.tc('2299')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(group_chat_name)
    chat.open_chat_profile()
    group_chat_profile = chunks.get_chunk(version, 'group_chat_profile')(driver, lang=lang)
    group_chat_profile.open_user_profile(users_data[0]['last_name'])
    user_profile = chunks.get_chunk(version, 'user_profile')(driver, lang=lang)
    user_profile.assert_profile_sidebar_with_name_opened(users_data[0])


@allure.id("36771")
@allure.title("Личные сообщения. Ответ на чужое сообщение")
@allure.label("owner", "Simon")
@allure.story("Личный чат")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_chat_message_reply(setup_multiple_auts, users_factory, teardown):
    auts = setup_multiple_auts(2)
    lang = auts['setup']['cmd']['lang']
    version = auts['setup']['cmd']['ver']
    users_data = users_factory
    usernames = [creds['username'] for creds in users_data]
    message_1 = get_random_string(10)
    message_2 = get_random_string(10)
    token = iva_one_web_login(auts, users_data[0])
    iva_one.create_p2p_chat(token, usernames[1])
    driver, driver_2 = auts['driver']
    teardown.append((lambda el: el.quit(), driver))
    teardown.append((lambda el: el.quit(), driver_2))

    log.tc('36771')

    driver_sessions.set_active(driver)
    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(usernames[0], users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    user1_chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    user1_chats = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    user1_chats_list.open_chat(users_data[1]['last_name'])
    user1_chats.assert_chat_with_chat_name_opened(users_data[1]['last_name'])

    driver_sessions.set_active(driver_2)
    login_page = pages.get_page(version, 'login')(driver_2, lang=lang)
    login_page.login(usernames[1], users_data[1].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver_2, lang=lang)
    left_menu.open_chats()
    user2_chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver_2, lang=lang)
    user2_chats = pages.get_page(version, 'chat')(driver_2, lang=lang, open_page=False)
    user2_chats_list.open_chat(users_data[0]['last_name'])

    user2_chats.send_text_message(message_1)
    user2_chats.assert_sent_message_exists(message_1)

    driver_sessions.set_active(driver)
    user1_chats.select_message_for_reply(message_1)
    user1_chats.send_text_message(message_2)
    user1_chats.assert_sent_message_exists(message_2)
    user1_chats.assert_sent_message_is_reply_for(message_2, message_1)


@allure.id("2375")
@allure.title("Переключение чатов в списке чатов")
@allure.label("owner", "Simon")
@allure.tag("web", "RFA")
@allure.story("Список чатов")
@allure.label("IVAQA", "IVAONE-8994", "IVAONE-9909")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_chat_switch_p2p_chats_inputs_availlable(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    group_chat_name = get_random_string(10)
    p2p_chat_user_data = users_data[1]
    token = iva_one_web_login(setup_aut, users_data[0])
    iva_one.create_p2p_chat(token, p2p_chat_user_data['username'])
    iva_one.create_chat(token, group_chat_name, [user['username'] for user in users_data])

    log.tc('2375')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(p2p_chat_user_data['last_name'])
    chat.assert_input(available=True)
    chats_list.open_chat(group_chat_name)
    chat.assert_input(available=True)


@allure.id("2261")
@allure.title("Переслать текстовое сообщение в чате")
@allure.tag("web", "RFA")
@allure.story("Инпут ввода")
@allure.feature("Чаты")
@allure.label("owner", "Vitaly")
@allure.label("IVAQA", "IVAONE-8728", "IVAONE-9913")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_chat_forward_text_message(setup_aut, users_factory, teardown):
    """Тест на пересылку текстового сообщения в чате"""
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]
    p2p_chat_user_data = users_factory[1]

    # Создать p2p чат между пользователями. Собеседник должен войти в web —
    # иначе chat-service не индексирует его в поиске чатов, и диалог пересылки
    # не найдёт чат; после логинов дожидаемся индексации (асинхронная, ~20-60s).
    iva_one_web_login(setup_aut, p2p_chat_user_data)
    token = iva_one_web_login(setup_aut, user_data)
    iva_one.create_p2p_chat(token, p2p_chat_user_data['username'])
    p2p_full_name = f'{p2p_chat_user_data["last_name"]} {p2p_chat_user_data["first_name"]}'
    iva_one.wait_user_in_chat_search(token, p2p_full_name)

    # Сообщение для пересылки
    message = get_random_string(10)

    log.tc('2261')

    # Авторизация
    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])

    # Открыть чаты
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()

    # Открыть чат с пользователем
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(p2p_chat_user_data['last_name'])

    # Написать и отправить сообщение
    chat.send_text_message(message)
    chat.assert_sent_message_exists(message)

    # Переслать сообщение в тот же чат
    chat.forward_message(message, p2p_chat_user_data['last_name'])

    # Проверить что сообщение переслано
    chat.assert_message_is_forwarded(message)


@allure.id("273")
@allure.title("Переход к цитируемому сообщению в глубь чата")
@allure.tag("web", "RFA")
@allure.story("Инпут ввода")
@allure.feature("Чаты")
@allure.label("owner", "Simon")
@allure.label("IVAQA", "IVAONE-8728", "IVAONE-9913")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_chat_quote_navigation_to_parent_message(setup_aut, users_factory, teardown):
    """Проверить переход к цитируемому сообщению вглубь чата по клику на цитату"""

    # 1. Arrange - подготовка
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory

    # 2. API предусловия - создать групповой чат с обоими пользователями
    group_chat_name = get_random_string(10)
    token = iva_one_web_login(setup_aut, users_data[0])
    chat_id = iva_one.create_chat(token, group_chat_name, [user['username'] for user in users_data])

    # 3. API предусловия - отправить 100 сообщений через API
    messages = []
    for i in range(100):
        message = get_random_string(10)
        messages.append(message)
        iva_one.send_message(token, chat_id, message)

    log.tc('273')

    # 4. Шаг 1 - Авторизация WEB
    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0]['username'], users_data[0]['password'])

    # 5. Шаг 2 - Переход в групповой чат
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()

    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(group_chat_name)

    # 6. Шаг 3 - Написать цитату на первое сообщение чата
    first_message = messages[0]

    chat.select_message_for_reply(first_message)
    reply_message = get_random_string(10)
    chat.send_text_message(reply_message)
    chat.assert_sent_message_exists(reply_message)

    # 7. Шаг 4 - Сделать ЛКМ клик по цитате в цитируемом сообщении
    chat.assert_sent_message_is_reply_for(reply_message, first_message)


@allure.id("2354")
@allure.title("Редактировать сообщение с ссылкой")
@allure.tag("web", "RFA")
@allure.story("Инпут ввода")
@allure.feature("Чаты")
@allure.label("owner", "Simon")
@allure.label("IVAQA", "IVAONE-8728", "IVAONE-8760", "IVAONE-9913")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_chat_edit_link_message(setup_aut, users_factory, teardown):
    """Проверить функционал редактирования ссылки с различным отображаемым и реальным её контентом"""

    # 1. Arrange - подготовка
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory

    # 2. API предусловия - создать групповой чат с обоими пользователями
    group_chat_name = get_random_string(10)
    token = iva_one_web_login(setup_aut, users_data[0])
    chat_id = iva_one.create_chat(token, group_chat_name, [user['username'] for user in users_data])

    # 3. API предусловия - отправить сообщение со ссылкой через API
    visual_url = 'https://files.hi-tech.org'
    real_url = 'http://10.0.207.100'
    iva_one.send_message(token, chat_id, visual_url, 'link')

    log.tc('2354')

    # 4. Шаг 1 - Авторизация WEB
    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0]['username'], users_data[0]['password'])

    # 5. Шаг 2 - Переход в групповой чат
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()

    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(group_chat_name)

    # 6. Шаг 3 - Редактировать ссылку, оставив текст без изменений
    chat.open_bubble_context_menu_by_visual_link(visual_url)
    chat.click_edit_message_in_context_menu()
    chat.click_edit_link_in_input()
    chat_input_edit_link_popup = pages.get_page(version, 'chat_input_edit_link_popup')(driver, lang=lang)
    chat_input_edit_link_popup.edit_link(real_url)
    chat_input_edit_link_popup.confirm()
    chat.send('enter')

    # 7. Шаг 4 - Перейти по ссылке в баббле сообщения и убедиться, что открылась страница с real_url
    chat.click_link_in_message(visual_url)
    chat.assert_link_redirect_correct(real_url)


@allure.id("1257")
@allure.title("Выбрать сообщение в групповом чате")
@allure.tag("web", "RFA")
@allure.story("Групповой чат")
@allure.label("owner", "Vitaly")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_select_message_in_group_chat(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    group_chat_name = get_random_string(10)
    message = get_random_string(10)
    token = iva_one_web_login(setup_aut, users_data[0])
    chat_id = iva_one.create_chat(token, group_chat_name, [user['username'] for user in users_data])
    iva_one.send_message(token, chat_id, message)

    log.tc('1257')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(group_chat_name)
    chat.open_bubble_context_menu_by_text(message)
    chat.click_select_in_context_menu()
    chat.assert_select_mode_toolbar_visible()


@allure.id("1261")
@allure.title("Просмотр реакций пользователей в сообщении")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Групповой чат")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_chat_view_message_reaction_users(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    group_chat_name = get_random_string(10)
    message_text = get_random_string(10)

    token_user_1 = iva_one_web_login(setup_aut, users_data[0])
    token_user_2 = iva_one_web_login(setup_aut, users_data[1])
    chat_id = iva_one.create_chat(token_user_1, group_chat_name, [user['username'] for user in users_data], has_reactions=True)
    sent_message = iva_one.send_message(token_user_1, chat_id, message_text)
    message_id = sent_message['id']
    iva_one.set_message_reaction(token_user_2, message_id)


    log.tc('1261')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(group_chat_name)

    chat.assert_sent_message_exists(message_text)
    chat.open_bubble_context_menu_by_text(message_text)
    chat.hover_reactions_in_context_menu()
    chat.assert_reaction_user_visible(users_data[1]['last_name'])


@allure.id("351")
@allure.title("Выгнать пользователя из группового  чата ")
@allure.tag("web", "RFA")
@allure.story("Групповой чат")
@allure.feature("Чаты")
@allure.label("owner", "Vitaly")
@allure.label("IVAQA", "IVAONE-6528", "IVAONE-7727", "IVAONE-8102")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_group_chat_kick_member(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    group_chat_name = get_random_string(10)
    token = iva_one_web_login(setup_aut, users_data[0])
    chat_id = iva_one.create_chat(token, group_chat_name, [user['username'] for user in users_data])
    wait_group_chat_materialized(token, chat_id, min_members=len(users_data))

    log.tc('351')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0]['username'], users_data[0]['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(group_chat_name)
    chat.open_chat_profile()
    group_chat_profile = chunks.get_chunk(version, 'group_chat_profile')(driver, lang=lang)
    group_chat_profile.open_member_context_menu(users_data[1]['last_name'])
    group_chat_profile.click_kick_member_in_context_menu()
    group_chat_profile.assert_user_not_in_profile_list(users_data[1]['last_name'])

    driver = relogin_session(setup_aut, teardown)

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[1]['username'], users_data[1]['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chats_list.assert_chat_not_in_list(group_chat_name)


@allure.id("702")
@allure.title("Групповой чат отправить сообщение")
@allure.tag("web", "RFA")
@allure.story("Групповой чат")
@allure.feature("Чаты")
@allure.label("owner", "Vitaly")
@allure.label("IVAQA", "IVAONE-7489", "IVAONE-8102", "IVAONE-8107", "IVAONE-8151", "IVAONE-8537", "IVAONE-8543", "IVAONE-8805")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_group_chat_send_message(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    group_chat_name = get_random_string(10)
    message = get_random_string(10)
    token = iva_one_web_login(setup_aut, users_data[0])
    iva_one.create_chat(token, group_chat_name, [user['username'] for user in users_data])

    log.tc('702')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(group_chat_name)
    chat.type_message(message)
    chat.send('click')
    chat.assert_sent_message_exists(message)
    chat.assert_sent_message_status_is_sent(message)


@allure.id("709")
@allure.title("Групповой чат. Передать права администратора")
@allure.tag("web", "RFA")
@allure.story("Групповой чат")
@allure.label("owner", "Vitaly")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_group_chat_transfer_admin_rights(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    group_chat_name = get_random_string(10)
    token = iva_one_web_login(setup_aut, users_data[0])
    chat_id = iva_one.create_chat(token, group_chat_name, [user['username'] for user in users_data])
    wait_group_chat_materialized(token, chat_id, min_members=len(users_data))

    log.tc('709')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(group_chat_name)
    chat.open_chat_profile()
    group_chat_profile = chunks.get_chunk(version, 'group_chat_profile')(driver, lang=lang)
    group_chat_profile.open_member_context_menu(users_data[1].get('last_name'))
    group_chat_profile.click_make_admin_in_context_menu()
    group_chat_profile.assert_user_is_admin(users_data[1].get('last_name'))


@allure.id("710")
@allure.title("Групповой чат. Передать права владельца")
@allure.tag("web", "RFA")
@allure.label("owner", "Vitaly")
@allure.story("Групповой чат")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_group_chat_transfer_owner_rights(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    group_chat_name = get_random_string(10)
    token = iva_one_web_login(setup_aut, users_data[0])
    chat_id = iva_one.create_chat(token, group_chat_name, [user['username'] for user in users_data])
    wait_group_chat_materialized(token, chat_id, min_members=len(users_data))

    log.tc('710')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(group_chat_name)
    chat.open_chat_profile()
    group_chat_profile = chunks.get_chunk(version, 'group_chat_profile')(driver, lang=lang)
    group_chat_profile.open_member_context_menu(users_data[1].get('last_name'))
    group_chat_profile.click_transfer_owner_in_context_menu()
    group_chat_profile.confirm_transfer_owner()
    group_chat_profile.assert_user_is_owner(users_data[1].get('last_name'))


@allure.id("966")
@allure.title("Групповой чат. Поиск сообщений")
@allure.tag("RFA", "web")
@allure.label("owner", "Vitaly")
@allure.story("Групповой чат")
@allure.label("IVAQA", "https://jira.iva.ru/browse/IVAONE-7670")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_group_chat_search_messages(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    group_chat_name = get_random_string(10)
    search_text = get_random_string(8)
    token = iva_one_web_login(setup_aut, users_data[0])
    chat_id = iva_one.create_chat(token, group_chat_name, [user['username'] for user in users_data])
    iva_one.send_message(token, chat_id, search_text)
    for _ in range(19):
        iva_one.send_message(token, chat_id, get_random_string(8))

    log.tc('966')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(group_chat_name)
    chat.click_search_btn()
    chat.assert_search_panel_visible()
    chat.search_message(search_text)
    chat.assert_message_found_in_search(search_text)


@allure.id("950")
@allure.title("Групповой чат. Упоминание пользователя")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Групповой чат")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_group_chat_mention_user(setup_multiple_auts, users_factory, teardown):
    auts = setup_multiple_auts(2)
    lang = auts['setup']['cmd']['lang']
    version = auts['setup']['cmd']['ver']
    users_data = users_factory
    group_chat_name = get_random_string(10)
    token = iva_one_web_login(auts, users_data[0])
    chat_id = iva_one.create_chat(token, group_chat_name, [user['username'] for user in users_data])
    iva_one.create_p2p_chat(token, users_data[1]['username'])
    driver, driver_2 = auts['driver']
    teardown.append((lambda el: el.quit(), driver))
    teardown.append((lambda el: el.quit(), driver_2))

    log.tc('950')

    driver_sessions.set_active(driver)
    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(group_chat_name)
    chat.assert_chat_with_chat_name_opened(group_chat_name)

    driver_sessions.set_active(driver_2)
    login_page_2 = pages.get_page(version, 'login')(driver_2, lang=lang)
    login_page_2.login(users_data[1].get('username'), users_data[1].get('password'))
    left_menu_2 = chunks.get_chunk(version, 'left_menu')(driver_2, lang=lang)
    left_menu_2.open_chats()
    chats_list_2 = chunks.get_chunk(version, 'chats_list')(driver=driver_2, lang=lang)
    chat_2 = pages.get_page(version, 'chat')(driver_2, lang=lang, open_page=False)
    chats_list_2.open_chat(users_data[0].get('last_name'))
    chat_2.assert_chat_with_chat_name_opened(users_data[0].get('last_name'))

    driver_sessions.set_active(driver)
    # Филлеры ДО упоминания: чат открывается на разделителе «Непрочитанные», и упоминание,
    # отправленное первым непрочитанным, сразу попадает во вьюпорт и читается — шеврон не появляется.
    for _ in range(50):
        iva_one.send_message(token, chat_id, get_random_string(8))
    chat.type_mention(users_data[1].get('last_name'))
    chat.assert_mention_popup_visible()
    chat.select_user_in_mention_popup(users_data[1].get('last_name'))
    chat.assert_mention_in_input(users_data[1].get('last_name'))
    chat.send(mode='click')
    chat.assert_mention_in_message(users_data[1].get('last_name'))

    driver_sessions.set_active(driver_2)
    chats_list_2.assert_mention_badge_visible(group_chat_name)
    chats_list_2.open_chat(group_chat_name)
    chat_2.assert_mention_chevron_visible()
    chat_2.click_mention_chevron()
    chat_2.assert_mention_in_message(users_data[1].get('last_name'))


@allure.id("52423")
@allure.title("ПКМ по упоминанию пользователя. Групповой чат.")
@allure.label("owner", "Simon")
@allure.tag("RFA")
@allure.story("Инпут ввода")
@allure.label("IVAQA", "IVAONE-12109")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_group_chat_mention_context_menu_no_copy_link(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    chat_name = get_random_string(10)
    message_text = 'Данное сообщение скопировать'
    token = iva_one_web_login(setup_aut, users_data[0])
    iva_one.create_chat(
        token,
        chat_name,
        [user['username'] for user in users_data],
        type=iva_one.ChatTypes.GROUP,
    )
    # Прогрев упоминаемого пользователя, чтобы он гарантированно резолвился в попапе @-упоминания
    iva_one_web_login(setup_aut, users_data[1])

    log.tc('52423')

    mentioned_user = users_data[1].get('last_name')
    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(chat_name)
    chat.type_mention(mentioned_user)
    chat.assert_mention_popup_visible()
    chat.select_user_in_mention_popup(mentioned_user)
    chat.assert_mention_in_input(mentioned_user)
    chat.type_message(f' {message_text}', check_value=False)
    chat.send(mode='enter')
    chat.assert_mention_in_message(mentioned_user)
    chat.assert_mention_color_differs_from_text(mentioned_user, message_text)
    chat.open_context_menu_on_mention(mentioned_user)
    chat.assert_copy_link_menu_item_absent()


@allure.id("52424")
@allure.title("ПКМ по упоминанию пользователя. Информационный канал.")
@allure.label("owner", "Simon")
@allure.tag("RFA")
@allure.story("Инпут ввода")
@allure.label("IVAQA", "IVAONE-12109")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_info_channel_mention_context_menu_no_copy_link(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    channel_name = get_random_string(10)
    message_text = 'Данное сообщение скопировать'
    token = iva_one_web_login(setup_aut, users_data[0])
    iva_one.create_chat(
        token,
        channel_name,
        [user['username'] for user in users_data],
        type=iva_one.ChatTypes.CHANNEL,
    )
    # Прогрев упоминаемого пользователя, чтобы он гарантированно резолвился в попапе @-упоминания
    iva_one_web_login(setup_aut, users_data[1])

    log.tc('52424')

    mentioned_user = users_data[1].get('last_name')
    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(channel_name)
    chat.type_mention(mentioned_user)
    chat.assert_mention_popup_visible()
    chat.select_user_in_mention_popup(mentioned_user)
    chat.assert_mention_in_input(mentioned_user)
    chat.type_message(f' {message_text}', check_value=False)
    chat.send(mode='enter')
    chat.assert_mention_in_message(mentioned_user)
    chat.assert_mention_color_differs_from_text(mentioned_user, message_text)
    chat.open_context_menu_on_mention(mentioned_user)
    chat.assert_copy_link_menu_item_absent()


@allure.id("52478")
@allure.title("Скопировать сообщение. Скопировать ссылку")
@allure.label("owner", "Simon")
@allure.tag("RFA")
@allure.story("Инпут ввода")
@allure.label("IVAQA", "IVAONE-12109")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_group_chat_link_context_menu_has_copy_link(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    chat_name = get_random_string(10)
    typed_url = 'www.allure.iva.ru'
    visible_link = 'https://www.allure.iva.ru'
    message_text = 'Данное сообщение скопировать'
    token = iva_one_web_login(setup_aut, users_data[0])
    iva_one.create_chat(
        token,
        chat_name,
        [user['username'] for user in users_data],
        type=iva_one.ChatTypes.GROUP,
    )

    log.tc('52478')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(chat_name)
    # Ввод URL + пробел превращает текст в ссылку (видимый текст — с префиксом https://).
    # NB: на Firefox падает — geckodriver send_keys не триггерит ProseMirror-линкификацию URL
    # в contenteditable (на Chromium/Safari работает). Воспроизвести авто-линк в UI на FF нельзя.
    chat.type_message(typed_url, check_value=False)
    chat.type_message(f' {message_text}', check_value=False)
    chat.send(mode='enter')
    chat.assert_link_in_message(visible_link)
    chat.assert_link_color_differs_from_text(visible_link, message_text)
    chat.open_context_menu_on_link(visible_link)
    chat.assert_copy_link_menu_item_visible()


@allure.id("52436")
@allure.title("ПКМ по упоминанию пользователя.  Тред.")
@allure.label("owner", "Simon")
@allure.tag("RFA")
@allure.story("Инпут ввода")
@allure.label("IVAQA", "IVAONE-12109")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_thread_mention_context_menu_no_copy_link(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    chat_name = get_random_string(10)
    parent_message_text = get_random_string(10)
    message_text = 'Данное сообщение скопировать'
    token = iva_one_web_login(setup_aut, users_data[0])
    chat_id = iva_one.create_chat(
        token,
        chat_name,
        [user['username'] for user in users_data],
        type=iva_one.ChatTypes.GROUP,
        has_threads=True,
    )
    # Прогрев упоминаемого пользователя, чтобы он гарантированно резолвился в попапе @-упоминания
    iva_one_web_login(setup_aut, users_data[1])
    # Родительское сообщение, по которому стартуем тред
    iva_one.send_message(token, chat_id, parent_message_text)

    log.tc('52436')

    mentioned_user = users_data[1].get('last_name')
    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(chat_name)
    chat.open_bubble_context_menu_by_text(parent_message_text)
    chat.click_start_thread_button_in_context_menu()
    chat.type_thread_mention(mentioned_user)
    chat.assert_mention_popup_visible()
    chat.select_user_in_mention_popup(mentioned_user)
    chat.type_thread_message(f' {message_text}', check_value=False)
    chat.send_thread_message()
    chat.assert_mention_in_message(mentioned_user)
    chat.assert_mention_color_differs_from_text(mentioned_user, message_text)
    chat.open_context_menu_on_mention(mentioned_user)
    chat.assert_copy_link_menu_item_absent()


@allure.id("52437")
@allure.title("ПКМ по упоминанию пользователя. Личный чат.")
@allure.label("owner", "Simon")
@allure.tag("RFA")
@allure.story("Инпут ввода")
@allure.label("IVAQA", "IVAONE-12109")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_p2p_chat_mention_context_menu_no_copy_link(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    message_text = 'Данное сообщение скопировать'
    token = iva_one_web_login(setup_aut, users_data[0])
    # create_p2p_chat ретраит отправку до материализации direct-чата (~20-60s на свежих юзерах)
    iva_one.create_p2p_chat(token, users_data[1]['username'])
    # Прогрев собеседника, чтобы он гарантированно резолвился в попапе @-упоминания
    iva_one_web_login(setup_aut, users_data[1])

    log.tc('52437')

    mentioned_user = users_data[1].get('last_name')
    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(mentioned_user)
    # В личном чате собеседник появляется в попапе только по одиночному "@" (без фильтра по имени)
    chat.trigger_mention_popup()
    chat.assert_mention_popup_visible()
    chat.select_user_in_mention_popup(mentioned_user)
    chat.assert_mention_in_input(mentioned_user)
    chat.type_message(f' {message_text}', check_value=False)
    chat.send(mode='enter')
    chat.assert_mention_in_message(mentioned_user)
    chat.assert_mention_color_differs_from_text(mentioned_user, message_text)
    chat.open_context_menu_on_mention(mentioned_user)
    chat.assert_copy_link_menu_item_absent()


@allure.id("1310")
@allure.title("Закрепить сообщение в групповом чате")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Групповой чат")
@allure.label("IVAQA", "IVAONE-6528", "IVAONE-8287")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_group_chat_pin_message(setup_multiple_auts, users_factory, teardown):
    auts = setup_multiple_auts(2)
    lang = auts['setup']['cmd']['lang']
    version = auts['setup']['cmd']['ver']
    users_data = users_factory
    group_chat_name = get_random_string(10)
    message = get_random_string(10)
    token = iva_one_web_login(auts, users_data[0])
    iva_one.create_p2p_chat(token, users_data[1]['username'])
    group_chat_id = iva_one.create_chat(token, group_chat_name, [user['username'] for user in users_data])
    iva_one.send_message(token, group_chat_id, message)
    driver, driver_2 = auts['driver']
    teardown.append((lambda el: el.quit(), driver))
    teardown.append((lambda el: el.quit(), driver_2))

    log.tc('1310')

    driver_sessions.set_active(driver_2)
    login_page = pages.get_page(version, 'login')(driver_2, lang=lang)
    login_page.login(users_data[1].get('username'), users_data[1].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver_2, lang=lang)
    left_menu.open_chats()
    chats_list_2 = chunks.get_chunk(version, 'chats_list')(driver=driver_2, lang=lang)
    chat_2 = pages.get_page(version, 'chat')(driver_2, lang=lang, open_page=False)
    chats_list_2.open_chat(group_chat_name)
    chat_2.assert_chat_with_chat_name_opened(group_chat_name)
    chats_list_2.open_chat(users_data[0].get('last_name'))
    chat_2.assert_chat_with_chat_name_opened(users_data[0].get('last_name'))

    driver_sessions.set_active(driver)
    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(group_chat_name)
    chat.open_bubble_context_menu_by_text(message)
    chat.click_pin_in_context_menu()
    chat.assert_message_is_pinned(message)
    user1_display_name = f"{users_data[0]['last_name']} {users_data[0]['first_name']}"
    chat.assert_pin_system_message_exists(user1_display_name)

    driver_sessions.set_active(driver_2)
    chats_list_2.assert_unread_badge_visible(group_chat_name)
    chats_list_2.open_chat(group_chat_name)
    chat_2.assert_pin_system_message_exists(user1_display_name)


@allure.id("1150")
@allure.title("Перейти к закрепленному сообщению")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Групповой чат")
@allure.label("IVAQA", "https://jira.iva.ru/browse/IVAONE-8832")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_go_to_pinned_message(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    group_chat_name = get_random_string(10)
    pinned_message_text = get_random_string(10)
    token = iva_one_web_login(setup_aut, users_data[0])
    chat_id = iva_one.create_chat(token, group_chat_name, [user['username'] for user in users_data])
    first_msg = iva_one.send_message(token, chat_id, pinned_message_text)
    for _ in range(49):
        iva_one.send_message(token, chat_id, get_random_string(10))
    message_id = first_msg.get('id')
    iva_one.pin_message(token, message_id)

    log.tc('1150')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(group_chat_name)
    chat.assert_message_is_pinned(pinned_message_text)
    chat.click_pinned_message(pinned_message_text)
    chat.assert_message_highlighted(pinned_message_text)


@allure.id("2303")
@allure.title("Область чата. Свой профиль")
@allure.label("owner", "Simon")
@allure.tag("RFA", "web")
@allure.story("Групповой чат")
@allure.label("IVAQA", "IVAONE-8789")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_chat_area_own_profile(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    group_chat_name = get_random_string(10)
    message_text = get_random_string(10)
    token = iva_one_web_login(setup_aut, users_data[0])
    chat_id = iva_one.create_chat(token, group_chat_name, [user['username'] for user in users_data])
    iva_one.send_message(token, chat_id, message_text)

    log.tc('2303')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(group_chat_name)
    chat.click_own_message_avatar()
    user_profile = chunks.get_chunk(version, 'user_profile')(driver, lang=lang)
    user_profile.assert_profile_sidebar_with_name_opened(users_data[0])


@allure.id("1312")
@allure.title("Ответить на сообщение в групповом чате")
@allure.label("owner", "Vitaly")
@allure.tag("Desktop", "RFA", "web")
@allure.story("Групповой чат")
@allure.label("IVAQA", "IVAONE-6529", "IVAONE-8042", "IVAONE-8287")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_group_chat_message_reply(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    group_chat_name = get_random_string(10)
    original_message = get_random_string(10)
    reply_message = get_random_string(10)
    token = iva_one_web_login(setup_aut, users_data[0])
    chat_id = iva_one.create_chat(token, group_chat_name, [user['username'] for user in users_data])
    iva_one.send_message(token, chat_id, original_message)

    log.tc('1312')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(group_chat_name)
    chat.select_message_for_reply(original_message)
    chat.send_text_message(reply_message)
    chat.assert_sent_message_is_reply_for(reply_message, original_message)


@allure.id("1134")
@allure.title("Отправить аудиофайл в групповой чат")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Групповой чат")
@allure.label("IVAQA", "IVAONE-10013")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_group_chat_send_audio_file(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    group_chat_name = get_random_string(10)
    audio_file_name = 'test_audio_sample.wav'
    token = iva_one_web_login(setup_aut, users_data[0])
    iva_one.create_chat(token, group_chat_name, [user['username'] for user in users_data])

    log.tc('1134')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(group_chat_name)
    chat.attach_file(audio_file_name)
    chat.send(mode='click')
    chat.assert_audio_message_exists(audio_file_name)


@allure.id("1136")
@allure.title("Отправить голосовое сообщение в групповой чат")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Групповой чат")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.multiple_browsers
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_group_chat_send_voice_message(setup_multiple_auts, users_factory, teardown):
    aut_init_list = [
        {'fake_audio_file_path': f'{BROWSER_DATA_DIR}/test_audio_sample.wav'},
        {},
    ]
    auts = setup_multiple_auts(2, aut_init_list)
    lang = auts['setup']['cmd']['lang']
    version = auts['setup']['cmd']['ver']
    users_data = users_factory
    group_chat_name = get_random_string(10)
    token = iva_one_web_login(auts, users_data[0])
    iva_one.create_chat(token, group_chat_name, [user['username'] for user in users_data])
    iva_one.create_p2p_chat(token, users_data[1]['username'])
    decoy_chat_name = f"{users_data[0]['last_name']} {users_data[0]['first_name']}"
    driver, driver_2 = auts['driver']
    teardown.append((lambda el: el.quit(), driver))
    teardown.append((lambda el: el.quit(), driver_2))

    log.tc('1136')

    # receiver pre-login: открыть p2p decoy ПЕРЕД voice send,
    # чтобы IVA не авто-открыла target group при первом login user_b и не сбросила badge.
    driver_sessions.set_active(driver_2)
    login_page = pages.get_page(version, 'login')(driver_2, lang=lang)
    login_page.login(users_data[1]['username'], users_data[1]['password'])
    left_menu_b = chunks.get_chunk(version, 'left_menu')(driver_2, lang=lang)
    left_menu_b.open_chats()
    chats_list_b = chunks.get_chunk(version, 'chats_list')(driver=driver_2, lang=lang)
    chat_b = pages.get_page(version, 'chat')(driver_2, lang=lang, open_page=False)
    chats_list_b.open_chat(decoy_chat_name)
    chat_b.assert_chat_with_chat_name_opened(decoy_chat_name)

    driver_sessions.set_active(driver)
    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0]['username'], users_data[0]['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list_a = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat_a = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list_a.open_chat(group_chat_name)
    chat_a.click_voice_record_btn()
    chat_a.send_voice_message()
    chat_a.assert_voice_message_visible()

    driver_sessions.set_active(driver_2)
    chats_list_b.assert_unread_badge_visible(group_chat_name)
    chats_list_b.open_chat(group_chat_name)
    chat_b.assert_voice_message_visible()


@allure.id("1370")
@allure.title("Отправить видеофайл в групповой чат")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Групповой чат")
@allure.label("IVAQA", "IVAONE-10013")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_group_chat_send_video_file(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    group_chat_name = get_random_string(10)
    video_file_name = 'test_video_sample.mp4'
    token = iva_one_web_login(setup_aut, users_data[0])
    iva_one.create_chat(token, group_chat_name, [user['username'] for user in users_data])

    log.tc('1370')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(group_chat_name)
    chat.attach_file(video_file_name)
    chat.send(mode='click')
    chat.assert_video_message_exists(video_file_name)


@allure.id("1368")
@allure.title("Отправить изображение в групповой чат")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Групповой чат")
@allure.label("IVAQA", "IVAONE-10013")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_group_chat_send_image(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    group_chat_name = get_random_string(10)
    image_file_name = 'test_image_sample.jpeg'
    token = iva_one_web_login(setup_aut, users_data[0])
    iva_one.create_chat(token, group_chat_name, [user['username'] for user in users_data])

    log.tc('1368')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(group_chat_name)
    chat.attach_file(image_file_name)
    chat.send(mode='click')
    chat.assert_image_message_exists(image_file_name)


@allure.id("1369")
@allure.title("Отправить текстовый документ в групповой чат")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Групповой чат")
@allure.label("IVAQA", "https://jira.iva.ru/browse/IVAONE-10013")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_group_chat_send_text_document(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    group_chat_name = get_random_string(10)
    text_file_name = 'test_text_file_sample.txt'
    token = iva_one_web_login(setup_aut, users_data[0])
    iva_one.create_chat(token, group_chat_name, [user['username'] for user in users_data])

    log.tc('1369')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(group_chat_name)
    chat.attach_file(text_file_name)
    chat.send(mode='click')
    chat.assert_document_message_exists(text_file_name)


@allure.id("1317")
@allure.title("Редактировать сообщение в групповом чате")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Групповой чат")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_group_chat_edit_message(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    group_chat_name = get_random_string(10)
    original_message = get_random_string(10)
    edited_message = get_random_string(10)
    token = iva_one_web_login(setup_aut, users_data[0])
    chat_id = iva_one.create_chat(token, group_chat_name, [user['username'] for user in users_data])
    iva_one.send_message(token, chat_id, original_message)

    log.tc('1317')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(group_chat_name)
    chat.open_bubble_context_menu_by_text(original_message)
    chat.click_edit_message_in_context_menu()
    chat.assert_editing_container_exists(original_message)
    chat.type_message(edited_message, check_value=False)
    chat.send(mode='enter')
    chat.assert_message_is_edited(original_message + edited_message)


@allure.id("1314")
@allure.title("Переслать сообщение из группового чата")
@allure.label("owner", "Vitaly")
@allure.tag("Desktop", "RFA", "web")
@allure.story("Групповой чат")
@allure.label("IVAQA", "https://jira.iva.ru/browse/IVAONE-8042")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_group_chat_forward_message_to_favorites_preview(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    group_chat_name = get_random_string(10)
    message_for_forward = get_random_string(10)
    favorites_chat_name = i18n.get_str('favorites_chat_name', lang)
    token = iva_one_web_login(setup_aut, users_data[0])
    chat_id = iva_one.create_chat(token, group_chat_name, [user['username'] for user in users_data])
    iva_one.send_message(token, chat_id, message_for_forward)

    log.tc('1314')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(group_chat_name)
    chat.open_bubble_context_menu_by_text(message_for_forward)
    chat.click_forward_button_in_context_menu()
    chat.forward_dialog.select_chat(favorites_chat_name)
    chat.assert_forward_preview_above_input(message_for_forward)


@allure.id("2391")
@allure.title("Переслать 50 сообщений из группового чата")
@allure.label("owner", "Vitaly")
@allure.tag("Desktop", "RFA", "web")
@allure.story("Групповой чат")
@allure.label("IVAQA", "https://jira.iva.ru/browse/IVAONE-8999")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_group_chat_forward_50_messages_to_favorites(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    group_chat_name = get_random_string(10)
    messages_for_forward = [f'{get_random_string(10)}_{idx}' for idx in range(50)]
    favorites_chat_name = i18n.get_str('favorites_chat_name', lang)
    expected_author_name = f'{users_data[0]["first_name"]} {users_data[0]["last_name"]}'
    token = iva_one_web_login(setup_aut, users_data[0])
    chat_id = iva_one.create_chat(token, group_chat_name, [user['username'] for user in users_data])
    for message in messages_for_forward:
        iva_one.send_message(token, chat_id, message)

    log.tc('2391')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(group_chat_name)
    chat.open_bubble_context_menu_by_text(messages_for_forward[-1])
    chat.click_select_in_context_menu()
    chat.assert_select_mode_toolbar_visible()
    for message in reversed(messages_for_forward[:-1]):
        chat.click_selectable_message_by_text_in_select_mode(message)
    chat.click_select_mode_forward_button()
    chat.forward_dialog.select_chat(favorites_chat_name)
    chat.assert_presence(chat.L_FORWARD_PREVIEW(), 'Превью пересылаемых сообщений отображается над полем ввода')
    chat.assert_forward_preview_title_contains_count(50)
    chat.assert_forward_preview_author_names([expected_author_name])
    chat.assert_send_button_active()


@allure.id("2271")
@allure.title("Подписаться на тред в публичном канале")
@allure.label("owner", "Simon")
@allure.tag("RFA", "web")
@allure.story("Групповой чат")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_channel_thread_subscribe_non_member(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    channel_name = get_random_string(10)
    message_text = get_random_string(10)
    thread_reply_text = get_random_string(10)
    token_user_1 = iva_one_web_login(setup_aut, users_data[0])
    channel_id = iva_one.create_chat(
        token_user_1,
        channel_name,
        [users_data[0]['username']],
        type=iva_one.ChatTypes.CHANNEL,
        is_public=True,
        has_threads=True,
    )
    iva_one.send_message(token_user_1, channel_id, message_text)

    log.tc('2271')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    user1_chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    user1_chats = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    user1_chats_list.open_chat(channel_name)
    user1_chats.create_thread_reply(message_text, thread_reply_text)

    driver = relogin_session(setup_aut, teardown)

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[1].get('username'), users_data[1].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    user2_chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    user2_chats = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    user2_chats_list.search_chat(channel_name)
    user2_chats_list.open_chat_from_search(channel_name)
    user2_chats.open_thread_by_message_text(message_text)
    user2_chats.subscribe_to_thread()
    user2_chats.assert_thread_subscribed()


@allure.id("833")
@allure.title("Начать тред в информационном канале")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Информационный канал")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_channel_thread_start(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]
    channel_name = get_random_string(10)
    parent_message_text = get_random_string(10)
    thread_reply_text = get_random_string(10)
    token = iva_one_web_login(setup_aut, user_data)
    channel_id = iva_one.create_chat(
        token,
        channel_name,
        [user_data['username']],
        type=iva_one.ChatTypes.CHANNEL,
        has_threads=True,
    )
    iva_one.send_message(token, channel_id, parent_message_text)

    log.tc('833')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(channel_name)
    chat.create_thread_reply(parent_message_text, thread_reply_text)
    chat.assert_thread_message_visible(thread_reply_text)
    chat.close_thread()
    chat.assert_thread_count_in_bubble(parent_message_text, 1)
    chat.open_threads_tab()
    chat.assert_thread_in_threads_tab(parent_message_text)


@allure.id("352")
@allure.title("Выгнать пользователя из информационного канала")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Информационный канал")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_channel_kick_member(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    channel_name = get_random_string(10)
    token = iva_one_web_login(setup_aut, users_data[0])
    chat_id = iva_one.create_chat(
        token,
        channel_name,
        [user['username'] for user in users_data],
        type=iva_one.ChatTypes.CHANNEL,
    )
    wait_group_chat_materialized(token, chat_id, min_members=len(users_data))

    log.tc('352')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0]['username'], users_data[0]['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(channel_name)
    chat.open_chat_profile('info_channel_profile')
    info_channel_profile = chunks.get_chunk(version, 'info_channel_profile')(driver, lang=lang)
    info_channel_profile.open_member_context_menu(users_data[1]['last_name'])
    info_channel_profile.click_kick_member_in_context_menu()
    info_channel_profile.assert_user_not_in_profile_list(users_data[1]['last_name'])

    driver = relogin_session(setup_aut, teardown)

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[1]['username'], users_data[1]['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chats_list.assert_chat_not_in_list(channel_name)


@allure.id("782")
@allure.title("Информационный канал. Передать права администратора")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Информационный канал")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_channel_make_admin_input_available(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    channel_name = get_random_string(10)
    token = iva_one_web_login(setup_aut, users_data[0])
    chat_id = iva_one.create_chat(
        token,
        channel_name,
        [user['username'] for user in users_data],
        type=iva_one.ChatTypes.CHANNEL,
    )
    wait_group_chat_materialized(token, chat_id, min_members=len(users_data))

    log.tc('782')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0]['username'], users_data[0]['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(channel_name)
    chat.open_chat_profile('info_channel_profile')
    info_channel_profile = chunks.get_chunk(version, 'info_channel_profile')(driver, lang=lang)
    info_channel_profile.open_member_context_menu(users_data[1]['last_name'])
    info_channel_profile.click_make_admin_in_context_menu()
    info_channel_profile.assert_user_is_admin(users_data[1]['last_name'])

    driver = relogin_session(setup_aut, teardown)

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[1]['username'], users_data[1]['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(channel_name)
    chat.assert_input(available=True)


@allure.id("784")
@allure.title("Информационный канал. Передать права владельца")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Информационный канал")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_channel_transfer_owner_input_available(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    channel_name = get_random_string(10)
    token = iva_one_web_login(setup_aut, users_data[0])
    chat_id = iva_one.create_chat(
        token,
        channel_name,
        [user['username'] for user in users_data],
        type=iva_one.ChatTypes.CHANNEL,
    )
    wait_group_chat_materialized(token, chat_id, min_members=len(users_data))

    log.tc('784')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0]['username'], users_data[0]['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(channel_name)
    chat.open_chat_profile('info_channel_profile')
    info_channel_profile = chunks.get_chunk(version, 'info_channel_profile')(driver, lang=lang)
    info_channel_profile.open_member_context_menu(users_data[1]['last_name'])
    info_channel_profile.click_transfer_owner_in_context_menu()
    info_channel_profile.confirm_transfer_owner()
    info_channel_profile.assert_user_is_owner(users_data[1]['last_name'])

    driver = relogin_session(setup_aut, teardown)

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[1]['username'], users_data[1]['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(channel_name)
    chat.assert_input(available=True)


@allure.id("303")
@allure.title("Начать тред с упоминания пользователя в публичном групповом чате")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Групповой чат")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_group_public_thread_mention_subscribes(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    config = setup_aut['setup']['config']
    users_data = users_factory
    group_name = get_random_string(10)
    parent_message_text = get_random_string(10)
    thread_reply_text = get_random_string(10)
    mention_target = users_data[1]['last_name']
    token = iva_one_web_login(setup_aut, users_data[0])
    # Прогрев user2 в адресной книге через iva-one client login — без этого user2 не появляется в mention popup
    mention_target_token = iva_one_web_login(setup_aut, users_data[1])
    chat_id = iva_one.create_chat(
        token,
        group_name,
        [users_data[0]['username']],
        is_public=True,
        has_threads=True,
    )
    wait_group_chat_materialized(token, chat_id, min_members=1)
    iva_one.send_message(token, chat_id, parent_message_text)

    log.tc('303')

    mention_notifications = CentrifugoListener(
        config['web_url'], mention_target_token, users_data[1]['id']).start()
    teardown.append(mention_notifications.stop)
    mention_notifications.wait_subscribed()

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0]['username'], users_data[0]['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(group_name)
    chat.open_bubble_context_menu_by_text(parent_message_text)
    chat.click_start_thread_button_in_context_menu()
    chat.type_thread_mention(mention_target)
    chat.select_user_in_mention_popup(mention_target)
    chat.type_thread_message(f' {thread_reply_text}', check_value=False)
    chat.send_thread_message()
    chat.assert_mention_in_message(mention_target)

    mention_notifications.wait_notification_event_received('chat.message.mention')

    driver = relogin_session(setup_aut, teardown)

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[1]['username'], users_data[1]['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chat.open_threads_tab()
    chat.assert_thread_in_threads_tab(parent_message_text)


@allure.id("300")
@allure.title("Начать тред с упоминания пользователя в непубличном групповом чате")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Групповой чат")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_group_private_thread_mention_no_subscribe(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    group_name = get_random_string(10)
    parent_message_text = get_random_string(10)
    thread_reply_text = get_random_string(10)
    mention_target = users_data[1]['last_name']
    token = iva_one_web_login(setup_aut, users_data[0])
    # Прогрев user2 в адресной книге через iva-one client login — без этого user2 не появляется в mention popup
    iva_one_web_login(setup_aut, users_data[1])
    chat_id = iva_one.create_chat(
        token,
        group_name,
        [users_data[0]['username']],
        is_public=False,
        has_threads=True,
    )
    iva_one.send_message(token, chat_id, parent_message_text)

    log.tc('300')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0]['username'], users_data[0]['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(group_name)
    chat.open_bubble_context_menu_by_text(parent_message_text)
    chat.click_start_thread_button_in_context_menu()
    chat.type_thread_mention(mention_target)
    chat.select_user_in_mention_popup(mention_target)
    chat.type_thread_message(f' {thread_reply_text}', check_value=False)
    chat.send_thread_message()
    chat.assert_mention_in_message(mention_target)

    driver = relogin_session(setup_aut, teardown)

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[1]['username'], users_data[1]['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chat.open_threads_tab()
    chat.assert_thread_not_in_threads_tab(parent_message_text)


@allure.id("758")
@allure.title("Начать тред с упоминания пользователя в публичном информационном канале")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Информационный канал")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_channel_public_thread_mention_subscribes(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    channel_name = get_random_string(10)
    parent_message_text = get_random_string(10)
    thread_reply_text = get_random_string(10)
    mention_target = users_data[1]['last_name']
    token = iva_one_web_login(setup_aut, users_data[0])
    # Прогрев user2 в адресной книге через iva-one client login — без этого user2 не появляется в mention popup
    iva_one_web_login(setup_aut, users_data[1])
    channel_id = iva_one.create_chat(
        token,
        channel_name,
        [users_data[0]['username']],
        type=iva_one.ChatTypes.CHANNEL,
        is_public=True,
        has_threads=True,
    )
    iva_one.send_message(token, channel_id, parent_message_text)

    log.tc('758')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0]['username'], users_data[0]['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(channel_name)
    chat.open_bubble_context_menu_by_text(parent_message_text)
    chat.click_start_thread_button_in_context_menu()
    chat.type_thread_mention(mention_target)
    chat.select_user_in_mention_popup(mention_target)
    chat.type_thread_message(f' {thread_reply_text}', check_value=False)
    chat.send_thread_message()
    chat.assert_mention_in_message(mention_target)

    driver = relogin_session(setup_aut, teardown)

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[1]['username'], users_data[1]['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chat.open_threads_tab()
    chat.assert_thread_in_threads_tab(parent_message_text)


@allure.id("759")
@allure.title("Начать тред с упоминания пользователя в непубличном информационном канале")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Информационный канал")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_channel_private_thread_mention_no_subscribe(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    channel_name = get_random_string(10)
    parent_message_text = get_random_string(10)
    thread_reply_text = get_random_string(10)
    mention_target = users_data[1]['last_name']
    token = iva_one_web_login(setup_aut, users_data[0])
    # Прогрев user2 в адресной книге через iva-one client login — без этого user2 не появляется в mention popup
    iva_one_web_login(setup_aut, users_data[1])
    channel_id = iva_one.create_chat(
        token,
        channel_name,
        [users_data[0]['username']],
        type=iva_one.ChatTypes.CHANNEL,
        is_public=False,
        has_threads=True,
    )
    iva_one.send_message(token, channel_id, parent_message_text)

    log.tc('759')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0]['username'], users_data[0]['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(channel_name)
    chat.open_bubble_context_menu_by_text(parent_message_text)
    chat.click_start_thread_button_in_context_menu()
    chat.type_thread_mention(mention_target)
    chat.select_user_in_mention_popup(mention_target)
    chat.type_thread_message(f' {thread_reply_text}', check_value=False)
    chat.send_thread_message()
    chat.assert_mention_in_message(mention_target)

    driver = relogin_session(setup_aut, teardown)

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[1]['username'], users_data[1]['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chat.open_threads_tab()
    chat.assert_thread_not_in_threads_tab(parent_message_text)


@allure.id("925")
@allure.title("Информационный канал добавить описание")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Информационный канал")
@allure.label("IVAQA", "https://jira.iva.ru/browse/IVAONE-6528")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_channel_edit_description_visible(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    channel_name = get_random_string(10)
    chat_description = get_random_string(10)
    token = iva_one_web_login(setup_aut, users_data[0])
    chat_id = iva_one.create_chat(
        token,
        channel_name,
        [users_data[0]['username']],
        type=iva_one.ChatTypes.CHANNEL,
    )
    # в members сеется только создатель — материализацию ждём по одному участнику
    wait_group_chat_materialized(token, chat_id, min_members=1)

    log.tc('925')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(channel_name)
    chat.open_chat_profile('info_channel_profile')
    info_channel_profile = chunks.get_chunk(version, 'info_channel_profile')(driver, lang=lang)
    info_channel_profile.click_edit_chat()
    info_channel_profile.assert_edit_form_opened()
    info_channel_profile.type_description(chat_description)
    info_channel_profile.assert_description_counter(chat_description)
    info_channel_profile.save_changes()
    info_channel_profile.assert_description_visible(chat_description)


@allure.id("926")
@allure.title("Редактировать информационный канал, загрузить аватар чата")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Информационный канал")
@allure.label(
    "IVAQA",
    "https://jira.iva.ru/browse/IVAONE-10287",
    "https://jira.iva.ru/browse/IVAONE-11048",
    "https://jira.iva.ru/browse/IVAONE-6528",
)
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_channel_edit_avatar_visible(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    channel_name = get_random_string(10)
    avatar_file_name = 'test_image_sample.jpeg'
    token = iva_one_web_login(setup_aut, users_data[0])
    iva_one.create_chat(
        token,
        channel_name,
        [users_data[0]['username']],
        type=iva_one.ChatTypes.CHANNEL
    )

    log.tc('926')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(channel_name)
    chat.open_chat_profile('info_channel_profile')
    info_channel_profile = chunks.get_chunk(version, 'info_channel_profile')(driver, lang=lang)
    info_channel_profile.click_edit_chat()
    info_channel_profile.assert_edit_form_opened()
    info_channel_profile.upload_avatar(avatar_file_name)
    info_channel_profile.assert_avatar_uploaded()
    info_channel_profile.save_changes()
    info_channel_profile.assert_avatar_visible()


@allure.id("938")
@allure.title("Редактировать чат, сделать чат публичным")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Групповой чат")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_chat_edit_make_public_join_via_link(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    chat_name = get_random_string(10)

    token = iva_one_web_login(setup_aut, users_data[0])
    chat_id = iva_one.create_chat(
        token,
        chat_name,
        [users_data[0]['username']],
        type=iva_one.ChatTypes.GROUP,
        is_public=False,
    )
    wait_group_chat_materialized(token, chat_id, min_members=1)

    log.tc('938')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(chat_name)
    chat.open_chat_profile()
    group_chat_profile = chunks.get_chunk(version, 'group_chat_profile')(driver, lang=lang)
    group_chat_profile.click_edit_chat()
    group_chat_profile.assert_edit_form_opened()
    group_chat_profile.toggle_chat_public()
    group_chat_profile.assert_chat_public_toggle_active()
    group_chat_profile.save_changes()
    group_chat_profile.assert_chat_is_public()
    chat_url = group_chat_profile.copy_chat_link()

    driver = relogin_session(setup_aut, teardown)

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[1].get('username'), users_data[1].get('password'))
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chat.open_chat_by_url(chat_url)
    chat.assert_join_btn_visible()
    chat.assert_input(available=False)


@allure.id("777")
@allure.title("Редактировать информационный канал, сделать чат публичным")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Информационный канал")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_channel_edit_make_public_subscribe_via_link(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    channel_name = get_random_string(10)

    token = iva_one_web_login(setup_aut, users_data[0])
    iva_one.create_chat(
        token,
        channel_name,
        [users_data[0]['username']],
        type=iva_one.ChatTypes.CHANNEL,
        is_public=False,
    )

    log.tc('777')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(channel_name)
    chat.open_chat_profile('info_channel_profile')
    info_channel_profile = chunks.get_chunk(version, 'info_channel_profile')(driver, lang=lang)
    info_channel_profile.click_edit_chat()
    info_channel_profile.assert_edit_form_opened()
    info_channel_profile.toggle_chat_public()
    info_channel_profile.assert_chat_public_toggle_active()
    info_channel_profile.save_changes()
    info_channel_profile.assert_chat_is_public()
    chat_url = info_channel_profile.copy_chat_link()

    driver = relogin_session(setup_aut, teardown)

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[1].get('username'), users_data[1].get('password'))
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chat.open_chat_by_url(chat_url)
    chat.assert_join_btn_visible(is_channel=True)
    chat.assert_input(available=False)


@allure.id("774")
@allure.title("Редактировать чат, изменить название, проверка кнопки очистить поле")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Информационный канал")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_channel_edit_clear_chat_name_input_empty(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]
    channel_name = get_random_string(10)
    token = iva_one_web_login(setup_aut, user_data)
    iva_one.create_chat(
        token,
        channel_name,
        [user_data['username']],
        type=iva_one.ChatTypes.CHANNEL,
    )

    log.tc('774')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data.get('username'), user_data.get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(channel_name)
    chat.open_chat_profile('info_channel_profile')
    info_channel_profile = chunks.get_chunk(version, 'info_channel_profile')(driver, lang=lang)
    info_channel_profile.click_edit_chat()
    info_channel_profile.assert_edit_form_opened()
    info_channel_profile.click_clear_chat_name_btn()
    info_channel_profile.assert_chat_name_input_empty()


@allure.id("772")
@allure.title("Редактировать чат, изменить название канала")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Информационный канал")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_channel_edit_chat_name_updated(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]
    initial_name = get_random_string(10)
    new_name = get_random_string(10)
    token = iva_one_web_login(setup_aut, user_data)
    iva_one.create_chat(
        token,
        initial_name,
        [user_data['username']],
        type=iva_one.ChatTypes.CHANNEL,
    )

    log.tc('772')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data.get('username'), user_data.get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(initial_name)
    chat.open_chat_profile('info_channel_profile')
    info_channel_profile = chunks.get_chunk(version, 'info_channel_profile')(driver, lang=lang)
    info_channel_profile.click_edit_chat()
    info_channel_profile.assert_edit_form_opened()
    info_channel_profile.click_clear_chat_name_btn()
    info_channel_profile.type_chat_name(new_name)
    info_channel_profile.save_changes()
    chat.assert_chat_with_chat_name_opened(new_name)
    chat.assert_channel_renamed_system_message(new_name)


@allure.id("778")
@allure.title("Редактировать чат, включение реакций")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Информационный канал")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_channel_edit_reactions_enabled_in_context_menu(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]
    channel_name = get_random_string(10)
    message = get_random_string(10)
    token = iva_one_web_login(setup_aut, user_data)
    chat_id = iva_one.create_chat(
        token,
        channel_name,
        [user_data['username']],
        type=iva_one.ChatTypes.CHANNEL,
        has_reactions=False,
    )
    iva_one.send_message(token, chat_id, message)

    log.tc('778')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data.get('username'), user_data.get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(channel_name)
    chat.open_bubble_context_menu_by_text(message)
    chat.assert_reactions_picker_menu_absent()
    chat.close_message_context_menu()
    chat.open_chat_profile('info_channel_profile')
    info_channel_profile = chunks.get_chunk(version, 'info_channel_profile')(driver, lang=lang)
    info_channel_profile.click_edit_chat()
    info_channel_profile.assert_edit_form_opened()
    info_channel_profile.toggle_reactions()
    info_channel_profile.assert_reactions_toggle_active()
    info_channel_profile.save_changes()
    chat.open_bubble_context_menu_by_text(message)
    chat.assert_reactions_picker_menu_visible()


@allure.id("780")
@allure.title("Редактировать чат, включение тредов")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Информационный канал")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_channel_edit_threads_enabled_in_context_menu(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]
    channel_name = get_random_string(10)
    message = get_random_string(10)
    token = iva_one_web_login(setup_aut, user_data)
    chat_id = iva_one.create_chat(
        token,
        channel_name,
        [user_data['username']],
        type=iva_one.ChatTypes.CHANNEL,
        has_threads=False,
    )
    iva_one.send_message(token, chat_id, message)

    log.tc('780')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data.get('username'), user_data.get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(channel_name)
    chat.open_bubble_context_menu_by_text(message)
    chat.assert_thread_menu_item_absent()
    chat.close_message_context_menu()
    chat.open_chat_profile('info_channel_profile')
    info_channel_profile = chunks.get_chunk(version, 'info_channel_profile')(driver, lang=lang)
    info_channel_profile.click_edit_chat()
    info_channel_profile.assert_edit_form_opened()
    info_channel_profile.toggle_threads()
    info_channel_profile.assert_threads_toggle_active()
    info_channel_profile.save_changes()
    chat.open_bubble_context_menu_by_text(message)
    chat.assert_thread_menu_item_visible()


@allure.id("2248")
@allure.title("Создать групповой чат")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Групповой чат")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_group_chat_create_via_wizard(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    owner = users_factory[0]
    member = users_factory[1]
    member_full_name = f"{member['last_name']} {member['first_name']}"
    chat_name = get_random_string(10)

    log.tc('2248')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(owner['username'], owner['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.click_create_chat_btn()
    chats_list.select_chat_type(iva_one.ChatTypes.GROUP)

    create_popup = chunks.get_chunk(version, 'create_chat_popup')(driver, lang=lang)
    create_popup.assert_step1_group_opened()
    create_popup.search_and_select_member(member_full_name)
    create_popup.click_next()
    create_popup.assert_step2_group_opened()
    create_popup.type_chat_name(chat_name)
    create_popup.click_create_group()
    create_popup.assert_dialog_closed()
    chat.assert_chat_with_chat_name_opened(chat_name)


@allure.id("703")
@allure.title("Создать непубличный групповой чат")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Групповой чат")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_group_chat_create_non_public_via_wizard(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    owner = users_factory[0]
    member = users_factory[1]
    member_full_name = f"{member['last_name']} {member['first_name']}"
    chat_name = get_random_string(10)

    log.tc('703')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(owner['username'], owner['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.click_create_chat_btn()
    chats_list.select_chat_type(iva_one.ChatTypes.GROUP)

    create_popup = chunks.get_chunk(version, 'create_chat_popup')(driver, lang=lang)
    create_popup.assert_step1_group_opened()
    create_popup.search_and_select_member(member_full_name)
    create_popup.click_next()
    create_popup.assert_step2_group_opened()
    create_popup.type_chat_name(chat_name)
    create_popup.assert_public_toggle_off()
    create_popup.click_create_group()
    create_popup.assert_dialog_closed()
    chat.assert_chat_with_chat_name_opened(chat_name)


@allure.id("704")
@allure.title("Создать публичный групповой чат")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Групповой чат")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_group_chat_create_public_via_wizard(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    owner = users_factory[0]
    member = users_factory[1]
    member_full_name = f"{member['last_name']} {member['first_name']}"
    chat_name = get_random_string(10)

    log.tc('704')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(owner['username'], owner['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.click_create_chat_btn()
    chats_list.select_chat_type(iva_one.ChatTypes.GROUP)

    create_popup = chunks.get_chunk(version, 'create_chat_popup')(driver, lang=lang)
    create_popup.assert_step1_group_opened()
    create_popup.search_and_select_member(member_full_name)
    create_popup.click_next()
    create_popup.assert_step2_group_opened()
    create_popup.type_chat_name(chat_name)
    create_popup.toggle_public_chat()
    create_popup.assert_public_toggle_on()
    create_popup.click_create_group()
    create_popup.assert_dialog_closed()
    chat.assert_chat_with_chat_name_opened(chat_name)


@allure.id("755")
@allure.title("Создать непубличный информационный канал")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Информационный канал")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_info_channel_create_non_public_via_wizard(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    owner = users_factory[0]
    member = users_factory[1]
    member_full_name = f"{member['last_name']} {member['first_name']}"
    channel_name = get_random_string(10)

    log.tc('755')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(owner['username'], owner['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.click_create_chat_btn()
    chats_list.select_chat_type(iva_one.ChatTypes.CHANNEL)

    create_popup = chunks.get_chunk(version, 'create_chat_popup')(driver, lang=lang)
    create_popup.assert_step1_channel_opened()
    create_popup.search_and_select_member(member_full_name)
    create_popup.click_next()
    create_popup.assert_step2_channel_opened()
    create_popup.type_chat_name(channel_name)
    create_popup.assert_public_toggle_off()
    create_popup.click_create_channel()
    create_popup.assert_dialog_closed()
    chat.assert_chat_with_chat_name_opened(channel_name)


@allure.id("756")
@allure.title("Создать публичный информационный канал")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Информационный канал")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_info_channel_create_public_via_wizard(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    owner = users_factory[0]
    member = users_factory[1]
    member_full_name = f"{member['last_name']} {member['first_name']}"
    channel_name = get_random_string(10)

    log.tc('756')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(owner['username'], owner['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.click_create_chat_btn()
    chats_list.select_chat_type(iva_one.ChatTypes.CHANNEL)

    create_popup = chunks.get_chunk(version, 'create_chat_popup')(driver, lang=lang)
    create_popup.assert_step1_channel_opened()
    create_popup.search_and_select_member(member_full_name)
    create_popup.click_next()
    create_popup.assert_step2_channel_opened()
    create_popup.type_chat_name(channel_name)
    create_popup.toggle_public_chat()
    create_popup.assert_public_toggle_on()
    create_popup.click_create_channel()
    create_popup.assert_dialog_closed()
    chat.assert_chat_with_chat_name_opened(channel_name)


@allure.id("931")
@allure.title("Создание группового чата, проверка обязательного поля \"Название группового чата\"")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Групповой чат")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_group_chat_create_name_required(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    owner = users_factory[0]
    chat_name = get_random_string(10)

    log.tc('931')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(owner['username'], owner['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chats_list.click_create_chat_btn()
    chats_list.select_chat_type(iva_one.ChatTypes.GROUP)

    create_popup = chunks.get_chunk(version, 'create_chat_popup')(driver, lang=lang)
    create_popup.assert_step1_group_opened()
    create_popup.click_next()
    create_popup.assert_step2_group_opened()
    create_popup.assert_create_group_btn_disabled()
    create_popup.type_chat_name(chat_name)
    create_popup.assert_create_group_btn_enabled()


@allure.id("930")
@allure.title("Создание информационного канала, проверка обязательного поля \"Название информационного канала\"")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Информационный канал")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_info_channel_create_name_required(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    owner = users_factory[0]
    channel_name = get_random_string(10)

    log.tc('930')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(owner['username'], owner['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chats_list.click_create_chat_btn()
    chats_list.select_chat_type(iva_one.ChatTypes.CHANNEL)

    create_popup = chunks.get_chunk(version, 'create_chat_popup')(driver, lang=lang)
    create_popup.assert_step1_channel_opened()
    create_popup.click_next()
    create_popup.assert_step2_channel_opened()
    create_popup.assert_create_channel_btn_disabled()
    create_popup.type_chat_name(channel_name)
    create_popup.assert_create_channel_btn_enabled()


@allure.id("927")
@allure.title("Создание группового чата, добавить аватар чата")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Групповой чат")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_group_chat_create_with_avatar(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    owner = users_factory[0]
    avatar_file_name = 'test_image_sample.jpeg'

    log.tc('927')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(owner['username'], owner['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chats_list.click_create_chat_btn()
    chats_list.select_chat_type(iva_one.ChatTypes.GROUP)

    create_popup = chunks.get_chunk(version, 'create_chat_popup')(driver, lang=lang)
    create_popup.assert_step1_group_opened()
    create_popup.click_next()
    create_popup.assert_step2_group_opened()
    create_popup.upload_avatar(avatar_file_name)
    create_popup.assert_avatar_uploaded()


@allure.id("929")
@allure.title("Создание информационного канала, добавить аватар чата")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Информационный канал")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_info_channel_create_with_avatar(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    owner = users_factory[0]
    avatar_file_name = 'test_image_sample.jpeg'

    log.tc('929')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(owner['username'], owner['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chats_list.click_create_chat_btn()
    chats_list.select_chat_type(iva_one.ChatTypes.CHANNEL)

    create_popup = chunks.get_chunk(version, 'create_chat_popup')(driver, lang=lang)
    create_popup.assert_step1_channel_opened()
    create_popup.click_next()
    create_popup.assert_step2_channel_opened()
    create_popup.upload_avatar(avatar_file_name)
    create_popup.assert_avatar_uploaded()


@allure.id("891")
@allure.title("Добавить пользователя в групповой чат из карточки чата")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Групповой чат")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_group_chat_add_member_via_profile(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    owner = users_data[0]
    member = users_data[1]
    owner_full_name = f"{owner['last_name']} {owner['first_name']}"
    member_full_name = f"{member['last_name']} {member['first_name']}"
    chat_name = get_random_string(10)
    token_owner = iva_one_web_login(setup_aut, owner)
    chat_id = iva_one.create_chat(token_owner, chat_name, [owner['username']])
    wait_group_chat_materialized(token_owner, chat_id, min_members=1)

    log.tc('891')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(owner['username'], owner['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(chat_name)
    chat.open_chat_profile('group_chat_profile')
    chat_profile = chunks.get_chunk(version, 'group_chat_profile')(driver, lang=lang)
    chat_profile.click_add_user_btn()
    chat_profile.search_and_select_member_in_add_popup(member_full_name)
    chat_profile.click_add_in_popup()
    chat_profile.assert_user_in_profile_list(member_full_name)
    chat.assert_user_added_system_message_exists(owner_full_name, member_full_name)


@allure.id("781")
@allure.title("Добавить пользователя в информационный канал из карточки чата")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Информационный канал")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_info_channel_add_member_via_profile(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    owner = users_data[0]
    member = users_data[1]
    member_full_name = f"{member['last_name']} {member['first_name']}"
    channel_name = get_random_string(10)
    token_owner = iva_one_web_login(setup_aut, owner)
    chat_id = iva_one.create_chat(
        token_owner, channel_name, [owner['username']], type=iva_one.ChatTypes.CHANNEL
    )
    wait_group_chat_materialized(token_owner, chat_id, min_members=1)

    log.tc('781')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(owner['username'], owner['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(channel_name)
    chat.open_chat_profile('info_channel_profile')
    chat_profile = chunks.get_chunk(version, 'info_channel_profile')(driver, lang=lang)
    chat_profile.click_add_user_btn()
    chat_profile.search_and_select_member_in_add_popup(member_full_name)
    chat_profile.click_add_in_popup()
    chat_profile.assert_user_in_profile_list(member_full_name)


@allure.id("149")
@allure.title("Информации о сообщении всем участникам информационного канала, нет в контекстном меню")
@allure.label("owner", "Simon")
@allure.tag("RFA", "web")
@allure.story("Информационный канал")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_info_channel_member_no_info_in_context_menu(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    channel_name = get_random_string(10)
    message_text = get_random_string(10)
    token_admin = iva_one_web_login(setup_aut, users_data[0])
    channel_id = iva_one.create_chat(
        token_admin,
        channel_name,
        [users_data[0]['username'], users_data[1]['username']],
        type=iva_one.ChatTypes.CHANNEL,
    )
    iva_one.send_message(token_admin, channel_id, message_text)

    log.tc('149')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[1].get('username'), users_data[1].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(channel_name)
    chat.open_bubble_context_menu_by_text(message_text)
    chat.assert_context_menu_info_button_absent()


@allure.id("36772")
@allure.title("Личные сообщения. Реакция на чужое сообщение")
@allure.label("owner", "Simon")
@allure.tag("RFA", "web")
@allure.story("Личный чат")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_p2p_chat_set_reaction_on_other_message(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    message_text = get_random_string(10)
    token_sender = iva_one_web_login(setup_aut, users_data[0])
    chat_id = iva_one.create_p2p_chat(token_sender, users_data[1]['username'])
    iva_one.send_message(token_sender, chat_id, message_text)

    log.tc('36772')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[1].get('username'), users_data[1].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(users_data[0]['last_name'])
    chat.open_bubble_context_menu_by_text(message_text)
    chat.set_reaction_from_context_menu(iva_one.ChatUsersReactions.FIRE)
    chat.assert_reaction_under_message(message_text, iva_one.ChatUsersReactions.FIRE)


@allure.id("1367")
@allure.title("Скопировать сообщение в групповом чате")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Групповой чат")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_group_chat_copy_message_via_context_menu(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    chat_name = get_random_string(10)
    message_text = get_random_string(10)
    token = iva_one_web_login(setup_aut, users_data[0])
    chat_id = iva_one.create_chat(
        token,
        chat_name,
        [users_data[0]['username']],
        type=iva_one.ChatTypes.GROUP,
    )
    iva_one.send_message(token, chat_id, message_text)

    log.tc('1367')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(chat_name)
    chat.open_bubble_context_menu_by_text(message_text)
    chat.copy_message_from_context_menu()
    chat.assert_message_in_clipboard(message_text)


@allure.id("1315")
@allure.title("Просмотр информации в сообщении группового чата")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Групповой чат")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_group_chat_show_message_info_dialog(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    chat_name = get_random_string(10)
    message_text = get_random_string(10)
    token = iva_one_web_login(setup_aut, users_data[0])
    chat_id = iva_one.create_chat(
        token,
        chat_name,
        [users_data[0]['username']],
        type=iva_one.ChatTypes.GROUP,
    )
    iva_one.send_message(token, chat_id, message_text)

    log.tc('1315')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(chat_name)
    chat.open_bubble_context_menu_by_text(message_text)
    chat.click_info_in_context_menu()
    author_full_name = f"{users_data[0]['last_name']} {users_data[0]['first_name']}"
    chat.assert_message_info_dialog_with_author(author_full_name)


@allure.id("1156")
@allure.title("Отключить уведомления в карточке группового чата")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Групповой чат")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_group_chat_mute_notifications_via_profile(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    chat_name = get_random_string(10)
    token = iva_one_web_login(setup_aut, users_data[0])
    iva_one.create_chat(
        token,
        chat_name,
        [users_data[0]['username']],
        type=iva_one.ChatTypes.GROUP,
    )

    log.tc('1156')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(chat_name)
    chat.open_chat_profile()
    group_chat_profile = chunks.get_chunk(version, 'group_chat_profile')(driver, lang=lang)
    group_chat_profile.toggle_notifications()
    group_chat_profile.assert_notifications_muted_toast_visible()


@allure.id("1313")
@allure.title("Включить уведомления в карточке группового чата")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Групповой чат")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_group_chat_unmute_notifications_via_profile(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    chat_name = get_random_string(10)
    token = iva_one_web_login(setup_aut, users_data[0])
    chat_id = iva_one.create_chat(
        token,
        chat_name,
        [users_data[0]['username']],
        type=iva_one.ChatTypes.GROUP,
    )
    iva_one.mute_chat(token, chat_id, mute=True)

    log.tc('1313')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(chat_name)
    chat.open_chat_profile()
    group_chat_profile = chunks.get_chunk(version, 'group_chat_profile')(driver, lang=lang)
    group_chat_profile.toggle_notifications()
    group_chat_profile.assert_notifications_unmuted_toast_visible()


@allure.id("2360")
@allure.title("Скопировать ссылку на чат из карточки группового чата")
@allure.label("owner", "Simon")
@allure.tag("RFA", "web")
@allure.story("Групповой чат")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_group_chat_copy_link_toast_via_profile(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    chat_name = get_random_string(10)
    token = iva_one_web_login(setup_aut, users_data[0])
    iva_one.create_chat(
        token,
        chat_name,
        [users_data[0]['username']],
        type=iva_one.ChatTypes.GROUP,
        is_public=True,
    )

    log.tc('2360')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(chat_name)
    chat.open_chat_profile()
    group_chat_profile = chunks.get_chunk(version, 'group_chat_profile')(driver, lang=lang)
    group_chat_profile.copy_chat_link()
    group_chat_profile.assert_copy_link_toast_visible()


@allure.id("2359")
@allure.title("Скопировать ссылку на канал из карточки канала")
@allure.label("owner", "Simon")
@allure.tag("RFA", "web")
@allure.story("Информационный канал")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_info_channel_copy_link_toast_via_profile(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    channel_name = get_random_string(10)
    token = iva_one_web_login(setup_aut, users_data[0])
    iva_one.create_chat(
        token,
        channel_name,
        [users_data[0]['username']],
        type=iva_one.ChatTypes.CHANNEL,
        is_public=True,
    )

    log.tc('2359')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(channel_name)
    chat.open_chat_profile('info_channel_profile')
    info_channel_profile = chunks.get_chunk(version, 'info_channel_profile')(driver, lang=lang)
    info_channel_profile.copy_chat_link()
    info_channel_profile.assert_copy_link_toast_visible()


@allure.id("373")
@allure.title("Удалить групповой чат")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Групповой чат")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_group_chat_delete_via_profile(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    chat_name = get_random_string(10)
    token = iva_one_web_login(setup_aut, users_data[0])
    iva_one.create_chat(
        token,
        chat_name,
        [users_data[0]['username'], users_data[1]['username']],
        type=iva_one.ChatTypes.GROUP,
    )

    log.tc('373')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    user1_chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    user1_chats = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    user1_chats_list.open_chat(chat_name)
    user1_chats.open_chat_profile()
    group_chat_profile = chunks.get_chunk(version, 'group_chat_profile')(driver, lang=lang)
    group_chat_profile.click_more_menu_btn()
    group_chat_profile.click_delete_chat_btn()
    group_chat_profile.confirm_delete_chat()
    user1_chats_list.assert_chat_not_in_list(chat_name)

    driver = relogin_session(setup_aut, teardown)

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[1].get('username'), users_data[1].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    user2_chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    user2_chats_list.assert_chat_not_in_list(chat_name)


@allure.id("832")
@allure.title("Удалить информационный канал")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Информационный канал")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_info_channel_delete_via_profile(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    channel_name = get_random_string(10)
    token = iva_one_web_login(setup_aut, users_data[0])
    iva_one.create_chat(
        token,
        channel_name,
        [users_data[0]['username'], users_data[1]['username']],
        type=iva_one.ChatTypes.CHANNEL,
    )

    log.tc('832')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    user1_chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    user1_chats = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    user1_chats_list.open_chat(channel_name)
    user1_chats.open_chat_profile('info_channel_profile')
    info_channel_profile = chunks.get_chunk(version, 'info_channel_profile')(driver, lang=lang)
    info_channel_profile.click_more_menu_btn()
    info_channel_profile.click_delete_chat_btn()
    info_channel_profile.confirm_delete_chat()
    user1_chats_list.assert_chat_not_in_list(channel_name)

    driver = relogin_session(setup_aut, teardown)

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[1].get('username'), users_data[1].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    user2_chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    user2_chats_list.assert_chat_not_in_list(channel_name)


@allure.id("893")
@allure.title("Переход в непубличный групповой чат по ссылке")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Групповой чат")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_group_chat_non_public_join_via_link_chat_not_found(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    chat_name = get_random_string(10)
    token = iva_one_web_login(setup_aut, users_data[0])
    iva_one.create_chat(
        token,
        chat_name,
        [users_data[0]['username']],
        type=iva_one.ChatTypes.GROUP,
        is_public=False,
    )

    log.tc('893')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    user1_chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    user1_chats = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    user1_chats_list.open_chat(chat_name)
    user1_chats.open_chat_profile()
    group_chat_profile = chunks.get_chunk(version, 'group_chat_profile')(driver, lang=lang)
    chat_url = group_chat_profile.copy_chat_link()

    driver = relogin_session(setup_aut, teardown)

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[1].get('username'), users_data[1].get('password'))
    user2_chats = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    user2_chats.open_chat_by_url(chat_url)
    user2_chats.assert_not_found_page_displayed()


@allure.id("769")
@allure.title("Переход в непубличный информационный канал по ссылке")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Информационный канал")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_info_channel_non_public_join_via_link_chat_not_found(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    channel_name = get_random_string(10)
    token = iva_one_web_login(setup_aut, users_data[0])
    iva_one.create_chat(
        token,
        channel_name,
        [users_data[0]['username']],
        type=iva_one.ChatTypes.CHANNEL,
        is_public=False,
    )

    log.tc('769')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    user1_chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    user1_chats = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    user1_chats_list.open_chat(channel_name)
    user1_chats.open_chat_profile('info_channel_profile')
    info_channel_profile = chunks.get_chunk(version, 'info_channel_profile')(driver, lang=lang)
    channel_url = info_channel_profile.copy_chat_link()

    driver = relogin_session(setup_aut, teardown)

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[1].get('username'), users_data[1].get('password'))
    user2_chats = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    user2_chats.open_chat_by_url(channel_url)
    user2_chats.assert_not_found_page_displayed()


@allure.id("705")
@allure.title("Вступить в публичный групповой чат по ссылке")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Групповой чат")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_group_chat_join_public_via_link(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    chat_name = get_random_string(10)
    owner_token = iva_one_web_login(setup_aut, users_data[0])
    chat_id = iva_one.create_chat(
        owner_token,
        chat_name,
        [users_data[0]['username']],
        type=iva_one.ChatTypes.GROUP,
        is_public=True,
    )
    chat_url = build_chat_link(chat_id)

    log.tc('705')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[1].get('username'), users_data[1].get('password'))
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chat.open_chat_by_url(chat_url)
    chat.assert_join_btn_visible()
    chat.assert_input(available=False)
    chat.click_join_btn()
    chat.assert_input(available=True)


@allure.id("776")
@allure.title("Вступить в публичный информационный канал по ссылке")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Информационный канал")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_info_channel_join_public_via_link(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    channel_name = get_random_string(10)
    owner_token = iva_one_web_login(setup_aut, users_data[0])
    channel_id = iva_one.create_chat(
        owner_token,
        channel_name,
        [users_data[0]['username']],
        type=iva_one.ChatTypes.CHANNEL,
        is_public=True,
    )
    channel_url = build_chat_link(channel_id)

    log.tc('776')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[1].get('username'), users_data[1].get('password'))
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chat.open_chat_by_url(channel_url)
    chat.assert_join_btn_visible(is_channel=True)
    chat.assert_input(available=False)
    chat.click_join_btn(is_channel=True)
    # Для информационного канала инпут не появляется (писать может только админ);
    # успех подписки проверяется по факту, что кнопка "Подписаться" пропала —
    # это уже учтено в click_join_btn(is_channel=True).


@allure.id("1316")
@allure.title("Удалить сообщение в групповом чате")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Групповой чат")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_group_chat_delete_message_via_context_menu(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    chat_name = get_random_string(10)
    message_text = get_random_string(10)
    owner_token = iva_one_web_login(setup_aut, users_data[0])
    chat_id = iva_one.create_chat(
        owner_token,
        chat_name,
        [users_data[0]['username'], users_data[1]['username']],
        type=iva_one.ChatTypes.GROUP,
    )
    iva_one.send_message(owner_token, chat_id, message_text)

    log.tc('1316')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    user1_chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    user1_chats = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    user1_chats_list.open_chat(chat_name)
    user1_chats.assert_sent_message_exists(message_text)
    user1_chats.open_bubble_context_menu_by_text(message_text)
    user1_chats.click_delete_message_in_context_menu()
    user1_chats.confirm_delete_message()
    user1_chats.assert_sent_message_absent(message_text)

    driver = relogin_session(setup_aut, teardown)

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[1].get('username'), users_data[1].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    user2_chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    user2_chats = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    user2_chats_list.open_chat(chat_name)
    user2_chats.assert_sent_message_absent(message_text)


@allure.id("1379")
@allure.title("Отключить уведомления в карточке личного чата")
@allure.label("owner", "D.nigmatulin")
@allure.tag("RFA", "web")
@allure.story("Личный чат")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_p2p_chat_mute_notifications_via_profile(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    token = iva_one_web_login(setup_aut, users_data[0])
    iva_one.create_p2p_chat(token, users_data[1]['username'])

    log.tc('1379')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(users_data[1]['last_name'])
    chat.open_chat_profile(chunk_name='p2p_chat_profile')
    p2p_profile = chunks.get_chunk(version, 'p2p_chat_profile')(driver, lang=lang)
    p2p_profile.click_more_menu_btn()
    p2p_profile.click_mute_notifications()
    p2p_profile.assert_notifications_muted_toast_visible()


@allure.id("1490")
@allure.title("Инф.канал. Прочитать сообщение")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Информационный канал")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_info_channel_read_message_clears_unread_badge(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    channel_name = get_random_string(10)
    message_text = get_random_string(10)
    admin_token = iva_one_web_login(setup_aut, users_data[1])
    channel_id = iva_one.create_chat(
        admin_token,
        channel_name,
        [users_data[0]['username'], users_data[1]['username']],
        type=iva_one.ChatTypes.CHANNEL,
    )
    iva_one.send_message(admin_token, channel_id, message_text)
    # decoy: ещё один свежий чат (p2p) после, чтобы UI на /chat авто-открыл его,
    # а не наш info-канал. Иначе badge мгновенно сбрасывается auto-open'ом и тест
    # не успевает его поймать.
    iva_one.create_p2p_chat(admin_token, users_data[0]['username'])

    log.tc('1490')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.assert_unread_badge_visible(channel_name)
    chats_list.open_chat(channel_name)
    # барьер: дождаться открытия комнаты (топбар) → сообщение прочитано → badge очищается,
    # иначе assert_unread_badge_absent гонится с асинхронным сбросом badge
    chat.assert_chat_with_chat_name_opened(channel_name)
    chats_list.assert_unread_badge_absent(channel_name)


@allure.id("757")
@allure.title("Информационный канал отправить сообщение админом")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Информационный канал")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_info_channel_send_message_by_admin(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    channel_name = get_random_string(10)
    message = get_random_string(10)
    admin_token = iva_one_web_login(setup_aut, users_data[0])
    iva_one.create_chat(
        admin_token,
        channel_name,
        [users_data[0]['username'], users_data[1]['username']],
        type=iva_one.ChatTypes.CHANNEL,
    )

    log.tc('757')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    admin_chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    admin_chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    admin_chats_list.open_chat(channel_name)
    admin_chat.send_text_message(message, mode='click')
    admin_chat.assert_sent_message_status_is_sent(message)

    driver = relogin_session(setup_aut, teardown)

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[1].get('username'), users_data[1].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    member_chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    member_chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    member_chats_list.open_chat(channel_name)
    member_chat.assert_sent_message_exists(message)


@allure.id("2392")
@allure.title("Переслать 50 сообщений из информационного канала")
@allure.label("owner", "Simon")
@allure.tag("RFA", "web")
@allure.story("Информационный канал")
@allure.label("IVAQA", "https://jira.iva.ru/browse/IVAONE-8999")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_info_channel_forward_50_messages_to_favorites(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    channel_name = get_random_string(10)
    messages_for_forward = [f'{get_random_string(10)}_{idx}' for idx in range(50)]
    favorites_chat_name = i18n.get_str('favorites_chat_name', lang)
    expected_author_name = f'{users_data[0]["first_name"]} {users_data[0]["last_name"]}'
    token = iva_one_web_login(setup_aut, users_data[0])
    channel_id = iva_one.create_chat(
        token,
        channel_name,
        [user['username'] for user in users_data],
        type=iva_one.ChatTypes.CHANNEL,
    )
    for message in messages_for_forward:
        iva_one.send_message(token, channel_id, message)

    log.tc('2392')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[0].get('username'), users_data[0].get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(channel_name)
    chat.open_bubble_context_menu_by_text(messages_for_forward[-1])
    chat.click_select_in_context_menu()
    chat.assert_select_mode_toolbar_visible()
    for message in reversed(messages_for_forward[:-1]):
        chat.click_selectable_message_by_text_in_select_mode(message)
    chat.click_select_mode_forward_button()
    chat.forward_dialog.select_chat(favorites_chat_name)
    chat.assert_presence(chat.L_FORWARD_PREVIEW(), 'Превью пересылаемых сообщений отображается над полем ввода')
    chat.assert_forward_preview_title_contains_count(50)
    chat.assert_forward_preview_author_names([expected_author_name])
    chat.assert_send_button_active()


@allure.id("834")
@allure.title("Поиск сообщений в информационном канале")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Информационный канал")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_info_channel_search_messages(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]
    channel_name = get_random_string(10)
    search_text = get_random_string(8)
    token = iva_one_web_login(setup_aut, user_data)
    channel_id = iva_one.create_chat(token, channel_name, [user_data['username']], type=iva_one.ChatTypes.CHANNEL)
    iva_one.send_message(token, channel_id, search_text)
    for _ in range(19):
        iva_one.send_message(token, channel_id, get_random_string(8))

    log.tc('834')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data.get('username'), user_data.get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(channel_name)
    chat.click_search_btn()
    chat.assert_search_panel_visible()
    chat.search_message(search_text)
    chat.assert_message_found_in_search(search_text)


@allure.id("147")
@allure.title("Информации о сообщении всем участникам треда созданного в информационном канале")
@allure.label("owner", "Simon")
@allure.tag("RFA", "web")
@allure.story("Информационный канал")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_info_channel_thread_message_info_dialog(setup_aut, users_factory, teardown):
    """Информация о сообщении в треде информационного канала: открыть тред из сообщения
    канала. ПКМ по 1-му (корневому) сообщению треда — пункта «Информация» нет; ПКМ по 2-му
    сообщению (ответу) — пункт «Информация» есть, открыть его → окно со списком прочитавших."""
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]
    channel_name = get_random_string(10)
    parent_message_text = get_random_string(10)
    thread_reply_text = get_random_string(10)
    token = iva_one_web_login(setup_aut, user_data)
    channel_id = iva_one.create_chat(
        token,
        channel_name,
        [user_data['username']],
        type=iva_one.ChatTypes.CHANNEL,
        has_threads=True,
    )
    iva_one.send_message(token, channel_id, parent_message_text)

    log.tc('147')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(channel_name)
    chat.create_thread_reply(parent_message_text, thread_reply_text)
    # ПКМ по 1-му (корневому) сообщению треда — пункта "Информация" нет (сообщение канала).
    chat.open_thread_bubble_context_menu_by_text(parent_message_text)
    chat.assert_context_menu_info_button_absent()
    chat.close_message_context_menu()
    # ПКМ по 2-му сообщению треда (ответу) — пункт "Информация" есть → открыть окно информации.
    chat.open_thread_bubble_context_menu_by_text(thread_reply_text)
    chat.assert_context_menu_info_button_visible()
    chat.click_info_in_context_menu()
    author_full_name = f"{user_data['last_name']} {user_data['first_name']}"
    chat.assert_message_info_dialog_with_author(author_full_name)


@allure.id("760")
@allure.title("Просмотр чата пользователем не являющимся админом")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Информационный канал")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_info_channel_view_as_non_admin(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    users_data = users_factory
    channel_name = get_random_string(10)
    admin_token = iva_one_web_login(setup_aut, users_data[0])
    iva_one.create_chat(
        admin_token,
        channel_name,
        [users_data[0]['username'], users_data[1]['username']],
        type=iva_one.ChatTypes.CHANNEL,
    )

    log.tc('760')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(users_data[1]['username'], users_data[1]['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(channel_name)
    chat.assert_input(available=False)
    chat.assert_input_disabled_plug_visible()


@allure.id("36816")
@allure.title("Список закрепленных сообщений")
@allure.label("owner", "Simon")
@allure.tag("RFA", "web")
@allure.story("Групповой чат")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_group_chat_open_pinned_messages_list(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]
    chat_name = get_random_string(10)
    pinned_message_1 = get_random_string(10)
    pinned_message_2 = get_random_string(10)
    token = iva_one_web_login(setup_aut, user_data)
    chat_id = iva_one.create_chat(token, chat_name, [user_data['username']], type=iva_one.ChatTypes.GROUP)
    msg_1 = iva_one.send_message(token, chat_id, pinned_message_1)
    msg_2 = iva_one.send_message(token, chat_id, pinned_message_2)
    iva_one.pin_message(token, msg_1['id'])
    iva_one.pin_message(token, msg_2['id'])

    log.tc('36816')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(chat_name)
    chat.click_pinned_list_open_btn()
    pinned_room = chunks.get_chunk(version, 'chat_pinned_messages_room')(driver=driver, lang=lang)
    pinned_room.assert_message_visible(pinned_message_1)
    pinned_room.assert_message_visible(pinned_message_2)
    pinned_room.assert_input_absent()


@allure.id("2304")
@allure.title("Область чата. Пересланное свое сообщение. Свой профиль")
@allure.label("owner", "Simon")
@allure.tag("RFA", "web")
@allure.story("Групповой чат")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_group_chat_click_forwarded_author_opens_own_profile(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]
    chat_name = get_random_string(10)
    message = get_random_string(10)
    favorites_chat_name = i18n.get_str('favorites_chat_name', lang)
    token = iva_one_web_login(setup_aut, user_data)
    chat_id = iva_one.create_chat(token, chat_name, [user_data['username']], type=iva_one.ChatTypes.GROUP)
    iva_one.send_message(token, chat_id, message)
    # «Избранное» свежего юзера создаётся фоновым job'ом бэка (лаг до ~120s): поиск в диалоге
    # пересылки находит его раньше (search-индекс), но строки в списке чатов ещё нет.
    wait_favorites_chat_materialized(token, user_data['id'])

    log.tc('2304')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(chat_name)
    chat.forward_message(message, favorites_chat_name)
    chats_list.open_chat(favorites_chat_name)
    chat.assert_message_is_forwarded(message)
    chat.click_forwarded_message_author_name(message)
    user_profile = chunks.get_chunk(version, 'user_profile')(driver=driver, lang=lang)
    user_profile.assert_profile_sidebar_with_name_opened(user_data)


@allure.id("770")
@allure.title("Редактировать групповой чат, загрузить аватар чата")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Групповой чат")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_group_chat_edit_avatar_visible(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]
    chat_name = get_random_string(10)
    avatar_file_name = 'test_image_sample.jpeg'
    token = iva_one_web_login(setup_aut, user_data)
    chat_id = iva_one.create_chat(
        token,
        chat_name,
        [user_data['username']],
        type=iva_one.ChatTypes.GROUP,
    )
    wait_group_chat_materialized(token, chat_id, min_members=1)

    log.tc('770')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data.get('username'), user_data.get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(chat_name)
    chat.open_chat_profile()
    group_chat_profile = chunks.get_chunk(version, 'group_chat_profile')(driver, lang=lang)
    group_chat_profile.click_edit_chat()
    group_chat_profile.assert_edit_form_opened()
    group_chat_profile.upload_avatar(avatar_file_name)
    group_chat_profile.assert_avatar_uploaded()
    group_chat_profile.save_changes()
    group_chat_profile.assert_avatar_visible()


@allure.id("775")
@allure.title("Редактировать групповой чат, добавить описание")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Групповой чат")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_group_chat_edit_description_visible(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]
    chat_name = get_random_string(10)
    chat_description = get_random_string(10)
    token = iva_one_web_login(setup_aut, user_data)
    chat_id = iva_one.create_chat(
        token,
        chat_name,
        [user_data['username']],
        type=iva_one.ChatTypes.GROUP,
    )
    wait_group_chat_materialized(token, chat_id, min_members=1)

    log.tc('775')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data.get('username'), user_data.get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(chat_name)
    chat.open_chat_profile()
    group_chat_profile = chunks.get_chunk(version, 'group_chat_profile')(driver, lang=lang)
    group_chat_profile.click_edit_chat()
    group_chat_profile.assert_edit_form_opened()
    group_chat_profile.type_description(chat_description)
    group_chat_profile.assert_description_counter(chat_description)
    group_chat_profile.save_changes()
    group_chat_profile.assert_description_visible(chat_description)


@allure.id("1381")
@allure.title("Галерея. Загрузка файла из чата на устройство")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Галерея")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_chat_gallery_video_download(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]
    chat_name = get_random_string(10)
    video_filename = 'test_video_sample.mp4'
    video_path = os.path.join(TEST_DATA_DIR, video_filename)
    token = iva_one_web_login(setup_aut, user_data)
    chat_id = iva_one.create_chat(
        token,
        chat_name,
        [user_data['username']],
        type=iva_one.ChatTypes.GROUP,
    )
    iva_one.send_file_message(token, chat_id, video_path)

    log.tc('1381')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(chat_name)
    chat.open_chat_profile()
    group_chat_profile = chunks.get_chunk(version, 'group_chat_profile')(driver, lang=lang)
    group_chat_profile.click_gallery_category('chat_profile_gallery_category_video')
    attachments = chunks.get_chunk(version, 'chat_attachments')(driver, lang=lang)
    attachments.assert_video_visible(video_filename)
    attachments.right_click_video(video_filename)
    attachments.click_context_menu_download()
    attachments.assert_download_initiated()


@allure.id("1469")
@allure.title("Галерея. Просмотр изображения")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Галерея")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_chat_gallery_image_fullscreen(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]
    chat_name = get_random_string(10)
    image_filename = 'test_image_sample.jpeg'
    image_path = os.path.join(TEST_DATA_DIR, image_filename)
    token = iva_one_web_login(setup_aut, user_data)
    chat_id = iva_one.create_chat(
        token,
        chat_name,
        [user_data['username']],
        type=iva_one.ChatTypes.GROUP,
    )
    iva_one.send_file_message(token, chat_id, image_path)

    log.tc('1469')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(chat_name)
    chat.open_chat_profile()
    group_chat_profile = chunks.get_chunk(version, 'group_chat_profile')(driver, lang=lang)
    group_chat_profile.click_gallery_category('chat_profile_gallery_category_images')
    attachments = chunks.get_chunk(version, 'chat_attachments')(driver, lang=lang)
    attachments.assert_image_visible(image_filename)
    attachments.click_image(image_filename)
    media_viewer = chunks.get_chunk(version, 'media_viewer')(driver, lang=lang)
    media_viewer.assert_image_viewer_open()
    media_viewer.close_via_esc()
    media_viewer.assert_closed()


@allure.id("1468")
@allure.title("Галерея. Просмотр видео")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Галерея")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_chat_gallery_video_fullscreen(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]
    chat_name = get_random_string(10)
    video_filename = 'test_video_sample.mp4'
    video_path = os.path.join(TEST_DATA_DIR, video_filename)
    token = iva_one_web_login(setup_aut, user_data)
    chat_id = iva_one.create_chat(
        token,
        chat_name,
        [user_data['username']],
        type=iva_one.ChatTypes.GROUP,
    )
    iva_one.send_file_message(token, chat_id, video_path)

    log.tc('1468')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(chat_name)
    chat.open_chat_profile()
    group_chat_profile = chunks.get_chunk(version, 'group_chat_profile')(driver, lang=lang)
    group_chat_profile.click_gallery_category('chat_profile_gallery_category_video')
    attachments = chunks.get_chunk(version, 'chat_attachments')(driver, lang=lang)
    attachments.assert_video_visible(video_filename)
    attachments.click_video(video_filename)
    media_viewer = chunks.get_chunk(version, 'media_viewer')(driver, lang=lang)
    media_viewer.assert_video_viewer_open()
    media_viewer.close_via_esc()
    media_viewer.assert_closed()


@allure.id("52274")
@allure.title("Галерея. Переход к сообщению")
@allure.label("owner", "Vitaly")
@allure.tag("RFA")
@allure.story("Галерея")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_chat_gallery_video_go_to_message(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    user_data = users_factory[0]
    chat_name = get_random_string(10)
    video_filename = 'test_video_sample.mp4'
    video_path = os.path.join(TEST_DATA_DIR, video_filename)
    token = iva_one_web_login(setup_aut, user_data)
    chat_id = iva_one.create_chat(
        token,
        chat_name,
        [user_data['username']],
        type=iva_one.ChatTypes.GROUP,
    )
    iva_one.send_file_message(token, chat_id, video_path)

    log.tc('52274')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user_data['username'], user_data['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(chat_name)
    chat.open_chat_profile()
    group_chat_profile = chunks.get_chunk(version, 'group_chat_profile')(driver, lang=lang)
    group_chat_profile.click_gallery_category('chat_profile_gallery_category_video')
    attachments = chunks.get_chunk(version, 'chat_attachments')(driver, lang=lang)
    attachments.assert_video_visible(video_filename)
    attachments.right_click_video(video_filename)
    attachments.click_context_menu_go_to_message()
    chat.assert_video_message_exists(video_filename)
    attachments.assert_gallery_open()


@allure.id("164")
@allure.title("Галерея аудио, отображение загруженных аудио")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web", "Q3 Bug")
@allure.story("Галерея")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_p2p_chat_gallery_audio_upload_counter(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    user1, user2 = users_factory
    audio_filename = 'test_audio_sample.wav'
    token = iva_one_web_login(setup_aut, user1)
    iva_one.create_p2p_chat(token, user2['username'])

    log.tc('164')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user1['username'], user1['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chat_name = f"{user2['last_name']} {user2['first_name']}"
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(chat_name)
    chat.attach_file(audio_filename)
    chat.send('click')
    chat.assert_audio_message_exists(audio_filename)
    chat.open_chat_profile('p2p_chat_profile')
    p2p_profile = chunks.get_chunk(version, 'p2p_chat_profile')(driver, lang=lang)
    p2p_profile.assert_gallery_category_count('chat_profile_gallery_category_audio', 1)
    p2p_profile.click_gallery_category('chat_profile_gallery_category_audio')
    attachments = chunks.get_chunk(version, 'chat_attachments')(driver, lang=lang)
    attachments.assert_audio_visible(audio_filename)


@allure.id("37723")
@allure.title("Групповой чат отправить сообщение получение уведомлений участниками чата")
@allure.label("owner", "Simon")
@allure.tag("RFA")
@allure.story("Групповой чат")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_group_chat_send_message_notifies_participant(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    config = setup_aut['setup']['config']
    sender_user, receiver_user = users_factory
    group_chat_name = get_random_string(10)
    message = get_random_string(10)

    sender_token = iva_one_web_login(setup_aut, sender_user)
    chat_id = iva_one.create_chat(sender_token, group_chat_name, [sender_user['username'], receiver_user['username']])
    receiver_token = iva_one_web_login(setup_aut, receiver_user)


    log.tc('37723')

    # Получатель — Centrifugo-подписчик на свой персональный канал user#<id> (подписка ДО отправки),
    # чтобы поймать серверное уведомление о новом сообщении напрямую (browser-agnostic, ловится и для Safari).
    notifications = CentrifugoListener(config['web_url'], receiver_token, receiver_user['id']).start()
    teardown.append(notifications.stop)
    notifications.wait_subscribed()

    # Отправитель отправляет сообщение в групповой чат.
    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(sender_user['username'], sender_user['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(group_chat_name)
    chat.send_text_message(message, mode='click')
    chat.assert_sent_message_status_is_sent(message)

    # Участнику группового чата приходит уведомление о новом сообщении.
    notifications.assert_message_notification_received(chat_id, message, expected_title=group_chat_name)


@allure.id("1154")
@allure.title("Перейти в чат через уведомление")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.story("Групповой чат")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_go_to_group_chat_via_notification(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    config = setup_aut['setup']['config']
    sender_user, receiver_user = users_factory
    group_chat_name = get_random_string(10)
    message = get_random_string(10)

    sender_token = iva_one_web_login(setup_aut, sender_user)
    group_id = iva_one.create_chat(sender_token, group_chat_name, [sender_user['username'], receiver_user['username']])
    iva_one.create_p2p_chat(sender_token, receiver_user['username'])  # decoy: получатель будет НЕ в целевой группе
    receiver_token = iva_one_web_login(setup_aut, receiver_user)


    log.tc('1154')

    # Получатель — подписчик Centrifugo: ловим notification.new и берём из него ссылку перехода.
    notifications = CentrifugoListener(config['web_url'], receiver_token, receiver_user['id']).start()
    teardown.append(notifications.stop)
    notifications.wait_subscribed()

    # Получатель находится в decoy-чате (не в целевой группе), иначе сообщение прочитается и уведомления не будет.
    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(receiver_user['username'], receiver_user['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    decoy_chat_name = f"{sender_user['last_name']} {sender_user['first_name']}"
    chats_list.open_chat(decoy_chat_name)
    chat.assert_chat_with_chat_name_opened(decoy_chat_name)

    # Пользователь А отправляет сообщение в групповой чат.
    iva_one.send_message(sender_token, group_id, message)

    # Участник получает уведомление; «кликаем по уведомлению» — переходим по его ссылке.
    notif = notifications.assert_message_notification_received(group_id, message, expected_title=group_chat_name)
    chat.open_via_notification_link(notif['link'])

    # Пользователь перенаправлен в групповой чат, сообщение выделено.
    chat.assert_chat_with_chat_name_opened(group_chat_name)
    chat.assert_message_highlighted(message)


@allure.id("338")
@allure.title("Ошибка во время загрузки файла")
@allure.label("owner", "Vitaly")
@allure.tag("Desktop", "RFA", "web")
@allure.story("Инпут ввода")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_chat_upload_file_connection_error(setup_aut, users_factory, teardown):
    """Загрузка файла встаёт при обрыве сети и догружается при восстановлении.

    Механизм реального обрыва зависит от браузера (`tools/helpers/network.py`):
    Chromium — CDP offline, Firefox — Marionette `Services.io.offline` (настоящий
    обрыв сети). Для **Safari** реального механизма нет (нет CDP/BiDi, safaridriver
    игнорит proxy), поэтому применяется ЭКСПЕРИМЕНТАЛЬНАЯ ИМИТАЦИЯ/ОБХОД: само
    соединение НЕ обрывается — транспорт чанков глушится перехватом XHR/fetch на
    странице (этого достаточно, чтобы загрузка реально встала), а тост о потере связи
    поднимается эмуляцией `navigator.onLine` + события online/offline.
    """
    lang, version, driver = web_preamble(setup_aut, teardown)
    user1, user2 = users_factory

    # файл не менее 30 МБ (генерируем в runtime, в git не коммитим; имя уникально,
    # чтобы параллельные win+mac прогоны не делили один файл в tools/data)
    upload_file_name = f'tc338_upload_{get_random_string()}.dat'
    upload_file_path = os.path.join(TEST_DATA_DIR, upload_file_name)
    with open(upload_file_path, 'wb') as f:
        f.write(b'\0' * (35 * 1024 * 1024))
    teardown.append(lambda: os.path.exists(upload_file_path) and os.remove(upload_file_path))

    token = iva_one_web_login(setup_aut, user1)
    iva_one.create_p2p_chat(token, user2['username'])

    log.tc('338')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user1['username'], user1['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    toast = chunks.get_chunk(version, 'toast')(driver=driver, lang=lang)
    p2p_chat_name = f"{user2['last_name']} {user2['first_name']}"
    chats_list.open_chat(p2p_chat_name)

    # Чанковая загрузка стартует сразу при выборе файла (ДО «Отправить»).
    chat.start_file_upload(upload_file_name)

    # Разорвать соединение во время загрузки → тост об отсутствии интернета,
    # загрузка встаёт (прогресс замирает).
    network.set_offline(driver, True)
    toast.assert_i18n_visible('chat_upload_no_internet_toast',
                              'Отображается тост "Нет подключения к интернету"')
    chat.assert_upload_stalled()

    # Восстановить соединение → тост о восстановлении, загрузка догружается.
    network.set_offline(driver, False)
    toast.assert_i18n_visible('chat_upload_connection_restored_toast',
                              'Отображается тост "Подключение к сети установлено"')
    chat.assert_upload_resumed()


@allure.id("96")
@allure.title("Отправить первое сообщение пользователю")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web", "Q3 Bug")
@allure.label("IVAQA", "IVAONE-7484", "IVAONE-8423", "IVAONE-8543")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_chat_send_first_message_to_user(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    sender = users_factory[0]
    recipient = users_factory[1]
    # Полное имя ("Фамилия Имя"), а не фамилия: пул фамилий Faker мал, при параллельном
    # прогоне эфемерный юзер соседнего воркера может совпасть по фамилии — поиск/клик
    # по одной фамилии нашёл бы чужого пользователя.
    recipient_full_name = f'{recipient["last_name"]} {recipient["first_name"]}'
    message = get_random_string(10)

    log.tc('96')

    # Получатель должен войти в web (получить токен) — иначе chat-service его не
    # индексирует в поиске чатов. Затем дожидаемся индексации (асинхронная, ~20-60s),
    # чтобы UI-поиск был детерминированным, а не гонкой с фоновой индексацией.
    iva_one_web_login(setup_aut, recipient)
    sender_token = iva_one_web_login(setup_aut, sender)
    iva_one.wait_user_in_chat_search(sender_token, recipient_full_name)

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(sender.get('username'), sender.get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.search_chat(recipient_full_name)
    chats_list.open_found_user_dialog(recipient_full_name)
    chat.assert_chat_is_empty()
    chat.send_text_message(message)
    chat.assert_sent_message_exists(message)


@allure.id("2263")
@allure.title("Закрепить чат в списке сообщений")
@allure.label("owner", "Vitaly")
@allure.tag("RFA", "web")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_chat_pin_chat_in_list(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    user = users_factory[0]
    peer = users_factory[1]

    log.tc('2263')

    # Создаём p2p-чат через REST, чтобы в списке был именованный чат для закрепления.
    user_token = iva_one_web_login(setup_aut, user)
    iva_one.create_p2p_chat(user_token, peer.get('username'))

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user.get('username'), user.get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chats_list.open_chat_context_menu(peer['last_name'])
    chats_list.click_pin_in_chat_context_menu()
    chats_list.assert_chat_pinned(peer['last_name'])


@allure.id("93")
@allure.title("Получить новое сообщение от пользователя, чат с которым был удален")
@allure.label("owner", "Simon")
@allure.tag("RFA", "web")
@allure.label("IVAQA", "IVAONE-7160", "IVAONE-7405")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
@pytest.mark.skip(reason="Флаки: очистка истории при удалении p2p-чата асинхронна и не наблюдаема по REST (у получателя GET /messages всегда пуст, у создателя clear не отражается) — нет детерминированного гейта, чтобы дождаться очистки до нового сообщения собеседника. UI-инфра (удаление через ПКМ + реоткрытие) готова. См. TODO 027")
@pytest.mark.parametrize("users_factory", [2], indirect=True)
def test_chat_receive_message_after_deleting_chat(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    user = users_factory[0]
    peer = users_factory[1]
    old_message = get_random_string(10)
    new_message = get_random_string(10)

    log.tc('93')

    # Наполняем p2p-чат сообщением от собеседника (peer создаёт чат и шлёт через REST).
    peer_token = iva_one_web_login(setup_aut, peer)
    chat_id = iva_one.create_p2p_chat(peer_token, user.get('username'))
    iva_one.send_message(peer_token, chat_id, old_message)

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user.get('username'), user.get('password'))
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    # Видим наполненный чат, затем удаляем его за себя через контекстное меню.
    chats_list.open_chat(peer['last_name'])
    chat.assert_sent_message_exists(old_message)
    chats_list.open_chat_context_menu(peer['last_name'])
    chats_list.click_delete_in_chat_context_menu()
    chats_list.confirm_delete_chat()
    chats_list.assert_chat_not_in_list(peer['last_name'])

    # Собеседник присылает новое сообщение в тот же чат.
    iva_one.send_message(peer_token, chat_id, new_message)

    # После удаления user1 остался на мёртвом роуте удалённого чата (404). Чат всплывает
    # заново с тем же id → клик по нему = переход на тот же URL (no-op роутера). Возвращаемся
    # в список чатов, затем открываем заново — доступно только новое сообщение, старая стёрта.
    left_menu.open_chats()
    chats_list.open_chat(peer['last_name'])
    chat.assert_sent_message_exists(new_message)
    chat.assert_sent_message_absent(old_message)


@allure.id("53242")
@allure.title("Отображение аудиофайла с успешно сконвертированным аудио-файлом")
@allure.tag("Audio", "Chat", "Positive")
@allure.story("Галерея")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_chat_audio_message_play(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    user = users_factory[0]
    chat_name = get_random_string(10)
    audio_path = os.path.join(TEST_DATA_DIR, 'test_audio_sample.wav')
    audio_name = os.path.basename(audio_path)
    token = iva_one_web_login(setup_aut, user)
    chat_id = media_chat.seed_media_chat(token, chat_name, [user['username']], [audio_path], expect=('audio',))
    audio_id = next(f['id'] for f in media_chat.get_chat_media_files(token, chat_id) if f.get('audio'))

    log.tc('53242')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user['username'], user['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(chat_name)
    chat.assert_audio_message_exists(audio_name)
    chat.click_audio_play(audio_name)
    chat.assert_audio_playing(audio_name)
    chat.assert_audio_loaded_via_mp3(audio_id)


@allure.id("53241")
@allure.title("Проверка парсинга нового поля video.preview.url (или video)")
@allure.tag("API", "Gallery", "Positive", "Viewer")
@allure.story("Галерея")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_chat_video_preview_in_viewer(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    user = users_factory[0]
    chat_name = get_random_string(10)
    video_path = os.path.join(TEST_DATA_DIR, 'test_video_sample.mp4')
    video_name = os.path.basename(video_path)
    token = iva_one_web_login(setup_aut, user)
    chat_id = media_chat.seed_media_chat(token, chat_name, [user['username']], [video_path], expect=('preview', 'video'))
    video_id = next(f['id'] for f in media_chat.get_chat_media_files(token, chat_id) if f.get('video'))

    log.tc('53241')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user['username'], user['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(chat_name)
    # Лента: постер видео из превью-поля /preview, оригинал не качается.
    chat.assert_video_message_exists(video_name)
    chat.assert_media_resource_loaded(
        video_id, 'preview', f'Постер видео "{video_name}" в ленте загружен из превью /preview')
    chat.assert_no_original_download([video_id])
    # Просмотрщик: воспроизводится mp4 из нового поля превью (/uploads/{id}/preview/video — транскод),
    # а не оригинал. По обновлённому TC 53241 это и есть ожидаемое поведение.
    chat.click_video_message(video_name)
    media_viewer = chunks.get_chunk(version, 'media_viewer')(driver, lang=lang)
    media_viewer.assert_video_viewer_open()
    chat.assert_media_resource_loaded(
        video_id, 'preview/video',
        f'В просмотрщике воспроизводится mp4 из нового поля превью видео "{video_name}" '
        f'(/uploads/{video_id}/preview/video)')


@allure.id("53251")
@allure.title("Проверка отображения галереи. Нет запросов download")
@allure.tag("Chat", "Negative", "Preview")
@allure.story("Галерея")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_chat_gallery_no_download_previews(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    user = users_factory[0]
    chat_name = get_random_string(10)
    image_name = 'test_image_sample.jpeg'
    video_name = 'test_video_sample.mp4'
    audio_name = 'test_audio_sample.wav'
    file_paths = [os.path.join(TEST_DATA_DIR, name) for name in (image_name, video_name, audio_name)]
    token = iva_one_web_login(setup_aut, user)
    chat_id = media_chat.seed_media_chat(
        token, chat_name, [user['username']], file_paths, expect=('preview', 'video', 'audio'))
    media_ids = [f['id'] for f in media_chat.get_chat_media_files(token, chat_id)]

    log.tc('53251')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user['username'], user['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(chat_name)
    chat.open_chat_profile()
    group_chat_profile = chunks.get_chunk(version, 'group_chat_profile')(driver, lang=lang)
    group_chat_profile.click_gallery_category('chat_profile_gallery_category_images')
    attachments = chunks.get_chunk(version, 'chat_attachments')(driver, lang=lang)
    attachments.assert_gallery_open()
    # Вкладка «Изображения»: превью показано, оригинал не качается.
    attachments.assert_image_visible(image_name)
    chat.assert_no_original_download(media_ids)
    # Вкладка «Видео».
    attachments.switch_to_tab('media_header_video')
    attachments.assert_video_visible(video_name)
    chat.assert_no_original_download(media_ids)
    # Вкладка «Аудио».
    attachments.switch_to_tab('media_header_audio')
    attachments.assert_audio_visible(audio_name)
    chat.assert_no_original_download(media_ids)


@allure.id("53239")
@allure.title("Проверка отображения чат-рума при наличии сообщений с медиа")
@allure.tag("Chat", "Negative", "Preview")
@allure.story("Галерея")
@allure.feature("Чаты")
@pytest.mark.suite_smoke
@pytest.mark.suite_regress
def test_chat_feed_with_media_no_download(setup_aut, users_factory, teardown):
    lang, version, driver = web_preamble(setup_aut, teardown)
    user = users_factory[0]
    chat_name = get_random_string(10)
    image_name = 'test_image_sample.jpeg'
    video_name = 'test_video_sample.mp4'
    audio_name = 'test_audio_sample.wav'
    file_paths = [os.path.join(TEST_DATA_DIR, name) for name in (image_name, video_name, audio_name)]
    token = iva_one_web_login(setup_aut, user)
    # Набор файлов → 100 текстовых сообщений → снова набор файлов (первый набор уедет наверх).
    chat_id = media_chat.seed_media_chat(
        token, chat_name, [user['username']], file_paths,
        text_filler=100, repeat_files=True, expect=('preview', 'video', 'audio'))

    log.tc('53239')

    login_page = pages.get_page(version, 'login')(driver, lang=lang)
    login_page.login(user['username'], user['password'])
    left_menu = chunks.get_chunk(version, 'left_menu')(driver, lang=lang)
    left_menu.open_chats()
    chats_list = chunks.get_chunk(version, 'chats_list')(driver=driver, lang=lang)
    chat = pages.get_page(version, 'chat')(driver, lang=lang, open_page=False)
    chats_list.open_chat(chat_name)
    # Шаг 1: лента отрендерилась без white-screen, медиа нижнего набора показаны превью.
    chat.assert_feed_rendered()
    chat.assert_image_message_exists(image_name)
    chat.assert_video_message_exists(video_name)
    chat.assert_audio_message_exists(audio_name)
    # Шаг 2: для видимого набора превью грузятся без download оригинала (generic: ловит
    # контентный GET на /uploads/.+/download любого медиа; аватары отсечены по initiatorType).
    chat.assert_no_original_download()
    # Шаг 3: доскроллить к первому набору (вверх сквозь 100 текстовых; достижение "Сообщение 1"
    # доказывает, что прошли прослойку до начала ленты) — первый набор подгружается лениво
    # (его медиа отсутствуют в DOM до скролла), и его превью тоже грузятся без download.
    chat.scroll_feed_to_oldest_message('Сообщение 1')
    chat.assert_image_message_exists(image_name)
    chat.assert_no_original_download()
