import os
import sys

# pytest-xdist: воркеры стартуют через execnet БЕЗ оригинального sys.argv, а autocore
# резолвит --env/браузер/--browser-tag из sys.argv на момент импорта. Без этого на воркере
# get_env() == None → config[None]['selenoid'] → KeyError. Главный процесс кладёт значимые
# аргументы в окружение (воркеры наследуют его при спавне), воркер восстанавливает их в
# sys.argv ДО импорта autocore ниже. На непараллельном прогоне ветка else — фактически no-op.
_XDIST_ARGV_ENV = 'AUTOCORE_XDIST_ARGV'
if os.environ.get('PYTEST_XDIST_WORKER'):
    _restored = os.environ.get(_XDIST_ARGV_ENV, '')
    if _restored:
        sys.argv.extend(_restored.split('\x1f'))
else:
    _relevant = []
    _args = sys.argv[1:]
    for _i, _tok in enumerate(_args):
        if _tok in ('--env', '--browser-tag') and _i + 1 < len(_args):
            _relevant += [_tok, _args[_i + 1]]
        elif _tok == '--from-pipeline' or 'browser_' in _tok:
            _relevant.append(_tok)
    os.environ[_XDIST_ARGV_ENV] = '\x1f'.join(_relevant)

# pytest-xdist: логгер autocore открывает фиксированные tests/logs/main.log{,.step,.debug}
# в 'w'-режиме — параллельные воркеры-процессы truncate'ят файлы и пишут каждый со своего
# смещения, перезаписывая байты друг друга. Переопределяем пути на per-worker ДО первого
# get_log(): он ленивый синглтон и читает consts.LOG_* атрибут-лукапом в момент создания
# хендлеров (autocore/test/logger.py:32-41). Мастер и непараллельный прогон остаются на
# дефолтном main.log.
if os.environ.get('PYTEST_XDIST_WORKER'):
    from autocore import consts as _consts

    _worker = os.environ['PYTEST_XDIST_WORKER']  # gw0, gw1, ...
    _consts.LOG_INFO = f'{_consts.LOG_DIR}/main-{_worker}.log'
    _consts.LOG_STEP = f'{_consts.LOG_DIR}/main-{_worker}.log.step'
    _consts.LOG_DEBUG = f'{_consts.LOG_DIR}/main-{_worker}.log.debug'

import re
import uuid
import pytest
import traceback
import allure
from allure_commons.types import AttachmentType
from selenium.common.exceptions import InvalidSessionIdException

from autocore import consts
from autocore import driver_sessions
from autocore.test.config import get_config, get_browser
from autocore.test.generate_data import generate_email, generate_cyryllic_name
from autocore.test.logger import get_log
from autocore import aut
from autocore.clients.rest import iva_one

log = get_log()
browser_full_name = get_browser()
browser_os = browser_full_name.split('_')[0]
option = None

BROWSER_DATA_DIR = None


def pytest_configure(config):
    global option
    option = config.option
    global BROWSER_DATA_DIR
    BROWSER_DATA_DIR = f'{consts.ROOT_DIR}/tools/data' if option.local else f'/testdata'


@pytest.hookimpl(tryfirst=True)
def pytest_collection_modifyitems(items):
    common_browser_marks = (
        pytest.mark.browser_win_firefox,
        pytest.mark.browser_win_chrome,
        pytest.mark.browser_win_msedge,
        pytest.mark.browser_lin_chrome,
        pytest.mark.browser_win_ya
    )

    only_single_session_browser_marks = (
        pytest.mark.browser_mac_safari,
    )

    for item in items:
        if item.name == 'test_basic_video':
            continue

        for mark in common_browser_marks:
            item.add_marker(mark)

        if 'setup_aut' in getattr(item, 'fixturenames', ()) and 'setup_multiple_auts' not in getattr(item, 'fixturenames', ()):
            for mark in only_single_session_browser_marks:
                item.add_marker(mark)

        # Тесты на общем предсозданном mail/LDAP-юзере (require_ldap_user) нельзя
        # гонять одновременно — один аккаунт, сессии перетирают друг друга. В
        # параллельном прогоне (-n N --dist loadgroup) держим их в одной xdist-группе
        # → один воркер → сериализация между собой. См. skill run-tests.
        if item.get_closest_marker('require_ldap_user'):
            item.add_marker(pytest.mark.xdist_group('ldap_user'))


@pytest.fixture(autouse=True)
def run_around_tests(request):
    test_case = re.findall('Function (.*?)>', str(request.keywords))[0]
    log.step(f'~~~~~START {test_case}~~~~~')
    yield
    log.step(f'~~~~~END {test_case}~~~~~')


@pytest.fixture(scope='session')
def version_reporter():
    # TODO: report version
    log.info('Calling "version_reporter" fixture')


@pytest.fixture(scope='session')
def setup(version_reporter):
    log.info('Calling "setup" fixture')
    log.info(f'Using "{option.env}" environment, language "{option.lang}", {option.version}')
    with open(f"{consts.ROOT_DIR}/allure-raw/environment.properties", "w") as f:
        f.write(f"browser={browser_full_name}\n")
    return {
        'config': get_config()[option.env],
        'cmd': {
            'ver': option.ver,
            'lang': option.lang,
            'local': option.local,
            'env': option.env,
        },
    }


@pytest.fixture
def create_user(setup, teardown):
    iva_one_config = setup['config']
    iva_one_web_realm = iva_one_config['web-realm']
    iva_one_admin_creds = iva_one_config['credentials']['admin']
    admin_token = iva_one.login(**iva_one_admin_creds)
    password = 'DnUx0o'

    def _create_user(email, attributes=None):
        cyr_name = generate_cyryllic_name()
        log.step(f'Создать пользователя {email}', where='IVA ONE REST API')
        user_data = {
            'username': email,
            'email': email,
            'password': password,
            'first_name': cyr_name['first_name'],
            'last_name': cyr_name['last_name']
        }
        user_creation_resp = iva_one.create_user(
            admin_token,
            iva_one_web_realm,
            user_data['username'],
            user_data['email'],
            user_data['first_name'],
            user_data['last_name'],
            attributes=attributes,
        )
        user_data['id'] = user_creation_resp['id']
        if attributes:
            user_data['attributes'] = attributes
        iva_one.set_user_password(admin_token, iva_one_web_realm, user_data['username'], user_data['password'])
        teardown.append(lambda: iva_one.delete_user(realm=iva_one_web_realm, username=email))
        return user_data

    return _create_user


@pytest.fixture
def users_factory(create_user, request):
    """Создаёт эфемерных юзеров. Параметр (indirect):
    - int N — N юзеров без Keycloak-атрибутов (поведение по умолчанию);
    - список — по элементу на юзера: dict атрибутов Keycloak
      (напр. {'position': ['...'], 'department': ['...']}) либо None для юзера без атрибутов.
    """
    param = getattr(request, "param", 1)
    specs = [None] * param if isinstance(param, int) else param

    users = []
    for i, attributes in enumerate(specs):
        # uuid-вставка: generate_email(full_name=False) — голый faker.email() с конечным пулом,
        # при параллельном прогоне (xdist) воркеры могут сгенерить одинаковый username → 409 Keycloak.
        user = create_user(f'0{i+1}_web_{uuid.uuid4().hex[:8]}_{generate_email(full_name=False)}', attributes=attributes)
        users.append(user)

    yield users


@pytest.fixture
def setup_aut(setup, mult=False):
    local = setup['cmd']['local']
    download_files_prefs = {'disable-incognito': True}  # Отключает режим инкогнито для обеспечения возможности скачивания файлов в selenoid

    if local:
        download_files_prefs['set-default-download-directory'] = True  # Задаёт директорию по умолчанию для скачивания файлов при локальных запусках

    def start_aut(mult, local, init_args=None):
        driver = aut.start(mult, local, init_args)
        if browser_os not in ['android', 'ios']:
            driver.maximize_window()
        return driver

    driver = start_aut(mult, local)
    driver_starter = lambda: start_aut(mult, local)
    driver_starter_with_download_prefs = lambda: start_aut(mult, local, download_files_prefs)
    return {
        'driver': driver,
        'setup': setup,
        'driver_starter': driver_starter,
        'driver_starter_download_mode': driver_starter_with_download_prefs
    }


@pytest.fixture
def setup_multiple_auts(request, setup):
    def inner(aut_to_start: int = 2, init_list: list = None, _request = request):
        if init_list is None:
            init_list = [{} for _ in range(aut_to_start)]

        drivers = []
        local = setup['cmd']['local']
        for i in range(aut_to_start):
            driver = aut.start(mult=True, local=local, init_args=init_list[i], start_aut=i)
            if browser_os not in ['android', 'ios']:
                driver.maximize_window()
            driver.number = i + 1
            driver.from_tc = _request.function.__name__
            drivers.append(driver)
        return {'driver': drivers, 'setup': setup}
    yield inner


@pytest.fixture
def teardown():
    methods = []
    yield methods

    for method in methods:
        try:  # все методы нужно выполнить несмотря на возможные ошибки
            method() if type(method) is not tuple else method[0](method[1])
        except Exception as exc:
            log.warn(f'teardown method failed with exception: "{exc}"')
        finally:
            if driver_sessions.multiple:
                driver_sessions.active_driver.clear()
                driver_sessions.multiple = False


def pytest_fixture_post_finalizer(fixturedef, request):
    # Вложение «Видео» отключено: запись сессий в Selenoid сейчас выключена → ссылка
    # http://{selenoid_ip}:4444/video/{session_id}.mp4 ведёт в никуда (мёртвый attachment,
    # шум в отчёте/evidence). Вернуть, когда восстановят запись видео.
    pass
    # if fixturedef.argname == 'setup_aut':
    #     cr = fixturedef.cached_result
    #     if cr:
    #         driver_session_id = cr[0]['driver'].session_id
    #         selenoid_ip = cr[0]['setup']['config']['selenoid']
    #         link = f'http://{selenoid_ip}:4444/video/{driver_session_id}.mp4'
    #         meta = f'<meta http-equiv="Refresh" content = "0; url=\'{link}\'" />'
    #         html = f'<head>{meta}</head><body></body>'
    #         allure.attach(html, 'Видео', allure.attachment_type.HTML)


def attach_screenshot(driver, item, multiple):
    try:
        if multiple:
            allure.attach(driver.get_screenshot_as_png(), name=f'Browser-{driver.number}-{item.name}', attachment_type=AttachmentType.PNG)
        else:
            allure.attach(driver.get_screenshot_as_png(), name=item.name, attachment_type=AttachmentType.PNG)
    except InvalidSessionIdException:
        log.warning('Something went wrong with driver session during screenshot')
        hasattr(driver, 'number') and log.warning(f'Driver number {driver.number}')
        hasattr(driver, 'from_tc') and log.warning(f'Driver from testcase "{driver.from_tc}"')


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    rep = outcome.get_result()
    if rep.when == 'call' and (rep.failed or 'xfail' in item.keywords):
        if 'setup_aut' in item.funcargs:
            driver = item.funcargs['setup_aut']['driver']
            attach_screenshot(driver, item, multiple=False)
        elif 'setup_multiple_auts' in item.funcargs:
            drivers = driver_sessions.active_driver
            for driver in drivers:
                attach_screenshot(driver, item, multiple=True)
        else:
            pass
    # logging each traceback to respective testcase
    if call.excinfo:
        tb_obj = call.excinfo.tb
        stack_summary = traceback.extract_tb(tb_obj)
        tb_strings = stack_summary.format()
        tb_string = ''.join(tb_strings)
        tb_string = call.excinfo.exconly() + '\n' + tb_string

        stack_summary_locals = stack_summary.extract(traceback.walk_tb(tb_obj), capture_locals=True)
        tb_strings_locals = stack_summary_locals.format()
        tb_string_locals = ''.join(tb_strings_locals)
        tb_string_locals = call.excinfo.exconly() + '\n' + tb_string_locals

        log.info(tb_string)
        log.debug(tb_string_locals)


def pytest_addoption(parser):
    parser.addoption('--env', action='store', help='Environment name')
    parser.addoption('--ver', action='store', help='Version', default='Version2')
    parser.addoption('--lang', action='store', help='AUT UI language', default=consts.LANG_RU)
    parser.addoption('--from-pipeline', action='store_true', default=False)
    parser.addoption('--local', action='store_true', default=False)
    parser.addoption('--browser-tag', action='store', help='Tag of browser version (min or current)', default='current')
